//
//  AppDelegate.swift
//  RYTLE
//
//  Created by pavan on 18/04/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces
import UserNotifications
import Foundation
import SystemConfiguration
import Photos
import PhotosUI
import Firebase
import SocketIO
import Fabric
import Crashlytics

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    var riderChangestatus:String = ""
    var scanBikeChangeStatus:String = ""
    var changeRiderSelected = Bool()
    var viewRouteFrom = ""
    var addressStatus = ""
    var popUpstatus = ""
    var trackparcel = ""
    var trackParcelId = ""
    var parcelHistoryStatus = ""
    var parcelHistoryDetailsStatus = ""
    var parcelHistoryDetailsStatus1 = ""
    var parcelHistoryParcelId = ""
    var pickAddAddress = ""
    var recieverAddAddress = ""
    var ntfPopUp: UIView = UIView()
    var sidemenucount: CGFloat = 0
    var profilePicStatusSideMenu = ""
    var profilePicStatus = ""
    let IS_IPHONE5 = abs(UIScreen.main.bounds.size.height-568) < 1;
    let IS_IPHONE6 = abs(UIScreen.main.bounds.size.height-667.0) < 1;
    let IS_IPHONE6PLUS = abs(UIScreen.main.bounds.size.height-736.0) < 1;
    let IS_IPADPRO9 = abs(UIScreen.main.bounds.size.height-1024.0) < 1;
    let IS_IPADPRO10 = abs(UIScreen.main.bounds.size.height-1112.0) < 1;
    let IS_IPADPRO12 = abs(UIScreen.main.bounds.size.height-1366.0) < 1;
    let IS_IPHONEX = abs(UIScreen.main.bounds.size.height-812.0) < 1;
    var pickupArray : NSMutableArray = NSMutableArray()
    var receiverArray : NSMutableArray = NSMutableArray()
    var pickupaddress = [PickupAddressData()]
    
   func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        FirebaseApp.configure()
        Fabric.with([Crashlytics.self])
        Fabric.sharedSDK().debug = true
        GMSServices.provideAPIKey(GoogleMapsApiKey.key)
        GMSPlacesClient.provideAPIKey(GoogleMapsApiKey.key)
        UIApplication.shared.statusBarStyle = .lightContent
        UIApplication.shared.registerForRemoteNotifications()
        if #available(iOS 10.0, *) {
            let center = UNUserNotificationCenter.current()
            center.delegate = self //DID NOT WORK WHEN self WAS MyOtherDelegateClass()
            center.requestAuthorization(options: [.alert, .sound, .badge]) {
                (granted, error) in
                // Enable or disable features based on authorization.
                if granted {
                    // update application settings
                }else{
                    // print("rejected push notification")
                    DispatchQueue.main.async(execute: { () -> Void in
                        let actionSheetController: UIAlertController = UIAlertController(title: NSLocalizedString("Rytle", comment: ""), message: NSLocalizedString("error_pushservice", comment: ""), preferredStyle: .alert)
                        let cancelAction: UIAlertAction = UIAlertAction(title: NSLocalizedString("lbl_ok", comment: ""), style: .cancel) { action -> Void in
                            
                            //                            if let url = URL(string: "App-Prefs:root=NOTIFICATIONS_ID&path=com.amt.rytleriderapp") {
                            //                                UIApplication.shared.open(url, completionHandler: .none)
                            //                            }
                            //  (UIApplication.shared.canOpenURL(URL(string:"comgooglemaps://")!))
                            // added by shilpa
                            guard let settingsUrl = URL(string:UIApplication.openSettingsURLString) else {
                                return
                            }
                            if UIApplication.shared.canOpenURL(settingsUrl)  {
                                if #available(iOS 10.0, *) {
                                    UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                                    })
                                }
                                else  {
                                    UIApplication.shared.openURL(settingsUrl)
                                }
                            }
                            //if let url = URL(string: "App-Prefs:root=NOTIFICATIONS_ID&path=com.amt.rytleriderapp") {
                            //UIApplication.shared.open(url, completionHandler: .none)
                            // }
                        }
                        actionSheetController.addAction(cancelAction)
                        self.window?.rootViewController?.present(actionSheetController, animated: true, completion: nil)
                    })
                }
            }
        } else {
            let type: UIUserNotificationType = [UIUserNotificationType.badge, UIUserNotificationType.alert, UIUserNotificationType.sound]
            let setting = UIUserNotificationSettings(types: type, categories: nil)
            UIApplication.shared.registerUserNotificationSettings(setting)
            UIApplication.shared.registerForRemoteNotifications()
        }
        self.setUpPacketZoom()
        self.orgnaizationAPi()
        self.checkingUserLoggedOrNot()
        TestFairy.begin("295ab89da6888eb0ee3fdc2bb8254d23c7813901")
        return true
    }
    func orgnaizationAPi(){
        
        let orgId = UserDefaults.standard.object(forKey: "customerOrgid")
        if orgId == nil {
            DispatchQueue.global().async {
                var bodyReq = [String:String]()
                bodyReq = ["secret_key":APPURLS.orgScrectKey1]
                if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                    APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.customerAppOrgWiseRegURL, method: "POST", token: "", body: "", productBody: bodyData as NSData) {(data,error,response) in
                        
                        if let httpResponse = response as? HTTPURLResponse{
                            print("httpResponse status code \(httpResponse.statusCode)")
                            switch(httpResponse.statusCode){
                            case 200:
                                if let receivedData = data{
                                    do{
                                        let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                        if let Result = resultDic as? [String:Any]{
                                            if let result = Result["Msg"] as? NSArray{
                                                if let resdDic = result[0] as? [String: Any]{
                                                    print(resdDic)
                                                    if let ordId = resdDic["org_id"] as? Int{
                                                        Constants.setValueInUserDefaults(objValue: String(ordId), for: "customerOrgid")
                                                    }
                                                }
                                            }
                                        }
                                    }catch {
                                    }
                                }
                                break
                            default: break
                            }
                        }
                    }
                }
            }
        }
    }
    func setUpPacketZoom(){
        var pzsc: PZSpeedController = PZSpeedController(appID: "e4c9c48f2c111cc70e676733f9700730", apiKey: "a12d610c94a0ab0765861a76ad854fc842cc2287")
    }
    func checkingUserLoggedOrNot(){
        let username = UserDefaults.standard.object(forKey: "username")
        if username != nil {
            Constants.checkingCountryLagunage()
            self.deviceTokanApi()
            let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
            // rootViewController
            let rootViewController = mainStoryboard.instantiateViewController(withIdentifier: "SWRevealViewController") as? SWRevealViewController
            self.window?.rootViewController?.present(rootViewController!, animated: true, completion: nil)
            // self.window
            self.window = UIWindow(frame: UIScreen.main.bounds)
            self.window!.rootViewController = rootViewController
            self.window!.makeKeyAndVisible()
        }
        else{
            let appCoordinator = AppCoordinator(window: self.window!)
            appCoordinator.start()
            Constants.setValueInUserDefaults(objValue: "local", for: "org")
        }
    }
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        // Saves changes in the application's managed object context before the application terminates.
  
    }
    func isInternetAvailable() -> Bool{
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = flags.contains(.reachable)
        let needsConnection = flags.contains(.connectionRequired)
        return (isReachable && !needsConnection)
    }
}
extension AppDelegate: UNUserNotificationCenterDelegate {
    // called when user interacts with notification (app not running in foreground)
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse, withCompletionHandler
        completionHandler: @escaping () -> Void) {
        
        if UserDefaults.standard.value(forKey: "customer_id") as? String == nil{
            return
        }else{
            if let dict = response.notification.request.content.userInfo as? NSDictionary {
                self.userTappedDisplayPickupRequestPopup(dict: dict)
            }
        }
        // the docs say you should execute this asap
        return completionHandler()
    }
    
    func displayPickupRequestPopup(dict : NSDictionary){
        // print("notification dic ::: ",dict)
        if let array1 = dict["user"] as? [String:Any]{
            var parcelIdStr = ""
            if let title = array1["parcelId"] as? String{
                parcelIdStr = title
                //  print("parcel id ::: ", parcelIdStr)
                if trackparcel == "Yes"{
                    let notificationDic:[String: Any] = ["parcelId": parcelIdStr]
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "TrackParcelNotifiation"), object: nil, userInfo: notificationDic)
                }else if parcelHistoryStatus == "Yes"{
                    let notificationDic:[String: Any] = ["parcelId": parcelIdStr]
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ParcelHistoryNotifiation"), object: nil, userInfo: notificationDic)
                }else if self.parcelHistoryDetailsStatus == "Yes"{
                    let notificationDic:[String: Any] = ["parcelId": parcelIdStr,"userTap" :"No"]
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ParcelHistoryDetailsNotifiation"), object: nil, userInfo: notificationDic)
                }
            }
        }
    }
    func userTappedDisplayPickupRequestPopup(dict : NSDictionary){
        //  print("notification dic ::: ",dict)
        if let array1 = dict["user"] as? [String:Any]{
            var parcelIdStr = ""
            if let title = array1["parcelId"] as? String{
                parcelIdStr = title
                //  print("parcel id ::: ", parcelIdStr)
                if trackparcel == "Yes"{
                    let notificationDic:[String: Any] = ["parcelId": parcelIdStr]
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "TrackParcelNotifiation"), object: nil, userInfo: notificationDic)
                }else if self.parcelHistoryDetailsStatus == "Yes"{
                    let notificationDic:[String: Any] = ["parcelId": parcelIdStr,"userTap" :"Yes"]
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ParcelHistoryDetailsNotifiation"), object: nil, userInfo: notificationDic)
                }else{
                    if let controller = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ParcelDetailVC") as? ParcelDetailVC {
                        controller.parcelId = parcelIdStr
                        self.parcelHistoryDetailsStatus1 = "yes"
                        if let window = self.window, let rootViewController = window.rootViewController {
                            var currentController = rootViewController
                            while let presentedController = currentController.presentedViewController {
                                currentController = presentedController
                            }
                            currentController.present(controller, animated: true, completion: nil)
                        }
                    }
                }
            }
        }
    }
    // called if app is running in foreground
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent
        notification: UNNotification, withCompletionHandler completionHandler:
        @escaping (UNNotificationPresentationOptions) -> Void) {
        if UserDefaults.standard.value(forKey: "customer_id") as? String == nil{
            return
        }else{
            if let dict = notification.request.content.userInfo as? NSDictionary {
                self.displayPickupRequestPopup(dict: dict)
            }
        }
        // show alert while app is running in foreground
        return completionHandler(UNNotificationPresentationOptions.alert)
    }
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let token = String(format: "%@", deviceToken as CVarArg)
            .trimmingCharacters(in: CharacterSet(charactersIn: "<>"))
            .replacingOccurrences(of: " ", with: "")
        Constants.setValueInUserDefaults(objValue:token as String , for:"devicetoken")
        self.deviceTokanApi()
        // print("Token :::: ",token)
    }
    func deviceTokanApi(){
        var customerId  = ""
        var deviceToken = ""
        if UserDefaults.standard.value(forKey: "customer_id") as? String == nil{
            return
        }else{
            if UserDefaults.standard.value(forKey: "devicetoken") as? String == nil{
                return
            }else{
                deviceToken = UserDefaults.standard.value(forKey: "devicetoken") as! String
                customerId = UserDefaults.standard.value(forKey: "customer_id") as! String
                var bodyReq = [String:String]()
                bodyReq = ["device_token":deviceToken,"rider_id": "" ,"device_type":"iphone","customer_id":customerId,"user_type":"customer"]
                // print("bodyReq",bodyReq)
                if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                    let token = UserDefaults.standard.value(forKey: "usertoken") as! String
                    let sessionStr = "Bearer " + token
                    //print(sessionStr)
                    APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.deviceTypeURL , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                        if let httpResponse = response as? HTTPURLResponse{
                            // print("httpResponse status code \(httpResponse.statusCode)")
                            switch(httpResponse.statusCode){
                            case 200:
                                Constants.setValueInUserDefaults(objValue:deviceToken , for:"devicetoken")
                                break
                            default:break
                            }
                        }
                    }
                }
            }
        }
    }
}
