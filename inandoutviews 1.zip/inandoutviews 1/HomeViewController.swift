//
//  HomeViewController.swift
//  RYTLE
//
//  Created by Admin on 18/04/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import UserNotifications

class HomeVC: UIViewController,SWRevealViewControllerDelegate{
    
    @IBOutlet weak var logoImgCenterCC: NSLayoutConstraint!
    @IBOutlet weak var logoImgTopTC: NSLayoutConstraint!
    @IBOutlet weak var modeViewTopTC: NSLayoutConstraint!
    @IBOutlet weak var homeLabel: UILabel!
    @IBOutlet var menuButton: UIButton!
    @IBOutlet var paymentLbl: UILabel!
    @IBOutlet var logoImg: UIImageView!
    @IBOutlet var detailBtn: UIButton!
    @IBOutlet weak var logoHeightHC: NSLayoutConstraint!
    @IBOutlet weak var logoWidthWC: NSLayoutConstraint!
    @IBOutlet weak var logoTopTC: NSLayoutConstraint!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    
    //modeView
    @IBOutlet var modeView: UIView!
    @IBOutlet var modeLbl: UILabel!
    @IBOutlet var modeBtn: UIButton!
    @IBOutlet var modeImg: UIImageView!
    
    let insuredDropDown = DropDown()
    let modeOfDeleiveryDropDown = DropDown()
    
    let appdeletegate:AppDelegate=(UIApplication.shared.delegate as! AppDelegate)
    
    lazy var dropDowns: [DropDown] = {
        return [
            self.insuredDropDown,
            self.modeOfDeleiveryDropDown
        ]
    }()
    
    override func viewDidLoad(){
        super.viewDidLoad()
        initialSetUp()
        self.setupConstraints()
        self.setupSideMenu()
        self.setupModeOfDeliveryDropDown()
    }
    override func viewWillAppear(_ animated: Bool){
        if self.ineternetAlert() == false{
            return
        }
    }
    
    func initialSetUp(){
        self.navigationController?.isNavigationBarHidden = true
        self.homeLabel.text = NSLocalizedString("lbl_home",comment:"")
        self.homeLabel.font = AppFont.boldTextFont
        self.homeLabel.textColor = AppColors.whiteColorRGB
        self.navigationController?.isNavigationBarHidden = true
        self.modeLbl.text = NSLocalizedString("lbl_mode", comment: "")
        self.modeLbl.textColor = AppColors.fontTextDarkColorRGB
        self.modeLbl.font = AppFont.regularTextFont
        self.paymentLbl.text = NSLocalizedString("lbl_parcelsend", comment: "")
        self.paymentLbl.textColor = AppColors.fontTextDarkColorRGB
        self.paymentLbl.font = AppFont.regularTextFont
        self.detailBtn.titleLabel?.text = NSLocalizedString("btn_details", comment: "")
        self.detailBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.detailBtn.titleLabel?.font = AppFont.boldTextFont
    }
    func setupSideMenu()
    {
        if revealViewController() != nil {
            revealViewController().rearViewRevealWidth = self.view.frame.size.width/1.2
            menuButton.addTarget(revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
            SWRevealViewController().delegate = self
        }
    }
    func setupConstraints()
    {
        if appdeletegate.IS_IPADPRO9 || appdeletegate.IS_IPADPRO10 || appdeletegate.IS_IPADPRO12{
            self.view.removeConstraint(self.logoWidthWC)
            self.view.removeConstraint(self.logoHeightHC)
            self.view.removeConstraint(self.logoImgTopTC)
            self.view.removeConstraint(self.modeViewTopTC)
            self.view.removeConstraint(self.logoImgCenterCC)
            self.view.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.height, relatedBy: NSLayoutRelation.equal, toItem: self.view, attribute: NSLayoutAttribute.height, multiplier: 200/736, constant: 0))
            self.view.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.width, relatedBy: NSLayoutRelation.equal, toItem: self.view, attribute: NSLayoutAttribute.width, multiplier: 150/414, constant: 0))
            self.view.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.top, relatedBy: NSLayoutRelation.equal, toItem: self.paymentLbl, attribute: NSLayoutAttribute.bottom, multiplier: 1, constant: 60))
            self.view.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.centerY, relatedBy: NSLayoutRelation.equal, toItem: self.view, attribute: NSLayoutAttribute.centerY, multiplier: 1, constant: -100))
            self.view.addConstraint(NSLayoutConstraint(item: self.modeView, attribute: NSLayoutAttribute.top, relatedBy: NSLayoutRelation.equal, toItem: self.logoImg, attribute: NSLayoutAttribute.bottom, multiplier: 1, constant: 100))
        }
        
        if appdeletegate.IS_IPHONEX{
            self.view.removeConstraint(self.logoWidthWC)
            self.view.removeConstraint(self.logoHeightHC)
            self.view.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.width, relatedBy: NSLayoutRelation.equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 200))
            self.view.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.height, relatedBy: NSLayoutRelation.equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 200))
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    
    @objc func slider(onslider:Bool){
        
        // print("bool",onslider)
    }
   
    func setupModeOfDeliveryDropDown(){
        modeOfDeleiveryDropDown.anchorView = self.modeView
        modeOfDeleiveryDropDown.dismissMode = .onTap
        modeOfDeleiveryDropDown.direction = .bottom
        modeOfDeleiveryDropDown.bottomOffset = CGPoint(x: 0, y: modeView.bounds.height)
        modeOfDeleiveryDropDown.dataSource = [
            NSLocalizedString("lbl_mode", comment: ""),
            NSLocalizedString("lbl_normal", comment: "")
        ]
        modeOfDeleiveryDropDown.selectionAction = { [unowned self] (index, item) in
            self.modeLbl.text = item
        Constants.setValueInUserDefaults(objValue:self.modeLbl.text! , for:"modeofdelivery")
        }
    }
    
    @IBAction func btnsTapped(_ sender : UIButton){
        let btn = sender as UIButton
        if btn.tag == 10{
            insuredDropDown.show()
        }else if btn.tag == 20{
            modeOfDeleiveryDropDown.show()
        }else if btn.tag == 30{
            self.nextBtnMethod()
        }
    }
    
    func nextBtnMethod(){
        if modeLbl.text == NSLocalizedString("lbl_mode", comment: ""){
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid MOD",comment: ""), completion: {(result) in
                self.modeBtn.sendActions(for: UIControlEvents.touchUpInside)
            })
            return
        }else{
            let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ParcelSizesVC") as! ParcelSizesVC
            self.present(nextViewController, animated:true, completion: nil)
        }
    }
}

