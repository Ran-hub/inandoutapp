//
//  MenuTableViewCell.swift
//  RYTLE
//
//  Created by Admin on 10/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class SideMenuTC: UITableViewCell {

    @IBOutlet var menuLabel : UILabel!
    @IBOutlet var logOutImg : UIImageView!
    @IBOutlet var borderLbl : UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
