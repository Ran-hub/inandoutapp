//
//  HomeTableViewCell.swift
//  RYTLE
//
//  Created by Admin on 31/07/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class HomeTC: UITableViewCell {

    @IBOutlet var deliveryStatusLbl: UILabel!
    @IBOutlet var addressLbl: UILabel!
    @IBOutlet var phoneNumberBtn: UIButton!
    @IBOutlet var arrowBtn: UIButton!
    @IBOutlet var deliveryLbl: UILabel!
    @IBOutlet var distanceLbl: UILabel!
    @IBOutlet var borderLbl: UILabel!
    @IBOutlet var seprateLbl: UILabel!

    @IBOutlet var milesLbl: UILabel!

    @IBOutlet var nameLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
