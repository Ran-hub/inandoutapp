//
//  ViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 14/08/17.
//  Copyright © 2017 admin. All rights reserved.
//

import UIKit

class LoginVC: UIViewController,UITextFieldDelegate,UIScrollViewDelegate{
    
    @IBOutlet weak var containerViewBC: NSLayoutConstraint!
    
    @IBOutlet weak var logoHeightHC: NSLayoutConstraint!
    @IBOutlet weak var logoWidthWC: NSLayoutConstraint!
    @IBOutlet weak var logoTopTC: NSLayoutConstraint!
    
    @IBOutlet var contentView: UIView!
    @IBOutlet var bgImg: UIImageView!
    @IBOutlet var logoImg: UIImageView!
    @IBOutlet var containerView: UIView!
    @IBOutlet var usernameTxt: UITextField!
    @IBOutlet var passwordTxt: UITextField!
    @IBOutlet var loginBtn: UIButton!
    @IBOutlet var forgotBtn: UIButton!
    @IBOutlet var registerBtn: UIButton!
    
    var btnArray = [Any]()
    
    @IBOutlet var scrollViewObj: UIScrollView!
    
    // @IBOutlet weak var containerTop: NSLayoutConstraint!
    
    var activeField: UITextField?
    var firstname = ""
    var secondName = ""
    
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Testing ...
        self.navigationController?.isNavigationBarHidden = true
        
        self.usernameTxt.text = "adi@amt.in"
        self.passwordTxt.text = "12345678"
        
        
        Constants.checkingCountryLagunage()
        
        if appdelegate.IS_IPHONE5
        {
            self.contentView.removeConstraint(self.logoTopTC)
            self.contentView.removeConstraint(self.containerViewBC)
            
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.top, relatedBy: NSLayoutRelation.equal, toItem: self.bgImg, attribute: NSLayoutAttribute.top, multiplier: 1, constant: self.view.frame.size.height/8))
            
            self.contentView.addConstraint(NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.bottom, relatedBy: NSLayoutRelation.equal, toItem: self.containerView, attribute: NSLayoutAttribute.bottom, multiplier: 1, constant: 0))
            
        }
        else if appdelegate.IS_IPHONE6 || appdelegate.IS_IPHONE6PLUS
        {
            self.contentView.removeConstraint(self.logoTopTC)
            self.contentView.removeConstraint(self.containerViewBC)
            
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.top, relatedBy: NSLayoutRelation.equal, toItem: self.bgImg, attribute: NSLayoutAttribute.top, multiplier: 1, constant: self.view.frame.size.height/7))
            
            self.contentView.addConstraint(NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.bottom, relatedBy: NSLayoutRelation.equal, toItem: self.containerView, attribute: NSLayoutAttribute.bottom, multiplier: 1, constant: 30))
            
        }
        else if appdelegate.IS_IPHONEX
        {
            self.contentView.removeConstraint(self.logoWidthWC)
            self.contentView.removeConstraint(self.logoHeightHC)
            self.contentView.removeConstraint(self.logoTopTC)
            
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.top, relatedBy: NSLayoutRelation.equal, toItem: self.bgImg, attribute: NSLayoutAttribute.top, multiplier: 1, constant: self.view.frame.size.height/7))
            
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.width, relatedBy: NSLayoutRelation.equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 250))
            
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.height, relatedBy: NSLayoutRelation.equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 160))
            
            self.contentView.addConstraint(NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.bottom, relatedBy: NSLayoutRelation.equal, toItem: self.containerView, attribute: NSLayoutAttribute.bottom, multiplier: 1, constant: 30))
        }
        
        if appdelegate.IS_IPADPRO9 || appdelegate.IS_IPADPRO10 || appdelegate.IS_IPADPRO12
        {
            self.contentView.removeConstraint(self.logoWidthWC)
            self.contentView.removeConstraint(self.logoHeightHC)
            self.contentView.removeConstraint(self.logoTopTC)
            
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.width, relatedBy: NSLayoutRelation.equal, toItem: self.contentView, attribute: NSLayoutAttribute.width, multiplier: 200/414, constant: 0))
            
            
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.height, relatedBy: NSLayoutRelation.equal, toItem: self.contentView, attribute: NSLayoutAttribute.height, multiplier: 150/736, constant: 0))
            
            
            if appdelegate.IS_IPADPRO9
            {
                self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.top, relatedBy: NSLayoutRelation.equal, toItem: self.bgImg, attribute: NSLayoutAttribute.top, multiplier: 1, constant: self.view.frame.size.height/5))
            }
                
            else if appdelegate.IS_IPADPRO10 || appdelegate.IS_IPADPRO12
            {
                self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutAttribute.top, relatedBy: NSLayoutRelation.equal, toItem: self.bgImg, attribute: NSLayoutAttribute.top, multiplier: 1, constant: self.view.frame.size.height/4.5))
            }
        }
        
        
        self.scrollViewObj.showsHorizontalScrollIndicator = false
        self.scrollViewObj.showsVerticalScrollIndicator = false
        self.scrollViewObj.delegate = self
        
        self.usernameTxt.placeholder = NSLocalizedString("lbl_username", comment: "")
        self.usernameTxt.font =  AppFont.regularTextFont
        self.usernameTxt.textColor = AppColors.greenColorRGB
        
        self.passwordTxt.placeholder = NSLocalizedString("lbl_password", comment: "")
        self.passwordTxt.font = AppFont.regularTextFont
        self.passwordTxt.textColor = AppColors.greenColorRGB
        
        self.loginBtn.setTitle(NSLocalizedString("btn_login", comment: ""), for: UIControlState.normal)
        self.loginBtn.titleLabel?.font = AppFont.boldTextFont
        self.loginBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        
        self.forgotBtn.setTitle(NSLocalizedString("btn_forgot", comment: ""), for: UIControlState.normal)
        self.forgotBtn.titleLabel?.font = AppFont.regularTextFont
        self.forgotBtn.titleLabel?.textColor = AppColors.btn_grayColorRGB
        
        self.registerBtn.setTitle(NSLocalizedString("btn_createaccount", comment: ""), for: UIControlState.normal)
        self.registerBtn.titleLabel?.font = AppFont.regularTextFont
        self.registerBtn.titleLabel?.textColor = AppColors.btn_grayColorRGB
        
        registerBtn = addBorder(button: registerBtn)
        forgotBtn = addBorder(button: forgotBtn)
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        self.bgImg.isUserInteractionEnabled = true
        self.bgImg.addGestureRecognizer(tapGestureRecognizer)
        
    }
    
    
    func addBorder(button : UIButton) -> UIButton
    {
        let borderBottom = CALayer()
        let borderWidth = CGFloat(1)
        borderBottom.borderColor = UIColor.lightGray.cgColor //AppColors.textBoderColorRgb.cgColor
        borderBottom.frame = CGRect(x:0, y: button.frame.size.height - 15, width: button.frame.origin.x+button.frame.size.width , height:1)
        borderBottom.borderWidth = borderWidth
        button.layer.addSublayer(borderBottom)
        button.layer.masksToBounds = true
        return button
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.registerForKeyboardNotifications()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear (animated)
        self.deregisterFromKeyboardNotifications()
    }
    func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        self.scrollViewObj.isScrollEnabled = false
        self.usernameTxt.resignFirstResponder()
        self.passwordTxt.resignFirstResponder()
    }
    
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func keyboardWasShown(notification: NSNotification)
    {
        //Need to calculate keyboard exact size due to Apple suggestions
        self.scrollViewObj.isScrollEnabled = true
        
        var info = notification.userInfo!
        
        var keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        
        if keyboardSize?.height == 0
        {
            keyboardSize?.height = 260
        }
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height+50, 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollViewObj.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
        
    }
    
    public func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        // scrollView.contentSize =  CGSize(width: self.scrollViewObj.frame.width, height: self.contentView.frame.origin.y+self.contentView.frame.size.height);
        scrollView.isScrollEnabled = false
    }
    
    
    func keyboardWillBeHidden(notification: NSNotification)
    {
        //Once keyboard disappears, restore original positions
        // var info = notification.userInfo!
        // let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)
        self.scrollViewObj.contentInset = contentInsets
        // self.scrollViewObj.scrollIndicatorInsets = contentInsets
        // self.view.endEditing(true)
        // self.scrollViewObj.isScrollEnabled = false
        //    self.scrollViewObj.contentSize = CGSize(width: self.scrollViewObj.frame.width, height: self.contentView.frame.origin.y+self.contentView.frame.size.height);
        // self.scrollviewToplayout.constant = 0
        // self.contentViewTopContraint.constant = 0
        //self.bmgTopConstraint.constant = 0
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        if textField == self.usernameTxt
        {
            textField.returnKeyType = .next
        }
        else if textField == self.passwordTxt
        {
            textField.returnKeyType = .done
        }
        
        self.activeField = textField
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        self.activeField = nil
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        switch textField
        {
        case self.usernameTxt:
            self.passwordTxt.becomeFirstResponder()
            break
        case self.passwordTxt:
            textField.resignFirstResponder()
            break
        default:
            textField.resignFirstResponder()
        }
        return true
    }
    
    
    @IBAction func btnsTapped(_ sender : UIButton)
    {
        let btn = sender as UIButton
        
        if btn.tag == 10
        {
            self.loginApiMethod()
        }
        else if btn.tag == 20
        {   self.usernameTxt.text = ""
            self.passwordTxt.text = ""
            /* let nextViewController = self.storyboard?.instantiateViewController(withIdentifier: "VerifyOtpVC") as! VerifyOtpVC
             self.present(nextViewController, animated: true, completion:nil)*/
            
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ForgotPasswordVC") as! ForgotPasswordVC
            self.present(nextViewController, animated: true, completion: nil)
            
        }else if btn.tag == 30
        {
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SignupVC") as! SignupVC
            // nextViewController.delegate = self
            self.present(nextViewController, animated: true, completion: nil)
        }
    }
    
    func loginApiMethod() {
        
        //   assert(false)
        
        if self.ineternetAlert() == false
        {
            return
        }
        
        if usernameTxt.text?.count == 0{
            
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_username",comment: ""), completion: {(result) in
                
                self.usernameTxt.becomeFirstResponder()
            })
            return
        }
        else if Constants().isValidEmail(usernameTxt.text!) == false{
            
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_username",comment: ""), completion: {(result) in
                
                self.usernameTxt.becomeFirstResponder()
            })
            return
        }
        else if passwordTxt.text?.count == 0
        {
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_password",comment: ""), completion: {(result) in
                
                self.passwordTxt.becomeFirstResponder()
            })
            return
        }
        else
        {
            usernameTxt.resignFirstResponder()
            passwordTxt.resignFirstResponder()
            
            IJProgressView.shared.showProgressView(view)
            
            var bodyReq = [String:String]()
            
            bodyReq = ["username":usernameTxt.text!,"password":passwordTxt.text!]
            
            // print("bodyReq",bodyReq)
            
            if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
            {
                APICommnicationManager.sharedInstance.requestforAPI(service:"/CustomerAuth/customerLogin" , method: "POST", token: "", body: "", productBody: bodyData as NSData) { (result, error) in
                    
                    if let Result = result as? [String:Any]{
                        
                        print("Result",Result)
                        
                        if let status = Result["status"] as? Bool {
                            
                            if status == true{
                                DispatchQueue.main.async(execute: { () -> Void in
                                    if let authentication = Result["token"] as? String{
                                        IJProgressView.shared.hideProgressView();
                                        Constants.setValueInUserDefaults(objValue:authentication , for:"usertoken")
                                        let rider_details :NSDictionary  = (Result["customer_details"] as? NSDictionary)!
                                        
                                        let riderNum = rider_details.object(forKey: "customer_id") as! Int
                                        let riderStr = String(riderNum)
                                        Constants.setValueInUserDefaults(objValue:riderStr , for:"customer_id")
                                        Constants.setValueInUserDefaults(objValue:(rider_details.object(forKey: "username") as! NSString) as String , for:"username")
                                        if let firstName = rider_details.object(forKey:"firstname") as? String{
                                            self.firstname = firstName.capitalizedFirst()
                                            
                                        }
                                        var profileImgURl = ""
                                        
                                        if let imageURL = rider_details["image"] as? String
                                        {
                                            profileImgURl = imageURL
                                        }
                                        Constants.setValueInUserDefaults(objValue: profileImgURl , for:"profileImgLink")
                                        if let lastName = rider_details.object(forKey: "lastname") as? String{
                                            self.secondName = lastName.capitalizedFirst()
                                        }
                                        let finalName = self.firstname + " " + self.secondName
                                        Constants.setValueInUserDefaults(objValue:finalName , for:"finalname")
                                        self.usernameTxt.text = ""
                                        self.passwordTxt.text = ""
                                        // self.profileImageURL()
                                        self.deviceTokanApi()
                                        self.appdelegate.sidemenucount = 0
                                        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                                        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
                                        self.present(nextViewController, animated: true, completion: nil)
                                    }
                                })
                            }
                            if status == false
                            {
                                DispatchQueue.main.async(execute: { () -> Void in
                                    
                                    IJProgressView.shared.hideProgressView()
                                    if let incorrect = Result["error"] as? String{
                                        
                                        if incorrect == "Incorrect user or password"
                                        {
                                            self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("error_Incorrect user or password", comment: ""), completion: {(result) in
                                                self.passwordTxt.text = ""
                                                self.passwordTxt.becomeFirstResponder()
                                            })
                                        }
                                        else  if incorrect == "User does not exist"
                                        {
                                            self.displayAlert(message: NSLocalizedString("error_Userdoesnotexist", comment: ""))
                                        }
                                        else  if incorrect == "User already loggedin through other device"
                                        {
                                            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("error_useralreadylogged",comment: ""), completion: {(result) in
                                                self.usernameTxt.text = ""
                                                self.passwordTxt.text = ""
                                            })
                                        }
                                    }
                                })
                            }
                        }
                    }
                    else
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            IJProgressView.shared.hideProgressView()
                            self.displayAlert(message: NSLocalizedString("ver_somethingwrong", comment: ""))
                        })
                    }
                }
            }
        }
    }
    func displayAlert(message: String)
    {
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    func profileImageURL()
    {
        if UserDefaults.standard.value(forKey: "profileImgLink") as? String == nil || UserDefaults.standard.value(forKey: "profileImgLink") as? String == ""
        {
            
        }
        else
        {
            // DispatchQueue.global().async {
            let profileImageURL = Constants.getValueFromUserDefults(for: "profileImgLink") as! String
            let concateStr = APPURLS.profileImageUrl + profileImageURL
            if let url = NSURL(string: concateStr) {
                if NSData.init(contentsOf: url as URL) != nil{
                    let imageData = NSData(contentsOf: url as URL)
                    UserDefaults.standard.set("", forKey: "propic")
                    UserDefaults.standard.set(imageData, forKey: "propic")
                }
            }
            //}
        }
    }
    func deviceTokanApi(){
        if self.ineternetAlert() == false{
            return
        }
        DispatchQueue.global().async {
            if UserDefaults.standard.value(forKey: "devicetoken") as? String == nil{
                return
            }else{
                var customerId  = ""
                var deviceToken = ""
                deviceToken = UserDefaults.standard.value(forKey: "devicetoken") as! String
                customerId = UserDefaults.standard.value(forKey: "customer_id") as! String
                var bodyReq = [String:String]()
                bodyReq = ["device_token":deviceToken,"rider_id": "" ,"device_type":"iphone","customer_id":customerId,"user_type":"customer"]
                
                if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
                {
                    let token = UserDefaults.standard.value(forKey: "usertoken") as! String
                    
                    let sessionStr = "Bearer " + token
                    
                    //print(sessionStr)
                    
                    APICommnicationManager.sharedInstance.requestforAPI(service:"/RiderAuth/identifyDeviceType" , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (result, error) in
                        
                        if let Result = result as? [String:Any]{
                             print("/RiderAuth/identifyDeviceType",Result)
                            if let status = Result["status"] as? Bool {
                                
                                if status == true{
                                    DispatchQueue.main.async(execute: { () -> Void in
                                        IJProgressView.shared.hideProgressView()
                                        Constants.setValueInUserDefaults(objValue:deviceToken , for:"devicetoken")
                                    })
                                }
                                if status == false
                                {
                                    self.displayAlert(message: NSLocalizedString("ver_notupdated", comment: ""))
                                }
                            }
                        }
                        else
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.displayAlert(message: NSLocalizedString("ver_somethingwrong", comment: ""))
                            })
                        }
                    }
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

