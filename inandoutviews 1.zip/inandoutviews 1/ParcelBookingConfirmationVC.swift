//
//  ConfirmationViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 28/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import Firebase

struct ParcelBooking{
    var p_name : String
    var p_address : String
    var p_zipCode : String
    var p_mobileNumber : String
    var pickupAddressId : String
    var r_name : String
    var r_address : String
    var r_zipCode : String
    var r_mobileNumber : String
    var receiverAddressId : String
    var length : String
    var width : String
    var height : String
    var weight : String
    var deliveryMode : String
    var insurance : String
}
class ParcelBookingConfirmationVC: UIViewController {
    
    @IBOutlet weak var parcelBookingTableView: UITableView!
    @IBOutlet var headerView: UIView!
    @IBOutlet var titleLbl: UILabel!
    @IBOutlet var cancelBtn: UIButton!
    @IBOutlet var bookparcelBtn: UIButton!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    
    var pickupDetailsArray : [String] = []
    var receiverDetailsArray : [String] = []
    var parcelsizesArray : [String] = []
    var parcelsizesPHArray : [String] = []
    
    var pickup_extNum = String()
    var receiver_extNum = String()
    var pick_nameStr = String()
    var pick_addressStr = String()
    var pick_zipcodeStr = String()
    var pick_mobileStr = String()
    var pick_addressIdStr = String()
    var receiver_nameStr = String()
    var receiver_addressStr = String()
    var receiver_zipcodeStr = String()
    var receiver_mobileStr = String()
    var receiver_addressIdStr = String()
    var parcel_lengthStr = String()
    var parcel_widthStr = String()
    var parcel_heightStr = String()
    var parcel_weightStr = String()
    var parcel_insuredStr = String()
    
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad(){
        super.viewDidLoad()
        self.initialSteup()
        self.intialConstraintsSetup()
        self.setupTableView()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func setupTableView(){
        self.parcelBookingTableView.register(UINib(nibName: "BookParcelTC", bundle: nil), forCellReuseIdentifier: "BookParcelTC")
    }
    func alertConfirm(){
        let alert = UIAlertController(title: NSLocalizedString("lbl_confirmbooking", comment: ""), message:"", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title:NSLocalizedString("btn_cancel", comment:""), style: .default) { (alert: UIAlertAction!) -> Void in
        }
        cancelAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        let confirmAction = UIAlertAction(title:NSLocalizedString("btn_confirmbook", comment: ""), style: .default) { (alert: UIAlertAction!) -> Void in
            self.confirmParcelBookingApi()
        }
        confirmAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        alert.addAction(cancelAction)
        alert.addAction(confirmAction)
        present(alert, animated: true, completion:nil)
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func initialSteup(){
        self.navigationController?.navigationBar.isHidden = true
        self.parcelsizesPHArray.append(NSLocalizedString("lbl_finallength", comment: ""))
        self.parcelsizesPHArray.append(NSLocalizedString("lbl_finalwidth", comment: ""))
        self.parcelsizesPHArray.append(NSLocalizedString("lbl_finalheight", comment: ""))
        self.parcelsizesPHArray.append(NSLocalizedString("lbl_finalweight", comment: ""))
        self.parcelsizesPHArray.append(NSLocalizedString("lbl_finaldelmode", comment: ""))

        self.titleLbl.text = NSLocalizedString("lbl_confirmation", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        self.titleLbl.textColor = AppColors.whiteColorRGB
      
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.bookparcelBtn.setTitle(NSLocalizedString("btn_confirmation", comment: ""), for: .normal)
        self.bookparcelBtn.titleLabel?.font = AppFont.boldTextFont
        self.bookparcelBtn.backgroundColor = AppColors.greenColorRGB
        self.bookparcelBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.bookparcelBtn.titleLabel?.font = AppFont.boldTextFont
        self.setDynamicPickupAddress()
    }
    func setDynamicPickupAddress(){
        
        self.pick_nameStr = UserDefaults.standard.object(forKey: "pickup_username") as! String
        self.pick_addressStr = UserDefaults.standard.object(forKey: "pickup_address") as! String
        self.pick_zipcodeStr = UserDefaults.standard.object(forKey: "pickup_zipcode") as! String
        self.pick_mobileStr = UserDefaults.standard.object(forKey: "pickup_mobileno") as! String
        self.pick_addressIdStr = UserDefaults.standard.object(forKey: "pickup_pickaddressID") as! String
        self.pickup_extNum = UserDefaults.standard.object(forKey: "pickup_extensionCode") as! String
        self.pickupDetailsArray.append(self.pick_nameStr)
        if self.pickup_extNum != ""{
        self.pick_mobileStr += " " + NSLocalizedString("tex_ext", comment: "") + " " + pickup_extNum
        }
        self.pickupDetailsArray.append(self.pick_addressStr)
        if self.pick_zipcodeStr != ""{
            self.pickupDetailsArray.append(self.pick_zipcodeStr)
        }
        if self.pick_mobileStr != ""{
            self.pickupDetailsArray.append(self.pick_mobileStr)
        }
        self.receiver_nameStr = UserDefaults.standard.object(forKey: "receiver_username") as! String
        self.receiver_addressStr = UserDefaults.standard.object(forKey: "receiver_address") as! String
        self.receiver_zipcodeStr = UserDefaults.standard.object(forKey: "receiver_zipcode") as! String
        self.receiver_mobileStr = UserDefaults.standard.object(forKey: "receiver_mobileno") as! String
        self.receiver_addressIdStr = UserDefaults.standard.object(forKey: "receiver_receiveraddressID") as! String
        self.receiver_extNum = UserDefaults.standard.object(forKey: "receiver_extNum") as! String

        self.receiverDetailsArray.append(self.receiver_nameStr)
        self.receiverDetailsArray.append(self.receiver_addressStr)
        
        if self.receiver_extNum != ""{
          self.receiver_mobileStr += " " + NSLocalizedString("tex_ext", comment: "") + " " + receiver_extNum
        }
        if self.receiver_zipcodeStr != ""{
            self.receiverDetailsArray.append(self.receiver_zipcodeStr)
        }
        if self.receiver_mobileStr != ""{
        self.receiverDetailsArray.append(self.receiver_mobileStr)
        }
        self.parcel_lengthStr = UserDefaults.standard.object(forKey: "length") as! String
        if self.parcel_lengthStr == ""{
            self.parcel_lengthStr = "0 cm"
        }
        self.parcelsizesArray.append(self.parcel_lengthStr)
        
        self.parcel_widthStr  = UserDefaults.standard.object(forKey: "width") as! String
        if self.parcel_widthStr == ""{
            self.parcel_widthStr = "0 cm"
        }
        self.parcelsizesArray.append(self.parcel_widthStr )
        
        self.parcel_heightStr = UserDefaults.standard.object(forKey: "height") as! String
        if self.parcel_heightStr == ""{
            self.parcel_heightStr = "0 cm"
        }
        self.parcelsizesArray.append(self.parcel_heightStr)
        
        self.parcel_weightStr = UserDefaults.standard.object(forKey: "weight") as! String
        if self.parcel_weightStr == ""{
            self.parcel_weightStr = "0 Kg"
        }
        self.parcelsizesArray.append(self.parcel_weightStr)
        let modeofDelivery = Constants.getValueFromUserDefults(for: "modeofdelivery") as? String
        self.parcelsizesArray.append(modeofDelivery!)
        self.parcel_insuredStr = UserDefaults.standard.object(forKey: "insured") as! String
        
    }
    func heightForView(text:String, font:UIFont, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRect(x:0, y:0, width:width, height:2000))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
   
    @IBAction func btnsTapped(_ sender: UIButton){
        let btn = sender as UIButton
        if btn.tag == 10{
            Analytics.logEvent("ParcelBookingConfirmationVC_CancelButtonTapped", parameters: nil)
            self.dismiss(animated: true, completion: nil)
        }else if btn.tag == 20{
            riderAvailabality()
        }
    }
    func confirmParcelBookingApi(){
        Analytics.logEvent("ParcelBookingConfirmationVC_BookParcelButtonTapped", parameters: nil)
        if self.ineternetAlert() == false{
            return
        }else{
           //self.cancelBtn.isUserInteractionEnabled = false
            IJProgressView.shared.showProgressView(view)
            var bodyReq = [String:String]()
            var modeofdevelivery = Constants.getValueFromUserDefults(for: "modeofdelivery") as! String
            if modeofdevelivery == "Normal"{
                modeofdevelivery = "2"
            }else if modeofdevelivery == "Express"{
                modeofdevelivery = "1"
            }
            var dimensions = ""
            var customdimensions = ""
            var dimensionType = ""
            var parcelDimensions = ""
             if Constants.getValueFromUserDefults(for: "DimensionType") as! String != ""{
                dimensionType = Constants.getValueFromUserDefults(for: "DimensionType") as! String
                if Constants.getValueFromUserDefults(for: "parcelDimensions") as! String != ""{
                    parcelDimensions = Constants.getValueFromUserDefults(for: "parcelDimensions") as! String
                    if dimensionType == "Custom"{
                        customdimensions = parcelDimensions
                    }else{
                        dimensions = parcelDimensions
                    }
                }
            }
            var notesTextStr = ""
            if Constants.getValueFromUserDefults(for: "parcelNotes") as! String != ""{
                notesTextStr = Constants.getValueFromUserDefults(for: "parcelNotes") as! String
            }
            var parcelType = ""
            if Constants.getValueFromUserDefults(for: "parceltype") as! String != ""{
                parcelType = Constants.getValueFromUserDefults(for: "parceltype") as! String
            }
            var orgId = ""
            orgId = Constants.getValueFromUserDefults(for:"customerOrgid") as! String
            let customer_id = UserDefaults.standard.value(forKey: "customer_id") as! String
            bodyReq = ["delivery_option": modeofdevelivery,"title": "" , "delivery_time" : "","length" : self.parcel_lengthStr , "height": self.parcel_heightStr,"width": self.parcel_widthStr,"weight":self.parcel_weightStr,"insurance":self.parcel_insuredStr ,"qr_code":"","booked_by" : customer_id,"pickup_add_id":self.pick_addressIdStr,"delivery_add_id" : receiver_addressIdStr,"org_id":orgId,"parcel_type_id":parcelType,"dimensions":dimensions,"custom_dimension":customdimensions,"notes":notesTextStr]
          //  print("bodyReq",bodyReq)
            if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                
                let token = UserDefaults.standard.value(forKey: "usertoken") as! String
                let sessionStr = "Bearer " + token
               // print(sessionStr)
                APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.parcelBookURL , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                    
                    if let httpResponse = response as? HTTPURLResponse{
                        IJProgressView.shared.hideProgressView()
                        //print("httpResponse status code \(httpResponse.statusCode)")
                        switch(httpResponse.statusCode){
                        case 200:
                            if let receivedData = data{
                                do{
                                    let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                    DispatchQueue.main.async {
                                        IJProgressView.shared.hideProgressView()
                                        self.apiResponse(response: resultDic as! [String : Any])
                                    }
                                }catch {
                                    DispatchQueue.main.async {
                                        IJProgressView.shared.hideProgressView()
                                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                    }
                                }
                            }
                            break
                        case 500:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                            break
                        case 505:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "BookParcel_505", controller: self)
                            }
                            break
                        case 498:
                            DispatchQueue.main.async {
                                self.tokenExpireAlert()
                            }
                            break
                        default:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                        }
                    }else{
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                      }
                    }
                }
            }
        }
    }
    func apiResponse(response : [String : Any]){
        if  UserDefaults.standard.value(forKey: "attachImage") as? NSData != nil{
            if let parcelID = response["Parcel_Id"] as? String{
                Constants.setValueInUserDefaults(objValue: parcelID, for: "responsParcelId")
                self.uploadParcelAttachImage()
            }
        }
        self.cancelBtn.isUserInteractionEnabled = true
        UserDefaults.standard.removeObject(forKey: "pickup_username")
        UserDefaults.standard.removeObject(forKey: "pickup_address")
        UserDefaults.standard.removeObject(forKey: "pickup_zipcode")
        UserDefaults.standard.removeObject(forKey: "pickup_mobileno")
        UserDefaults.standard.removeObject(forKey: "pickup_pickaddressID")
        UserDefaults.standard.removeObject(forKey: "receiver_username")
        UserDefaults.standard.removeObject(forKey: "receiver_address")
        UserDefaults.standard.removeObject(forKey: "receiver_zipcode")
        UserDefaults.standard.removeObject(forKey: "receiver_mobileno")
        UserDefaults.standard.removeObject(forKey: "receiver_receiveraddressID")
        UserDefaults.standard.removeObject(forKey: "length")
        UserDefaults.standard.removeObject(forKey: "width")
        UserDefaults.standard.removeObject(forKey: "height")
        UserDefaults.standard.removeObject(forKey: "weight")
        UserDefaults.standard.removeObject(forKey: "insured")
        Constants.removeValueFromUserDefults(for: "parceltype")
        Constants.removeValueFromUserDefults(for: "DimensionType")
        Constants.removeValueFromUserDefults(for: "parcelDimensions")
       
        self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("val_parcelbookingconfirmation",comment: ""), completion: {(result) in
            
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
            self.present(nextViewController, animated: true, completion: nil)
        })
        
    }
    func uploadParcelAttachImage(){
        DispatchQueue.global().async {
            if let propicdata = UserDefaults.standard.object(forKey: "attachImage") as? Data{
                let parcelId = Constants.getValueFromUserDefults(for: "responsParcelId") as! String
                let imageStr = propicdata.base64EncodedString()
                var body = [String:String]()
                body = ["image":imageStr,"parcel_id": parcelId]
                var authToken = ""
                if Constants.getValueFromUserDefults(for:"usertoken") != nil{
                    authToken = Constants.getValueFromUserDefults(for:"usertoken") as! String
                }
                let authStr = "Bearer" + " " + authToken
                if let bodyData = try? JSONSerialization.data(withJSONObject: body, options:[]){
                    APICommnicationManager.sharedInstance.requestforImageUploading(service:APPURLS.uploadParcelAttachImageURL, method: "POST", token:authStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                       
                        if let httpResponse = response as? HTTPURLResponse{
                          //  print("APPURLS.uploadParcelAttachImageURL :::\(httpResponse.statusCode)")
                            switch(httpResponse.statusCode){
                            case 200:
                               // print("image uploaded successfully")
                                Constants.setValueInUserDefaults(objValue: "", for: "responsParcelId")
                                UserDefaults.standard.set("", forKey: "attachImage")
                                break
                            default: break
                            }
                        }
                    }
                }
            }
        }
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    func riderAvailabality(){
        if self.ineternetAlert() == false{
            return
        }else{
            IJProgressView.shared.showProgressView(view)
            var bodyReq = [String:String]()
            var orgId = ""
            orgId = Constants.getValueFromUserDefults(for:"customerOrgid") as! String
            bodyReq = ["pickup_add_id":self.pick_addressIdStr,"org_id":orgId]
           // print("bodyReq",bodyReq)
            if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                let token = UserDefaults.standard.value(forKey: "usertoken") as! String
                let sessionStr = "Bearer " + token
                APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.riderAvailabilityURL ,method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                   
                    if let httpResponse = response as? HTTPURLResponse{
                        //print("httpResponse status code \(httpResponse.statusCode)")
                        switch(httpResponse.statusCode){
                        case 200:
                           DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                                self.alertConfirm()
                                }
                            break
                        case 500:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                            break
                        case 505:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "NoRiderAvailable_505", controller: self)
                            }
                            break
                        case 506:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                                errorCodesMessageDisplayAlert(statusCode: "NoRiderAvailable_505", controller: self)
                            }
                            break
                        case 498:
                            DispatchQueue.main.async {
                                self.tokenExpireAlert()
                            }
                            break
                        default:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                        }
                    }else{
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                      }
                    }
                    
                              /*      if let Result = result as? [String:Any]{
                                    print("riderAvailability",Result)
                                        
                                    if let status = Result["status"] as? Bool {
                                        if status == true{
                                        DispatchQueue.main.async(execute: { () -> Void in
                                        IJProgressView.shared.hideProgressView()
                                        if Result["Msg"] as? String == "No rider Available"{
                                        self.displayAlert(message: NSLocalizedString("error_ridernotavailable", comment:""))
                                        }else {
                                            self.alertConfirm()
                                        }
                                    })
                                }
                                  if status == false{
                                  DispatchQueue.main.async(execute: { () -> Void in
                                    self.cancelBtn.isUserInteractionEnabled = true
                                    IJProgressView.shared.hideProgressView()
                                    self.displayAlert(message: NSLocalizedString("error_ridernotavailable", comment:""))
                                        })
                                    }
                                }else{
                                    DispatchQueue.main.async(execute: { () -> Void in
                                    IJProgressView.shared.hideProgressView()
                                    if Result["code"] as? String == "InvalidCredentials"{
                                     self.tokenExpireAlert()
                                    }else{
                                    self.displayAlert(message: NSLocalizedString("ver_somethingwrong", comment: ""))
                                    }
                                })
                              }
                            }else{
                                DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.cancelBtn.isUserInteractionEnabled = true
                                self.displayAlert(message: NSLocalizedString("ver_somethingwrong", comment:""))
                                })
                        }*/
                }
            }
        }
    }
}
extension ParcelBookingConfirmationVC : UITableViewDataSource,UITableViewDelegate{
  
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return self.pickupDetailsArray.count
        case 1:
            return self.receiverDetailsArray.count
        case 2:
            return self.parcelsizesArray.count
        default:
            return 0
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BookParcelTC") as! BookParcelTC
        cell.nameLabel.isHidden = true
        cell.dimensionLbl.isHidden = true
        cell.dimensionApiLbl.isHidden = true
        
        if indexPath.section == 0{
            cell.nameLabel.isHidden = false
            cell.nameLabel.text = self.pickupDetailsArray[indexPath.row]
            cell.nameLabel.numberOfLines = 0
            cell.nameLabel.lineBreakMode = .byWordWrapping
            cell.nameLabel.font = AppFont.regularTextFont
            if indexPath.row == 0{
                cell.nameLabel.font = AppFont.boldMediumTextFont
            }
        }else if indexPath.section == 1{
            cell.nameLabel.isHidden = false
            cell.nameLabel.numberOfLines = 0
            cell.nameLabel.lineBreakMode = .byWordWrapping
            cell.nameLabel.text = self.receiverDetailsArray[indexPath.row]
            cell.nameLabel.font = AppFont.regularTextFont
            if indexPath.row == 0{
                cell.nameLabel.font = AppFont.boldMediumTextFont
            }
        }else if indexPath.section == 2{
            cell.nameLabel.isHidden = true
            cell.dimensionLbl.isHidden = false
            cell.dimensionApiLbl.isHidden = false
            cell.dimensionLbl.numberOfLines = 1
            cell.dimensionApiLbl.numberOfLines = 1
            cell.dimensionLbl.text = self.parcelsizesPHArray[indexPath.row]
            cell.dimensionApiLbl.text = self.parcelsizesArray[indexPath.row]
            cell.dimensionApiLbl.font = AppFont.regularTextFont
            cell.dimensionLbl.font = AppFont.regularTextFont
        }else{
            
        }
        return cell
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        let title = UILabel()
        if section == 0{
            headerView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 50)
            title.frame = CGRect(x: 10, y: 0, width: self.view.frame.size.width-30, height: 50)
            title.text = NSLocalizedString("lbl_pickupdetails", comment: "")
        }else if  section == 1{
            headerView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 40)
            title.frame = CGRect(x: 10, y: 0, width: self.view.frame.size.width-30, height: 40)
            title.text =  NSLocalizedString("lbl_receiverpdetails", comment: "")
        }else if section == 2{
            headerView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 40)
            title.frame = CGRect(x: 10, y: 0, width: self.view.frame.size.width-30, height: 40)
            title.text =  NSLocalizedString("lbl_parceldetails", comment: "")
        }
        title.font = AppFont.boldTextFont
        headerView.addSubview(title)
        headerView.backgroundColor = UIColor.whiteColorCode
        return headerView
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        if section == 0{
            return 50
        }else if section == 1{
            return 40
        }else if section == 2{
            return 40
        }else{
            return 0
        }
    }
   
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 || indexPath.section == 1{
            
            return UITableView.automaticDimension
        }else if indexPath.section == 2{
            return 30
        }
        return 0
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
}
