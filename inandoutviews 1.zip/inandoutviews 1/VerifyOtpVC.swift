
import UIKit
import Firebase

class VerifyOtpVC: UIViewController ,UITextFieldDelegate, UIScrollViewDelegate{
    
    @IBOutlet weak var verifyButton: UIButton!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var resendOtpBtn: UIButton!
    @IBOutlet weak var otpField: UITextField!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var textLbl: UILabel!
    @IBOutlet weak var scrollViewObj: UIScrollView!
    @IBOutlet weak var bgImg: UIImageView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var logoImg: UIImageView!
    @IBOutlet weak var logoHeightHC: NSLayoutConstraint!
    @IBOutlet weak var logoWidthWC: NSLayoutConstraint!
    @IBOutlet weak var logoTopTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblCC: NSLayoutConstraint!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    var activeField: UITextField?
    var timer: Timer!
    var counter = 0
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var controlername : String = String()
    
    override func viewDidLoad(){
        super.viewDidLoad()
        self.scrollViewObj.delegate = self
        self.initialSetUp()
        self.intialConstraintsSetup()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    
    func addBorder(button : UIButton) -> UIButton
    {
        let borderBottom = CALayer()
        let borderWidth = CGFloat(1)
        borderBottom.borderColor = UIColor.lightGray.cgColor
        //AppColors.textBoderColorRgb.cgColor
        borderBottom.frame = CGRect(x:0, y: button.frame.size.height - 10, width:button.frame.origin.x+button.frame.size.width , height:1)
        borderBottom.borderWidth = borderWidth
        button.layer.addSublayer(borderBottom)
        button.layer.masksToBounds = true
        
        return button
    }
    func initialSetUp(){
        if appdelegate.IS_IPADPRO9 || appdelegate.IS_IPADPRO10 || appdelegate.IS_IPADPRO12{
            self.contentView.removeConstraint(self.logoWidthWC)
            self.contentView.removeConstraint(self.logoHeightHC)
            self.contentView.removeConstraint(self.logoTopTC)
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.contentView, attribute: NSLayoutConstraint.Attribute.height, multiplier: 150/736, constant: 0))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.contentView, attribute: NSLayoutConstraint.Attribute.width, multiplier: 200/414, constant: 0))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.bgImg, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: self.view.frame.size.height/7))
        }else if appdelegate.IS_IPHONEX{
            self.contentView.removeConstraint(self.logoWidthWC)
            self.contentView.removeConstraint(self.logoHeightHC)
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem:nil, attribute: .notAnAttribute, multiplier: 1, constant: 250))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 160))
        }else if appdelegate.IS_IPHONE5{
            self.contentView.removeConstraint(self.logoTopTC)
            self.contentView.addConstraint(NSLayoutConstraint(item: self.otpField, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.logoImg, attribute: .bottom, multiplier: 1, constant: self.view.frame.size.height/9))
        }
        otpField.delegate = self
        otpField.placeholder = NSLocalizedString("lbl_passordotp",comment:"")
        otpField.font = AppFont.regularTextFont
        titleLbl.text = NSLocalizedString("lbl_verifyotp",comment:"")
        titleLbl.font = AppFont.boldTextFont
        titleLbl.textColor = AppColors.whiteColorRGB
        resendOtpBtn.setTitle(NSLocalizedString("btn_resendOTP",comment:""),for:.normal)
        resendOtpBtn.titleLabel?.font = AppFont.regularTextFont
        resendOtpBtn.titleLabel?.textColor = AppColors.btn_grayColorRGB
        cancelButton.setTitle(NSLocalizedString("btn_cancel",comment:""),for:.normal)
        cancelButton.titleLabel?.font = AppFont.regularTextFont
        cancelButton.titleLabel?.textColor = AppColors.greenColorRGB
        verifyButton.setTitle(NSLocalizedString("btn_submitotp",comment:""),for:.normal)
        verifyButton.titleLabel?.textColor = AppColors.whiteColorRGB
        verifyButton.titleLabel?.font = AppFont.boldTextFont
        verifyButton.backgroundColor = AppColors.greenColorRGB
        resendOtpBtn = addBorder(button:resendOtpBtn)
        self.registerForKeyboardNotifications()
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        self.bgImg.isUserInteractionEnabled = true
        self.bgImg.addGestureRecognizer(tapGestureRecognizer)
        self.languageValidationForGermany()
    }
    func languageValidationForGermany(){
        let languageCode = Constants.getValueFromUserDefults(for: "languageCode") as! String
        if languageCode == "Yes"{
            self.languageValidationForGermany(headerView: self.headerView, cancelBtn: self.cancelButton, labelConstraints: self.titleLblCC, titleLbl: self.titleLbl)
        }
    }
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        self.scrollViewObj.isScrollEnabled = false
        self.otpField.resignFirstResponder()
    }
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name:UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name:UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        self.scrollViewObj.isScrollEnabled = true
        var info = notification.userInfo!
        var keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
   
        if keyboardSize?.height == 0
        {
            keyboardSize?.height = 260
        }
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: keyboardSize!.height+50, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollViewObj.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
    }
    
    @objc func keyboardWillBeHidden(notification: NSNotification)
    {
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        if textField == self.otpField
        {
            textField.returnKeyType = .next
            self.otpField.keyboardType = .numberPad
            let keyPadToolBar = UIToolbar()
            keyPadToolBar.barStyle = UIBarStyle.blackTranslucent
            keyPadToolBar.barTintColor = AppColors.greenColorRGB
            keyPadToolBar.sizeToFit()
            let DoneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(VerifyOtpVC.dismissKeypad))
            DoneButton.tintColor = AppColors.whiteColorRGB
            keyPadToolBar.setItems([DoneButton], animated: true)
            otpField.inputAccessoryView = keyPadToolBar
        }
        self.activeField = textField
    }
    
    func textFieldDidEndEditing(_ textField: UITextField){
        self.activeField = nil
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        return true
    }
    
    @objc func dismissKeypad(){
        self.otpField.resignFirstResponder()
    }
    @IBAction func verifyAction(_ sender: Any){
        Analytics.logEvent("VerifyOtpVC_VerifyOTPButtonTapped", parameters: nil)
        if self.ineternetAlert() == false{
            return
        }
        if self.otpField.text?.count == 0{
            self.displayAlert(message: NSLocalizedString("ver_OTP", comment: ""))
        }else {
            otpField.resignFirstResponder()
                    if UserDefaults.standard.value(forKey: "customerOrgid") as? String == nil{
                        self.orgnaizationAPi(completion:{(result) in
                            DispatchQueue.main.async {
                                self.verifyOpt(orgId: result)
                            }
                        })
                    }else{
                        var orgId = ""
                        orgId = Constants.getValueFromUserDefults(for:"customerOrgid") as! String
                        self.verifyOpt(orgId: orgId)
                    }
        }
    }
    func verifyOpt(orgId:String){
    IJProgressView.shared.showProgressView(view)
    var bodyReq = [String:String]()
    let forgotEmail = Constants.getValueFromUserDefults(for: "forgotEmail") as! String
    bodyReq = ["email":forgotEmail,"OTP":otpField.text!,"org_id":orgId]
     //print("bodyReq",bodyReq)
    if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
    {
        APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.verifyOTPURL , method: "POST", token: "", body: "", productBody: bodyData as NSData) { (data,error,response) in
           
            if let httpResponse = response as? HTTPURLResponse{
                IJProgressView.shared.hideProgressView()
               // print("httpResponse status code \(httpResponse.statusCode)")
                switch(httpResponse.statusCode){
                case 200:
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                        let nextViewController = self.storyboard?.instantiateViewController(withIdentifier: "ResetPasswordVC") as! ResetPasswordVC
                        self.present(nextViewController, animated: true, completion:nil)
                    }
                    break
                case 500:
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                    }
                    break
                case 505:
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "VOT_505", controller: self)
                    }
                    break
                case 506:
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "VOT_506", controller: self)
                    }
                    break
                case 498:
                    DispatchQueue.main.async {
                        self.tokenExpireAlert()
                    }
                    break
                default:
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                    }
                }
            }else{
                DispatchQueue.main.async {
                    IJProgressView.shared.hideProgressView()
                errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
              }
            }
        }
     }
   }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    func timerMethod(){
        resendOtpBtn.isUserInteractionEnabled = false
        resendOtpBtn.setTitleColor(AppColors.darkGrayColorRGB, for: .normal)
        timer = Timer.scheduledTimer(timeInterval: 30, target:self, selector: #selector((VerifyOtpVC.updateCounter)), userInfo: nil, repeats: false)
    }
    @objc func updateCounter(){
        resendOtpBtn.isUserInteractionEnabled = true
        resendOtpBtn.setTitleColor(AppColors.whiteColorRGB, for: .normal)
    }
    @IBAction func resendOTPBtn(_ sender: Any){
        Analytics.logEvent("VerifyOtpVC_ResendOTPButtonTapped", parameters: nil)
        if self.ineternetAlert() == false{
            return
        }
        self.timerMethod()
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        let forgotEmail = UserDefaults.standard.value(forKey: "forgotEmail") as! String
        let forgotMobile = UserDefaults.standard.value(forKey: "forgotMobile") as! String
        var orgId = ""
        orgId = Constants.getValueFromUserDefults(for:"customerOrgid") as! String
        bodyReq = ["mobile": forgotMobile,"email":forgotEmail,"org_id":orgId]
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.forgotPasswordURL, method: "POST", token: "", body: "", productBody: bodyData as NSData) { (data,error,response) in
               
                if let httpResponse = response as? HTTPURLResponse{
                    IJProgressView.shared.hideProgressView()
                  //  print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            let alertController = UIAlertController(title:nil, message:NSLocalizedString("success_mailsuccessfullysent", comment:""), preferredStyle: UIAlertController.Style.alert)
                            alertController.addAction(UIAlertAction(title: NSLocalizedString("lbl_ok", comment: ""), style: UIAlertAction.Style.default,handler: { action in
                            }
                            ))
                            self.present(alertController, animated: false, completion: nil)
                        }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            self.updateCounter()
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            self.updateCounter()
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "FP_505", controller: self)
                        }
                        break
                    case 507:
                        DispatchQueue.main.async {
                            self.updateCounter()
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "FP_507", controller: self)
                        }
                        break
                    default:
                        DispatchQueue.main.async {
                            self.updateCounter()
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        self.updateCounter()
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                   }
                }
            }
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear (animated)
        self.deregisterFromKeyboardNotifications()
    }
    @IBAction func cancelAction(_ sender: Any){
        Analytics.logEvent("VerifyOtpVC_CancelButtonTapped", parameters: nil)
        self.dismiss(animated:true,completion:nil)
    }
    
    public func scrollViewDidScroll(_ scrollView: UIScrollView){
        scrollView.isScrollEnabled = false
    }
    
}

