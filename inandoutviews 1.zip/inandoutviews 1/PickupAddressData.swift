//
//  AddressData.swift
//  RYTLECUSTOMERAPP
//
//  Created by Shilpashree on 06/09/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class PickupAddressData: NSObject {
    var houseno =  String()
    var street1 = String()
    var street2 = String()
    var street3 = String()
    var city = String()
    var state = String()
    var country = String()
    var name = String()
    var zipcode = String()
    var mobile = String()
    var flatNumber = String()
    var email = String()
    var address_id = String()
    var fulladdress = String()
    var latitude = String()
    var longitude = String()
    var addressType = String()
    var extensionCode = String()
}
