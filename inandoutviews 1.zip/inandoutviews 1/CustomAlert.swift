//
//  CustomAlert.swift
//  RYTLECUSTOMERAPP
//
//  Created by AMT on 7/3/18.
//  Copyright © 2018 Pavan. All rights reserved.
//

import Foundation
import UIKit

func errorCodesMessageDisplayAlert(statusCode:String, controller:UIViewController){
    
    var messageStr = ""
    if statusCode == "Server_500"{
        messageStr = NSLocalizedString("ver_somethingwrong", comment: "")
    }else if statusCode == "Login_505"{
        messageStr = NSLocalizedString("error_Userdoesnotexist", comment: "")
    }else if statusCode == "Login_506"{
        messageStr = NSLocalizedString("error_Incorrectuserorpassword", comment: "")
    }else if statusCode == "Register_200"{
        messageStr = NSLocalizedString("ver_userregistersuccess", comment: "")
    }else if statusCode == "Register_505"{
        messageStr = NSLocalizedString("dup_emailregistration", comment: "")
    }else if statusCode == "Register_506"{
        messageStr = NSLocalizedString("dup_username", comment: "")
    }else if statusCode == "Register_507"{
        messageStr = NSLocalizedString("dup_mobilenumber", comment: "")
    }else if statusCode == "Register_508"{
        messageStr = NSLocalizedString("err_registrationfailed", comment: "")
    }else if statusCode == "FP_505"{
        messageStr = NSLocalizedString("error_thisisnotregisteredemailid", comment: "")
    }else if statusCode == "FP_507"{
        messageStr = NSLocalizedString("err_failedtosendthemail", comment: "")
    }else if statusCode == "VOT_505"{
        messageStr = NSLocalizedString("error_IncorrectOTP", comment: "")
    }else if statusCode == "VOT_506"{
        messageStr = NSLocalizedString("error_failedtoverifytheotp", comment: "")
    }else if statusCode == "RP_500"{
        messageStr = NSLocalizedString("password_updatefailure", comment: "")
    }else if statusCode == "PickupAdd_505"{
        messageStr =  NSLocalizedString("error_failedtoaddnewaddress", comment: "")
    }else if statusCode == "PickupList_505"{
        messageStr = NSLocalizedString("ver_noaddress", comment: "")
    }else if statusCode == "PickupList_506"{
        messageStr = NSLocalizedString("error_failedtogetpickupaddresslist", comment: "")
    }else if statusCode == "PickupUpdate_505"{
        messageStr = NSLocalizedString("err_notupdatedaddress", comment: "")
    }else if statusCode == "PickupDelete_200"{
        messageStr = NSLocalizedString("delete_add_success", comment: "")
    }else if statusCode == "PickupDelete_505"{
        messageStr = NSLocalizedString("delete_add_failure", comment: "")
    }else if statusCode == "PickupDelete_506"{
        messageStr = NSLocalizedString("error_pickupaddressiddoesnotexist", comment: "")
    }else if statusCode == "ReceiverList_506"{
        messageStr = NSLocalizedString("error_failedtogetreceiveraddresslist", comment: "")
    }else if statusCode == "ReceiverDelete_506"{
        messageStr = NSLocalizedString("error_deliveryaddressiddoesnotexist", comment: "")
    }else if statusCode == "NoRiderAvailable_505"{
        messageStr = NSLocalizedString("error_ridernotavailable", comment: "")
    }else if statusCode == "BookParcel_505"{
        messageStr = NSLocalizedString("val_failedtobookparcel", comment: "")
    }else if statusCode == "GetProfile_505"{
        messageStr = NSLocalizedString("ver_failedtogetprofiledetails", comment: "")
    }else if statusCode == "GetProfile_506"{
        messageStr = NSLocalizedString("custiddoesnotexist", comment: "")
    }else if statusCode == "UpdateProfile_505"{
        messageStr = NSLocalizedString("ver_profileupdatefailure", comment: "")
    }else if statusCode == "UpdateFailProfile_505"{
        messageStr = NSLocalizedString("error_propicfailure", comment: "")
    }else if statusCode == "ParcelDetails_500"{
        messageStr = NSLocalizedString("ver_noparceldetailsfound", comment: "")
    }else if statusCode == "ParcelDetails_506"{
        messageStr = NSLocalizedString("err_parceliddoesnotexists", comment: "")
    }else if statusCode == "ParcelCancel_505"{
        messageStr = NSLocalizedString("alert_errorparcelcancelfailed", comment: "")
    }else if statusCode == "ParcelCancel_506"{
        messageStr = NSLocalizedString("alert_parcelpickupiddoesnotexist", comment: "")
    }else if statusCode == "FeedBack_505"{
        messageStr = NSLocalizedString("val_feedbackfailure", comment: "")
    }else if statusCode == "CP_505"{
        messageStr = NSLocalizedString("err_failurepassword", comment: "")
    }else if statusCode == "CP_506"{
        messageStr = NSLocalizedString("err_passwordssame", comment: "")
    }else if statusCode == "CP_507"{
        messageStr = NSLocalizedString("err_incorrectpassword", comment: "")
    }else if statusCode == "Logout_505"{
        messageStr = NSLocalizedString("err_logout", comment: "")
    }else if statusCode == "ParcelType_505"{
        messageStr = NSLocalizedString("err_failedtogetparceltype", comment: "")
    }else if statusCode == "ParcelType_506"{
        messageStr = NSLocalizedString("err_noparceltypefound", comment: "")
    }else if statusCode == "ParcelDimension_505"{
        messageStr = NSLocalizedString("err_failedtogetparceldimensions", comment: "")
    }else if statusCode == "ParcelDimension_506"{
        messageStr = NSLocalizedString("err_noparceldimensionsfound", comment: "")
    }else if statusCode == "ParcelWeight_505"{
        messageStr = NSLocalizedString("err_failedtogetparcelweights", comment: "")
    }else if statusCode == "ParcelWeight_506"{
        messageStr = NSLocalizedString("err_noparcelweightfound", comment: "")
    }else if statusCode == "GetAddressType_505"{
        messageStr = NSLocalizedString("error_failedtogetaddresstype", comment: "")
    }else if statusCode == "GetAddressType_506"{
        messageStr = NSLocalizedString("err_noaddresstypefound", comment: "")
    }
    let alert = UIAlertController(title: nil, message: messageStr, preferredStyle: UIAlertController.Style.alert)
    alert.addAction(UIAlertAction(title: NSLocalizedString("lbl_ok", comment: ""), style: UIAlertAction.Style.default, handler: nil))
    controller.present(alert, animated: true, completion: nil)
}
