
//
//  ReciverAddressViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 28/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import Firebase

class ReciverAddressVC: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var continueButtonHC: NSLayoutConstraint!
    @IBOutlet weak var continueButtonTC: NSLayoutConstraint!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var cancelBtn : UIButton!
    @IBOutlet weak var titleTxt : UILabel!
    @IBOutlet weak var reciverDetailsTable : UITableView!
    @IBOutlet weak var continueBtn : UIButton!
    @IBOutlet weak var addnewBtn : UIButton!
    @IBOutlet weak var headerView : UIView!
    @IBOutlet weak var titleLblCC: NSLayoutConstraint!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    var receiverAddessData = [PickupAddressData()]
    var refreshControl = UIRefreshControl()
    var count : Int = 0
    var addressSelected = true
    var recieverListModalArray : NSMutableArray = NSMutableArray()
    let appdeletegate:AppDelegate=(UIApplication.shared.delegate as! AppDelegate)
    var editAddressid = ""
    var editAddressIndex : Int = -1
    var editAddressStatus = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.recieverAddressapi()
        self.initialSetup()
        self.intialConstraintsSetup()
        self.addRefreshVCToTableView()
        self.languageValidationForGermany()
        self.gesturesSetup()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func initialSetup(){
        self.statusLabel.text = NSLocalizedString("ver_noaddress", comment: "")
        self.statusLabel.numberOfLines = 2
        self.statusLabel.isHidden = true
        self.reciverDetailsTable.register(UINib(nibName: "ReciverAddressTC", bundle: nil), forCellReuseIdentifier: "ReciverAddressTC")
        self.titleTxt.text = NSLocalizedString("lbl_receiverdetails", comment: "")
        self.titleTxt.font = AppFont.boldTextFont
        if appdeletegate.IS_IPHONE5{
            titleTxt.font = UIFont(name: "HelveticaNeue", size: 18)
        }
        self.titleTxt.textColor = AppColors.whiteColorRGB
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.continueBtn.setTitle(NSLocalizedString("btn_continue", comment: ""), for: .normal)
        self.continueBtn.titleLabel?.font = AppFont.boldTextFont
        self.continueBtn.backgroundColor = AppColors.greenColorRGB
        self.continueBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.continueBtn.titleLabel?.font = AppFont.boldTextFont
        self.addnewBtn.setTitle(NSLocalizedString("btn_addnew", comment: ""), for: .normal)
        self.addnewBtn.titleLabel?.font = AppFont.boldTextFont
        self.addnewBtn.backgroundColor = AppColors.greenColorRGB
        self.addnewBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.addnewBtn.titleLabel?.font = AppFont.boldTextFont
        self.continueButtonHC.constant = 0
        self.continueButtonTC.constant = 0
        self.continueBtn.isHidden = true
    }
    func addRefreshVCToTableView(){
        if #available(iOS 10.0, *) {
            reciverDetailsTable.refreshControl = refreshControl
        } else {
            reciverDetailsTable.addSubview(refreshControl)
        }
        refreshControl.tintColor = AppColors.greenColorRGB
        refreshControl.attributedTitle = NSAttributedString(string: NSLocalizedString("lbl_loading", comment: ""))
        refreshControl.addTarget(self, action: #selector(ReciverAddressVC.refreshData), for: .valueChanged)
    }
    func gesturesSetup(){
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(PickupAddressVC.respondToSwipeGesture(gesture:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.down
        self.statusLabel.isUserInteractionEnabled = true
        self.statusLabel.addGestureRecognizer(swipeRight)
    }
    func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
                self.statusLabel.isHidden = true
                self.recieverAddressapi()
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    func intialConstraintsSetup(){
        if appdeletegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func languageValidationForGermany(){
        let languageCode = Constants.getValueFromUserDefults(for: "languageCode") as! String
        if languageCode == "Yes"{
            self.languageValidationForGermany(headerView: self.headerView, cancelBtn: self.cancelBtn, labelConstraints: self.titleLblCC, titleLbl: self.titleTxt)
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        if self.appdeletegate.recieverAddAddress == "yes"{
            self.appdeletegate.recieverAddAddress = ""
            self.recieverAddressapi()
        }
    }
    @objc func refreshData(){
        self.editAddressStatus = ""
        self.recieverAddressapi()
    }
    override func viewWillDisappear(_ animated: Bool){
        self.refreshControl.endRefreshing()
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    @IBAction func btnsTapped(_ sender : UIButton){
        let btn = sender as UIButton
        if btn.tag == 10 {
            Analytics.logEvent("ReciverAddressVC_CancelButtonTapped", parameters: nil)
            self.dismiss(animated: true, completion: nil)
        }else if btn.tag == 20{
            if addressSelected == true{
                Analytics.logEvent("ReciverAddressVC_ContinueButtonTapped", parameters: nil)
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ParcelBookingConfirmationVC") as! ParcelBookingConfirmationVC
                self.present(nextViewController, animated:true, completion: nil)
            }else{
                self.displayAlert(message: NSLocalizedString("ver_address", comment: ""))
            }
        }else if btn.tag == 30{
            Analytics.logEvent("ReciverAddressVC_AddNewAddressButtonTapped", parameters: nil)
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "NewAddressVC") as! NewAddressVC
            nextViewController.controllerName = "ReceiverDetails"
            self.present(nextViewController, animated:true, completion: nil)
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return recieverListModalArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return  UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 111
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "ReciverAddressTC") as! ReciverAddressTC
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        cell.selectedBtn.layer.masksToBounds = true
        cell.selectedBtn.layer.cornerRadius = cell.selectedBtn.frame.size.width/2
        cell.selectedView.layer.masksToBounds = true
        cell.selectedView.layer.cornerRadius = cell.selectedView.frame.size.width/2
        cell.unSelectedView.layer.masksToBounds = true
        cell.unSelectedView.layer.cornerRadius = cell.unSelectedView.frame.size.width/2
        cell.deleteButton.tag = indexPath.row
        cell.deleteButton.addTarget(self, action: #selector(ReciverAddressVC.deleteAddress), for:.touchUpInside)
        cell.editButton.tag = indexPath.row
        cell.editButton.addTarget(self, action: #selector(ReciverAddressVC.editAddress(sender:)), for:.touchUpInside)
        if self.count == indexPath.row{
            cell.unSelectedView.isHidden = false
        }else{
            cell.unSelectedView.isHidden = true
        }
        cell.selectedBtn.isUserInteractionEnabled = false
        cell.borderlbl.frame = CGRect(x: 0, y: cell.frame.size.height-1, width: cell.frame.size.width, height: 0.5)
        let reciever = self.recieverListModalArray.object(at: indexPath.row) as! PickupAddressData
        cell.usernameLbl.text = reciever.name
        cell.usernameLbl.lineBreakMode = NSLineBreakMode.byWordWrapping
        cell.usernameLbl.numberOfLines = 0
        cell.addresssLbl.text = reciever.fulladdress
        cell.addresssLbl.lineBreakMode = NSLineBreakMode.byWordWrapping
        cell.addresssLbl.numberOfLines = 0
        cell.zipcodeLbl.text = reciever.zipcode
        cell.contactLbl.text = reciever.mobile
        if reciever.mobile == ""{
            cell.contactLbl.isHidden = true
        }
        if reciever.mobile != ""{
            if reciever.extensionCode != ""{
                cell.contactLbl.text = reciever.mobile + "  " + NSLocalizedString("tex_ext", comment: "") + " " + reciever.extensionCode
            }
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        count = indexPath.row
        let receiverAddress = self.recieverListModalArray.object(at: indexPath.row) as! PickupAddressData
        self.addressSelected = true
        Constants.setValueInUserDefaults(objValue:receiverAddress.name , for:"receiver_username")
        Constants.setValueInUserDefaults(objValue:receiverAddress.fulladdress , for:"receiver_address")
        Constants.setValueInUserDefaults(objValue:receiverAddress.zipcode , for:"receiver_zipcode")
        Constants.setValueInUserDefaults(objValue:receiverAddress.mobile , for:"receiver_mobileno")
        Constants.setValueInUserDefaults(objValue:receiverAddress.address_id , for:"receiver_receiveraddressID")
        Constants.setValueInUserDefaults(objValue:receiverAddress.extensionCode , for:"receiver_extNum")
        reciverDetailsTable.reloadData()
    }
    func heightForView(text:String, font:UIFont, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRect(x:0, y:0, width:width, height:2000))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    @objc func editAddress(sender : UIButton){
        Analytics.logEvent("ReciverAddressVC_EditAddressButtonTapped", parameters: nil)
        let receiverAddress = self.recieverListModalArray.object(at: sender.tag) as! PickupAddressData
        self.count = sender.tag
        Constants.setValueInUserDefaults(objValue:receiverAddress.name , for:"receiver_username")
        Constants.setValueInUserDefaults(objValue:receiverAddress.fulladdress , for:"receiver_address")
        Constants.setValueInUserDefaults(objValue:receiverAddress.zipcode , for:"receiver_zipcode")
        Constants.setValueInUserDefaults(objValue:receiverAddress.mobile , for:"receiver_mobileno")
        Constants.setValueInUserDefaults(objValue:receiverAddress.address_id , for:"receiver_receiveraddressID")
        Constants.setValueInUserDefaults(objValue:receiverAddress.extensionCode , for:"receiver_extNum")

        self.editAddressStatus = "editaddress"
        self.editAddressid = receiverAddress.address_id
        self.reciverDetailsTable.reloadData()
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let newAddressVC = storyBoard.instantiateViewController(withIdentifier: "NewAddressVC") as! NewAddressVC
        newAddressVC.controllerName = ""
        newAddressVC.addressArray.removeAllObjects()
        newAddressVC.controllerName = "EditReceiverDetails"
        newAddressVC.addressArray.add(receiverAddress.latitude)
        newAddressVC.addressArray.add(receiverAddress.longitude)
        newAddressVC.addressArray.add(receiverAddress.address_id)
        newAddressVC.addressArray.add(receiverAddress.name)
        newAddressVC.addressArray.add(receiverAddress.email)
        newAddressVC.addressArray.add(receiverAddress.mobile)
        newAddressVC.addressArray.add(receiverAddress.addressType)
        newAddressVC.addressArray.add(receiverAddress.flatNumber)
        newAddressVC.addressArray.add(receiverAddress.extensionCode)
        self.present(newAddressVC, animated:true, completion: nil)
    }
    func recieverAddressapi(){
        if self.ineternetAlert() == false{
            self.statusLabel.text = NSLocalizedString("ver_internetavailable_error", comment: "")
            return
        }
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        var cust_id = String()
        if Constants.getValueFromUserDefults(for:"customer_id") as? String != nil{
            cust_id = Constants.getValueFromUserDefults(for:"customer_id") as! String
        }
        bodyReq = ["customer_id":cust_id]
        var token = String()
        var session = ""
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            session = "Bearer" + " " + token
        }
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.deleveryAddressURL
            , method: "POST", token:session, body: "", productBody: bodyData as NSData) { (data,error,response) in
               
                if let httpResponse = response as? HTTPURLResponse{
                   // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        if let receivedData = data{
                            do{
                                let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    self.responseApi(response: resultDic as! [String : Any])
                                }
                            }catch {
                                self.somethingWentWrong()
                            }
                        }
                        break
                    case 500:
                        self.somethingWentWrong()

                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            self.statusDisplay(status: NSLocalizedString("ver_noaddress", comment: ""))
                            self.refreshControl.endRefreshing()
                            if self.recieverListModalArray.count != 0{
                                errorCodesMessageDisplayAlert(statusCode: "PickupList_505", controller: self)
                            }
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            self.statusDisplay(status: NSLocalizedString("error_failedtogetreceiveraddresslist", comment: ""))
                            self.refreshControl.endRefreshing()
                            if self.recieverListModalArray.count != 0{
                                errorCodesMessageDisplayAlert(statusCode: "ReceiverList_506", controller: self)
                            }
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                        break
                    default:
                        self.somethingWentWrong()
                    }
                }else{
                   self.somethingWentWrong()
                }
            }
        }
    }
    func somethingWentWrong(){
        DispatchQueue.main.async {
            IJProgressView.shared.hideProgressView()
            self.statusDisplay(status: NSLocalizedString("ver_somethingwrong", comment: ""))
            self.refreshControl.endRefreshing()
            if self.recieverListModalArray.count != 0{
                errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
            }
        }
    }
    func responseApi(response : [String : Any]){
           // print("Result",response)
            if let status = response["status"] as? Bool {
                if status == true{
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                        self.recieverListModalArray.removeAllObjects()
                        self.receiverAddessData.removeAll()
                        self.refreshControl.endRefreshing()
                        let newArray  = response["Msg"] as? [[String:Any]]
                        for (index,resultDic) in newArray!.enumerated() {
                             var address_id = ""
                            if let pickupaddressid = resultDic["del_add_id"] as? Int{
                                address_id = String(pickupaddressid)
                            }
                            ApiResponse.pickupAndReceiverAddressApiResponse(response: resultDic, pikupAddressArray: self.recieverListModalArray, addressStatus: "receiver")
                            if self.editAddressStatus == "editaddress"{
                                if self.editAddressid == address_id{
                                   // print("self.editAddressid",self.editAddressid)
                                   // print("address_id",address_id)
                                    self.editAddressIndex = index
                                }
                            }
                        }
                        self.statusDisplay(status: NSLocalizedString("ver_noaddress", comment: ""))
                    })
                }
        }
    }
    func addAddressDelegateTapped() {
        self.recieverAddressapi()
    }
    func statusDisplay(status:String){
        if self.recieverListModalArray.count == 0{
            self.continueButtonHC.constant = 0
            self.continueButtonTC.constant = 0
            self.continueBtn.isHidden = true
            self.reciverDetailsTable.isHidden = true
            self.statusLabel.isHidden = false
            self.continueBtn.isUserInteractionEnabled = false
            self.statusLabel.text = NSLocalizedString(status, comment: "")
            self.continueBtn.backgroundColor = AppColors.lightGrayColorRGB
            self.addressSelected = false
        }else{
            self.continueButtonHC.constant = 50
            self.continueButtonTC.constant = 10
            self.continueBtn.isHidden = false
            self.addressSelected = true
            self.statusLabel.isHidden = true
            self.reciverDetailsTable.isHidden = false
            self.continueBtn.isUserInteractionEnabled = true
            self.continueBtn.backgroundColor = AppColors.greenColorRGB
            self.reciverDetailsTable.reloadData()
            if editAddressStatus == "editaddress"{
                self.editAddressStatus = ""
                self.editAddressid = ""
                let indexPath = IndexPath(row: self.editAddressIndex, section: 0)
                self.reciverDetailsTable.selectRow(at: indexPath, animated: true, scrollPosition: .top)
                self.reciverDetailsTable.delegate?.tableView!(reciverDetailsTable, didSelectRowAt: indexPath)
                self.editAddressIndex = -1
            }else{
            let indexPath = IndexPath(row: 0, section: 0)
            self.reciverDetailsTable.selectRow(at: indexPath, animated: true, scrollPosition: .top)
            self.reciverDetailsTable.delegate?.tableView!(reciverDetailsTable, didSelectRowAt: indexPath)
            }
        }
    }
    @objc func deleteAddress(sender:UIButton){
        if self.ineternetAlert() == false{
            return
        }
        self.count = sender.tag
        self.reciverDetailsTable.reloadData()
        let alert = UIAlertController(title: NSLocalizedString("Rytle", comment: ""), message:NSLocalizedString("alert_msg", comment: ""), preferredStyle: .alert)
        let confirmAction = UIAlertAction(title:NSLocalizedString("alert_delete", comment: ""), style: .destructive) { (alert: UIAlertAction!) -> Void in
            Analytics.logEvent("ReciverAddressVC_DeleteAddressButtonTapped", parameters: nil)
            let receiverAddress = self.recieverListModalArray.object(at: sender.tag) as! PickupAddressData
            let address_id =  receiverAddress.address_id
            self.deleteReceiverAddress(addressid: address_id, index: sender.tag)
        }
        confirmAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        let cancelAction = UIAlertAction(title:NSLocalizedString("btn_cancel", comment:""), style: .default) { (alert: UIAlertAction!) -> Void in
            Analytics.logEvent("ReciverAddressVC_CancelledDeleteAddress", parameters: nil)
        }
        cancelAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        alert.addAction(cancelAction)
        alert.addAction(confirmAction)
        present(alert, animated: true, completion:nil)
    }
    func deleteReceiverAddress(addressid: String,index: Int){
        IJProgressView.shared.showProgressView(self.view)
        editAddressStatus = ""
        var bodyReq = [String:String]()
        bodyReq = ["delivery_add_id":addressid]
        var token = String()
        var session = ""
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            session = "Bearer" + " " + token
        }
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.deleteDeliveryAddressURL
            , method: "POST", token:session, body: "", productBody: bodyData as NSData) { (data,error,response) in
               
                if let httpResponse = response as? HTTPURLResponse{
                    IJProgressView.shared.hideProgressView()
                   // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                                self.recieverListModalArray.removeObject(at:index)
                                self.statusDisplay(status: NSLocalizedString("ver_noaddress", comment: ""))
                                errorCodesMessageDisplayAlert(statusCode: "PickupDelete_200", controller: self)
                            }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "PickupDelete_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "ReceiverDelete_506", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                        break
                    default:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                    }
                }
            }
        }
    }
}

