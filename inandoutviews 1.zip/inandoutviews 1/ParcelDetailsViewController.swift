//
//  ParcelDetailsViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 24/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
//import DropDown
struct ConstantsString {
    static let MAX_BEFORE_DECIMAL_DIGITS = 3
    static let MAX_AFTER_DECIMAL_DIGITS = 2
}

class ParcelSizesVC: UIViewController,UIScrollViewDelegate,UITextFieldDelegate {
    @IBOutlet weak var scrollViewObject : UIScrollView!
    @IBOutlet weak var contentView :UIView!
    @IBOutlet weak var lengthLbl : UILabel!
    @IBOutlet weak var lengthTxt : UITextField!
    @IBOutlet weak var widthLbl : UILabel!
    @IBOutlet weak var widthTxt : UITextField!
    @IBOutlet weak var heightLbl : UILabel!
    @IBOutlet weak var heightTxt : UITextField!
    @IBOutlet weak var weightLbl : UILabel!
    @IBOutlet weak var weightTxt : UITextField!
    @IBOutlet weak var insuredLbl : UILabel!
    @IBOutlet weak var yesLbl : UILabel!
    @IBOutlet weak var noLbl : UILabel!
    @IBOutlet weak var yesBtn : UIButton!
    @IBOutlet weak var noBtn : UIButton!
    @IBOutlet weak var lengthUnitTF: UITextField!
    @IBOutlet weak var widthUnitTF: UITextField!
    @IBOutlet weak var weightUnitTF: UITextField!
    @IBOutlet weak var heightUnitTF: UITextField!
    @IBOutlet weak var heightViewObj: UIView!
    @IBOutlet weak var lengthViewObj: UIView!
    @IBOutlet weak var widthViewObj: UIView!
    @IBOutlet weak var weightViewObj: UIView!
    @IBOutlet weak var lengthButton: UIButton!
    @IBOutlet weak var widthBUTTON: UIButton!
    //headerView
    @IBOutlet weak var headerView : UIView!
    @IBOutlet weak var cancelBtn : UIButton!
    @IBOutlet weak var titleLbl : UILabel!
    @IBOutlet weak var doneBtn : UIButton!
    @IBOutlet weak var heightBUTTON: UIButton!
    @IBOutlet weak var weightButton: UIButton!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    
    var activeField: UITextField?
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    @IBOutlet var scrollHeight: NSLayoutConstraint!
    @IBOutlet weak var heightButton: UIButton!
    var lengthText = ""
    var widthText = ""
    var heightText = ""
    var weightText = ""
    let amountDropDown = DropDown()
    let lengthDropDown = DropDown()
    let widthDropDown = DropDown()
    let heightDropDown = DropDown()
    let weightDropDown = DropDown()
    lazy var dropDowns: [DropDown] = {
        return [
            self.amountDropDown, self.lengthDropDown,self.widthDropDown,self.heightDropDown,self.weightDropDown
        ]
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.BtnPadding()
        self.intialConstraintsSetup()
        self.intialSetup()
        self.registerForKeyboardNotifications()
        
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONE5{
            self.view.addConstraint(NSLayoutConstraint(item: self.scrollViewObject, attribute: NSLayoutAttribute.top, relatedBy: NSLayoutRelation.equal, toItem: self.headerView, attribute: NSLayoutAttribute.bottom, multiplier: 1, constant: 0))
            self.view.addConstraint(NSLayoutConstraint(item: self.scrollViewObject, attribute: NSLayoutAttribute.leading, relatedBy: NSLayoutRelation.equal, toItem: self.view, attribute: NSLayoutAttribute.leading, multiplier: 1, constant: 0))
            self.view.addConstraint(NSLayoutConstraint(item: self.scrollViewObject, attribute: NSLayoutAttribute.trailing, relatedBy: NSLayoutRelation.equal, toItem: self.view, attribute: NSLayoutAttribute.trailing, multiplier: 1, constant: 0))
            self.view.addConstraint(NSLayoutConstraint(item: self.scrollViewObject, attribute: NSLayoutAttribute.height, relatedBy: NSLayoutRelation.equal, toItem: nil, attribute: NSLayoutAttribute.notAnAttribute, multiplier: 1, constant: 410))
            self.view.addConstraint(NSLayoutConstraint(item: self.doneBtn, attribute: NSLayoutAttribute.top, relatedBy: NSLayoutRelation.equal, toItem: self.scrollViewObject, attribute: NSLayoutAttribute.bottom, multiplier: 1, constant: 30))
        }else if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func BtnPadding(){
        let lengthbutton = UIButton(type: .custom)
        lengthbutton.setImage(UIImage(named:"icon_downarrow"), for: .normal)
        lengthbutton.imageEdgeInsets = UIEdgeInsetsMake(0, -16, 0, 0)
        lengthbutton.frame = CGRect(x: CGFloat(self.lengthUnitTF.frame.size.width - 25), y: CGFloat(5), width: CGFloat(22), height: CGFloat(22))
        lengthbutton.tag = 10
        self.lengthUnitTF.rightView = lengthbutton
        self.lengthUnitTF.rightViewMode = .always
        let heightbutton = UIButton(type: .custom)
        heightbutton.setImage(UIImage(named:"icon_downarrow"), for: .normal)
        heightbutton.imageEdgeInsets = UIEdgeInsetsMake(0, -16, 0, 0)
        heightbutton.frame = CGRect(x: CGFloat(self.heightUnitTF.frame.size.width - 25), y: CGFloat(5), width: CGFloat(22), height: CGFloat(22))
        heightbutton.tag = 20
        heightUnitTF.rightView = heightbutton
        heightUnitTF.rightViewMode = .always
        let widthbutton = UIButton(type: .custom)
        widthbutton.setImage(UIImage(named:"icon_downarrow"), for: .normal)
        widthbutton.imageEdgeInsets = UIEdgeInsetsMake(0, -16, 0, 0)
        widthbutton.frame = CGRect(x: CGFloat(self.widthUnitTF.frame.size.width - 25), y: CGFloat(5), width: CGFloat(22), height: CGFloat(22))
        widthbutton.tag = 30
        self.widthUnitTF.rightView = widthbutton
        self.widthUnitTF.rightViewMode = .always
        let weightbutton = UIButton(type: .custom)
        weightbutton.setImage(UIImage(named:"icon_downarrow"), for: .normal)
        weightbutton.tag = 40
        weightbutton.imageEdgeInsets = UIEdgeInsetsMake(0, -16, 0, 0)
        weightbutton.frame = CGRect(x: CGFloat(self.weightUnitTF.frame.size.width - 25), y: CGFloat(5), width: CGFloat(22), height: CGFloat(22))
        weightUnitTF.rightView = weightbutton
        weightUnitTF.rightViewMode = .always
    }
    
    func setupLengthDropDown()
    {
        lengthDropDown.anchorView = self.lengthButton
        lengthDropDown.dismissMode = .onTap
        lengthDropDown.direction = .bottom
        
        //  lengthDropDown.bottomOffset = CGPoint(x: 0, y: lengthUnitTF.bounds.height)
        
        lengthDropDown.dataSource = [
            NSLocalizedString("lbl_Dropdownunit", comment: ""),
            NSLocalizedString("lbl_mm", comment: ""),
            NSLocalizedString("lbl_cm", comment: ""),
            NSLocalizedString("lbl_m", comment: "")
            
        ]
        
        lengthDropDown.selectionAction = { [unowned self] (index, item) in
            
            self.lengthUnitTF.text = item
            if self.lengthUnitTF.text ==  NSLocalizedString("lbl_mm", comment: ""){
                self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                if self.widthUnitTF.text == "" && self.heightUnitTF.text == "" {
                    self.widthUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
                    self.heightUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                }
                else{
                    
                    self.widthUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
                    self.heightUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    
                }
            }
            if self.lengthUnitTF.text ==  NSLocalizedString("lbl_cm", comment: ""){
                if self.widthUnitTF.text == "" && self.heightUnitTF.text == "" {
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                }
                    
                else{
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    
                    
                }
            }
            if self.lengthUnitTF.text ==  NSLocalizedString("lbl_m", comment: ""){
                if self.widthUnitTF.text == "" && self.heightUnitTF.text == "" {
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                }
                else{
                    
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    
                }
            }
        }
    }
    
    func setupWidthDropDown()
    {
        widthDropDown.anchorView = self.widthBUTTON
        widthDropDown.dismissMode = .onTap
        widthDropDown.direction = .bottom
        
        widthDropDown.bottomOffset = CGPoint(x: 0, y: self.widthUnitTF.bounds.height)
        
        widthDropDown.dataSource = [ NSLocalizedString("lbl_Dropdownunit", comment: ""),
                                     NSLocalizedString("lbl_mm", comment: ""),
                                     NSLocalizedString("lbl_cm", comment: ""),
                                     NSLocalizedString("lbl_m", comment: "")
        ]
        
        widthDropDown.selectionAction = { [unowned self] (index, item) in
            
            self.widthUnitTF.text = item
            if self.widthUnitTF.text ==  NSLocalizedString("lbl_mm", comment: ""){
                if self.heightUnitTF.text == "" && self.lengthUnitTF.text == ""{
                    self.widthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                }
                else{
                    self.widthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    
                }
            }
            if self.widthUnitTF.text ==  NSLocalizedString("lbl_m", comment: ""){
                if self.heightUnitTF.text == "" && self.lengthUnitTF.text == ""{
                    self.widthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.heightUnitTF.text = NSLocalizedString("lbl_m", comment:"")
                    self.lengthUnitTF.text = NSLocalizedString("lbl_m", comment:"")
                }
                else{
                    self.widthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.heightUnitTF.text = NSLocalizedString("lbl_m", comment:"")
                    self.lengthUnitTF.text = NSLocalizedString("lbl_m", comment:"")
                    
                }
                
            }
            if self.widthUnitTF.text ==  NSLocalizedString("lbl_cm", comment: ""){
                if self.heightUnitTF.text == "" && self.lengthUnitTF.text == ""{
                    self.widthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.heightUnitTF.text = NSLocalizedString("lbl_cm", comment:"")
                    self.lengthUnitTF.text = NSLocalizedString("lbl_cm", comment:"")
                }
                else{
                    self.widthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.heightUnitTF.text = NSLocalizedString("lbl_cm", comment:"")
                    self.lengthUnitTF.text = NSLocalizedString("lbl_cm", comment:"")
                    
                }
                
            }
        }
    }
    func setupHeightDropDown()
    {
        heightDropDown.anchorView = self.heightBUTTON
        heightDropDown.dismissMode = .onTap
        heightDropDown.direction = .bottom
        
        heightDropDown.bottomOffset = CGPoint(x: 0, y: heightUnitTF.bounds.height)
        
        heightDropDown.dataSource = [ NSLocalizedString("lbl_Dropdownunit", comment: ""),
                                      NSLocalizedString("lbl_mm", comment: ""),
                                      NSLocalizedString("lbl_cm", comment: ""),
                                      NSLocalizedString("lbl_m", comment: "")
        ]
        
        heightDropDown.selectionAction = { [unowned self] (index, item) in
            
            self.heightUnitTF.text = item
            
            
            if self.heightUnitTF.text ==  NSLocalizedString("lbl_mm", comment: ""){
                self.heightUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                if self.widthUnitTF.text == "" && self.lengthUnitTF.text == ""{
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                }
                else{
                    
                    
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    
                }
            }
            if self.heightUnitTF.text ==  NSLocalizedString("lbl_cm", comment: ""){
                if self.widthUnitTF.text == "" && self.lengthUnitTF.text == ""{
                    self.heightUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                }
                else{
                    
                    
                    self.heightUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    
                    
                    
                    
                    
                }
            }
            if self.heightUnitTF.text ==  NSLocalizedString("lbl_m", comment: ""){
                if self.widthUnitTF.text == "" && self.lengthUnitTF.text == ""{
                    self.heightUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                }
                else{
                    
                    self.heightUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                }
            }
        }
    }
    
    func centimeterTomilimeter(textfield:UITextField)
    {
        if #available(iOS 10.0, *) {
            let heightFeet = Measurement(value:Double(textfield.text!)!, unit: UnitLength.centimeters)
            let heightInches = heightFeet.converted(to: UnitLength.millimeters)
            //print(heightInches)
            var name: String = String(describing: heightInches)
            let endIndex = name.index(name.endIndex, offsetBy: -3)
            let truncated = name.substring(to: endIndex)
            textfield.text = truncated
            if textfield == lengthTxt {
                self.lengthUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
            }
            if textfield == widthTxt {
                self.widthUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
            }
            if textfield == heightTxt {
                self.heightUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
            }
            
        } else {
            // Fallback on earlier versions
        }
        
    }
    func meterTocentimeter(textfield:UITextField)
    {
        if #available(iOS 10.0, *) {
            let heightFeet = Measurement(value:Double(textfield.text!)!, unit: UnitLength.meters)
            let heightInches = heightFeet.converted(to: UnitLength.centimeters)
            // print(heightInches)
            var name: String = String(describing: heightInches)
            let endIndex = name.index(name.endIndex, offsetBy: -3)
            let truncated = name.substring(to: endIndex)
            textfield.text = truncated
            if textfield == lengthTxt {
                self.lengthUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
            }
            if textfield == widthTxt {
                self.widthUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
            }
            if textfield == heightTxt {
                self.heightUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
            }
        } else {
            // Fallback on earlier versions
        }
        
    }
    func meterTomilimeter(textfield:UITextField)
    {
        if #available(iOS 10.0, *) {
            // print("textfield.text!",Double(textfield.text!))
            let heightFeet = Measurement(value:Double(textfield.text!)!, unit: UnitLength.meters)
            let heightInches = heightFeet.converted(to: UnitLength.millimeters)
            // print(heightInches)
            var name: String = String(describing: heightInches)
            let endIndex = name.index(name.endIndex, offsetBy: -3)
            let truncated = name.substring(to: endIndex)
            textfield.text = truncated
            if textfield == lengthTxt {
                self.lengthUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
            }
            if textfield == widthTxt {
                self.widthUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
            }
            if textfield == heightTxt {
                self.heightUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
            }
            
        } else {
            // Fallback on earlier versions
        }
        
    }
    func centimeterTometer(textfield:UITextField)
    {
        if #available(iOS 10.0, *) {
            let heightFeet = Measurement(value:Double(textfield.text!)!, unit: UnitLength.centimeters)
            let heightInches = heightFeet.converted(to: UnitLength.meters)
            // print(heightInches)
            let name: String = String(describing: heightInches)
            let endIndex = name.index(name.endIndex, offsetBy: -2)
            let truncated = name.substring(to: endIndex)
            textfield.text = truncated
            if textfield == lengthTxt {
                self.lengthUnitTF.text = NSLocalizedString("lbl_m", comment: "")
            }
            if textfield == widthTxt {
                self.widthUnitTF.text = NSLocalizedString("lbl_m", comment: "")
            }
            if textfield == heightTxt {
                self.heightUnitTF.text = NSLocalizedString("lbl_m", comment: "")
            }
        } else {
            // Fallback on earlier versions
        }
        
    }
    func milimeterTometer(textfield:UITextField)
    {
        if #available(iOS 10.0, *) {
            let heightFeet = Measurement(value:Double(textfield.text!)!, unit: UnitLength.millimeters)
            let heightInches = heightFeet.converted(to: UnitLength.meters)
            // print(heightInches)
            var name: String = String(describing: heightInches)
            let endIndex = name.index(name.endIndex, offsetBy: -2)
            let truncated = name.substring(to: endIndex)
            textfield.text = truncated
            if textfield == lengthTxt {
                self.lengthUnitTF.text = NSLocalizedString("lbl_m", comment: "")
            }
            if textfield == widthTxt {
                self.widthUnitTF.text = NSLocalizedString("lbl_m", comment: "")
            }
            if textfield == heightTxt {
                self.heightUnitTF.text = NSLocalizedString("lbl_m", comment: "")
            }
            
        } else {
            // Fallback on earlier versions
        }
        
    }
    func milimeterToCenti(textfield:UITextField)
    {
        if #available(iOS 10.0, *) {
            let heightFeet = Measurement(value:Double(textfield.text!)!, unit: UnitLength.millimeters)
            let heightInches = heightFeet.converted(to: UnitLength.centimeters)
            // print(heightInches)
            var name: String = String(describing: heightInches)
            let endIndex = name.index(name.endIndex, offsetBy: -3)
            let truncated = name.substring(to: endIndex)
            textfield.text = truncated
            if textfield == lengthTxt {
                self.lengthUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
            }
            if textfield == widthTxt {
                self.widthUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
            }
            if textfield == heightTxt {
                self.heightUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
            }
        } else {
            // Fallback on earlier versions
        }
    }
    
    func setupWeightDropDown()
    {
        weightDropDown.anchorView = self.weightButton
        weightDropDown.dismissMode = .onTap
        weightDropDown.direction = .top
        
        weightDropDown.bottomOffset = CGPoint(x: 0, y: weightUnitTF.bounds.height)
        
        weightDropDown.dataSource = [ NSLocalizedString("lbl_Dropdownunit", comment: ""),
                                      NSLocalizedString("lbl_mg", comment: ""),
                                      NSLocalizedString("lbl_g", comment: ""),
                                      NSLocalizedString("lbl_kg", comment: "")
        ]
        
        weightDropDown.selectionAction = { [unowned self] (index, item) in
            
            self.weightUnitTF.text = item
            
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear (animated)
        self.dismissKeypad()
        self.deregisterFromKeyboardNotifications()
    }
    func intialSetup(){
        lengthUnitTF.delegate = self
        widthUnitTF.delegate = self
        heightUnitTF.delegate = self
        weightUnitTF .delegate = self
        setupLengthDropDown()
        setupWidthDropDown()
        setupWeightDropDown()
        setupHeightDropDown()
        self.titleLbl.text = NSLocalizedString("lbl_parceldetals", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        self.titleLbl.textColor = AppColors.whiteColorRGB
        self.lengthLbl.text = NSLocalizedString("lbl_lenght", comment: "")
        self.lengthLbl.font = AppFont.regularTextFont
        self.widthLbl.text = NSLocalizedString("lbl_width", comment: "")
        self.widthLbl.font = AppFont.regularTextFont
        self.heightLbl.text = NSLocalizedString("lbl_height", comment: "")
        self.heightLbl.font = AppFont.regularTextFont
        self.weightLbl.text = NSLocalizedString("lbl_weight", comment: "")
        self.weightLbl.font = AppFont.regularTextFont
        self.insuredLbl.text = NSLocalizedString("lbl_insured", comment: "")
        self.weightLbl.font = AppFont.regularTextFont
        self.yesLbl.text = NSLocalizedString("lbl_yes", comment: "")
        self.yesLbl.font = AppFont.regularTextFont
        self.noLbl.text = NSLocalizedString("lbl_no", comment: "")
        self.noLbl.font = AppFont.regularTextFont
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.doneBtn.setTitle(NSLocalizedString("btn_continue", comment: ""), for: .normal)
        self.doneBtn.titleLabel?.font = AppFont.boldTextFont
        self.doneBtn.backgroundColor = AppColors.greenColorRGB
        self.doneBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.heightUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
        self.widthUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
        self.lengthUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
        self.weightUnitTF.text = NSLocalizedString("lbl_g", comment: "")
        self.noBtn.setBackgroundImage(UIImage(named:"icon_selectedBtn"), for: .normal)
        noBtn.isSelected = true
        Constants.setValueInUserDefaults(objValue:"No" , for:"insured")
        self.scrollViewObject.delegate = self
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        self.scrollViewObject.isUserInteractionEnabled = true
        self.scrollViewObject.addGestureRecognizer(tapGestureRecognizer)
        if appdelegate.IS_IPHONE5{
            self.scrollViewObject.isScrollEnabled = true
        }else{
            self.scrollViewObject.isScrollEnabled = false
        }
        if appdelegate.IS_IPHONE5 {
            self.setFont()
        }
    }
    func setFont(){
        self.lengthLbl.font = AppFont.regularSmallTextFont
        self.widthLbl.font = AppFont.regularSmallTextFont
        self.heightLbl.font = AppFont.regularSmallTextFont
        self.weightLbl.font = AppFont.regularSmallTextFont
        self.insuredLbl.font = AppFont.regularSmallTextFont
        // self.deleiveryLbl.font = AppFont.regularSmallTextFont
    }
    override func viewDidLayoutSubviews(){
        DispatchQueue.main.async{
                if self.appdelegate.IS_IPHONE5{
                    self.scrollViewObject.isScrollEnabled = true
                    self.scrollViewObject.translatesAutoresizingMaskIntoConstraints = true
                    self.scrollViewObject.contentSize = CGSize(width: 0, height: self.contentView.frame.origin.y+self.contentView.frame.size.height)
                }else{
                    self.scrollViewObject.isScrollEnabled = false
                }
          }
     }
    
    
    func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        self.heightTxt.resignFirstResponder()
        self.widthTxt.resignFirstResponder()
        self.lengthTxt.resignFirstResponder()
        self.weightTxt.resignFirstResponder()
        DispatchQueue.main.async() {
            UIView.animate(withDuration: 0.0, delay: 0, options: UIViewAnimationOptions.curveLinear, animations: {
            }, completion: nil)
        }
    }
 
    @IBAction func btnsTapped(_ sender : UIButton){
        let btn = sender as UIButton
        if btn.tag == 1{
            lengthTxt.resignFirstResponder()
            widthTxt.resignFirstResponder()
            heightTxt.resignFirstResponder()
            weightTxt.resignFirstResponder()
            lengthDropDown.show()
        }else if btn.tag == 2{
            lengthTxt.resignFirstResponder()
            widthTxt.resignFirstResponder()
            heightTxt.resignFirstResponder()
            weightTxt.resignFirstResponder()
            widthDropDown.show()
        }else if btn.tag == 3{
            lengthTxt.resignFirstResponder()
            widthTxt.resignFirstResponder()
            heightTxt.resignFirstResponder()
            weightTxt.resignFirstResponder()
            heightDropDown.show()
        }else if btn.tag == 4{
            lengthTxt.resignFirstResponder()
            widthTxt.resignFirstResponder()
            heightTxt.resignFirstResponder()
            weightTxt.resignFirstResponder()
            weightDropDown.show()
        }else if btn.tag == 10{
            self.dismiss(animated: true, completion: nil)
        }else if btn.tag == 20{
            self.doneBtnTapped()
        }else if btn.tag == 30{
            appdelegate.addressStatus = "Yes"
            amountDropDown.show()
        }else if btn.tag == 40{
            self.yesBtn.isSelected = true
            self.yesBtn.setBackgroundImage(UIImage.init(named: "icon_selectedBtn"), for: UIControlState.normal)
            self.noBtn.isSelected = false
            self.noBtn.setBackgroundImage(UIImage.init(named: "icon_unselectedBtn"), for: UIControlState.normal)
            Constants.setValueInUserDefaults(objValue:"Yes" , for:"insured")
        }else if btn.tag == 50{
            Constants.setValueInUserDefaults(objValue:"No" , for:"insured")
            self.yesBtn.isSelected = false
            self.noBtn.isSelected = true
            self.yesBtn.setBackgroundImage(UIImage.init(named: "icon_unselectedBtn"), for: UIControlState.normal)
            self.noBtn.setBackgroundImage(UIImage.init(named: "icon_selectedBtn"), for: UIControlState.normal)
        }
    }
    
    func doneBtnTapped(){
        if lengthTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_length",comment: ""), completion: {(result) in
                self.lengthTxt.becomeFirstResponder()
            })
            return
        }else if heightTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_height",comment: ""), completion: {(result) in
                self.heightTxt.becomeFirstResponder()
            })
            return
        }else if widthTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_width",comment: ""), completion: {(result) in
                self.widthTxt.becomeFirstResponder()
            })
            return
        }else if weightTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_weight",comment: ""), completion: {(result) in
                self.weightTxt.becomeFirstResponder()
            })
            return
        }else if Double(lengthTxt.text!) == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_length",comment: ""), completion: {(result) in
                self.lengthTxt.becomeFirstResponder()
            })
            return
        }else if Double(widthTxt.text!) == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_width",comment: ""), completion: {(result) in
                self.widthTxt.becomeFirstResponder()
            })
            return
        }else if Double(heightTxt.text!) == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_height",comment: ""), completion: {(result) in
                self.heightTxt.becomeFirstResponder()
            })
            return
        }else if Double(weightTxt.text!) == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_weight",comment: ""), completion: {(result) in
                self.weightTxt.becomeFirstResponder()
            })
            return
        }else if lengthUnitTF.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_lengthunit",comment: ""), completion: {(result) in
            })
            return
        }else if heightUnitTF.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_heightunit",comment: ""), completion: {(result) in
            })
            return
        }else if widthUnitTF.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_widthunit",comment: ""), completion: {(result) in
            })
            return
        }else if weightUnitTF.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_weightunit",comment: ""), completion: {(result) in
            })
            return
        }else if lengthUnitTF.text ==   NSLocalizedString("lbl_Dropdownunit", comment: "") {
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_lengthunit",comment: ""), completion: {(result) in
            })
            return
        }else if heightUnitTF.text ==  NSLocalizedString("lbl_Dropdownunit", comment: ""){
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_heightunit",comment: ""), completion: {(result) in
            })
            return
        }else if widthUnitTF.text ==   NSLocalizedString("lbl_Dropdownunit", comment: ""){
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_widthunit",comment: ""), completion: {(result) in
            })
            return
        }else if weightUnitTF.text ==   NSLocalizedString("lbl_Dropdownunit", comment: ""){
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_weightunit",comment: ""), completion: {(result) in
            })
            return
        }else if yesBtn.isSelected == false && noBtn.isSelected == false {
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("Please select insured or not",comment: ""), completion: {(result) in
            })
            return
        }else{
            self.dismissKeypad()
            let length = lengthTxt.text! + " " + lengthUnitTF.text!
            Constants.setValueInUserDefaults(objValue:length, for:"length")
            let width = widthTxt.text!  + " " + widthUnitTF.text!
            Constants.setValueInUserDefaults(objValue:width , for:"width")
            let height = heightTxt.text! +  " " +  heightUnitTF.text!
            Constants.setValueInUserDefaults(objValue:height , for:"height")
            let weight = weightTxt.text!  + " " + weightUnitTF.text!
            Constants.setValueInUserDefaults(objValue:weight , for:"weight")
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "PickupAddressViewController") as! PickupAddressViewController
            self.present(nextViewController, animated:true, completion: nil)
        }
    }
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        if appdelegate.IS_IPHONE6 || appdelegate.IS_IPHONE6PLUS{
            self.scrollViewObject.isScrollEnabled = false
        }
        else{
            self.scrollViewObject.isScrollEnabled = true
        }
        var info = notification.userInfo!
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height, 0.0)
        self.scrollViewObject.contentInset = contentInsets
        self.scrollViewObject.scrollIndicatorInsets = contentInsets
        
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollViewObject.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
        
        if appdelegate.IS_IPHONE5{
            if activeField == self.weightTxt{
                DispatchQueue.main.async() {
                    UIView.animate(withDuration: 0.0, delay: 0, options: UIViewAnimationOptions.curveLinear, animations: {
                        self.scrollViewObject.contentOffset.y = 100
                    }, completion: nil)
                }
            }
        }
    }
    
    func keyboardWillBeHidden(notification: NSNotification){
        //Once keyboard disappears, restore original positions
        var info = notification.userInfo!
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)
        self.scrollViewObject.contentInset = contentInsets
        self.scrollViewObject.scrollIndicatorInsets = contentInsets
        self.view.endEditing(true)
        DispatchQueue.main.async{
                self.scrollViewObject.isScrollEnabled = true
                self.scrollViewObject.contentSize = CGSize(width: 0, height: self.contentView.frame.origin.y+self.contentView.frame.size.height)
        }
        if appdelegate.IS_IPHONE5{
            if activeField == self.weightTxt{
                DispatchQueue.main.async() {
                    UIView.animate(withDuration: 0.0, delay: 0, options: UIViewAnimationOptions.curveLinear, animations: {
                        self.scrollViewObject.contentOffset.y = 0
                    }, completion: nil)
                }
            }
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField){
        if textField == self.lengthTxt{
            textField.returnKeyType = .next
        }else if textField == self.widthTxt{
            textField.returnKeyType = .next
        }else if textField == self.heightTxt{
            textField.returnKeyType = .next
        }else if textField == self.weightTxt{
            textField.returnKeyType = .done
        }
        self.activeField = textField
    }
    
    func dismissKeypad (){
        self.widthTxt.resignFirstResponder()
        self.weightTxt.resignFirstResponder()
        self.heightTxt.resignFirstResponder()
        self.lengthTxt.resignFirstResponder()
    }
    
    func nextButtonTapped (){
        if activeField == self.lengthTxt{
            self.widthTxt.becomeFirstResponder()
        }else if activeField == self.widthTxt{
            self.heightTxt.becomeFirstResponder()
        }else  if activeField == self.heightTxt{
            self.weightTxt.becomeFirstResponder()
        }else  if activeField == self.weightTxt{
            self.weightTxt.resignFirstResponder()
        }
    }
    func previouesButtonTapped (){
        if activeField == self.widthTxt{
            DispatchQueue.main.async() {
                UIView.animate(withDuration: 0.0, delay: 0, options: UIViewAnimationOptions.curveLinear, animations: {
                    self.scrollViewObject.contentOffset.y = 0
                }, completion: nil)
            }
            self.lengthTxt.becomeFirstResponder()
        }else  if activeField == self.heightTxt{
            self.widthTxt.becomeFirstResponder()
        }else  if activeField == self.weightTxt{
            self.heightTxt.becomeFirstResponder()
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField){
        self.activeField = nil
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == lengthTxt || textField == widthTxt || textField == heightTxt || textField == weightTxt{
            let inverseSet = NSCharacterSet(charactersIn:"0123456789").inverted
            let components = string.components(separatedBy: inverseSet)
            let filtered = components.joined(separator: "")
            if filtered == string {
                let computationString = (textField.text! as NSString).replacingCharacters(in: range, with:filtered)
                // Take number of digits present after the decimal point.
                let arrayOfSubStrings = computationString.components(separatedBy: ".")
                if arrayOfSubStrings.count == 1 && computationString.count > ConstantsString.MAX_BEFORE_DECIMAL_DIGITS {
                    return false
                }else if arrayOfSubStrings.count == 2 {
                    let stringPostDecimal = arrayOfSubStrings[1]
                    return stringPostDecimal.count <= ConstantsString.MAX_AFTER_DECIMAL_DIGITS
                }
                return true
            } else {
                if string == "." {
                    let countdots = textField.text!.components(separatedBy:".").count - 1
                    if countdots == 0 {
                        return true
                    }else{
                        if countdots > 0 && string == "." {
                            return false
                        } else {
                            return true
                        }
                    }
                }else{
                    return false
                }
            }
            
            
        }
        
        return true
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == lengthUnitTF || textField == heightUnitTF || textField == widthUnitTF || textField == weightUnitTF {
            return false //do not show keyboard nor cursor
        }
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        if textField.returnKeyType ==  UIReturnKeyType.next{
            if textField == lengthTxt{
                lengthTxt.resignFirstResponder()
                widthTxt.becomeFirstResponder()
            }
            if textField == widthTxt{
                widthTxt.resignFirstResponder()
                heightTxt.becomeFirstResponder()
            }
            if textField == heightTxt{
                heightTxt.resignFirstResponder()
                weightTxt.becomeFirstResponder()
            }
        }
        if textField.returnKeyType ==  UIReturnKeyType.done{
            if textField == weightTxt{
                weightTxt.resignFirstResponder()
            }
        }
        
        return true
    }
    
}


