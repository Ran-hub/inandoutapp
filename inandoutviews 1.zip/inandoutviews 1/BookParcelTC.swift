//
//  BookParcelTC.swift
//  RYTLECUSTOMERAPP
//
//  Created by AMT on 6/28/18.
//  Copyright © 2018 Pavan. All rights reserved.
//

import UIKit

class BookParcelTC: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var dimensionLbl: UILabel!
    @IBOutlet weak var dimensionApiLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
