//
//  ImageLoader.swift
//  RYTLECUSTOMERAPP
//
//  Created by AMT on 2/22/18.
//  Copyright © 2018 Pavan. All rights reserved.
//

import Foundation

class ImageLoader {
    
    var cache = NSCache<AnyObject, AnyObject>()
    
    class var sharedLoader : ImageLoader {
        struct Static {
            static let instance : ImageLoader = ImageLoader()
        }
        return Static.instance
    }
    
    func imageForUrl(urlString: String, completionHandler:@escaping (_ image: UIImage?, _ url: String) -> ()) {
        DispatchQueue.global().async(execute: {() in
            let data: NSData? = self.cache.object(forKey: urlString as AnyObject) as? NSData
            if let goodData = data {
                let image = UIImage(data: goodData as Data)
                DispatchQueue.main.async {
                    completionHandler(image, urlString)
                }
                return
            }
            let downloadTask : URLSessionDataTask = URLSession.shared.dataTask(with: NSURL(string: urlString)! as URL, completionHandler: {(data:Data, response: URLResponse!, error: NSError!) in
                if (error != nil) {
                    completionHandler(nil, urlString)
                    return
                }
                if data != nil {
                    let image = UIImage(data: data)
                    self.cache.setObject(data as AnyObject, forKey: urlString as AnyObject)
                    DispatchQueue.main.async {
                        completionHandler(image, urlString)
                    }
                    return
                }
                } as! (Data?, URLResponse?, Error?) -> Void)
            downloadTask.resume()
        })
    }
   
}
