//
//  ChangePasswordViewController.swift
//  RYTLE
//
//  Created by Shilpashree on 17/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import Firebase

class ResetPasswordVC: UIViewController,UITextFieldDelegate,UIScrollViewDelegate {
    
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var newPasswordTextField: UITextField!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var scrollViewObj: UIScrollView!
    @IBOutlet weak var bgImg: UIImageView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var titleLblCC: NSLayoutConstraint!
    @IBOutlet weak var logoImg: UIImageView!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    @IBOutlet weak var logoHeightHC: NSLayoutConstraint!
    @IBOutlet weak var logoWidthWC: NSLayoutConstraint!
    @IBOutlet weak var logoBottomBC: NSLayoutConstraint!
    @IBOutlet weak var contentView: UIView!
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var activeField: UITextField?
    
    override func viewDidLoad(){
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        initialSetUp()
        self.intialConstraintsSetup()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func initialSetUp(){
        if appdelegate.IS_IPADPRO9 || appdelegate.IS_IPADPRO10 || appdelegate.IS_IPADPRO12{
            self.contentView.removeConstraint(self.logoWidthWC)
            self.contentView.removeConstraint(self.logoHeightHC)
            self.contentView.removeConstraint(self.logoBottomBC)
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.contentView, attribute: NSLayoutConstraint.Attribute.height, multiplier: 150/736, constant: 0))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.contentView, attribute: NSLayoutConstraint.Attribute.width, multiplier: 200/414, constant: 0))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.bgImg, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: self.view.frame.size.height/6.5))
        }else if appdelegate.IS_IPHONEX{
            self.contentView.removeConstraint(self.logoWidthWC)
            self.contentView.removeConstraint(self.logoHeightHC)
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem:nil, attribute: .notAnAttribute, multiplier: 1, constant: 250))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem:nil, attribute: .notAnAttribute, multiplier: 1, constant: 160))
        }else if appdelegate.IS_IPHONE5{
            self.contentView.removeConstraint(self.logoBottomBC)
            self.contentView.addConstraint(NSLayoutConstraint(item: self.newPasswordTextField, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.logoImg, attribute: .bottom, multiplier: 1, constant: self.view.frame.size.height/8))
        }
        self.scrollViewObj.delegate = self
        titleLbl.font = AppFont.boldTextFont
        if appdelegate.IS_IPHONE5{
            titleLbl.font = UIFont(name: "HelveticaNeue", size: 18)
        }
        titleLbl.text = NSLocalizedString("lbl_changepassword",comment:"")
        titleLbl.textColor = AppColors.whiteColorRGB
        newPasswordTextField.placeholder = NSLocalizedString("lbl_newpassword",comment:"")
        newPasswordTextField.font = AppFont.regularTextFont
        confirmPasswordTextField.placeholder = NSLocalizedString("lbl_confirmpassword",comment:"")
        confirmPasswordTextField.font = AppFont.regularTextFont
        cancelButton.setTitle(NSLocalizedString("btn_cancel",comment:""),for:.normal)
        cancelButton.titleLabel?.font = AppFont.regularTextFont
        cancelButton.titleLabel?.textColor = AppColors.whiteColorRGB
        submitButton.setTitle(NSLocalizedString("btn_confirm1",comment:""),for:.normal)
        submitButton.titleLabel?.textColor = .whiteColorCode
        submitButton.titleLabel?.font = AppFont.boldTextFont
        submitButton.backgroundColor = AppColors.greenColorRGB
        self.registerForKeyboardNotifications()
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        self.bgImg.isUserInteractionEnabled = true
        self.bgImg.addGestureRecognizer(tapGestureRecognizer)
        self.languageValidationForGermany()
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func languageValidationForGermany(){
        let languageCode = Constants.getValueFromUserDefults(for: "languageCode") as! String
        if languageCode == "Yes"{
            self.languageValidationForGermany(headerView: self.headerView, cancelBtn: self.cancelButton, labelConstraints: self.titleLblCC, titleLbl: self.titleLbl)
        }
    }
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        self.scrollViewObj.isScrollEnabled = false
        self.newPasswordTextField.resignFirstResponder()
        self.confirmPasswordTextField.resignFirstResponder()
    }
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name:UIResponder.keyboardWillHideNotification, object: nil)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear (animated)
        deregisterFromKeyboardNotifications()
    }
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        self.scrollViewObj.isScrollEnabled = true
        var info = notification.userInfo!
        var keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        if keyboardSize?.height == 0
        {
            keyboardSize?.height = 260
        }
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: keyboardSize!.height+50, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollViewObj.scrollRectToVisible(activeField.frame, animated: true)
                self.scrollViewObj.isScrollEnabled = false
            }
        }
    }
    
    @objc func keyboardWillBeHidden(notification: NSNotification){
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField){
        if textField == newPasswordTextField{
            textField.returnKeyType = .next
        }else if textField == self.confirmPasswordTextField{
            textField.returnKeyType = .done
        }
        self.activeField = textField
    }
    
    func textFieldDidEndEditing(_ textField: UITextField){
        self.activeField = nil
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string == " "{
            return false
        }
        else{
            return true
        }
        return true
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        switch textField{
        case self.newPasswordTextField:
            self.confirmPasswordTextField.becomeFirstResponder()
            break
        case self.confirmPasswordTextField:
            textField.resignFirstResponder()
            break
        default:
            textField.resignFirstResponder()
        }
        return true
    }
    public func scrollViewDidScroll(_ scrollView: UIScrollView){
        scrollView.isScrollEnabled = false
    }
    @IBAction func cancelAction(_ sender: Any) {
        Analytics.logEvent("ResetPasswordVC_CancelButtonTapped", parameters: nil)
        self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
    }
    func resignTextFields(){
        self.newPasswordTextField.resignFirstResponder()
        self.confirmPasswordTextField.resignFirstResponder()
    }
    
    @IBAction func submitAction(_ sender: Any) {
        Analytics.logEvent("ResetPasswordVC_ResetPasswordButtonTapped", parameters: nil)
        self.resignTextFields()
        if self.ineternetAlert() == false{
            return
        }
        if self.newPasswordTextField.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE", comment: ""), messageStr: NSLocalizedString("valid_password", comment: "") , completion: {(result) in
                self.newPasswordTextField.becomeFirstResponder()
            })
        }else if (self.newPasswordTextField.text?.count)! < 8 || (self.newPasswordTextField.text?.count)! > 20{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE", comment: ""), messageStr: NSLocalizedString("valid_passworddigits", comment: "") , completion: {(result) in
                self.newPasswordTextField.becomeFirstResponder()
            })
        }else if self.confirmPasswordTextField.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE", comment: ""), messageStr: NSLocalizedString("valid_invalidpwd", comment: "") , completion: {(result) in
                self.confirmPasswordTextField.becomeFirstResponder()
            })
        }else if (self.confirmPasswordTextField.text?.count)! < 8 || (self.confirmPasswordTextField.text?.count)! > 20{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE", comment: ""), messageStr: NSLocalizedString("valid_passworddigits", comment: "") , completion: {(result) in
                self.confirmPasswordTextField.becomeFirstResponder()
            })
        }else if self.newPasswordTextField.text != self.confirmPasswordTextField.text{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE", comment: ""), messageStr: NSLocalizedString("valid_invalidpwd", comment: "") , completion: {(result) in
                self.confirmPasswordTextField.becomeFirstResponder()
            })
        }else {
            if UserDefaults.standard.value(forKey: "customerOrgid") as? String == nil{
                self.orgnaizationAPi(completion:{(result) in
                    DispatchQueue.main.async {
                        self.resetPasswordApi(orgId: result)
                    }
                })
            }else{
                var orgId = ""
                orgId = Constants.getValueFromUserDefults(for:"customerOrgid") as! String
                self.resetPasswordApi(orgId: orgId)
            }
        }
    }
    func resetPasswordApi(orgId:String){
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        let forgotEmail = UserDefaults.standard.value(forKey: "forgotEmail") as! String
        bodyReq = ["email":forgotEmail,"newPassword":newPasswordTextField.text!,"org_id":orgId]
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.resetPasswordURL, method: "POST", token: "", body: "", productBody: bodyData as NSData) { (data,error,response) in
               
                if let httpResponse = response as? HTTPURLResponse{
                   // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            let alertController = UIAlertController(title: "RYTLE", message:NSLocalizedString("password_updatesuccess", comment:""), preferredStyle: UIAlertController.Style.alert)
                            alertController.addAction(UIAlertAction(title:NSLocalizedString("lbl_ok", comment: "") , style: UIAlertAction.Style.default,handler: { action in
                                self.presentingViewController?.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
                            }
                            ))
                            self.present(alertController, animated: false, completion: nil)
                        }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "RP_505", controller: self)
                        }
                        break
                    default:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                  }
                }
            }
        }
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
}

