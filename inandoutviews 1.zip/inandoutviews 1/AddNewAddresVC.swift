//
//  AddressDetailsViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by AMT on 12/11/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import Firebase

struct CountryCode1 {
    var code: String?
    var name: String?
    var phoneCode: String?
    init(code: String?, name: String?, phoneCode: String?) {
        self.code = code
        self.name = name
        self.phoneCode = phoneCode
    }
}
struct GetAddressType{
    var parcel_type: String?
    var parcel_type_id: String?
    init(parcel_type: String?, parcel_type_id: String?) {
        self.parcel_type = parcel_type
        self.parcel_type_id = parcel_type_id
    }
}
class AddNewAddresVC: UIViewController,UITextFieldDelegate,countryCodeProtocol {
    
    @IBOutlet weak var phoneNumberField: ACFloatingTextfield!
    @IBOutlet weak var nameField: ACFloatingTextfield!
    @IBOutlet weak var emailField: ACFloatingTextfield!
    @IBOutlet weak var typeOffParcelTxt: UITextField!
    @IBOutlet weak var conutryCodeTxt: UITextField!
    @IBOutlet weak var extensionCodeTxt: UITextField!
    @IBOutlet weak var flatNumberTxt: ACFloatingTextfield!
    @IBOutlet weak var contentViewHC: NSLayoutConstraint!
    @IBOutlet weak var contentViewObj: UIView!
    @IBOutlet weak var scroolContentViewObj: UIView!
    @IBOutlet weak var addressViewObj: UIView!
    @IBOutlet weak var confirmBtm: UIButton!
    @IBOutlet weak var addressBtn: UIButton!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var addressLbl: UILabel!
    @IBOutlet weak var addressLblHC: NSLayoutConstraint!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var typeofParcel: UILabel!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    @IBOutlet weak var scrollViewObj: UIScrollView!
    @IBOutlet weak var contentViewTC: NSLayoutConstraint!

    var getAddressTypeNamesArray = [String]()
    var getAddressTypeArray = [GetAddressType]()

    var activeField: UITextField?
    var editAddessArray = NSMutableArray()
    var countriesObj = [CountryCode1]()
    var controlerName : String = String()
    var addressObjStr : String = String()
    var nameObjStr : String = String()
    var zipcodeObjStr : String = String()
    var contactNoObjStr : String = String()
    var emailObjStr : String = String()
    var houseNoObjStr : String = String()
    var streetObjStr1 : String = String()
    var streetObjStr2: String = String()
    var streetObjStr3 : String = String()
    var cityObjStr : String = String()
    var stateObjStr : String = String()
    var countryObjStr : String = String()
    var typeofAddressObjStr : String = String()
    var fullAddress = ""
    var typeOfAddressID = ""
    var latitudeObjStr : String = String()
    var longitudeObjStr : String = String()
    let appdeletegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    let addressDropDown = DropDown()
    var tapGestureRecognizer = UITapGestureRecognizer()
    lazy var dropDowns: [DropDown] = {
        return [
            self.addressDropDown
        ]
    }()
    override func viewDidLoad(){
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.initialSetup()
        self.intialConstraintsSetup()
        self.getCountryCode()
        self.editAddress()
        self.gesturesSetup()
        self.registerForKeyboardNotifications()
        DispatchQueue.global().async {
            self.getParcelTypeApi(status: "background")
        }
    }
    func gesturesSetup(){
        tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        self.view.isUserInteractionEnabled = true
        self.view.addGestureRecognizer(tapGestureRecognizer)
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        self.nameField.resignFirstResponder()
        self.emailField.resignFirstResponder()
        self.phoneNumberField.resignFirstResponder()
        self.flatNumberTxt.resignFirstResponder()
        self.extensionCodeTxt.resignFirstResponder()
    }
    func registerForKeyboardNotifications(){
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    deinit{
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        self.scrollViewObj.isScrollEnabled = true
        var info = notification.userInfo!
        var keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        if keyboardSize?.height == 0{
            keyboardSize?.height = 258
        }
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: keyboardSize!.height, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollViewObj.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
    }
    @objc func keyboardWillBeHidden(notification: NSNotification){
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        self.view.endEditing(true)
        self.scrollViewObj.isScrollEnabled = true
    }
    func sendCountryCode(code: String) {
        self.conutryCodeTxt.text = code
    }
    func intialConstraintsSetup(){
        if appdeletegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func editAddress(){
        if controlerName == "EditPickupDetails" || controlerName == "EditReceiverDetails"{
            self.nameField.text = self.editAddessArray.object(at: 3) as? String
            self.emailField.text = self.editAddessArray.object(at: 4) as? String
            if self.editAddessArray.object(at: 5) as? String != ""{
                self.phoneNumberField.text = self.editAddessArray.object(at: 5) as? String
                self.extensionCodeTxt.isUserInteractionEnabled = true
            }
          //  self.typeOffParcelTxt.text = self.editAddessArray.object(at: 6) as? String
            self.splitCountryCode()
            if self.editAddessArray.object(at: 7) as? String != ""{
                self.flatNumberTxt.text = self.editAddessArray.object(at: 7) as? String
            }
            if self.editAddessArray.object(at: 8) as? String != ""{
                self.extensionCodeTxt.text = self.editAddessArray.object(at: 8) as? String
                self.extensionCodeTxt.isUserInteractionEnabled = true
            }
        }
    }
    func splitCountryCode(){
        if let str1 = self.phoneNumberField.text?.components(separatedBy: " "){
            let count = str1.count
            switch count {
            case 0:
                break;
            case 1:
                self.conutryCodeTxt.text = str1[0]
                break;
            case 2:
                self.conutryCodeTxt.text = str1[0]
                self.phoneNumberField.text = str1[1]
            default:
                break;
            }
        }
    }
    func getCountryCode(){
        countriesObj = self.countryNamesByCode()
        if let countryCode = (Locale.current as NSLocale).object(forKey: .countryCode) as? String {
            //  print("countryCode",countryCode)
            for country in countriesObj{
                if countryCode == country.code{
                    self.conutryCodeTxt.text = country.phoneCode
                }
            }
        }
    }
    func countryNamesByCode() -> [CountryCode1] {
        let countries = [CountryCode1]()
        do{
            if let file = Bundle.main.url(forResource: "countryCodes", withExtension: "json") {
                let data = try Data(contentsOf: file)
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                if json is [String: Any] {
                    // json is a dictionary
                } else if let object = json as? [Any] {
                    for jsonObject in object {
                        guard let countryObj = jsonObject as? NSDictionary else {
                            return countries
                        }
                        guard let code = countryObj["code"] as? String, let phoneCode = countryObj["dial_code"] as? String, let name = countryObj["name"] as? String else {
                            return countries
                        }
                        let country1 = CountryCode1(code: code, name: name, phoneCode: phoneCode)
                        countriesObj.append(country1)
                    }
                } else {
                }
            }else{
            }
        }catch{
        }
        return countriesObj
    }
    @IBAction func contentViewTapped(_ sender: UIControl) {
//        self.nameField.resignFirstResponder()
//        self.emailField.resignFirstResponder()
//        self.phoneNumberField.resignFirstResponder()
//        self.flatNumberTxt.resignFirstResponder()
//        self.extensionCodeTxt.resignFirstResponder()
    }
    func initialSetup(){
        DispatchQueue.main.async {
            self.scrollViewObj.isScrollEnabled = true
            self.scrollViewObj.contentSize = CGSize(width: self.scrollViewObj.frame.width, height: self.scroolContentViewObj.frame.origin.y+self.scroolContentViewObj.frame.size.height+60);
        }
        self.nameField.placeholder = NSLocalizedString("txt_receivername", comment: "")
        self.nameField.font = AppFont.regularTextFont
        self.emailField.placeholder = NSLocalizedString("txt_eamil", comment: "")
        self.emailField.font = AppFont.regularTextFont
        self.flatNumberTxt.placeholder = NSLocalizedString("txt_flatnumber", comment: "")
        self.flatNumberTxt.font = AppFont.regularTextFont
        self.conutryCodeTxt.placeholder = NSLocalizedString("lbl_code", comment: "")
        self.conutryCodeTxt.font = AppFont.regularTextFont
        self.extensionCodeTxt.placeholder = NSLocalizedString("tex_ext", comment: "")
        self.extensionCodeTxt.font = AppFont.regularTextFont
        self.phoneNumberField.placeholder = NSLocalizedString("txt_contactno",comment: "")
        self.phoneNumberField.font = AppFont.regularTextFont
        self.typeofParcel.text = NSLocalizedString("txt_typeofparcel",comment: "")
        self.typeOffParcelTxt.font = AppFont.regularTextFont
        self.titleLbl.text = NSLocalizedString("lbl_addressdetails", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        self.titleLbl.textColor = AppColors.whiteColorRGB
        if appdeletegate.IS_IPHONE5{
            self.titleLbl.font = UIFont(name: "HelveticaNeue", size: 18)
        }
        self.nameField.font = AppFont.regularTextFont
        self.emailField.font = AppFont.regularTextFont
        self.phoneNumberField.font = AppFont.regularTextFont
        self.confirmBtm.setTitle(NSLocalizedString("btn_confirm", comment: ""), for: .normal)
        self.confirmBtm.backgroundColor = AppColors.greenColorRGB
        self.confirmBtm.titleLabel?.textColor = AppColors.whiteColorRGB
        self.confirmBtm.titleLabel?.font = AppFont.boldTextFont
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.addressLbl.text = self.fullAddress
        var height : CGFloat = 0
        height += self.heightForView(text: self.addressLbl.text!, font: UIFont(name: "HelveticaNeue", size: 17)!, width: self.addressLbl.frame.size.width)
        self.addressLblHC.constant = height
        self.addressLbl.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.addressLbl.numberOfLines = 0
        self.addressLbl.sizeToFit()
        if appdeletegate.IS_IPHONE5{
            self.contentViewTC.constant = 20
        }
        self.contentViewHC.constant = 10+50+10+50+10+50+1+50+15+height+15+50+10
        let dropdown = UIButton()
        dropdown.setImage(UIImage(named:"icon_downarrow"), for: .normal)
        dropdown.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: -16, bottom: 0, right: 0)
        dropdown.frame = CGRect(x: CGFloat(self.typeOffParcelTxt.frame.size.width - 25), y: CGFloat(5), width: CGFloat(25), height: CGFloat(25))
        dropdown.isUserInteractionEnabled = true
        self.typeOffParcelTxt.rightView = dropdown
        self.typeOffParcelTxt.rightViewMode = .always
        let dropdown1 = UIButton()
        dropdown1.setImage(UIImage(named:"icon_downarrow"), for: .normal)
        dropdown1.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: -16, bottom: 0, right: 0)
        dropdown1.frame = CGRect(x: CGFloat(self.typeOffParcelTxt.frame.size.width - 25), y: CGFloat(5), width: CGFloat(25), height: CGFloat(25))
        dropdown1.isUserInteractionEnabled = true
        self.conutryCodeTxt.rightView = dropdown1
        self.conutryCodeTxt.rightViewMode = .always
       // self.setupAddressDropDown()
        self.extensionCodeTxt.isUserInteractionEnabled = false
    }
    func setupAddressDropDown(){
        getAddressTypeNamesArray.append(NSLocalizedString("txt_typeofparcel", comment: ""))
        for (index,parcelTypeDetails) in self.getAddressTypeArray.enumerated(){
            let parcelTypeList = parcelTypeDetails
            if controlerName == "EditPickupDetails" || controlerName == "EditReceiverDetails"{
                if ((self.editAddessArray.object(at: 6) as? String)?.contains(String(parcelTypeList.parcel_type_id!)))!{
                    self.typeOffParcelTxt.text = parcelTypeList.parcel_type!
                    self.typeOfAddressID = String(parcelTypeList.parcel_type_id!)
                }
            }else{
                if index == 0{
                    self.typeOffParcelTxt.text = parcelTypeList.parcel_type!
                    self.typeOfAddressID = String(parcelTypeList.parcel_type_id!)
                }
            }
           // print(parcelTypeList.parcel_type!)
            getAddressTypeNamesArray.append(parcelTypeList.parcel_type!)
        }
        addressDropDown.anchorView = self.addressViewObj
        addressDropDown.dismissMode = .onTap
        addressDropDown.direction = .top
        addressDropDown.bottomOffset = CGPoint(x: 0, y: addressViewObj.bounds.height)
        addressDropDown.dataSource = self.getAddressTypeNamesArray
      /*  addressDropDown.dataSource = [NSLocalizedString("txt_typeofparcel",comment: ""),NSLocalizedString("valid_home",comment: ""),
                                      NSLocalizedString("valid_office",comment: "")
        ]*/
        addressDropDown.selectionAction = { [unowned self] (index, item) in
            if item == NSLocalizedString("txt_typeofparcel", comment: ""){
            }else{
                let getaddresstype = self.getAddressTypeArray[index-1]
               // print(getaddresstype.parcel_type_id)
               self.typeOffParcelTxt.text = item
              self.typeOfAddressID = String(getaddresstype.parcel_type_id!)
            }
        }
    }
    func heightForView(text:String, font:UIFont, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRect(x:0, y:0, width:width, height:10000))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    override func viewDidLayoutSubviews() {
        DispatchQueue.main.async {
            self.scrollViewObj.isScrollEnabled = true
           // self.scrollViewObj.translatesAutoresizingMaskIntoConstraints = true
            self.scrollViewObj.contentSize = CGSize(width: self.scrollViewObj.frame.width, height: self.scroolContentViewObj.frame.origin.y+self.scroolContentViewObj.frame.size.height+60);
        }
    }
    @IBAction func btnsTapped(_ sender: UIButton){
        let btn = sender as UIButton
        if btn.tag == 10{
            Analytics.logEvent("AddNewAddresVC_CancelButtonTapped", parameters: nil)
            dismissKeybord()
            self.dismiss(animated: true, completion: nil)
        }else if btn.tag == 20{
            dismissKeybord()
            if self.getAddressTypeArray.count == 0{
                self.getParcelTypeApi(status: "")
            }else{
                self.addressDropDown.show()
            }
        }else if btn.tag == 30{
            self.callApisForPickuporReceiverAddress()
        }else if btn.tag == 40{
            self.dismissKeybord()
            self.navigateToSearchCountryCode()
        }
    }
    func navigateToSearchCountryCode(){
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let countryCode = storyBoard.instantiateViewController(withIdentifier: "SearchCountryCodeVC") as! SearchCountryCodeVC
        countryCode.delegate = self
        self.present(countryCode, animated: true, completion: nil)
    }
    func disableConfirmButtonIneteraction(){
        self.confirmBtm.backgroundColor = AppColors.lightGrayColorRGB
        self.confirmBtm.isUserInteractionEnabled = false
    }
    func enableConfirmButtonIneteraction(){
        self.confirmBtm.backgroundColor = AppColors.greenColorRGB
        self.confirmBtm.isUserInteractionEnabled = true
    }
    func getParcelTypeApi(status: String){
        if status == "background"{
        }else{
            IJProgressView.shared.showProgressView(view)
        }
        var token = String()
        var sessionToken = ""
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            sessionToken = "Bearer" + " " + token
        }
       // print(sessionToken)
        APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.getAddressTypeURL
        , method: "GET", token:sessionToken, body: "", productBody: nil) { (data,error,response) in
            if let httpResponse = response as? HTTPURLResponse{
               print("httpResponse status code \(httpResponse.statusCode)")
                switch(httpResponse.statusCode){
                case 200:
                    if let receivedData = data{
                        do{
                            let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                                if let Result = resultDic as? [String:Any]{
                                  //  print("Result",Result)
                                    let newArray  = Result["Msg"] as? [[String:Any]]
                                    for resultDic in newArray!{
                                        var parcelType = ""
                                        var parcelTypeID = ""
                                        if let parcelTypeStr = resultDic["add_type_name"] as? String{
                                            parcelType = parcelTypeStr
                                        }
                                        if let parcelTypeIdStr = resultDic["add_type_id"] as? Int{
                                            parcelTypeID = String(parcelTypeIdStr)
                                        }
                                        let parcelTypeList = GetAddressType(parcel_type: parcelType, parcel_type_id: parcelTypeID)
                                        self.getAddressTypeArray.append(parcelTypeList)
                                    }
                                    self.setupAddressDropDown()
                                }
                            }
                        }catch {
                            self.somethingWentWrong()
                        }
                    }
                    break
                case 500:
                    self.somethingWentWrong()
                    break
                case 505:
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "GetAddressType_505", controller: self)
                    }
                    break
                case 506:
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "GetAddressType_506", controller: self)
                    }
                    break
                case 498:
                    DispatchQueue.main.async {
                        self.tokenExpireAlert()
                    }
                    break
                default:
                    self.somethingWentWrong()
                }
            }else{
                self.somethingWentWrong()
            }
        }
    }
    func callApisForPickuporReceiverAddress(){
        if nameField.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_name",comment: ""), completion: {(result) in
                self.nameField.becomeFirstResponder()
            })
            return
        }else if emailField.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_email",comment: ""), completion: {(result) in
                self.emailField.becomeFirstResponder()
            })
            return
        }else if Constants().isValidEmail(emailField.text!) == false{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_email1",comment: ""), completion: {(result) in
                self.emailField.becomeFirstResponder()
            })
            return
        };
        if self.phoneNumberField.text?.count != 0 && self.conutryCodeTxt.text?.count == 0 || self.phoneNumberField.text?.count != 0 && self.conutryCodeTxt.text?.count == 0 && self.extensionCodeTxt.text?.count != 0{
                self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_country",comment: ""), completion: {(result) in
                })
                return
        }else if self.phoneNumberField.text?.count == 0 && self.extensionCodeTxt.text?.count != 0 ||  self.phoneNumberField.text?.count == 0 && self.extensionCodeTxt.text?.count != 0 && self.conutryCodeTxt.text?.count == 0{
                self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_phno",comment: ""), completion: {(result) in
                })
                return
        }
        if typeOffParcelTxt.text  == NSLocalizedString("txt_typeofparcel",comment:""){
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_parceltype",comment: ""), completion: {(result) in
            })
            return
        }else if typeOffParcelTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_parceltype",comment: ""), completion: {(result) in
            })
            return
        }else if self.phoneNumberField.text?.count == 0{
           self.mobileParcelConfirmalert()
            return
        }else{
            self.dismissKeybord()
            if self.ineternetAlert() == false{
                return
            }
            self.disableConfirmButtonIneteraction()
            self.callingApisMethods()
        }
    }
    func callingApisMethods(){
        let customer_id = UserDefaults.standard.value(forKey: "customer_id") as! String
        var flatNumber = ""; var extensionCodeNumber = "";var mobileNumber = ""
        if self.flatNumberTxt.text?.count != 0{
            flatNumber = self.flatNumberTxt.text!
        }
        if self.extensionCodeTxt.text?.count != 0{
            extensionCodeNumber = self.extensionCodeTxt.text!
        }
        if self.phoneNumberField.text?.count != 0{
         mobileNumber = self.conutryCodeTxt.text! + " " + self.phoneNumberField.text!
        }
        if controlerName == "PickupDetails"{
            Analytics.logEvent("AddNewAddresVC_AddNewPickAddressButtonTapped", parameters: nil)
            self.pickupAddNewAddressApi(p_fullname: self.nameField.text!, p_email_id: self.emailField.text!, p_mobile_no: mobileNumber, customer_id:customer_id , house_noStr: houseNoObjStr, streetStr1: streetObjStr1, streetStr2: streetObjStr2, streetStr3: streetObjStr3, zip_code: zipcodeObjStr, state: stateObjStr, city: cityObjStr, country: countryObjStr, longitude: longitudeObjStr, latitude: latitudeObjStr, address_type: self.typeOfAddressID,flatno: flatNumber, extensionCode: extensionCodeNumber)
        }else if controlerName == "ReceiverDetails"{
            Analytics.logEvent("AddNewAddresVC_AddNewReceiverAddressButtonTapped", parameters: nil)
            self.receiverAddNewAddressApi(d_fullname: self.nameField.text!, d_email_id: self.emailField.text!, d_mobile_no: mobileNumber, customer_id: customer_id , house_noStr: houseNoObjStr, streetStr1: streetObjStr1, streetStr2: streetObjStr2, streetStr3: streetObjStr3, zip_code: zipcodeObjStr, state: stateObjStr, city: cityObjStr, country: countryObjStr, longitude: longitudeObjStr, latitude: latitudeObjStr, address_type: self.typeOfAddressID,flatno: flatNumber, extensionCode: extensionCodeNumber)
        }else if controlerName == "EditReceiverDetails"{
            Analytics.logEvent("AddNewAddresVC_EditReceiverAddressButtonTapped", parameters: nil)
            self.editReceiverAddNewAddressApi(d_fullname: self.nameField.text!, d_email_id: self.emailField.text!, d_mobile_no: mobileNumber, customer_id: customer_id , house_noStr: houseNoObjStr, streetStr1: streetObjStr1, streetStr2: streetObjStr2, streetStr3: streetObjStr3, zip_code: zipcodeObjStr, state: stateObjStr, city: cityObjStr, country: countryObjStr, longitude: longitudeObjStr, latitude: latitudeObjStr, address_type: self.typeOfAddressID,flatno: flatNumber, extensionCode: extensionCodeNumber)
        }else if controlerName == "EditPickupDetails"{
            Analytics.logEvent("AddNewAddresVC_EditPickupAddressButtonTapped", parameters: nil)
            self.editPickupAddNewAddressApi(p_fullname: self.nameField.text!, p_email_id: self.emailField.text!, p_mobile_no: mobileNumber, customer_id:customer_id , house_noStr: houseNoObjStr, streetStr1: streetObjStr1, streetStr2: streetObjStr2, streetStr3: streetObjStr3, zip_code: zipcodeObjStr, state: stateObjStr, city: cityObjStr, country: countryObjStr, longitude: longitudeObjStr, latitude: latitudeObjStr, address_type: self.typeOfAddressID,flatno: flatNumber, extensionCode: extensionCodeNumber)
        }
    }
    func mobileParcelConfirmalert(){
        let alert = UIAlertController(title:nil , message:NSLocalizedString("alert_nomobilenumberforparcel", comment: ""), preferredStyle: .alert)
        let cancelAction = UIAlertAction(title:NSLocalizedString("btn_cancel", comment:""), style: .default) { (alert: UIAlertAction!) -> Void in
        }
        cancelAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        let clearAction = UIAlertAction(title:NSLocalizedString("btn_confirmbook", comment: ""), style: .default) { (alert: UIAlertAction!) -> Void in
            self.callingApisMethods()
        }
        clearAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        alert.addAction(cancelAction)
        alert.addAction(clearAction)
        present(alert, animated: true, completion:nil)
    }
    func receiverAddNewAddressApi(d_fullname : String ,d_email_id :String, d_mobile_no : String,customer_id : String,house_noStr : String ,streetStr1 : String ,streetStr2: String, streetStr3 : String ,zip_code : String,state :String, city :String,country:String,longitude: String, latitude:String,address_type:String,flatno:String,extensionCode:String){
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        var orgId = ""
        orgId = Constants.getValueFromUserDefults(for:"customerOrgid") as! String
        bodyReq = ["d_fullname":d_fullname,"d_email_id":d_email_id,"house_no": house_noStr,"d_mobile_no":d_mobile_no,"customer_id":customer_id,"street1": streetStr1,"street2":streetStr2,"street3":streetStr3,"zip_code":zip_code,"state" : state,"city":city,"country":country,"latitude" : latitude,"longitude":longitude,"address_type":address_type,"flat_no":flatno,"extension":extensionCode,"org_id":orgId]
        
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            let token = UserDefaults.standard.value(forKey: "usertoken") as! String
            let sessionStr = "Bearer " + token
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.createDeliveryAddressURl , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
               
                if let httpResponse = response as? HTTPURLResponse{
                   // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                     DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                        self.appdeletegate.recieverAddAddress = "yes"
                        self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
                        }
                        break
                    case 500:
                        self.somethingWentWrong()
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            self.enableConfirmButtonIneteraction()
                        errorCodesMessageDisplayAlert(statusCode: "PickupAdd_505", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                        break
                    default:
                       self.somethingWentWrong()
                    }
                }else{
                   self.somethingWentWrong()
                }
            }
        }
    }
    func editReceiverAddNewAddressApi(d_fullname:String,d_email_id:String, d_mobile_no:String,customer_id:String,house_noStr : String ,streetStr1 : String,streetStr2:String, streetStr3:String ,zip_code:String,state:String, city:String,country:String,longitude:String,latitude:String,address_type:String,flatno:String,extensionCode:String){
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        bodyReq = ["d_fullname":d_fullname,"d_email_id":d_email_id, "house_no" : house_noStr,"d_mobile_no" : d_mobile_no, "customer_id": customer_id,"street1": streetStr1,"street2":streetStr2,"street3":streetStr3 ,"zip_code":zip_code,"state" : state,"city":city,"country" : country,"latitude" : latitude ,"longitude":longitude , "address_type" : address_type,"delivery_add_id": self.editAddessArray.object(at: 2) as! String,"landmark":"","flat_no":flatno,"extension":extensionCode]
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            let token = UserDefaults.standard.value(forKey: "usertoken") as! String
            let sessionStr = "Bearer " + token
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.updateDeliveryAddress , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                
                if let httpResponse = response as? HTTPURLResponse{
                    IJProgressView.shared.hideProgressView()
                   // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                        self.appdeletegate.recieverAddAddress = "yes"
                        self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
                        }
                        break
                    case 500:
                       self.somethingWentWrong()
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            self.enableConfirmButtonIneteraction()
                        errorCodesMessageDisplayAlert(statusCode: "PickupUpdate_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            self.enableConfirmButtonIneteraction()
                        errorCodesMessageDisplayAlert(statusCode: "ReceiverDelete_506", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                        break
                    default:
                       self.somethingWentWrong()
                    }
                }else{
                    self.somethingWentWrong()
                }
            }
        }
    }
    func somethingWentWrong(){
        DispatchQueue.main.async {
            IJProgressView.shared.hideProgressView()
            self.enableConfirmButtonIneteraction()
            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
        }
    }
    func pickupAddNewAddressApi(p_fullname : String ,p_email_id :String, p_mobile_no : String,customer_id : String,house_noStr : String ,streetStr1 : String ,streetStr2: String, streetStr3 : String ,zip_code : String,state :String, city :String,country:String,longitude: String, latitude:String,address_type:String,flatno:String,extensionCode:String){
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        bodyReq = ["p_fullname":p_fullname,"p_email_id":p_email_id, "house_no" : house_noStr,"p_mobile_no" : p_mobile_no, "customer_id": customer_id,"street1": streetStr1,"street2":streetStr2,"street3":streetStr3 ,"zip_code":zip_code,"state" : state,"city":city,"country" : country,"latitude" : latitude ,"longitude":longitude , "address_type" : address_type,"flat_no":flatno,"extension":extensionCode]
        
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            let token = UserDefaults.standard.value(forKey: "usertoken") as! String
            let sessionStr = "Bearer " + token
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.createPickupAddressURL , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
               
                if let httpResponse = response as? HTTPURLResponse{
                    IJProgressView.shared.hideProgressView()
                   // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            self.appdeletegate.pickAddAddress = "yes"
                    self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
                        }
                        break
                    case 500:
                      self.somethingWentWrong()
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            self.enableConfirmButtonIneteraction()
                        errorCodesMessageDisplayAlert(statusCode: "PickupAdd_505", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                        break
                    default:
                        self.somethingWentWrong()
                    }
                }else{
                   self.somethingWentWrong()
                }
            }
        }
    }
    func editPickupAddNewAddressApi(p_fullname : String ,p_email_id :String, p_mobile_no : String,customer_id : String,house_noStr : String ,streetStr1 : String ,streetStr2: String, streetStr3 : String ,zip_code : String,state :String, city :String,country:String,longitude: String, latitude:String,address_type:String,flatno:String,extensionCode:String){
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        bodyReq = ["p_fullname":p_fullname,"p_email_id":p_email_id, "house_no" : house_noStr,"p_mobile_no" : p_mobile_no, "customer_id": customer_id,"street1": streetStr1,"street2":streetStr2,"street3":streetStr3 ,"zip_code":zip_code,"state" : state,"city":city,"country" : country,"latitude" : latitude ,"longitude":longitude , "address_type" : address_type,"pick_add_id":editAddessArray.object(at: 2) as! String,"landmark":"","flat_no":flatno,"extension":extensionCode]
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            let token = UserDefaults.standard.value(forKey: "usertoken") as! String
            let sessionStr = "Bearer " + token
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.updatePickupAddress , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
               
                if let httpResponse = response as? HTTPURLResponse{
                    IJProgressView.shared.hideProgressView()
                  //  print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                        self.appdeletegate.pickAddAddress = "yes"
                        self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
                        }
                        break
                    case 500:
                        self.somethingWentWrong()
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            self.enableConfirmButtonIneteraction()
                        errorCodesMessageDisplayAlert(statusCode: "PickupUpdate_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            self.enableConfirmButtonIneteraction()
                        errorCodesMessageDisplayAlert(statusCode: "PickupDelete_506", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                        break
                    default:
                        self.somethingWentWrong()
                    }
                }else{
                    self.somethingWentWrong()
                }
            }
        }
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    @objc func dismissKeybord(){
        self.nameField.resignFirstResponder()
        self.emailField.resignFirstResponder()
        self.phoneNumberField.resignFirstResponder()
        self.flatNumberTxt.resignFirstResponder()
        self.extensionCodeTxt.resignFirstResponder()
    }
    func textFieldDidBeginEditing(_ textField: UITextField){
        if textField == self.nameField{
            self.nameField.returnKeyType = .next
        }else if textField == self.emailField{
            self.emailField.returnKeyType = .next
            self.emailField.keyboardType = .emailAddress
        }else if textField == self.phoneNumberField{
            self.phoneNumberField.keyboardType = .numberPad
            self.addBarBtnToKeyboard(textfield: self.phoneNumberField)
        }else if textField == self.extensionCodeTxt{
            self.extensionCodeTxt.keyboardType = .numberPad
            self.addBarBtnToKeyboard(textfield: self.extensionCodeTxt)
        }else if textField == self.flatNumberTxt{
            self.flatNumberTxt.keyboardType = .default
            self.flatNumberTxt.returnKeyType = .done
            self.addBarBtnToKeyboard(textfield: self.flatNumberTxt)
        }
         activeField = textField
    }
  
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == self.phoneNumberField{
            if string.count > 0{
                self.extensionCodeTxt.isUserInteractionEnabled = true
            }else{
                let textFieldString = textField.text! as NSString
                if textFieldString.replacingCharacters(in: range, with: string).count == 0{
                self.extensionCodeTxt.isUserInteractionEnabled = false
                }
            }
        }
        if textField == self.extensionCodeTxt{
            guard case let textFieldString as NSString = textField.text,
                textFieldString.replacingCharacters(in: range, with: string).count <= 4 else {
                    return false
            }
        }
        return true
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
       
        switch textField{
        case self.nameField:
            self.emailField.becomeFirstResponder()
            break
        case self.emailField:
            self.phoneNumberField.becomeFirstResponder()
            break
        case self.phoneNumberField:
            self.flatNumberTxt.becomeFirstResponder()
            break
        case self.flatNumberTxt:
            textField.resignFirstResponder()
            break
        default:
            textField.resignFirstResponder()
        }
        return true
    }
    func addBarBtnToKeyboard(textfield:UITextField){
        let keyPadToolBar = UIToolbar()
        keyPadToolBar.barStyle = UIBarStyle.blackTranslucent
        keyPadToolBar.barTintColor = AppColors.greenColorRGB
        keyPadToolBar.sizeToFit()
        var doneButton = UIBarButtonItem()
        var spaceButton = UIBarButtonItem()
        var nextButton =  UIBarButtonItem()
        if textfield == self.phoneNumberField || textfield == self.extensionCodeTxt{
           doneButton = UIBarButtonItem(title:NSLocalizedString("keyboard_done", comment: ""), style: UIBarButtonItem.Style.done, target: self, action: #selector(AddNewAddresVC.dismissKeybord))
             spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace , target: self, action: nil)
             nextButton = UIBarButtonItem(title:NSLocalizedString("keyboard_next", comment: ""), style: UIBarButtonItem.Style.done, target: self, action: #selector(AddNewAddresVC.nextDismissKeybordButtonTapped(_sender:)))
            if textfield == self.phoneNumberField{
                nextButton.tag = 10
            }else if textfield == self.extensionCodeTxt{
                nextButton.tag = 20
            }
            doneButton.tintColor = AppColors.whiteColorRGB
            nextButton.tintColor = AppColors.whiteColorRGB
            keyPadToolBar.setItems([doneButton,spaceButton,nextButton], animated: true)
            textfield.inputAccessoryView = keyPadToolBar
        }
    }
    @objc func nextDismissKeybordButtonTapped(_sender : UIBarButtonItem){
        if _sender.tag == 10{
            self.phoneNumberField.resignFirstResponder()
            self.flatNumberTxt.becomeFirstResponder()
        }else if _sender.tag == 20{
            self.extensionCodeTxt.resignFirstResponder()
            self.flatNumberTxt.becomeFirstResponder()
        }
    }
}

