//
//  LeftViewController.swift
//  RYTLE
//
//  Created by Admin on 19/04/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import UserNotifications
import Firebase

protocol sideMenuProtocol {
    func menuBtnClosedStatus()
}
class LeftViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet var menuTableObject: UITableView!
    @IBOutlet var menuButton: UIButton!
    var imgView = UIImageView()
    var myActivityIndicator = UIActivityIndicatorView()
    var AvailableLabel = UILabel()
    var menuArray :NSMutableArray = NSMutableArray()
    var delegate : sideMenuProtocol?
    let appdelegate :AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var rider_availabilitystatus = ""
    var switchBtn = UIButton()
    var count : CGFloat =  0
    var appVersion = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetup()
        NotificationCenter.default.addObserver(self, selector: #selector(LeftViewController.updateProfileImage) , name:NSNotification.Name(rawValue : "sidemenu") , object: nil)
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func initialSetup(){
        self.navigationController?.isNavigationBarHidden = true
        self.menuTableObject.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height)
        if let versionStr = Bundle.main.infoDictionary?["CFBundleShortVersionString"]  as? String {
            print(versionStr)
            self.appVersion = NSLocalizedString("lbl_appversion", comment: "") + versionStr
        }
        menuArray.add(NSLocalizedString("lbl_profileside", comment: ""))
        menuArray.add(NSLocalizedString("lbl_parcelhistory", comment: ""))
        menuArray.add(NSLocalizedString("lbl_settingcp", comment: ""))
        menuArray.add(self.appVersion)
        menuArray.add(NSLocalizedString("lbl_logout", comment: ""))
        self.menuTableObject.register(UINib(nibName: "SideMenuTC", bundle: nil), forCellReuseIdentifier: "SideMenuTC")
        self.menuTableObject.backgroundColor = UIColor.white
        self.menuTableObject.isScrollEnabled = false

    }
    func setActivityIndicator(){
        self.myActivityIndicator.frame = CGRect(x: 0, y: 0, width: 30, height: 30);
        myActivityIndicator.style =
            UIActivityIndicatorView.Style.gray
        myActivityIndicator.center = self.imgView.center
        myActivityIndicator.hidesWhenStopped = true
        self.imgView.addSubview(self.myActivityIndicator)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
        appdelegate.profilePicStatusSideMenu = "yes"
      //  UIApplication.shared.isStatusBarHidden = true
        let statusBar: UIView = UIApplication.shared.value(forKey: "statusBar") as! UIView
        statusBar.isHidden = true
        menuTableObject.reloadData()
    }
    override func viewDidAppear(_ animated: Bool){
        super.viewDidAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
        //UIApplication.shared.isStatusBarHidden = true
        let statusBar: UIView = UIApplication.shared.value(forKey: "statusBar") as! UIView
        statusBar.isHidden = true
    }
    override func viewDidDisappear(_ animated: Bool){
        super.viewDidDisappear(animated)
       // UIApplication.shared.isStatusBarHidden = false
        let statusBar: UIView = UIApplication.shared.value(forKey: "statusBar") as! UIView
        statusBar.isHidden = false
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        appdelegate.profilePicStatusSideMenu = ""
        //UIApplication.shared.isStatusBarHidden = false
        let statusBar: UIView = UIApplication.shared.value(forKey: "statusBar") as! UIView
        statusBar.isHidden = false
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.menuTableObject.dequeueReusableCell(withIdentifier: "SideMenuTC") as! SideMenuTC
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        cell.menuLabel.text = self.menuArray.object(at: indexPath.row) as? String
        cell.menuLabel.textColor = AppColors.greenColorRGB
        cell.menuLabel.font = AppFont.regularTextFont
        cell.isUserInteractionEnabled = true
        cell.borderLbl.backgroundColor = AppColors.lightGrayColorRGB
        cell.isUserInteractionEnabled = true
        if indexPath.row == 3{
            cell.isUserInteractionEnabled = false
        }
        if indexPath.row == 4{
            cell.menuLabel.textColor = AppColors.blackColorRGB
            cell.borderLbl.isHidden = true
            cell.logOutImg.isHidden = false
            cell.logOutImg.frame = CGRect(x: 12.5, y: 14, width: 25, height: 25)
        }
        return cell
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return headerView()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        if appdelegate.IS_IPADPRO9 || appdelegate.IS_IPADPRO10 || appdelegate.IS_IPADPRO12{
            return 300
        }else{
            return 250
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
      //  UIApplication.shared.isStatusBarHidden = false
        let statusBar: UIView = UIApplication.shared.value(forKey: "statusBar") as! UIView
        statusBar.isHidden = false
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        if indexPath.row == 0{
            Analytics.logEvent("LeftViewController_ProfileButtonTapped", parameters: nil)
            self.revealViewController().revealToggle(animated: true)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
            self.present(nextViewController, animated:true, completion: nil)
        }else if indexPath.row == 1{
            Analytics.logEvent("LeftViewController_ParcelsHistoryButtonTapped", parameters: nil)
            self.revealViewController().revealToggle(animated: true)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ParcelsHistoryVC") as! ParcelsHistoryVC
            self.present(nextViewController, animated:true, completion: nil)
        }else if indexPath.row == 2{
            Analytics.logEvent("LeftViewController_ChangePasswordButtonTapped", parameters: nil)
            self.revealViewController().revealToggle(animated: true)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ChangePasswordVC") as! ChangePasswordVC
            self.present(nextViewController, animated:true, completion: nil)
        }else if indexPath.row == 4{
            Analytics.logEvent("LeftViewController_logoutButtonTapped", parameters: nil)
            self.revealViewController().revealToggle(animated: true)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "logout"), object: nil)
        }
    }
    func dynamicHeightForRow() -> CGFloat{
        let count : Int = menuArray.count
        var height:CGFloat = CGFloat()
        height = self.view.frame.size.height - 200
        // print(height)
        let count1 = Int(height)
        // print(CGFloat(count1/count));
        return CGFloat(count1/count-1)
    }
    func headerView() -> UIView{
        let headerView = UIView()
        headerView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.height, height: 200)
        headerView.backgroundColor = UIColor(red: 19/255, green: 19/255, blue: 17/255, alpha: 1)
        if appdelegate.IS_IPADPRO9 || appdelegate.IS_IPADPRO10 || appdelegate.IS_IPADPRO12{
            imgView.frame = CGRect(x: (self.view.frame.size.width/2)-75, y: 40, width: 150, height: 150)
        }else{
            imgView.frame = CGRect(x: (self.view.frame.size.width/2)-75, y: 40, width: 150, height: 150)
        }
        imgView.backgroundColor = UIColor.white
        imgView.layer.cornerRadius = imgView.frame.size.height/2
        imgView.layer.masksToBounds = true
        headerView.addSubview(imgView)
        self.myActivityIndicator.frame = CGRect(x: (imgView.frame.size.width/2)-15, y: (imgView.frame.size.height/2)-15, width: 30, height: 30);
        myActivityIndicator.style =
            UIActivityIndicatorView.Style.gray
        myActivityIndicator.center = self.imgView.center
        myActivityIndicator.hidesWhenStopped = true
        self.view.addSubview(self.myActivityIndicator)
        self.profilePicValidation()
        let nameLabel = UILabel()
        nameLabel.frame = CGRect(x: 0, y:  imgView.frame.origin.y + imgView.frame.size.height+20, width:self.view.frame.size.width, height: 25)
        nameLabel.textAlignment = NSTextAlignment.center
        if UserDefaults.standard.value(forKey: "finalname") as? String == nil{
            nameLabel.text = "Username"
        }else{
            let username = UserDefaults.standard.object(forKey: "finalname") as! String
            nameLabel.text = username
        }
        nameLabel.font = AppFont.regularLargeTextFont
        nameLabel.textColor = UIColor(red: 44/255, green: 192/255, blue: 130/255, alpha: 1)
        headerView.addSubview(nameLabel)
        
        return headerView
    }
    func profilePicValidation(){
        if Constants.getValueFromUserDefults(for: "profileImgLink") as? String == nil || Constants.getValueFromUserDefults(for: "profileImgLink") as? String == ""{
            if UserDefaults.standard.value(forKey: "propic") as? Data != nil{
                let propicdata = UserDefaults.standard.object(forKey: "propic") as! Data
                imgView.image = UIImage(data: propicdata)
            }else{
                imgView.image = UIImage.init(named: "icon_profile")
            }
        }else{
            if UserDefaults.standard.value(forKey: "propic") as? Data == nil{
                imgView.image = UIImage.init(named: "icon_profile")
                self.profileImageURL()
            }else {
                self.myActivityIndicator.stopAnimating()
                let propicdata = UserDefaults.standard.object(forKey: "propic") as! Data
                imgView.image = UIImage(data: propicdata)
            }
        }
    }
    func profileImageURL(){
        self.myActivityIndicator.isHidden = false
        self.myActivityIndicator.startAnimating()
        DispatchQueue.global().async {
            self.getImageFromApi()
        }
    }
    func getImageFromApi(){
        self.getProfilePicData(completion: {(responseData,error) in
            if responseData != nil{
                if let image = UIImage(data: responseData! as Data) {
                    DispatchQueue.main.async {
                        self.myActivityIndicator.stopAnimating()
                        self.myActivityIndicator.isHidden = true
                        self.imgView.image = image
                        UserDefaults.standard.set(responseData, forKey: "propic")
                        if self.appdelegate.profilePicStatus == "yes"{
                            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "profilepic"), object: nil)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                    self.myActivityIndicator.stopAnimating()
                    self.myActivityIndicator.isHidden = true
                    self.imgView.image = UIImage.init(named: "icon_profile")
                    }
                }
            }else{
                DispatchQueue.main.async {
                    self.myActivityIndicator.stopAnimating()
                    self.myActivityIndicator.isHidden = true
                    self.imgView.image = UIImage.init(named: "icon_profile")
                }
            }
        })
    }
    @objc func updateProfileImage(){
        self.myActivityIndicator.stopAnimating()
        self.profilePicValidation()
    }
    func displayAlert(message: String)
    {
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
}


