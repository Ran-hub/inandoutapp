//
//  TrackingParcelViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 29/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import GoogleMaps
import CoreLocation
import GooglePlaces
import GooglePlacePicker
import SocketIO
import Firebase

protocol TrackParcelProtocol {
    func refreshParcelDetailsApi()
}
class ParcelTrackingVC: UIViewController {
    
    var delegate : TrackParcelProtocol!
    
    @IBOutlet var headerView: UIView!
    @IBOutlet var titleLbl: UILabel!
    @IBOutlet var mapViewObj: GMSMapView!
    @IBOutlet var containerView: UIView!
    @IBOutlet var cancelBtn: UIButton!
    @IBOutlet var confirmBtn: UIButton!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var parcelStatusLbl: UILabel!
    @IBOutlet weak var riderStatusLbl: UILabel!
    @IBOutlet weak var api_parcelStatusLbl: UILabel!
    @IBOutlet weak var api_riderNameLbl: UILabel!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    var riderLiveTrackingStatus = ""
    var location1 = CLLocation()
    var location2 = CLLocation()
    var locationsArray = NSMutableArray()
    var riderCountTracking : CGFloat = 0
    var rotationStr = ""
    var rotation : CGFloat = 0
    var riderLat = ""
    var riderLong = ""
    let socket = SocketIOClient(socketURL: URL(string: APPURLS.baseURL)!)
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var locationManager = CLLocationManager()
    var riderMarker: GMSMarker = GMSMarker()
    var customerMarker: GMSMarker = GMSMarker()
    var socketTimer = Timer()
    var locationStatus = ""
    var parcelId = ""
    var riderId = String()
    var parcelStatusStr = String()
    var status_api = String()
    var riderId_api = String()
    var seconds : CGFloat = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.isHidden = true
        self.insitialSetUp()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func arCarMovement(_ movedMarker: GMSMarker, bearing : CGFloat) {
        self.riderMarker = movedMarker
        self.riderMarker.title = "RIDER LOCATION"
        self.riderMarker.icon = UIImage.init(named: "icon-rider")
        self.riderMarker.groundAnchor = CGPoint(x: 0.5, y: 0.5)
        self.riderMarker.rotation = CLLocationDegrees(bearing)
        self.riderMarker.map = self.mapViewObj
        self.mapViewObj.animate(toBearing: CLLocationDegrees(bearing))
        if self.locationsArray.count == 1{
            let pickuplocation = self.locationsArray[0] as! CLLocation
            let startLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(pickuplocation.coordinate.latitude, pickuplocation.coordinate.longitude);
            let pickupLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(self.riderMarker.position.latitude,self.riderMarker.position.longitude);
            let bounds1 = GMSCoordinateBounds(coordinate: startLocation, coordinate: pickupLocation)
            let boundUpdate = GMSCameraUpdate.fit(bounds1, with: UIEdgeInsets.init(top: 50, left: 40, bottom: 250, right: 40))
            self.mapViewObj.animate(with: boundUpdate)
            //self.mapViewObj.setMinZoom(14,maxZoom: 18)
        }else{
            self.mapViewObj.animate(to: GMSCameraPosition.camera(withLatitude:self.riderMarker.position.longitude, longitude:self.riderMarker.position.longitude, zoom: 15.0))
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.socket.disconnect()
        self.delegate.refreshParcelDetailsApi()
    }
    func locationSetup(){
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.activityType = .automotiveNavigation
        locationManager.distanceFilter = 10.0
        locationManager.startUpdatingLocation()
        locationManager.requestAlwaysAuthorization()
        if CLLocationManager.locationServicesEnabled() {
            switch(CLLocationManager.authorizationStatus()) {
            case .notDetermined, .restricted, .denied:
                locationStatus = "Yes"
                self.checkinglocationService()
            case .authorizedAlways:
                print("authorizedAlways")
            case .authorizedWhenInUse:
                print("authorizedWhenInUse")
                break
            }
        } else {
            print("Location services are not enabled")
        }
    }
    func insitialSetUp(){
        self.containerView.isHidden = true
        self.getParcelDetailsApi(parcelId: parcelId)
        self.statusLbl.text = NSLocalizedString("lbl_status", comment: "")
        self.riderStatusLbl.text = NSLocalizedString("lbl_riderassigned", comment: "")
        self.locationSetup()
        if !CLLocationManager.locationServicesEnabled() {
            locationStatus = "Yes"
            checkinglocationService()
        }else{
            self.checkingRiderStatus()
        }
        self.intialConstraintsSetup()
        appdelegate.trackparcel = "Yes"
        self.titleLbl.text = NSLocalizedString("lbl_trackingparcel", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        if appdelegate.IS_IPHONE5{
            titleLbl.font = UIFont(name: "HelveticaNeue", size: 18)
        }
        self.titleLbl.textColor = AppColors.whiteColorRGB
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.confirmBtn.setTitle(NSLocalizedString("btn_feedback", comment: ""), for: .normal)
        self.confirmBtn.titleLabel?.textColor = UIColor.clear
        self.confirmBtn.titleLabel?.font = AppFont.boldTextFont
        self.confirmBtn.isHidden = true
        self.mapViewObj.bringSubviewToFront(containerView)
        // self.mapViewObj.bringSubview(toFront: self.confirmBtn)
        let notificationIdentifier: String = "TrackParcelNotifiation"
        NotificationCenter.default.addObserver(self, selector: #selector(ParcelTrackingVC.notifcationMethod(notification:)), name: NSNotification.Name(rawValue: notificationIdentifier), object: nil)
    }
    func checkingRiderStatus(){
        Constants.setValueInUserDefaults(objValue: self.parcelId, for: "track_parcelid")
        if riderId_api == "0" || riderId_api == ""{
        }else{
            if self.parcelStatusStr == NSLocalizedString("lbl_waitingforpickup", comment: "") || self.parcelStatusStr == NSLocalizedString("lbl_pickedup", comment: "") || self.parcelStatusStr == NSLocalizedString("lbl_outfordelivery", comment: ""){
                socket.connect()
                socket.on("connect") {data, ack in
                    if(self.socket.status == .connected){
                        //  print("socket connected")
                        self.socket.on(self.riderId_api) {data, ack in
                            //print("Message for you! \(data[0])")
                            if let arrayobj  = data[0] as? NSDictionary{
                                if let data = arrayobj["data"] as? NSDictionary{
                                    if let lat = data["latitude"] as? String{
                                        // print("latitude",lat)
                                        self.riderLat = lat
                                    }
                                    if let long = data["longitude"] as? String{
                                        // print("long", long)
                                        self.riderLong = long
                                    }
                                    if let bearing = data["bearing"] as? String{
                                        if let n = NumberFormatter().number(from: bearing){
                                            self.rotation = CGFloat(truncating: n)
                                        }
                                    }
                                }
                                self.riderMarker.position = CLLocationCoordinate2D(latitude: Double(self.riderLat)!, longitude:Double(self.riderLong)!)
                                // print("self.rotataion",self.rotation)
                                self.arCarMovement(self.riderMarker, bearing: self.rotation)
                                
                            }
                            ack.with("I got your message, and I'll send my response")
                        }
                    }
                    else if(self.socket.status == .connecting)
                    {
                        print("socket connecting")
                    }
                    else if(self.socket.status == .disconnected)
                    {
                        print("socket disconnected")
                    }
                    else if(self.socket.status == .notConnected)
                    {
                        print("socket notConnected")
                    }
                    else
                    {
                        // self.reconnectSocket()
                    }
                }
                //self.getRiderTrackingLocation(riderid: riderId_api)
            }
        }
    }
    
    func checkinglocationService(){
        let actionSheetController: UIAlertController = UIAlertController(title: NSLocalizedString("Rytle", comment: ""), message: NSLocalizedString("error_locationservice", comment: ""), preferredStyle: .alert)
        let cancelAction: UIAlertAction = UIAlertAction(title: NSLocalizedString("lbl_ok", comment: ""), style: .cancel) { action -> Void in
            //Just dismiss the action sheet
            DispatchQueue.main.async {
                //                if let url = URL(string: "App-Prefs:root=Privacy&path=LOCATION") {
                //                    if #available(iOS 10.0, *)
                //                    {
                //                        UIApplication.shared.open(url, completionHandler: .none)
                //                    }else
                //                    {
                //                        UIApplication.shared.openURL(url)
                //                    }
                //                }
                
                // added by shilpa
                guard let settingsUrl = URL(string:UIApplication.openSettingsURLString) else {
                    return
                }
                if UIApplication.shared.canOpenURL(settingsUrl)  {
                    if #available(iOS 10.0, *) {
                        UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                        })
                    }
                    else  {
                        UIApplication.shared.openURL(settingsUrl)
                    }
                }
            }
        }
        actionSheetController.addAction(cancelAction)
        self.present(actionSheetController, animated: true, completion: nil)
    }
    
    override func viewDidDisappear(_ animated: Bool){
        appdelegate.trackparcel = ""
        appdelegate.trackParcelId = ""
        Constants.removeValueFromUserDefults(for: "parcelid")
        self.socket.disconnect()
        NotificationCenter.default.removeObserver(self, name:NSNotification.Name(rawValue: "TrackParcelNotifiation") , object: nil)
    }
    @objc func notifcationMethod(notification : NSNotification){
        if let not_parcelId = notification.userInfo?["parcelId"] as? String {
            if not_parcelId == parcelId{
                self.getParcelDetailsApi(parcelId: not_parcelId)
            }
        }
    }
    @IBAction func btnsTapped(_ sender : UIButton){
        
        let btn = sender as UIButton
        if btn.tag == 10{
            Analytics.logEvent("ParcelTrackingVC_CancelButtonTapped", parameters: nil)
            self.dismiss(animated: true, completion: nil)
        }else if btn.tag == 20{
            let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "FeedBackVC") as! FeedBackVC
            nextViewController.parcel_id = self.parcelId
            self.present(nextViewController, animated:true, completion: nil)
        }
    }
    
    func getRiderTrackingLocation(riderid : String){
        
        if self.ineternetAlert() == false{
            return
        }
        if appdelegate.trackParcelId == self.parcelId{
        }else{
            IJProgressView.shared.showProgressView(view)
        }
        var bodyReq = [String:String]()
        bodyReq = ["movr_id":riderid]
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            var token = ""
            
            if UserDefaults.standard.value(forKey: "usertoken") != nil{
                token = UserDefaults.standard.value(forKey: "usertoken") as! String
            }
            let sessionStr = "Bearer " + token
            APICommnicationManager.sharedInstance.requestforAPI(service:"/Movr/trackMovr" , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                
                if let httpResponse = response as? HTTPURLResponse{
                    //  print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        if let receivedData = data{
                            do{
                                let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    self.responseFromApi(response: resultDic as! [String : Any])
                                }
                            }catch {
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                }
                            }
                        }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "ParcelDetails_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "ParcelDetails_506", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                        break
                    default:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                    }
                }
                
            }
        }
    }
    func responseFromApi(response:[String : Any]){
        if let authentication = response["Msg"] as? NSArray{
            var latitudeStr = Double()
            var longitudeStr = Double()
            
            if let dic = authentication[0] as? [String:Any]{
                if let latitude = dic["latitude"] as? String{
                    // print(latitude)
                    latitudeStr = Double(latitude)!
                }
                if let longitude = dic["longitude"] as? String{
                    // print(longitude)
                    longitudeStr = Double(longitude)!
                }
                DispatchQueue.main.async(execute: {
                    let position = CLLocationCoordinate2DMake(latitudeStr ,longitudeStr )
                    let marker = GMSMarker(position: position)
                    marker.title = "Rider Location"
                    // marker.snippet = "fulladdress"
                    marker.map = self.mapViewObj
                    self.mapViewObj.animate(to: GMSCameraPosition.camera(withLatitude:latitudeStr, longitude:longitudeStr, zoom: 15.0))
                })
            }
        }
    }
    func responseFromApi1(response:[String : Any]){
        
    }
    
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    func getParcelDetailsApi(parcelId : String){
        
        if self.ineternetAlert() == false{
            return
        }
        if appdelegate.trackParcelId == self.parcelId{
        }else{
            IJProgressView.shared.showProgressView(view)
        }
        var bodyReq = [String:String]()
        bodyReq = ["parcel_id":parcelId]
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            var token = ""
            if UserDefaults.standard.value(forKey: "usertoken") != nil{
                token = UserDefaults.standard.value(forKey: "usertoken") as! String
            }
            let sessionStr = "Bearer " + token
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.parcelDetailsURL , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                
                if let httpResponse = response as? HTTPURLResponse{
                    //   print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        if let receivedData = data{
                            do{
                                let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    self.notificationResponseFromApi(response: resultDic as! [String : Any])
                                }
                            }catch {
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                }
                            }
                        }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "ParcelDetails_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "ParcelDetails_506", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                        break
                    default:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                    }
                }
                
            }
        }
    }
    func notificationResponseFromApi(response:[String : Any]){
        print("Parcel/getParceldetails :: ",response)
        if let array1 = response["Msg"] as? [[String:Any]]{
            for array in array1{
                var Status = 0
                self.status_api = ""
                var firstname = ""
                var lastname = ""
                var parcel_Status = ""
                var latitudeStr = ""
                var longitudeStr = ""
                var TitleStr = ""
                var rider_id = 0
                self.riderLiveTrackingStatus = ""
                if let firstnameStr = array["firstname"] as? String{
                    firstname = firstnameStr
                }
                if let lastnameStr = array["lastname"] as? String{
                    lastname = lastnameStr
                }
                if let liveStatus = array["live_tracking"] as? String{
                    self.riderLiveTrackingStatus = liveStatus
                }
                if let parcelstatus =  array["parcel_fk_status"] as? Int{
                    Status = parcelstatus
                }
                if let riderid =  array["rider_id"] as? Int{
                    rider_id = riderid
                }
                if Status  == 1{
                    self.status_api = "Picked Up"
                    parcel_Status = "is picked parcel."
                }else if Status  == 2{
                    self.status_api = "Out for Delivery"
                    parcel_Status = "is on the way to deliver the parcel."
                }else if Status  == 8{
                    self.status_api = "Waiting for pickup"
                    parcel_Status = "is on the way to pick the parcel."
                }
                else if Status  == 11{
                    self.status_api = "Delivered"
                    parcel_Status = "delivered the parcel."
                }
                else if Status  == 12{
                    self.status_api = "Not Delivered"
                    parcel_Status = "not delivered the parcel."
                }
                else if Status  == 14{
                    self.status_api = "Not Picked up"
                    parcel_Status = "not picked up the parcel."
                }
                if self.status_api  == "Out for Delivery"{
                    TitleStr = "RECEIVER LOCATION"
                    var receiverLat = Double()
                    var receiverLong = Double()
                    if self.riderLiveTrackingStatus != "Yes"{
                        self.socket.disconnect()
                        self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("lbl_pickedupstatus", comment: ""), completion: {(result) in
                            self.dismiss(animated: true, completion: nil)
                        })
                        return
                    }
                    if let latitude =  array["latitude"] as? String{
                        latitudeStr = latitude
                        receiverLat = Double(latitudeStr)!
                    }
                    if let longitude =  array["longitude"] as? String{
                        longitudeStr = longitude
                        receiverLong = Double(longitudeStr)!
                    }
                    DispatchQueue.main.async {
                        self.locationsArray.removeAllObjects()
                        let deliveryLocation = CLLocation.init(latitude: receiverLat, longitude: receiverLong)
                        self.locationsArray.add(deliveryLocation)
                        self.addMarkerPickup(pickupLocation: deliveryLocation, titleStr: TitleStr, riderID: rider_id, firstName: firstname, lastName: lastname, parcelStatus: parcel_Status)
                    }
                }else if self.status_api == "Waiting for pickup" || self.status_api == "Picked Up"{
                    var pickupLat = Double()
                    var pickupLong = Double()
                    TitleStr = "PICKUP LOCATION"
                    if let latitude =  array["pickup_latitude"] as? String{
                        latitudeStr = latitude
                        pickupLat = Double(latitudeStr)!
                    }
                    if let longitude =  array["pickup_longitude"] as? String{
                        longitudeStr = longitude
                        pickupLong = Double(longitudeStr)!
                    }
                    DispatchQueue.main.async {
                        self.locationsArray.removeAllObjects()
                        let pickupLocation = CLLocation.init(latitude: pickupLat, longitude: pickupLong)
                        self.locationsArray.add(pickupLocation)
                        self.addMarkerPickup(pickupLocation: pickupLocation, titleStr: TitleStr, riderID: rider_id, firstName: firstname, lastName: lastname, parcelStatus: parcel_Status)
                    }
                }else if self.status_api == "Delivered"{
                    if self.riderLiveTrackingStatus != "Yes"{
                        self.socket.disconnect()
                        self.api_parcelStatusLbl.text = self.status_api;
                        if self.api_parcelStatusLbl.text == "Delivered"{
                            self.api_parcelStatusLbl.text = NSLocalizedString("lbl_parceldelivered", comment: "")
                        }
                        self.parcelStatusLbl.text =  firstname + " " + lastname + " " + parcel_Status
                        self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("lbl_deliverystatus", comment: ""), completion: {(result) in
                            self.dismiss(animated: true, completion: nil)
                        })
                    }
                }else if self.status_api == "Not Picked up"{
                    if self.riderLiveTrackingStatus != "Yes"{
                        self.socket.disconnect()
                        self.api_parcelStatusLbl.text = NSLocalizedString("lbl_notpickedup", comment: "")
                        self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("alert_parcelnotpickup", comment: ""), completion: {(result) in
                            self.dismiss(animated: true, completion: nil)
                        })
                        return
                    }
                }else if self.status_api == "Not Delivered"{
                    if self.riderLiveTrackingStatus != "Yes"{
                        self.socket.disconnect()
                        self.api_parcelStatusLbl.text = NSLocalizedString("lbl_notdelivered", comment: "")
                        self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("alert_parcelnotdeliverd", comment: ""), completion: {(result) in
                            self.dismiss(animated: true, completion: nil)
                        })
                        return
                    }
                }
            }
        }
    }
    
    func addMarkerPickup(pickupLocation : CLLocation, titleStr: String,riderID : Int , firstName : String , lastName : String, parcelStatus : String){
        DispatchQueue.main.async {
            if self.locationsArray.count == 0{
                return
            }
            let pickupPosition = CLLocationCoordinate2DMake(pickupLocation.coordinate.latitude ,pickupLocation.coordinate.longitude )
            self.customerMarker = GMSMarker(position: pickupPosition)
            self.customerMarker.title = titleStr
            //marker.snippet = fulladdress
            self.customerMarker.map = self.mapViewObj
            self.mapViewObj.animate(to: GMSCameraPosition.camera(withLatitude: pickupLocation.coordinate.latitude, longitude: pickupLocation.coordinate.longitude, zoom: 15.0))
            if riderID == 0{
                self.api_parcelStatusLbl.text = self.status_api
                self.api_riderNameLbl.text = firstName + " " + lastName
                self.parcelStatusLbl.text =  firstName + " " + lastName + " " + parcelStatus
                self.containerView.isHidden = false
                self.mapViewObj.addConstraint(NSLayoutConstraint(item: self.containerView, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50))
                self.riderStatusLbl.isHidden = true
                self.api_riderNameLbl.isHidden = true
                self.parcelStatusLbl.isHidden = true
                self.containerView.isHidden = false
            }else{
                self.riderStatusLbl.isHidden = false
                self.api_riderNameLbl.isHidden = false
                self.parcelStatusLbl.isHidden = false
                self.api_parcelStatusLbl.text = self.status_api
                if self.api_parcelStatusLbl.text == "Waiting for pickup"{
                    self.api_parcelStatusLbl.text = NSLocalizedString("lbl_waitingforpickup", comment: "")
                }else if self.api_parcelStatusLbl.text == "Out for Delivery"{
                    self.api_parcelStatusLbl.text = NSLocalizedString("lbl_outfordelivery", comment: "")
                }
                self.api_riderNameLbl.text = firstName + " " + lastName
                self.parcelStatusLbl.text =  firstName + " " + lastName + " " + parcelStatus
                self.setDynamicHeightForContentView(textStr: self.parcelStatusLbl.text!)
                self.containerView.isHidden = false
            }
        }
    }
    
    func addMarkerReceiever(receiverLocation : CLLocation, titleStr: String,riderID : Int , firstName : String , lastName : String, parcelStatus : String){
        DispatchQueue.main.async {
            let receiverPosition = CLLocationCoordinate2DMake(receiverLocation.coordinate.latitude ,receiverLocation.coordinate.longitude )
            let marker = GMSMarker(position: receiverPosition)
            marker.title = titleStr
            marker.map = self.mapViewObj
            self.mapViewObj.animate(to: GMSCameraPosition.camera(withLatitude: receiverLocation.coordinate.latitude, longitude: receiverLocation.coordinate.longitude, zoom: 15.0))
            if riderID == 0{
                self.api_parcelStatusLbl.text = self.status_api
                self.api_riderNameLbl.text = firstName + " " + lastName
                self.parcelStatusLbl.text =  firstName + " " + lastName + " " + parcelStatus
                self.containerView.isHidden = false
                self.mapViewObj.addConstraint(NSLayoutConstraint(item: self.containerView, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50))
                self.riderStatusLbl.isHidden = true
                self.api_riderNameLbl.isHidden = true
                self.parcelStatusLbl.isHidden = true
                self.containerView.isHidden = false
            }else{
                self.riderStatusLbl.isHidden = false
                self.api_riderNameLbl.isHidden = false
                self.parcelStatusLbl.isHidden = false
                self.api_parcelStatusLbl.text = self.status_api
                self.api_riderNameLbl.text = firstName + " " + lastName
                if parcelStatus == "Parcel not Picked up."{
                    self.parcelStatusLbl.text = parcelStatus
                }else{
                    self.parcelStatusLbl.text =  firstName + " " + lastName + " " + parcelStatus
                }
                self.setDynamicHeightForContentView(textStr: self.parcelStatusLbl.text!)
                self.containerView.isHidden = false
            }
        }
    }
    
    func setDynamicHeightForContentView(textStr : String){
        var height : CGFloat = 0
        height += self.heightForView(text: textStr, font: AppFont.regularTextFont!, width: self.parcelStatusLbl.frame.size.width,labelObj:self.parcelStatusLbl)
        if height < 25{
            height += 25
        }
        self.parcelStatusLbl.frame = CGRect(x: 10, y: self.parcelStatusLbl.frame.origin.y, width: self.parcelStatusLbl.frame.size.width, height: height)
        self.containerView.addConstraint(NSLayoutConstraint(item: self.parcelStatusLbl, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: height))
        self.parcelStatusLbl.text = textStr
        self.parcelStatusLbl.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.parcelStatusLbl.numberOfLines = 0
        height += 10+25+10+25+10+15
        self.mapViewObj.addConstraint(NSLayoutConstraint(item: self.containerView, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: height))
    }
    func heightForView(text:String, font:UIFont, width:CGFloat, labelObj : UILabel) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRect(x:10, y:0, width:width, height:2000))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
}
extension ParcelTrackingVC:GMSMapViewDelegate{
}
extension ParcelTrackingVC:CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedWhenInUse:
            manager.startUpdatingLocation()
            break
        case .authorizedAlways:
            manager.startUpdatingLocation()
            break
        case .denied:
            //handle denied
            self.checkinglocationService()
            break
        case .notDetermined:
            manager.requestWhenInUseAuthorization()
            // self.checkinglocationService()
            break
        default:
            break
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        if locationStatus == "Yes"{
            locationStatus = ""
        }
        locationManager.stopUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Couldn't get your location")
    }
}

