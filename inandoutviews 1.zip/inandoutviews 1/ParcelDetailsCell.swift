//
//  ParcelDetailsCell.swift
//  RYTLECUSTOMERAPP
//
//  Created by AMT on 12/21/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class ParcelDetailsTC: UITableViewCell {

    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var apitextLbl: UILabel!
    @IBOutlet weak var topBordeLbl: UILabel!
    @IBOutlet weak var bottomBorderLbl: UILabel!
    @IBOutlet weak var nameLblLC: NSLayoutConstraint!
    @IBOutlet weak var topBordeLblLC: NSLayoutConstraint!
    @IBOutlet weak var bottomBorderLblLC: NSLayoutConstraint!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
