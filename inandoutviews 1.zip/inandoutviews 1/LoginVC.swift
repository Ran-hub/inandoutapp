//
//  ViewController.swift
//  RYTLECUSTOMERAPP
//  Created by Admin on 14/08/17.
//  Copyright © 2017 admin. All rights reserved.
//
import UIKit
import Crashlytics
import Firebase
import Foundation

class LoginVC: UIViewController,UITextFieldDelegate,UIScrollViewDelegate{
    
    @IBOutlet weak var containerViewBC: NSLayoutConstraint!
    @IBOutlet weak var logoHeightHC: NSLayoutConstraint!
    @IBOutlet weak var logoWidthWC: NSLayoutConstraint!
    @IBOutlet weak var logoTopTC: NSLayoutConstraint!
    @IBOutlet var contentView: UIView!
    @IBOutlet var bgImg: UIImageView!
    @IBOutlet var logoImg: UIImageView!
    @IBOutlet var containerView: UIView!
    @IBOutlet var usernameTxt: UITextField!
    @IBOutlet var passwordTxt: paaawordTextField!
    @IBOutlet var loginBtn: UIButton!
    @IBOutlet var forgotBtn: UIButton!
    @IBOutlet var registerBtn: UIButton!
    @IBOutlet var scrollViewObj: UIScrollView!
    var activeField: UITextField?
    var firstname = ""
    var secondName = ""
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        Constants.checkingCountryLagunage()
        self.initialSetup()
        self.intialConstraintsSetup()
        self.gesturesSetup()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func gesturesSetup(){
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        self.bgImg.isUserInteractionEnabled = true
        self.bgImg.addGestureRecognizer(tapGestureRecognizer)
    }
    func initialSetup(){
        self.scrollViewObj.showsHorizontalScrollIndicator = false
        self.scrollViewObj.showsVerticalScrollIndicator = false
        self.scrollViewObj.delegate = self
        self.usernameTxt.placeholder = NSLocalizedString("txt_username", comment: "")
        self.usernameTxt.font =  AppFont.regularTextFont
        self.usernameTxt.textColor = AppColors.greenColorRGB
        self.passwordTxt.placeholder = NSLocalizedString("lbl_password", comment: "")
        self.passwordTxt.font = AppFont.regularTextFont
        self.passwordTxt.textColor = AppColors.greenColorRGB
        self.loginBtn.setTitle(NSLocalizedString("btn_login", comment: ""), for: UIControl.State.normal)
        self.loginBtn.titleLabel?.font = AppFont.boldTextFont
        self.loginBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.forgotBtn.setTitle(NSLocalizedString("btn_forgot", comment: ""), for: UIControl.State.normal)
        self.forgotBtn.titleLabel?.font = AppFont.regularTextFont
        self.forgotBtn.titleLabel?.textColor = AppColors.btn_grayColorRGB
        self.registerBtn.setTitle(NSLocalizedString("btn_createaccount", comment: ""), for: UIControl.State.normal)
        self.registerBtn.titleLabel?.font = AppFont.regularTextFont
        self.registerBtn.titleLabel?.textColor = AppColors.btn_grayColorRGB
        registerBtn = addBorder(button: registerBtn)
        forgotBtn = addBorder(button: forgotBtn)
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONE5{
            self.contentView.removeConstraint(self.logoTopTC)
            self.contentView.removeConstraint(self.containerViewBC)
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.bgImg, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: self.view.frame.size.height/8))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.contentView, attribute: NSLayoutConstraint.Attribute.bottom, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.containerView, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 0))
        }else if appdelegate.IS_IPHONE6 || appdelegate.IS_IPHONE6PLUS{
            self.contentView.removeConstraint(self.logoTopTC)
            self.contentView.removeConstraint(self.containerViewBC)
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.bgImg, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: self.view.frame.size.height/7))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.contentView, attribute: NSLayoutConstraint.Attribute.bottom, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.containerView, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 30))
        }else if appdelegate.IS_IPHONEX{
            self.contentView.removeConstraint(self.logoWidthWC)
            self.contentView.removeConstraint(self.logoHeightHC)
            self.contentView.removeConstraint(self.logoTopTC)
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.bgImg, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: self.view.frame.size.height/7))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 250))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 160))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.contentView, attribute: NSLayoutConstraint.Attribute.bottom, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.containerView, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1, constant: 30))
        }
        if appdelegate.IS_IPADPRO9 || appdelegate.IS_IPADPRO10 || appdelegate.IS_IPADPRO12{
            self.contentView.removeConstraint(self.logoWidthWC)
            self.contentView.removeConstraint(self.logoHeightHC)
            self.contentView.removeConstraint(self.logoTopTC)
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.contentView, attribute: NSLayoutConstraint.Attribute.width, multiplier: 200/414, constant: 0))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.contentView, attribute: NSLayoutConstraint.Attribute.height, multiplier: 150/736, constant: 0))
            if appdelegate.IS_IPADPRO9{
                self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.bgImg, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: self.view.frame.size.height/5))
            }else if appdelegate.IS_IPADPRO10 || appdelegate.IS_IPADPRO12{
                self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.bgImg, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: self.view.frame.size.height/4.5))
            }
        }
    }
    func addBorder(button : UIButton) -> UIButton{
        let borderBottom = CALayer()
        let borderWidth = CGFloat(1)
        borderBottom.borderColor = UIColor.lightGray.cgColor
        borderBottom.frame = CGRect(x:0, y: button.frame.size.height - 15, width: button.frame.origin.x+button.frame.size.width , height:1)
        borderBottom.borderWidth = borderWidth
        button.layer.addSublayer(borderBottom)
        button.layer.masksToBounds = true
        return button
    }
    override func viewWillAppear(_ animated: Bool) {
        self.registerForKeyboardNotifications()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear (animated)
        self.deregisterFromKeyboardNotifications()
    }
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        self.scrollViewObj.isScrollEnabled = false
        self.usernameTxt.resignFirstResponder()
        self.passwordTxt.resignFirstResponder()
    }
    func registerForKeyboardNotifications(){
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    func deregisterFromKeyboardNotifications(){
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func keyboardWasShown(notification: NSNotification){
        self.scrollViewObj.isScrollEnabled = true
        var info = notification.userInfo!
        var keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        if keyboardSize?.height == 0{
            keyboardSize?.height = 260
        }
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: keyboardSize!.height+50, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
        self.scrollViewObj.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
    }
    public func scrollViewDidScroll(_ scrollView: UIScrollView){
        scrollView.isScrollEnabled = false
    }
    @objc func keyboardWillBeHidden(notification: NSNotification){
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
    }
    func textFieldDidBeginEditing(_ textField: UITextField){
        if textField == self.usernameTxt{
            textField.returnKeyType = .next
        }else if textField == self.passwordTxt{
            textField.returnKeyType = .done
        }
        self.activeField = textField
    }
    func textFieldDidEndEditing(_ textField: UITextField){
        self.activeField = nil
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == self.passwordTxt{
            if string == " "{
                return false
            }else{
                return true
            }
        }
        return true
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        switch textField{
        case self.usernameTxt:
            self.passwordTxt.becomeFirstResponder()
            break
        case self.passwordTxt:
            textField.resignFirstResponder()
            break
        default:
            textField.resignFirstResponder()
        }
        return true
    }
    @IBAction func btnsTapped(_ sender : UIButton){
        let btn = sender as UIButton
        if btn.tag == 10{
            Analytics.logEvent("LoginVC_LoginButtonTapped", parameters:["loginname":"LoginButton"])
            self.loginApiValidations()
        }else if btn.tag == 20{
            Analytics.logEvent("LoginVC_ForgotPasswordButtonTapped", parameters: nil)
            self.usernameTxt.text = ""
            self.passwordTxt.text = ""
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ForgotPasswordVC") as! ForgotPasswordVC
            self.present(nextViewController, animated: true, completion: nil)
        }else if btn.tag == 30{
            Analytics.logEvent("LoginVC_SignupButtonTapped", parameters: nil)
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SignupVC") as! SignupVC
            self.present(nextViewController, animated: true, completion: nil)
        }
    }
    func loginApiValidations() {
        if self.ineternetAlert() == false{
            return
        }
        if usernameTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_username",comment: ""), completion: {(result) in
                self.usernameTxt.becomeFirstResponder()
            })
            return
        }else if passwordTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_password",comment: ""), completion: {(result) in
                self.passwordTxt.becomeFirstResponder()
            })
            return
        }else{
            self.usernameTxt.resignFirstResponder()
            self.passwordTxt.resignFirstResponder()
            if UserDefaults.standard.value(forKey: "customerOrgid") as? String == nil{
                    self.orgnaizationAPi(completion:{(result) in
                         DispatchQueue.main.async {
                        self.loginApi(orgId: result)
                        }
                    })
            }else{
                var orgId = ""
                orgId = Constants.getValueFromUserDefults(for:"customerOrgid") as! String
                self.loginApi(orgId: orgId)
            }
        }
    }
    func loginApi(orgId:String){
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        bodyReq = ["username":self.usernameTxt.text!,"password":self.passwordTxt.text!,"org_id":orgId]
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.loginURL, method: "POST", token: "", body: "", productBody: bodyData as NSData) { (data, error,response) in
                if let httpResponse = response as? HTTPURLResponse{
                   // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        if let receivedData = data{
                            do{
                                let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    self.responseApi(response: resultDic as! [String : Any])
                                }
                            }catch {
                                self.somethingWentWrong()
                            }
                        }
                        break
                    case 500:
                        self.somethingWentWrong()
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Login_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Login_506", controller: self)
                        }
                        break
                    default:
                        self.somethingWentWrong()
                    }
                }else{
                    self.somethingWentWrong()
                }
            }
        }
    }
    func somethingWentWrong(){
        DispatchQueue.main.async {
            IJProgressView.shared.hideProgressView()
            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
        }
    }
    func responseApi(response : [String : Any]){
          //  print("Result",response)
            if let status = response["status"] as? Bool {
                if status == true{
                        if let authentication = response["token"] as? String{
                            IJProgressView.shared.hideProgressView();
                            Constants.setValueInUserDefaults(objValue:authentication , for:"usertoken")
                            let rider_details :NSDictionary  = (response["customer_details"] as? NSDictionary)!
                            let riderNum = rider_details.object(forKey: "customer_id") as! Int
                            let riderStr = String(riderNum)
                            Constants.setValueInUserDefaults(objValue:riderStr , for:"customer_id")
                            Constants.setValueInUserDefaults(objValue:(rider_details.object(forKey: "username") as! NSString) as String , for:"username")
                            if let firstName = rider_details.object(forKey:"firstname") as? String{
                                self.firstname = firstName.capitalizedFirst()
                            }
                            var profileImgURl = ""
                            if let imageURL = rider_details["image"] as? String{
                                profileImgURl = imageURL
                            }
                            Constants.setValueInUserDefaults(objValue: profileImgURl , for:"profileImgLink")
                            if let lastName = rider_details.object(forKey: "lastname") as? String{
                                self.secondName = lastName.capitalizedFirst()
                            }
                            let finalName = self.firstname + " " + self.secondName
                            Constants.setValueInUserDefaults(objValue:finalName , for:"finalname")
                            self.usernameTxt.text = ""
                            self.passwordTxt.text = ""
                            self.profileImageURL()
                            self.deviceTokanApi()
                            self.appdelegate.sidemenucount = 0
                            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
                            self.present(nextViewController, animated: true, completion: nil)
                        }
                     }
                  }
               }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    func profileImageURL(){
        if UserDefaults.standard.value(forKey: "profileImgLink") as? String == nil || UserDefaults.standard.value(forKey: "profileImgLink") as? String == ""{
        }else {
            DispatchQueue.global().async {
                self.getImageFromApi()
            }
        }
    }
    func getImageFromApi(){
        self.getProfilePicData(completion: {(responseData,error) in
            if responseData != nil{
                UserDefaults.standard.set(responseData, forKey: "propic")
                if self.appdelegate.profilePicStatusSideMenu == "yes"{
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "sidemenu"), object: nil)
                }else if self.appdelegate.profilePicStatus == "yes"{
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "profilepic"), object: nil)
                }
            }else{
                print(error!)
            }
        })
    }
    func deviceTokanApi(){
        if self.ineternetAlert() == false{
            return
        }
        DispatchQueue.global().async {
            if UserDefaults.standard.value(forKey: "devicetoken") as? String == nil{
                return
            }else{
                var customerId  = ""
                var deviceToken = ""
                deviceToken = UserDefaults.standard.value(forKey: "devicetoken") as! String
                customerId = UserDefaults.standard.value(forKey: "customer_id") as! String
                var bodyReq = [String:String]()
                bodyReq = ["device_token":deviceToken,"rider_id": "" ,"device_type":"iphone","customer_id":customerId,"user_type":"customer"]
                if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                    let token = UserDefaults.standard.value(forKey: "usertoken") as! String
                    let sessionStr = "Bearer " + token
                APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.deviceTypeURL , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                   
                    if let httpResponse = response as? HTTPURLResponse{
                      //  print("httpResponse status code \(httpResponse.statusCode)")
                        switch(httpResponse.statusCode){
                        case 200:
                            Constants.setValueInUserDefaults(objValue:deviceToken , for:"devicetoken")
                            break
                            default:break
                        }
                      }
                   }
                }
            }
        }
    }
}

class paaawordTextField: UITextField{
    open override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        return false
    }
}
