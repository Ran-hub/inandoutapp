//
//  CountryDetails.swift
//  RYTLECUSTOMERAPP
//
//  Created by Shilpashree on 16/09/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class CountryDetails: NSObject {
    var countryname = ""
    var countrycode = ""
    var phonecode = ""
}
