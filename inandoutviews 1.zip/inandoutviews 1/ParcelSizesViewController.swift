//
//  ParcelSizesViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by AMT on 5/18/18.
//  Copyright © 2018 Pavan. All rights reserved.
//

import UIKit
import Photos
import PhotosUI
import Firebase
import AssetsLibrary

struct ConstantsLengthString {
    static let MAX_BEFORE_DECIMAL_DIGITS = 3
    static let MAX_AFTER_DECIMAL_DIGITS = 2
}
struct ParcelType{
    var parcel_type: String?
    var parcel_type_id: String?
    init(parcel_type: String?, parcel_type_id: String?) {
        self.parcel_type = parcel_type
        self.parcel_type_id = parcel_type_id
    }
}
struct ParcelWeights{
    var weight: String?
    var name: String?
    var parcel_weight_id: String?
    var parcel_type_fk_id: String?
    init(weight: String?, name: String?, parcel_weight_id: String?,parcel_type_fk_id:String) {
        self.weight = weight
        self.name = name
        self.parcel_weight_id = parcel_weight_id
        self.parcel_type_fk_id = parcel_type_fk_id
    }
}
struct ParcelDimension{
    var dimension: String?
    var name: String?
    var parcel_dimen_id: String?
    var parcel_type_fk_id: String?
    init(dimension: String?, name: String?, parcel_dimen_id: String?,parcel_type_fk_id:String) {
        self.dimension = dimension
        self.name = name
        self.parcel_dimen_id = parcel_dimen_id
        self.parcel_type_fk_id = parcel_type_fk_id
    }
}
class ParcelSizesViewController: UIViewController{
    
    @IBOutlet weak var headerView : UIView!
    @IBOutlet weak var cancelBtn : UIButton!
    @IBOutlet weak var titleLbl : UILabel!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var selectTypeView: UIView!
    @IBOutlet weak var selectDimensionView: UIView!
    @IBOutlet weak var selectWeightView: UIView!
    @IBOutlet weak var insuranceView: UIView!
    @IBOutlet weak var selectTypeTF: UITextField!
    @IBOutlet weak var selectDimensionTF: UITextField!
    @IBOutlet weak var selectWeightTF: UITextField!
    @IBOutlet weak var selectTypeLabel: UILabel!
    @IBOutlet weak var selectDimensionLabel: UILabel!
    @IBOutlet weak var selectWeightLabel: UILabel!
    @IBOutlet weak var selectedDimensionValuesLabel: UILabel!
    @IBOutlet weak var hideLabel: UILabel!
    @IBOutlet weak var hideLabelHC: NSLayoutConstraint!
    @IBOutlet weak var selectedDimensionValuesLabelHC: NSLayoutConstraint!
    @IBOutlet weak var insuranceLabel: UILabel!
    @IBOutlet weak var yesLabel: UILabel!
    @IBOutlet weak var noLabel: UILabel!
    @IBOutlet weak var yesBtn: UIButton!
    @IBOutlet weak var noBtn: UIButton!
    @IBOutlet weak var badgeLabel: UILabel!
    @IBOutlet weak var notesView: UIView!
    @IBOutlet weak var notesTextView: UITextView!
    @IBOutlet weak var attchButton: UIButton!
    @IBOutlet weak var attachImage: UIImageView!
    @IBOutlet weak var attachLabel: UILabel!
    
    @IBOutlet weak var lengthLbl : UILabel!
    @IBOutlet weak var lengthTxt : UITextField!
    @IBOutlet weak var lengthUnitTF: UITextField!
    @IBOutlet weak var lengthButton: UIButton!
    
    @IBOutlet weak var widthLbl : UILabel!
    @IBOutlet weak var widthTxt : UITextField!
    @IBOutlet weak var widthUnitTF: UITextField!
    @IBOutlet weak var widthButton: UIButton!
    
    @IBOutlet weak var heightLbl : UILabel!
    @IBOutlet weak var heightTxt : UITextField!
    @IBOutlet weak var heightUnitTF: UITextField!
    @IBOutlet weak var heightButton: UIButton!
    
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var popupView: UIView!
    @IBOutlet weak var popupBgView: UIView!
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var popupBgViewYaxis: NSLayoutConstraint!
    @IBOutlet weak var clearButton: UIButton!
    @IBOutlet weak var clearImageView: UIImageView!
    
    @IBOutlet weak var attachImageBtnWC: NSLayoutConstraint!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    
    let picker = UIImagePickerController()
    var tapGestureRecognizer = UITapGestureRecognizer()
    
    var parcelTypeNameArray = [String]()
    var parcelTypeIdArray = [String]()
    var parcelDimensionNameArray = [String]()
    var parcelWeightNameArray = [String]()
    
    var activeField: UITextField?
    var parcelDimesionArray = [ParcelDimension]()
    var parcelWeightsArray = [ParcelWeights]()
    var parcelTypeArray = [ParcelType]()
    
    var parcelTypeIndex : Int = 0
    var parcelTypeStatus = ""
    
    var lengthText = ""
    var widthText = ""
    var heightText = ""
    var weightText = ""
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    let lengthDropDown = DropDown()
    let widthDropDown = DropDown()
    let heightDropDown = DropDown()
    
    let selectTypeDropDown = DropDown()
    let selectDimensionDropDown = DropDown()
    let selectWeightDropDown = DropDown()
    lazy var dropDowns: [DropDown] = {
        return [
            self.selectTypeDropDown, self.selectDimensionDropDown,self.selectWeightDropDown,self.lengthDropDown,self.widthDropDown,self.heightDropDown
        ]
    }()
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getParcelTypeApi()
        self.initialSetup()
        self.languageValidationForGermany()
        self.intialConstraintsSetup()
        self.setupLengthDropDown()
        self.setupWidthDropDown()
        self.setupHeightDropDown()
        self.setPaddingToTextfiledForArrowBtns()
        self.leftPaddingForTextfileds()
        self.popupBgView.bringSubviewToFront(self.clearImageView)
        self.popupBgView.bringSubviewToFront(self.clearButton)
        self.gesturesSetupForAttachImage()
        print(parcelTypeIndex)
        
        
    }
    func languageValidationForGermany(){
        let languageCode = Constants.getValueFromUserDefults(for: "languageCode") as! String
        if languageCode == "Yes"{
            if appdelegate.IS_IPHONE5{
                self.insuranceLabel.font = AppFont.regularSmallTextFont
            }
        }
    }
    func gesturesSetupForAttachImage(){
        tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(removeTheAttachedImage(tapGestureRecognizer:)))
        self.attachImage.isUserInteractionEnabled = true
        self.attachImage.addGestureRecognizer(tapGestureRecognizer)
    }
    @objc func removeTheAttachedImage(tapGestureRecognizer: UITapGestureRecognizer){
        self.badgeLabel.isHidden = true
        Analytics.logEvent("ParcelSizesViewController_ClearParcelImageButtonTapped", parameters: nil)
        Constants.setValueInUserDefaults(objValue:"" , for:"attachImage")
        self.attachLabel.text = NSLocalizedString("lbl_attachaphoto", comment: "")
        self.attachImage.image = UIImage.init(named: "icon_camera")
        self.attachImageBtnWC.constant = 130
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func initialSetup(){
        self.titleLbl.text = NSLocalizedString("lbl_parceldetals", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        self.titleLbl.textColor = AppColors.whiteColorRGB
        self.lengthLbl.text = NSLocalizedString("lbl_lenght", comment: "")
        self.lengthLbl.font = AppFont.regularTextFont
        self.lengthUnitTF.font = AppFont.regularTextFont
        self.widthLbl.text = NSLocalizedString("lbl_width", comment: "")
        self.widthLbl.font = AppFont.regularTextFont
        self.widthUnitTF.font = AppFont.regularTextFont
        self.heightLbl.text = NSLocalizedString("lbl_height", comment: "")
        self.heightLbl.font = AppFont.regularTextFont
        self.heightUnitTF.font = AppFont.regularTextFont
        self.selectWeightLabel.text = NSLocalizedString("lbl_weight", comment: "")
        self.selectWeightLabel.font = AppFont.regularTextFont
        self.insuranceLabel.text = NSLocalizedString("lbl_insured", comment: "")
        self.yesLabel.text = NSLocalizedString("lbl_yes", comment: "")
        self.yesLabel.font = AppFont.regularTextFont
        self.noLabel.text = NSLocalizedString("lbl_no", comment: "")
        self.noLabel.font = AppFont.regularTextFont
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.continueButton.setTitle(NSLocalizedString("btn_continue", comment: ""), for: .normal)
        self.continueButton.titleLabel?.font = AppFont.boldTextFont
        self.continueButton.backgroundColor = AppColors.greenColorRGB
        self.continueButton.setTitleColor(AppColors.whiteColorRGB, for: .normal)
        self.nextButton.setTitle(NSLocalizedString("btn_continue", comment: ""), for: .normal)
        self.nextButton.titleLabel?.font = AppFont.boldTextFont
        self.nextButton.backgroundColor = AppColors.greenColorRGB
        self.nextButton.setTitleColor(AppColors.whiteColorRGB, for: .normal)
        self.attachLabel.text = NSLocalizedString("lbl_attachaphoto", comment: "")
        self.attachImage.image = UIImage.init(named: "icon_camera")
        self.heightUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
        self.widthUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
        self.lengthUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
        self.noBtn.setBackgroundImage(UIImage(named:"icon_selectedBtn"), for: .normal)
        self.noBtn.isSelected = true
        self.attachImageBtnWC.constant = 130
        Constants.setValueInUserDefaults(objValue:"No" , for:"insured")
        self.selectTypeLabel.text = NSLocalizedString("lbl_type", comment: "")
        self.selectTypeTF.placeholder = NSLocalizedString("lbl_selecttype", comment: "")
        self.selectDimensionTF.placeholder = NSLocalizedString("lbl_selectdimension", comment: "")
        self.selectWeightTF.placeholder = NSLocalizedString("lbl_selectweight", comment: "")
        self.hideLabelHC.constant = 0
        self.selectedDimensionValuesLabelHC.constant = 0
        self.hideLabel.isHidden = true
        self.selectedDimensionValuesLabel.isHidden = true
        self.notesView.bringSubviewToFront(self.badgeLabel)
        self.backgroundView.bringSubviewToFront(self.popupView)
        self.badgeLabel.isHidden = true
        self.backgroundView.isHidden = true
        Constants.setValueInUserDefaults(objValue:"" , for:"parceltype")
        Constants.setValueInUserDefaults(objValue:"" , for:"DimensionType")
        Constants.setValueInUserDefaults(objValue:"" , for:"parcelDimensions")
        UserDefaults.standard.set("", forKey: "attachImage")
        Constants.setValueInUserDefaults(objValue:"0 cm", for:"length")
        Constants.setValueInUserDefaults(objValue:"0 cm" , for:"width")
        Constants.setValueInUserDefaults(objValue:"0 cm" , for:"height")
    }
    override func viewWillAppear(_ animated: Bool) {
        self.registerForKeyboardNotifications()
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.deregisterFromKeyboardNotifications()
    }
    override func viewDidLayoutSubviews(){
        DispatchQueue.main.async{
            self.scrollView.translatesAutoresizingMaskIntoConstraints = true
            self.scrollView.isScrollEnabled = true
            self.scrollView.contentSize = CGSize(width: 0, height: self.contentView.frame.origin.y+self.contentView.frame.size.height)
        }
    }
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func keyboardWasShown(notification: NSNotification){
        self.scrollView.isScrollEnabled = true
        var info = notification.userInfo!
        var keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        if keyboardSize?.height == 0{
            keyboardSize?.height = 260
        }
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: keyboardSize!.height, right: 0.0)
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        // print(aRect)
        if let activeField = self.activeField {
            //   print(activeField.frame)
            //  print(activeField.frame.origin)
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollView.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
    }
    @objc func keyboardWillBeHidden(notification: NSNotification){
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
        self.view.endEditing(true)
    }
    func setPaddingToTextfiledForArrowBtns(){
        let selectTypeBtn = UIButton(type: .custom)
        selectTypeBtn.setImage(UIImage(named:"icon_downarrow1"), for: .normal)
        selectTypeBtn.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: -16, bottom: 0, right: 0)
        selectTypeBtn.imageView?.contentMode = .scaleAspectFit
        selectTypeBtn.frame = CGRect(x: CGFloat(self.selectTypeTF.frame.size.width - 30), y: CGFloat(12.5), width: CGFloat(25), height: CGFloat(25))
        selectTypeBtn.tag = 10
        self.selectTypeTF.rightView = selectTypeBtn
        self.selectTypeTF.rightViewMode = .always
        let selectDimensionBtn = UIButton(type: .custom)
        selectDimensionBtn.setImage(UIImage(named:"icon_downarrow1"), for: .normal)
        selectDimensionBtn.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: -16, bottom: 0, right: 0)
        selectDimensionBtn.frame = CGRect(x: CGFloat(self.selectDimensionTF.frame.size.width - 30), y: CGFloat(12.5), width: CGFloat(25), height: CGFloat(25))
        selectDimensionBtn.tag = 20
        self.selectDimensionTF.rightView = selectDimensionBtn
        self.selectDimensionTF.rightViewMode = .always
        let selectWeightBtn = UIButton(type: .custom)
        selectWeightBtn.setImage(UIImage(named:"icon_downarrow1"), for: .normal)
        selectWeightBtn.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: -16, bottom: 0, right: 0)
        selectWeightBtn.frame = CGRect(x: CGFloat(self.selectWeightTF.frame.size.width - 30), y: CGFloat(12.5), width: CGFloat(25), height: CGFloat(25))
        selectWeightBtn.tag = 30
        self.selectWeightTF.rightView = selectWeightBtn
        self.selectWeightTF.rightViewMode = .always
        
        let lengthbutton = UIButton(type: .custom)
        lengthbutton.setImage(UIImage(named:"icon_downarrow1"), for: .normal)
        lengthbutton.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: -16, bottom: 0, right: 0)
        lengthbutton.frame = CGRect(x: CGFloat(self.lengthUnitTF.frame.size.width - 25), y: CGFloat(12.5), width: CGFloat(25), height: CGFloat(25))
        lengthbutton.tag = 10
        self.lengthUnitTF.rightView = lengthbutton
        self.lengthUnitTF.rightViewMode = .always
        let heightbutton = UIButton(type: .custom)
        heightbutton.setImage(UIImage(named:"icon_downarrow1"), for: .normal)
        heightbutton.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: -16, bottom: 0, right: 0)
        heightbutton.frame = CGRect(x: CGFloat(self.heightUnitTF.frame.size.width - 25), y: CGFloat(12.5), width: CGFloat(25), height: CGFloat(25))
        heightbutton.tag = 20
        heightUnitTF.rightView = heightbutton
        heightUnitTF.rightViewMode = .always
        let widthbutton = UIButton(type: .custom)
        widthbutton.setImage(UIImage(named:"icon_downarrow1"), for: .normal)
        widthbutton.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: -16, bottom: 0, right: 0)
        widthbutton.frame = CGRect(x: CGFloat(self.widthUnitTF.frame.size.width - 25), y: CGFloat(12.5), width: CGFloat(25), height: CGFloat(25))
        widthbutton.tag = 30
        self.widthUnitTF.rightView = widthbutton
        self.widthUnitTF.rightViewMode = .always
    }
    func leftPaddingForTextfileds(){
        let selectTypeBtn = UIButton(type: .custom)
        selectTypeBtn.frame = CGRect(x: 0, y: 0, width:10, height: 50)
        self.selectTypeTF.leftView = selectTypeBtn
        self.selectTypeTF.leftViewMode = .always
        let selectDimensionBtn = UIButton(type: .custom)
        selectDimensionBtn.frame = CGRect(x: 0, y: 0, width:10, height: 50)
        self.selectDimensionTF.leftView = selectDimensionBtn
        self.selectDimensionTF.leftViewMode = .always
        let selectWeightBtn = UIButton(type: .custom)
        selectWeightBtn.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(10), height: CGFloat(50))
        self.selectWeightTF.leftView = selectWeightBtn
        self.selectWeightTF.leftViewMode = .always
    }
    func cameraSelected(){
        if AVCaptureDevice.authorizationStatus(for: AVMediaType(rawValue: convertFromAVMediaType(AVMediaType.video))) ==  AVAuthorizationStatus.authorized {
            DispatchQueue.main.async {
                self.camera()
            }
        } else {
            AVCaptureDevice.requestAccess(for: AVMediaType(rawValue: convertFromAVMediaType(AVMediaType.video)), completionHandler: { (granted: Bool) -> Void in
                if granted == true {
                    // User granted
                    DispatchQueue.main.async {
                        self.camera()
                    }
                } else {
                    // User Rejected
                    DispatchQueue.main.async {
                        self.displayCameraAlert()
                    }
                }
            })
        }
    }
    func displayCameraAlert(){
        let actionSheetController: UIAlertController = UIAlertController(title:nil, message: NSLocalizedString("error_cameraservice", comment: ""), preferredStyle: .alert)
        let okaction: UIAlertAction = UIAlertAction(title: "Ok", style: .cancel) { action -> Void in
            //Just dismiss the action sheet
            DispatchQueue.main.async {
                //if let url = URL(string: "App-Prefs:root=Privacy&path=CAMERA") {
               // If general location settings are disabled then open general location settings
                //  UIApplication.shared.openURL(url)
                // }
                
                //Added by shilpa
                guard let settingsUrl = URL(string:UIApplication.openSettingsURLString) else {
                    return
                }
                if UIApplication.shared.canOpenURL(settingsUrl)  {
                    if #available(iOS 10.0, *) {
                        UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                        })
                    }
                    else  {
                        UIApplication.shared.openURL(settingsUrl)
                    }
                }
            }
        }
        actionSheetController.addAction(okaction)
        self.present(actionSheetController, animated: true, completion: nil)
    }
    @IBAction func btnsTapped(_ sender : UIButton){
        if sender.tag == 10{
            Analytics.logEvent("ParcelSizesViewController_CancelButtonTapped", parameters: nil)
            self.dismiss(animated: true, completion: nil)
        }else if sender.tag == 20{
            // self.attchButton.tag = 25
            self.badgeLabel.isHidden = true
            Constants.setValueInUserDefaults(objValue:"" , for:"attachImage")
            self.attachLabel.text = NSLocalizedString("lbl_attachaphoto", comment: "")
            self.attachImage.image = UIImage.init(named: "icon_camera")
            self.cameraSelected()
            //  self.displayCameraFunctionality()
        }/*else if sender.tag == 25{
             self.badgeLabel.isHidden = true
             self.attchButton.tag = 20
             Analytics.logEvent("ParcelSizesViewController_ClearParcelImageButtonTapped", parameters: nil)
             Constants.setValueInUserDefaults(objValue:"" , for:"attachImage")
             self.attachLabel.text = NSLocalizedString("lbl_attachaphoto", comment: "")
             self.attachImage.image = UIImage.init(named: "icon_camera")
         }*/else if sender.tag == 30{
            self.dismissKeyboardForPopup()
            self.lengthDropDown.show()
        }else if sender.tag == 40{
            self.dismissKeyboardForPopup()
            self.widthDropDown.show()
        }else if sender.tag == 50{
            self.dismissKeyboardForPopup()
            self.heightDropDown.show()
        }else if sender.tag == 60{
            self.concateDimensions()
        }else if sender.tag == 70{
            if self.selectDimensionTF.text?.count != 0 && self.selectedDimensionValuesLabel.text?.count != 0{
                self.popupBgViewYaxis.constant = 0
                self.backgroundView.isHidden = true
            }else{
                self.selectDimensionTF.text = ""
                self.resetParcelSizes()
                self.dismissTextFileds()
                self.popupBgViewYaxis.constant = 0
                self.backgroundView.isHidden = true
            }
        }else if sender.tag == 80{
            self.continueBtnTapped()
        }else if sender.tag == 90{
            self.yesBtn.isSelected = true
            self.yesBtn.setBackgroundImage(UIImage.init(named: "icon_selectedBtn"), for: UIControl.State.normal)
            self.noBtn.isSelected = false
            self.noBtn.setBackgroundImage(UIImage.init(named: "icon_unselectedBtn"), for: UIControl.State.normal)
            Constants.setValueInUserDefaults(objValue:"Yes" , for:"insured")
        }else if sender.tag == 100{
            Constants.setValueInUserDefaults(objValue:"No" , for:"insured")
            self.yesBtn.isSelected = false
            self.noBtn.isSelected = true
            self.yesBtn.setBackgroundImage(UIImage.init(named: "icon_unselectedBtn"), for: UIControl.State.normal)
            self.noBtn.setBackgroundImage(UIImage.init(named: "icon_selectedBtn"), for: UIControl.State.normal)
        }
    }
    func dismissTextFileds(){
        self.lengthTxt.resignFirstResponder()
        self.widthTxt.resignFirstResponder()
        self.heightTxt.resignFirstResponder()
    }
    func continueBtnTapped(){
        Analytics.logEvent("ParcelSizesViewController_ContinueButtonTapped", parameters: nil)
        if self.selectTypeTF.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("lbl_typeparcel",comment: ""), completion: {(result) in
            })
        }else{
            var parcelDimensionValues = ""
            if self.selectedDimensionValuesLabel.text?.count != 0{
                parcelDimensionValues = self.selectedDimensionValuesLabel.text!
            }
            if self.selectDimensionTF.text == NSLocalizedString("lbl_selectcustom", comment: ""){
                Constants.setValueInUserDefaults(objValue:"Custom" , for:"DimensionType")
            }else{
                Constants.setValueInUserDefaults(objValue:"Box" , for:"DimensionType")
            }
            Constants.setValueInUserDefaults(objValue:parcelDimensionValues , for:"parcelDimensions")
            
            var notesTextStr = ""
            if self.notesTextView.text.count != 0{
                notesTextStr = self.notesTextView.text!
            }
            var weightStr = "0 kg"
            if self.selectWeightTF.text?.count != 0{
                weightStr = self.selectWeightTF.text!
            }
            Constants.setValueInUserDefaults(objValue:weightStr , for:"weight")
            Constants.setValueInUserDefaults(objValue:notesTextStr , for:"parcelNotes")
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "PickupAddressVC") as! PickupAddressVC
            self.present(nextViewController, animated:true, completion: nil)
        }
    }
    func resetDimensionsForCustom(){
        self.lengthTxt.text = ""
        self.widthTxt.text = ""
        self.heightTxt.text = ""
        self.heightUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
        self.widthUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
        self.lengthUnitTF.text = NSLocalizedString("lbl_cm", comment: "")
    }
    func concateDimensions(){
        
        if lengthTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_length",comment: ""), completion: {(result) in
                self.lengthTxt.becomeFirstResponder()
            })
            return
        }else if heightTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_height",comment: ""), completion: {(result) in
                self.heightTxt.becomeFirstResponder()
            })
            return
        }else if widthTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_width",comment: ""), completion: {(result) in
                self.widthTxt.becomeFirstResponder()
            })
            return
        }else if Double(lengthTxt.text!) == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_length",comment: ""), completion: {(result) in
                self.lengthTxt.becomeFirstResponder()
            })
            return
        }else if Double(widthTxt.text!) == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_width",comment: ""), completion: {(result) in
                self.widthTxt.becomeFirstResponder()
            })
            return
        }else if Double(heightTxt.text!) == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_height",comment: ""), completion: {(result) in
                self.heightTxt.becomeFirstResponder()
            })
            return
        }else if lengthUnitTF.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_lengthunit",comment: ""), completion: {(result) in
            })
            return
        }else if heightUnitTF.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_heightunit",comment: ""), completion: {(result) in
            })
            return
        }else if widthUnitTF.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_widthunit",comment: ""), completion: {(result) in
            })
            return
        }else if lengthUnitTF.text ==   NSLocalizedString("lbl_Dropdownunit", comment: "") {
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_lengthunit",comment: ""), completion: {(result) in
            })
            return
        }else if heightUnitTF.text ==  NSLocalizedString("lbl_Dropdownunit", comment: ""){
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_heightunit",comment: ""), completion: {(result) in
            })
            return
        }else if widthUnitTF.text ==   NSLocalizedString("lbl_Dropdownunit", comment: ""){
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_widthunit",comment: ""), completion: {(result) in
            })
            return
        }else{
            self.dismissTextFileds()
            self.backgroundView.isHidden = true
            self.selectDimensionTF.text = NSLocalizedString("lbl_selectcustom", comment: "")
            var lengthStr = ""
            var widthStr = ""
            var heightStr = ""
            var unitStr = ""
            var concateString = ""
            lengthStr = self.lengthTxt.text!
            widthStr = self.widthTxt.text!
            heightStr = self.heightTxt.text!
            unitStr  = self.lengthUnitTF.text!
            if lengthStr != ""{
                concateString += lengthStr + " x "
            }
            if widthStr != ""{
                concateString += widthStr + " x "
            }
            if heightStr != ""{
                concateString += heightStr + " "
            }
            if unitStr != ""{
                concateString += unitStr
            }
            if self.lengthTxt.text?.count == 0 && self.widthTxt.text?.count == 0 &&    self.heightTxt.text?.count == 0{
                Constants.setValueInUserDefaults(objValue:"0 cm", for:"length")
                Constants.setValueInUserDefaults(objValue:"0 cm" , for:"width")
                Constants.setValueInUserDefaults(objValue:"0 cm" , for:"height")
            }else{
                self.selectedDimensionValuesLabel.text = concateString
                self.hideLabelHC.constant = 25
                self.selectedDimensionValuesLabelHC.constant = 25
                self.hideLabel.isHidden = false
                self.selectedDimensionValuesLabel.isHidden = false
                self.splitTheDimensions(concateStr: concateString)
            }
        }
    }
    func splitTheDimensions(concateStr : String){
        var length = ""
        var width = ""
        var height = ""
        var height1 = ""
        var dimensionStr = ""
        let splitStr =  concateStr.split{$0 == "x"}.map(String.init)
        //  print(splitStr)
        length = splitStr[0]
        length = self.removeTheWhiteSpaceFromDimensions(str: length)
        width = splitStr[1]
        width = self.removeTheWhiteSpaceFromDimensions(str: width)
        height = splitStr[2]
        // print(height)
        let splitHeightStr =  height.split{$0 == " "}.map(String.init)
        height1 = splitHeightStr[0]
        height1 = self.removeTheWhiteSpaceFromDimensions(str: height1)
        dimensionStr = splitHeightStr[1]
        
        if dimensionStr == NSLocalizedString("lbl_cm", comment: ""){
            length += " " + NSLocalizedString("lbl_cm", comment: "")
            width += " " + NSLocalizedString("lbl_cm", comment: "")
            height1 += " " + NSLocalizedString("lbl_cm", comment: "")
        }else if dimensionStr == NSLocalizedString("lbl_mm", comment: ""){
            length += " " + NSLocalizedString("lbl_mm", comment: "")
            width += " " + NSLocalizedString("lbl_mm", comment: "")
            height1 += " " + NSLocalizedString("lbl_mm", comment: "")
        }else if dimensionStr == NSLocalizedString("lbl_m", comment: ""){
            length += " " + NSLocalizedString("lbl_m", comment: "")
            width += " " + NSLocalizedString("lbl_m", comment: "")
            height1 += " " + NSLocalizedString("lbl_m", comment: "")
        }
        Constants.setValueInUserDefaults(objValue:length, for:"length")
        Constants.setValueInUserDefaults(objValue:width , for:"width")
        Constants.setValueInUserDefaults(objValue:height1 , for:"height")
    }
    func removeTheWhiteSpaceFromDimensions(str : String)->String{
        let formattedString = str.replacingOccurrences(of: " ", with: "")
        // print(formattedString)
        return formattedString
    }
    func displayCameraFunctionality() {
        let optionMenuController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let cameraAction = UIAlertAction(title: NSLocalizedString("lbl_camera", comment: ""), style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            Analytics.logEvent("ParcelSizesViewController_SelectCameraToTakeParcelImageButtonTapped", parameters: nil)
            self.camera()
        })
        let cancelAction = UIAlertAction(title: NSLocalizedString("btn_cancel", comment: ""), style: .default , handler: {
            (alert: UIAlertAction!) -> Void in
            Analytics.logEvent("ParcelSizesViewController_CanceledParcelImageButtonTapped", parameters: nil)
            
        })
        optionMenuController.addAction(cameraAction)
        optionMenuController.addAction(cancelAction)
        self.present(optionMenuController, animated: true, completion: nil)
    }
    func photolibrary(){
        picker.delegate = self
        picker.allowsEditing = false
        picker.sourceType = .photoLibrary
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(picker, animated: true, completion: nil)
    }
    func camera(){
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            picker.delegate = self
            picker.allowsEditing = false
            picker.sourceType = UIImagePickerController.SourceType.camera
            picker.cameraCaptureMode = .photo
            picker.modalPresentationStyle = .fullScreen
            present(picker,animated: true,completion: nil)
        } else {
            noCamera()
        }
    }
    func noCamera(){
        let alertVC = UIAlertController(
            title: "No Camera",
            message: "Sorry, this device has no camera",
            preferredStyle: .alert)
        let okAction = UIAlertAction(
            title: NSLocalizedString("lbl_ok", comment: ""),
            style:.default,
            handler: nil)
        alertVC.addAction(okAction)
        present(
            alertVC,
            animated: true,
            completion: nil)
    }
    func dismissKeyboardForPopup(){
        lengthTxt.resignFirstResponder()
        widthTxt.resignFirstResponder()
        heightTxt.resignFirstResponder()
    }
    @IBAction func dropdownViewsTapped(_ sender: UIControl) {
        if sender.tag == 10{
            if self.parcelTypeArray.count == 0{
                self.getParcelTypeApi()
            }else{
                self.selectTypeDropDown.show()
            }
        }else if sender.tag == 20{
            if selectTypeTF.text == ""{
                self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("lbl_typeparcel",comment: ""), completion: {(result) in
                })
            }else{
                if self.parcelDimesionArray.count == 0{
                    if parcelTypeIndex == 0 || parcelTypeIndex > 0{
                        let parcelType = self.parcelTypeArray[parcelTypeIndex]
                        self.getDimensionUsingParcelType(type: parcelType.parcel_type_id!)
                    }
                }else{
                    self.selectDimensionDropDown.show()
                }
            }
        }else if sender.tag == 30{
            if selectTypeTF.text == ""{
                self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("lbl_typeparcel",comment: ""), completion: {(result) in
                })
            }else{
                if self.parcelWeightsArray.count == 0{
                    if parcelTypeIndex == 0 || parcelTypeIndex > 0{
                        let parcelType = self.parcelTypeArray[parcelTypeIndex]
                        self.getWeightUsingParcelType(type: parcelType.parcel_type_id!)
                    }
                }else{
                    self.selectWeightDropDown.show()
                }
            }
        }
    }
    func setupSelectTypeDropDown(){
        parcelTypeNameArray.append(NSLocalizedString("lbl_selecttype", comment: ""))
        for parcelTypeDetails in parcelTypeArray{
            let parcelTypeList = parcelTypeDetails
            // print(parcelTypeList.parcel_type!)
            parcelTypeNameArray.append(parcelTypeList.parcel_type!)
        }
        selectTypeDropDown.anchorView = self.selectTypeView
        selectTypeDropDown.dismissMode = .onTap
        selectTypeDropDown.direction = .bottom
        selectTypeDropDown.dataSource = self.parcelTypeNameArray
        selectTypeDropDown.selectionAction = { [unowned self] (index, item) in
            if item == NSLocalizedString("lbl_selecttype", comment: ""){
            }else{
                print(index)
                self.parcelTypeIndex = index-1
                self.selectTypeTF.text = item
                self.resetParcelSizes()
                print(self.parcelTypeArray)
                let parcelTypes = self.parcelTypeArray[index-1]
                self.parcelTypeStatus =  parcelTypes.parcel_type_id!
                print(parcelTypes.parcel_type_id as Any)
                print(parcelTypes.parcel_type as Any)
                Constants.setValueInUserDefaults(objValue:parcelTypes.parcel_type_id! , for:"parceltype")
                self.getDimensionUsingParcelType(type: parcelTypes.parcel_type_id!)
                DispatchQueue.global().sync {
                    self.getWeightUsingParcelType(type: parcelTypes.parcel_type_id!)
                }
            }
        }
    }
    func resetParcelSizes(){
        self.selectDimensionTF.text = ""
        self.selectWeightTF.text = ""
        self.selectDimensionTF.placeholder = NSLocalizedString("lbl_selectdimension", comment: "")
        self.selectWeightTF.placeholder = NSLocalizedString("lbl_selectweight", comment: "")
        self.hideLabelHC.constant = 0
        self.selectedDimensionValuesLabelHC.constant = 0
        self.hideLabel.isHidden = true
        self.selectedDimensionValuesLabel.isHidden = true
    }
    func setupSelectDimensionDropDown(){
        parcelDimensionNameArray.append(NSLocalizedString("lbl_selectdimension", comment: ""))
        for dimensionDetails in parcelDimesionArray{
            let dimensionList = dimensionDetails
            parcelDimensionNameArray.append(dimensionList.name! + "- " +  dimensionList.dimension!)
            
            if self.selectTypeTF.text == "Document"{
                self.selectDimensionTF.text = dimensionList.dimension
                self.selectedDimensionValuesLabel.text = dimensionList.dimension
                self.splitTheDimensions(concateStr: self.selectedDimensionValuesLabel.text!)
                Constants.setValueInUserDefaults(objValue:self.selectDimensionTF.text! , for:"Dimension")
            }
        }
        if self.parcelTypeStatus == "1"{
            parcelDimensionNameArray.append(NSLocalizedString("lbl_selectcustom", comment: ""))
        }
        selectDimensionDropDown.anchorView = self.selectDimensionView
        selectDimensionDropDown.dismissMode = .onTap
        selectDimensionDropDown.direction = .bottom
        selectDimensionDropDown.dataSource = parcelDimensionNameArray
        selectDimensionDropDown.selectionAction = { [unowned self] (index, item) in
            if item == NSLocalizedString("lbl_selectdimension", comment: ""){
                
            }else{
                if self.parcelDimesionArray.count == index-1{
                    //set custom dimensions
                   // self.resetDimensionsForCustom()
                    self.backgroundView.isHidden = false
                   // self.selectDimensionTF.text = item
                }else{
                    //  print(index)
                    let parcelDimens = self.parcelDimesionArray[index-1]
                   // print(parcelDimens.dimension!)
                    self.selectDimensionTF.text = ""
                    self.selectedDimensionValuesLabel.text = ""
                    self.selectDimensionTF.text = item
                    self.selectedDimensionValuesLabel.text = parcelDimens.dimension!
                    self.splitTheDimensions(concateStr: self.selectedDimensionValuesLabel.text!)
                    self.hideLabelHC.constant = 0
                    self.selectedDimensionValuesLabelHC.constant = 0
                    self.hideLabel.isHidden = false
                    self.selectedDimensionValuesLabel.isHidden = true
                }
            }
        }
    }
    func setupSelectWeightDropDown(){
        parcelWeightNameArray.append(NSLocalizedString("lbl_selectweight", comment: ""))
        for weightDetails in parcelWeightsArray{
            let weightList = weightDetails
            //print(weightList.weight ?? "")
            parcelWeightNameArray.append(weightList.weight!)
            
            if self.selectTypeTF.text == "Document"{
                self.selectWeightTF.text = weightList.weight
                Constants.setValueInUserDefaults(objValue:self.selectWeightTF.text! , for:"weight")
            }
        }
        selectWeightDropDown.anchorView = self.selectWeightView
        selectWeightDropDown.dismissMode = .onTap
        selectWeightDropDown.direction = .bottom
        selectWeightDropDown.dataSource = parcelWeightNameArray
        selectWeightDropDown.selectionAction = { [unowned self] (index, item) in
            if item == NSLocalizedString("lbl_selectweight", comment: ""){
                Constants.setValueInUserDefaults(objValue:"", for:"weight")
            }else{
                // print(index)
                let weights = self.parcelWeightsArray[index-1]
                // print(weights.weight!)
                self.selectWeightTF.text = item
                Constants.setValueInUserDefaults(objValue:self.selectWeightTF.text! , for:"weight")
            }
        }
    }
    func setupLengthDropDown(){
        lengthDropDown.anchorView = self.lengthButton
        lengthDropDown.dismissMode = .onTap
        lengthDropDown.direction = .bottom
        lengthDropDown.dataSource = [
            NSLocalizedString("lbl_Dropdownunit", comment: ""),
            NSLocalizedString("lbl_mm", comment: ""),
            NSLocalizedString("lbl_cm", comment: ""),
            NSLocalizedString("lbl_m", comment: "")
        ]
        lengthDropDown.selectionAction = { [unowned self] (index, item) in
            self.lengthUnitTF.text = item
            if self.lengthUnitTF.text ==  NSLocalizedString("lbl_mm", comment: ""){
                self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                if self.widthUnitTF.text == "" && self.heightUnitTF.text == "" {
                    self.widthUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
                    self.heightUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                }
                else{
                    self.widthUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
                    self.heightUnitTF.text = NSLocalizedString("lbl_mm", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                }
            }
            if self.lengthUnitTF.text ==  NSLocalizedString("lbl_cm", comment: ""){
                if self.widthUnitTF.text == "" && self.heightUnitTF.text == "" {
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                }else{
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                }
            }
            if self.lengthUnitTF.text ==  NSLocalizedString("lbl_m", comment: ""){
                if self.widthUnitTF.text == "" && self.heightUnitTF.text == "" {
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                }else{
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                }
            }
        }
    }
    
    func setupWidthDropDown(){
        widthDropDown.anchorView = self.widthButton
        widthDropDown.dismissMode = .onTap
        widthDropDown.direction = .bottom
        widthDropDown.bottomOffset = CGPoint(x: 0, y: self.widthUnitTF.bounds.height)
        widthDropDown.dataSource = [ NSLocalizedString("lbl_Dropdownunit", comment: ""),
                                     NSLocalizedString("lbl_mm", comment: ""),
                                     NSLocalizedString("lbl_cm", comment: ""),
                                     NSLocalizedString("lbl_m", comment: "")
        ]
        widthDropDown.selectionAction = { [unowned self] (index, item) in
            self.widthUnitTF.text = item
            if self.widthUnitTF.text ==  NSLocalizedString("lbl_mm", comment: ""){
                if self.heightUnitTF.text == "" && self.lengthUnitTF.text == ""{
                    self.widthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                }
                else{
                    self.widthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                }
            }
            if self.widthUnitTF.text ==  NSLocalizedString("lbl_m", comment: ""){
                if self.heightUnitTF.text == "" && self.lengthUnitTF.text == ""{
                    self.widthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.heightUnitTF.text = NSLocalizedString("lbl_m", comment:"")
                    self.lengthUnitTF.text = NSLocalizedString("lbl_m", comment:"")
                }
                else{
                    self.widthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.heightUnitTF.text = NSLocalizedString("lbl_m", comment:"")
                    self.lengthUnitTF.text = NSLocalizedString("lbl_m", comment:"")
                }
            }
            if self.widthUnitTF.text ==  NSLocalizedString("lbl_cm", comment: ""){
                if self.heightUnitTF.text == "" && self.lengthUnitTF.text == ""{
                    self.widthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.heightUnitTF.text = NSLocalizedString("lbl_cm", comment:"")
                    self.lengthUnitTF.text = NSLocalizedString("lbl_cm", comment:"")
                }
                else{
                    self.widthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.heightUnitTF.text = NSLocalizedString("lbl_cm", comment:"")
                    self.lengthUnitTF.text = NSLocalizedString("lbl_cm", comment:"")
                }
            }
        }
    }
    func setupHeightDropDown(){
        
        heightDropDown.anchorView = self.heightButton
        heightDropDown.dismissMode = .onTap
        heightDropDown.direction = .bottom
        heightDropDown.bottomOffset = CGPoint(x: 0, y: heightUnitTF.bounds.height)
        heightDropDown.dataSource = [ NSLocalizedString("lbl_Dropdownunit", comment: ""),
                                      NSLocalizedString("lbl_mm", comment: ""),
                                      NSLocalizedString("lbl_cm", comment: ""),
                                      NSLocalizedString("lbl_m", comment: "")
        ]
        
        heightDropDown.selectionAction = { [unowned self] (index, item) in
            self.heightUnitTF.text = item
            if self.heightUnitTF.text ==  NSLocalizedString("lbl_mm", comment: ""){
                self.heightUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                if self.widthUnitTF.text == "" && self.lengthUnitTF.text == ""{
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                }
                else{
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                    self.heightUnitTF.text =  NSLocalizedString("lbl_mm", comment: "")
                }
            }
            if self.heightUnitTF.text ==  NSLocalizedString("lbl_cm", comment: ""){
                if self.widthUnitTF.text == "" && self.lengthUnitTF.text == ""{
                    self.heightUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                }
                else{
                    self.heightUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_cm", comment: "")
                }
            }
            if self.heightUnitTF.text ==  NSLocalizedString("lbl_m", comment: ""){
                if self.widthUnitTF.text == "" && self.lengthUnitTF.text == ""{
                    self.heightUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                }
                else{
                    self.heightUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.lengthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                    self.widthUnitTF.text =  NSLocalizedString("lbl_m", comment: "")
                }
            }
        }
    }
    func getParcelTypeApi(){
        IJProgressView.shared.showProgressView(view)
        var token = String()
        var sessionToken = ""
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            sessionToken = "Bearer" + " " + token
        }
        // print(sessionToken)
        APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.getParcelTypeURL
        , method: "GET", token:sessionToken, body: "", productBody: nil) { (data,error,response) in
            if let httpResponse = response as? HTTPURLResponse{
                //   print("httpResponse status code \(httpResponse.statusCode)")
                switch(httpResponse.statusCode){
                case 200:
                    if let receivedData = data{
                        do{
                            let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                                if let Result = resultDic as? [String:Any]{
                                    //  print("Result",Result)
                                    self.parcelTypeArray.removeAll()
                                    self.parcelTypeNameArray.removeAll()
                                    let newArray  = Result["Msg"] as? [[String:Any]]
                                    for resultDic in newArray!{
                                        var parcelType = ""
                                        var parcelTypeID = ""
                                        if let parcelTypeStr = resultDic["parcel_type"] as? String{
                                            parcelType = parcelTypeStr
                                        }
                                        if let parcelTypeIdStr = resultDic["parcel_type_id"] as? Int{
                                            parcelTypeID = String(parcelTypeIdStr)
                                        }
                                        let parcelTypeList = ParcelType(parcel_type: parcelType, parcel_type_id: parcelTypeID)
                                        self.parcelTypeArray.append(parcelTypeList)
                                    }
                                    self.setupSelectTypeDropDown()
                                }
                            }
                        }catch {
                            self.somethingWentWrong()
                        }
                    }
                    break
                case 500:
                    self.somethingWentWrong()
                    break
                case 505:
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "ParcelType_505", controller: self)
                    }
                    break
                case 506:
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "ParcelType_506", controller: self)
                    }
                    break
                case 498:
                    DispatchQueue.main.async {
                        self.tokenExpireAlert()
                    }
                    break
                default:
                    self.somethingWentWrong()
                }
            }else{
                self.somethingWentWrong()
            }
        }
    }
    func getDimensionUsingParcelType(type : String){
        if self.ineternetAlert() == false{
            return
        }
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        bodyReq = ["parcel_type":type]
        var token = String()
        var sessionToken = ""
        // print(bodyReq)
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            sessionToken = "Bearer" + " " + token
        }
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.getParcelDimensionURL , method: "POST", token:sessionToken, body: "", productBody: bodyData as NSData) {(data,error,response)  in
                
                if let httpResponse = response as? HTTPURLResponse{
                    // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        if let receivedData = data{
                            do{
                                let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    if let Result = resultDic as? [String:Any]{
                                        print("Dimension Result\(Result)")
                                        self.parcelDimensionNameArray.removeAll()
                                        self.parcelDimesionArray.removeAll()
                                        let newArray  = Result["Msg"] as? [[String:Any]]
                                        for resultDic in newArray!{
                                            var parcelDimension = ""
                                            var parcelName = ""
                                            var parcelDimensionId = ""
                                            var parcelTypefdId = ""
                                            if let dimension = resultDic["dimension"] as? String{
                                                parcelDimension = dimension
                                            }
                                            if let name = resultDic["name"] as? String{
                                                parcelName = name
                                            }
                                            if let parcel_dimen_id = resultDic["parcel_dimen_id"] as? Int{
                                                parcelDimensionId = String(parcel_dimen_id)
                                            }
                                            if let parcel_type_fk_id = resultDic["parcel_type_fk_id"] as? Int{
                                                parcelTypefdId = String(parcel_type_fk_id)
                                            }
                                            let parcelDimensionObj = ParcelDimension(dimension: parcelDimension, name: parcelName, parcel_dimen_id: parcelDimensionId, parcel_type_fk_id: parcelTypefdId)
                                            self.parcelDimesionArray.append(parcelDimensionObj)
                                        }
                                        self.setupSelectDimensionDropDown()
                                    }
                                }
                            }catch {
                                self.somethingWentWrong()
                            }
                        }
                        break
                    case 500:
                        self.somethingWentWrong()
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "ParcelDimension_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "ParcelDimension_506", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                    default:
                        self.somethingWentWrong()
                    }
                }else{
                    self.somethingWentWrong()
                }
            }
        }
    }
    func somethingWentWrong(){
        DispatchQueue.main.async {
            IJProgressView.shared.hideProgressView()
            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
        }
    }
    func getWeightUsingParcelType(type : String){
        if self.ineternetAlert() == false{
            return
        }
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        bodyReq = ["parcel_type":type]
        var token = String()
        var sessionToken = ""
        // print(bodyReq)
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            sessionToken = "Bearer" + " " + token
        }
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.getParcelWeightsURL , method: "POST", token:sessionToken, body: "", productBody: bodyData as NSData) {(data,error,response)  in
                
                if let httpResponse = response as? HTTPURLResponse{
                    // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        if let receivedData = data{
                            do{
                                let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    if let Result = resultDic as? [String:Any]{
                                        print("weight result\(Result)")
                                        self.parcelWeightNameArray.removeAll()
                                        self.parcelWeightsArray.removeAll()
                                        let newArray  = Result["Msg"] as? [[String:Any]]
                                        for resultDic in newArray!{
                                            var parcelWeights = ""
                                            var parcelName = ""
                                            var parcelWeightId = ""
                                            var parcelTypefdId = ""
                                            if let weight = resultDic["weight"] as? String{
                                                parcelWeights = weight
                                            }
                                            if let name = resultDic["name"] as? String{
                                                parcelName = name
                                            }
                                            if let parcel_weight_id = resultDic["parcel_weight_id"] as? Int{
                                                parcelWeightId = String(parcel_weight_id)
                                            }
                                            if let parcel_type_fk_id = resultDic["parcel_type_fk_id"] as? Int{
                                                parcelTypefdId = String(parcel_type_fk_id)
                                            }
                                            // print(parcelWeights)
                                            // print(parcelName)
                                            // print(parcelWeightId)
                                            // print(parcelTypefdId)
                                            let parcelDimensionObj = ParcelWeights(weight: parcelWeights, name: parcelName, parcel_weight_id: parcelWeightId, parcel_type_fk_id: parcelTypefdId)
                                            self.parcelWeightsArray.append(parcelDimensionObj)
                                        }
                                        self.setupSelectWeightDropDown()
                                    }
                                }
                            }catch {
                                self.somethingWentWrong()
                            }
                        }
                        break
                    case 500:
                        self.somethingWentWrong()
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "ParcelWeight_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "ParcelWeight_506", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                    default:
                        self.somethingWentWrong()
                    }
                }else{
                    self.somethingWentWrong()
                }
            }
        }
    }
}
extension ParcelSizesViewController : UITextViewDelegate{
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        if appdelegate.IS_IPHONE6PLUS {
            self.scrollView.contentOffset = CGPoint(x: 0, y: 150)
        }else if appdelegate.IS_IPHONE5{
            self.scrollView.contentOffset = CGPoint(x: 0, y: 280)
        }else if appdelegate.IS_IPHONE6{
            self.scrollView.contentOffset = CGPoint(x: 0, y: 200)
        }else if appdelegate.IS_IPHONEX{
            self.scrollView.contentOffset = CGPoint(x: 0, y: 150)
        }
        return true
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        self.activeField = nil
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
}
extension ParcelSizesViewController : UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField){
        if textField == self.lengthTxt{
            self.lengthTxt.keyboardType = .decimalPad
            self.addBarBtnToKeyboard(textfield: self.lengthTxt)
        }else if textField == self.widthTxt{
            textField.keyboardType = .decimalPad
            self.addBarBtnToKeyboard(textfield: self.widthTxt)
        }else if textField == self.heightTxt{
            if appdelegate.IS_IPHONE5{
                self.popupBgViewYaxis.constant = -80
            }else if appdelegate.IS_IPHONE6{
                self.popupBgViewYaxis.constant = -50
            }else if appdelegate.IS_IPHONEX{
                self.popupBgViewYaxis.constant = -50
            }else if appdelegate.IS_IPHONE6PLUS{
                self.popupBgViewYaxis.constant = -50
            }
            textField.keyboardType = UIKeyboardType.decimalPad
            self.addBarBtnToKeyboard(textfield: self.heightTxt)
        }
        self.activeField = textField
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        if textField == lengthTxt || textField == widthTxt || textField == heightTxt{
            let inverseSet = NSCharacterSet(charactersIn:"0123456789").inverted
            let components = string.components(separatedBy: inverseSet)
            let filtered = components.joined(separator: "")
            if filtered == string {
                let computationString = (textField.text! as NSString).replacingCharacters(in: range, with:filtered)
                let arrayOfSubStrings = computationString.components(separatedBy: ".")
                if arrayOfSubStrings.count == 1 && computationString.count > ConstantsLengthString.MAX_BEFORE_DECIMAL_DIGITS {
                    return false
                }else if arrayOfSubStrings.count == 2 {
                    let stringPostDecimal = arrayOfSubStrings[1]
                    return stringPostDecimal.count <= ConstantsLengthString.MAX_AFTER_DECIMAL_DIGITS
                }
                return true
            } else {
                if string == "." {
                    let countdots = textField.text!.components(separatedBy:".").count - 1
                    if countdots == 0 {
                        return true
                    }else{
                        if countdots > 0 && string == "." {
                            return false
                        } else {
                            return true
                        }
                    }
                }else{
                    return false
                }
            }
        }
        return true
    }
    func addBarBtnToKeyboard(textfield : UITextField){
        let keyPadToolBar = UIToolbar()
        keyPadToolBar.barStyle = UIBarStyle.blackTranslucent
        keyPadToolBar.barTintColor = AppColors.greenColorRGB
        keyPadToolBar.sizeToFit()
        let doneButton = UIBarButtonItem(title: NSLocalizedString("keyboard_done", comment: ""), style: UIBarButtonItem.Style.done, target: self, action: #selector(ParcelSizesViewController.dismissKeypad))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace , target: self, action: nil)
        doneButton.tintColor = AppColors.whiteColorRGB
        let nextButton = UIBarButtonItem(title: NSLocalizedString("keyboard_next", comment: ""), style: UIBarButtonItem.Style.done, target: self, action: #selector(ParcelSizesViewController.nextButtonTapped))
        nextButton.tintColor = AppColors.whiteColorRGB
        if textfield == self.heightTxt{
            keyPadToolBar.setItems([doneButton], animated: true)
        }else{
            keyPadToolBar.setItems([doneButton,spaceButton,nextButton], animated: true)
        }
        textfield.inputAccessoryView = keyPadToolBar
    }
    @objc func dismissKeypad (){
        self.widthTxt.resignFirstResponder()
        self.heightTxt.resignFirstResponder()
        self.lengthTxt.resignFirstResponder()
    }
    @objc func nextButtonTapped (){
        if activeField == self.lengthTxt{
            self.widthTxt.becomeFirstResponder()
        }else if activeField == self.widthTxt{
            self.heightTxt.becomeFirstResponder()
        }else if activeField == self.heightTxt{
        }
    }
    func previouesButtonTapped (){
        if activeField == self.widthTxt{
            DispatchQueue.main.async(){
                UIView.animate(withDuration: 0.0, delay: 0, options: UIView.AnimationOptions.curveLinear, animations: {
                }, completion: nil)
            }
            self.lengthTxt.becomeFirstResponder()
        }else  if activeField == self.heightTxt{
            self.widthTxt.becomeFirstResponder()
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField){
        self.activeField = nil
        if textField == self.heightTxt{
            self.popupBgViewYaxis.constant = 0
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        if textField.returnKeyType ==  UIReturnKeyType.next{
            if textField == lengthTxt{
                lengthTxt.resignFirstResponder()
                widthTxt.becomeFirstResponder()
            }
            if textField == widthTxt{
                widthTxt.resignFirstResponder()
                heightTxt.becomeFirstResponder()
            }
            if textField == heightTxt{
                heightTxt.resignFirstResponder()
            }
        }
        return true
    }
}
extension ParcelSizesViewController:UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
// Local variable inserted by Swift 4.2 migrator.
let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)

        if let chosenImage = info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.originalImage)] as? UIImage{
            self.badgeLabel.isHidden = false
            self.attachImageBtnWC.constant = 100
            UserDefaults.standard.set("", forKey: "attachImage")
            self.attachLabel.text = NSLocalizedString("lbl_attachedphoto", comment: "")
            self.attachImage.image = UIImage.init(named: "icon_cancel")
            let profileImage = chosenImage.resizeImage(image: chosenImage)
            print(profileImage.size.width)
            print(profileImage.size.height)
            let imageData = profileImage.jpegData(compressionQuality: 0.5)
            UserDefaults.standard.set(imageData, forKey: "attachImage")
        }else{
            print("Something went wrong")
        }
        self.dismiss(animated:true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated:true, completion: nil)
    }
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
	return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromAVMediaType(_ input: AVMediaType) -> String {
	return input.rawValue
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromUIImagePickerControllerInfoKey(_ input: UIImagePickerController.InfoKey) -> String {
	return input.rawValue
}
