//
//  ProfileViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 24/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import Photos
import PhotosUI
import Firebase

class ProfileVC: UIViewController,UITextFieldDelegate,countryCodeProtocol {
    @IBOutlet weak var editProfile: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var personalLabel: UILabel!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var scrollViewObj: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet var profilePicImg: UIImageView!
    @IBOutlet weak var usernameLbl: UILabel!
    @IBOutlet weak var firstNameTxt: UITextField!
    @IBOutlet weak var lastNameTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var contactNoTxt: UITextField!
    @IBOutlet weak var orgnaisationTxt: UITextField!
    @IBOutlet weak var custtypeTxt: UITextField!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet var countrycodeView: UIView!
    @IBOutlet weak var countryCodeTxt: UITextField!
    @IBOutlet weak var countryButton: UIButton!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    @IBOutlet weak var editBtnTC: NSLayoutConstraint!
    
    var myActivityIndicator = UIActivityIndicatorView()
    let picker = UIImagePickerController()
    var isSearching = false
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var cust_type = ""
    var activeField: UITextField?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        countryCodeTxt.isUserInteractionEnabled = false
        countryButton.isUserInteractionEnabled = false
        self.getProfileApi()
        self.initialSetUp()
        self.intialConstraintsSetup()
        NotificationCenter.default.addObserver(self, selector: #selector(ProfileVC.updateProfileImage) , name:NSNotification.Name(rawValue : "profilepic") , object: nil)
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    @objc func updateProfileImage(){
        self.activityIndicator.stopAnimating()
        self.activityIndicator.isHidden = true
        self.profilePicValidation()
    }
    override func viewWillAppear(_ animated: Bool) {
        appdelegate.profilePicStatus = "yes"
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
            self.editBtnTC.constant = 35
        }
    }
    func resignKeyBoard(){
        firstNameTxt.resignFirstResponder()
        lastNameTxt.resignFirstResponder()
        emailTxt.resignFirstResponder()
        contactNoTxt.resignFirstResponder()
        custtypeTxt.resignFirstResponder()
        orgnaisationTxt.resignFirstResponder()
    }
    func cameraSelected(){
        if AVCaptureDevice.authorizationStatus(for: AVMediaType(rawValue: convertFromAVMediaType(AVMediaType.video))) ==  AVAuthorizationStatus.authorized {
            DispatchQueue.main.async {
                self.camera()
            }
        } else {
            AVCaptureDevice.requestAccess(for: AVMediaType(rawValue: convertFromAVMediaType(AVMediaType.video)), completionHandler: { (granted: Bool) -> Void in
                if granted == true {
                    // User granted
                    DispatchQueue.main.async {
                        self.camera()
                    }
                } else {
                    // User Rejected
                    DispatchQueue.main.async {
                        self.displayCameraAlert()
                    }
                }
            })
        }
    }
    func displayCameraAlert(){
        let actionSheetController: UIAlertController = UIAlertController(title:nil, message: NSLocalizedString("error_cameraservice", comment: ""), preferredStyle: .alert)
        let okaction: UIAlertAction = UIAlertAction(title: "Ok", style: .cancel) { action -> Void in
            //Just dismiss the action sheet
            DispatchQueue.main.async {
                //                if let url = URL(string: "App-Prefs:root=Privacy&path=CAMERA") {
                //                    // If general location settings are disabled then open general location settings
                //                    UIApplication.shared.openURL(url)
                //                }
                // added by shilpa
                guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                    
                    return
                }
                if UIApplication.shared.canOpenURL(settingsUrl)  {
                    if #available(iOS 10.0, *) {
                        UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                        })
                    }
                    else  {
                        UIApplication.shared.openURL(settingsUrl)
                    }
                    
                }
            }
        }
        actionSheetController.addAction(okaction)
        self.present(actionSheetController, animated: true, completion: nil)
    }
    func editProfilePicAction() {
        let optionMenuController = UIAlertController(title: nil, message: "", preferredStyle: .alert)
        let cameraAction = UIAlertAction(title: NSLocalizedString("lbl_camera", comment: ""), style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            Analytics.logEvent("ProfileVC_CameraButtonTapped", parameters: nil)
            self.cameraSelected()
        })
        let gallerAction = UIAlertAction(title: NSLocalizedString("lbl_photolibrary", comment: ""), style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            Analytics.logEvent("ProfileVC_PhotoLibraryButtonTapped", parameters: nil)
            self.photolibrary()
        })
        let cancelAction = UIAlertAction(title: NSLocalizedString("btn_cancel", comment: ""), style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            Analytics.logEvent("ProfileVC_CancelledToUpdatedProfilePic", parameters: nil)
        })
        optionMenuController.addAction(cameraAction)
        optionMenuController.addAction(gallerAction)
        optionMenuController.addAction(cancelAction)
        self.present(optionMenuController, animated: true, completion: nil)
    }
    @objc func showPhotoAndCamera(_ sender:AnyObject){
        self.editProfilePicAction()
    }
    func photolibrary(){
        picker.delegate = self
        picker.allowsEditing = false
        picker.sourceType = .photoLibrary
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(picker, animated: true, completion: nil)
    }
    func camera(){
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            picker.delegate = self
            picker.allowsEditing = false
            picker.sourceType = UIImagePickerController.SourceType.camera
            picker.cameraCaptureMode = .photo
            picker.modalPresentationStyle = .fullScreen
            present(picker,animated: true,completion: nil)
        } else {
            noCamera()
        }
    }
    func noCamera(){
        let alertVC = UIAlertController(
            title: "No Camera",
            message: "Sorry, this device has no camera",
            preferredStyle: .alert)
        let okAction = UIAlertAction(
            title: NSLocalizedString("lbl_ok", comment: ""),
            style:.default,
            handler: nil)
        alertVC.addAction(okAction)
        present(
            alertVC,
            animated: true,
            completion: nil)
    }
    override func viewDidLayoutSubviews() {
        DispatchQueue.main.async {
            self.scrollViewObj.translatesAutoresizingMaskIntoConstraints = true
            self.scrollViewObj.contentSize = CGSize(width: self.scrollViewObj.frame.width, height: self.contentView.frame.origin.y+self.contentView.frame.size.height);
        }
    }
    func initialSetUp(){
        self.usernameLbl?.textColor = AppColors.greenColorRGB
        self.editButton.setTitle(NSLocalizedString("btn_edit", comment: ""), for:.normal)
        self.editButton.titleLabel?.textColor = AppColors.greenColorRGB
        self.editButton.titleLabel?.font = AppFont.regularTextFont
        self.titleLbl.text = NSLocalizedString("lbl_profile", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        self.titleLbl.textColor = AppColors.whiteColorRGB
        self.personalLabel.text = NSLocalizedString("lbl_peronal", comment: "")
        self.personalLabel.font = AppFont.regularTextFont
        self.personalLabel.textColor = AppColors.blackColorRGB
        self.firstNameTxt.placeholder = NSLocalizedString("txt_firstname", comment: "")
        self.firstNameTxt.font = AppFont.regularTextFont
        self.lastNameTxt.placeholder = NSLocalizedString("txt_lastname", comment: "")
        self.lastNameTxt.font = AppFont.regularTextFont
        self.contactNoTxt.placeholder = NSLocalizedString("txt_mobileno", comment: "")
        self.lastNameTxt.font = AppFont.regularTextFont
        self.emailTxt.placeholder = NSLocalizedString("txt_eamil", comment: "")
        self.emailTxt.font = AppFont.regularTextFont
        self.custtypeTxt.placeholder = NSLocalizedString("lbl_custtype", comment: "")
        self.custtypeTxt.font = AppFont.regularTextFont
        self.orgnaisationTxt.placeholder = NSLocalizedString("txt_organisation", comment: "")
        self.orgnaisationTxt.font = AppFont.regularTextFont
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        profilePicImg.layer.masksToBounds = true
        profilePicImg.layer.cornerRadius =  profilePicImg.frame.size.width/2
        self.profilePicValidation()
        self.registerForKeyboardNotifications()
        firstNameTxt.textColor = AppColors.lightGrayColorRGB
        lastNameTxt.textColor = AppColors.lightGrayColorRGB
        countryCodeTxt.textColor = AppColors.lightGrayColorRGB
        emailTxt.textColor = AppColors.lightGrayColorRGB
        contactNoTxt.textColor = AppColors.lightGrayColorRGB
        orgnaisationTxt.textColor = AppColors.lightGrayColorRGB
        firstNameTxt.isUserInteractionEnabled = false
        lastNameTxt.isUserInteractionEnabled = false
        emailTxt.isUserInteractionEnabled = false
        contactNoTxt.isUserInteractionEnabled = false
        custtypeTxt.isUserInteractionEnabled = false
        orgnaisationTxt.isUserInteractionEnabled = false
        firstNameTxt.delegate = self
        lastNameTxt.delegate = self
        emailTxt.delegate = self
        contactNoTxt.delegate = self
        custtypeTxt.delegate = self
        orgnaisationTxt.delegate = self
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ProfileVC.showPhotoAndCamera(_:)))
        self.profilePicImg.isUserInteractionEnabled = false
        self.profilePicImg.addGestureRecognizer(tapGestureRecognizer)
    }
    func profilePicValidation(){
        if Constants.getValueFromUserDefults(for: "profileImgLink") as? String == nil || Constants.getValueFromUserDefults(for: "profileImgLink") as? String == ""{
            if UserDefaults.standard.value(forKey: "propic") as? NSData != nil{
                let propicdata = UserDefaults.standard.object(forKey: "propic") as! NSData
                self.profilePicImg.image = UIImage(data: propicdata as Data)
            }else{
                self.profilePicImg.image = UIImage.init(named: "icon_profile")
            }
        }else{
            if UserDefaults.standard.value(forKey: "propic") as? NSData == nil{
                self.profilePicImg.image = UIImage.init(named: "icon_profile")
                self.profileImageURL()
            }else {
                let propicdata = UserDefaults.standard.object(forKey: "propic") as! NSData
                self.profilePicImg.image = UIImage(data: propicdata as Data)
            }
        }
    }
    func getImageFromApi(){
        self.getProfilePicData(completion: {(responseData,error) in
            if responseData != nil{
                if let image = UIImage(data: responseData! as Data) {
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        self.activityIndicator.isHidden = true
                        self.profilePicImg.image = image
                        UserDefaults.standard.set(responseData, forKey: "propic")
                    }
                }else{
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        self.activityIndicator.isHidden = true
                        self.profilePicImg.image = UIImage.init(named: "icon_profile")
                    }
                }
            }else{
                DispatchQueue.main.async {
                    self.activityIndicator.stopAnimating()
                    self.activityIndicator.isHidden = true
                    self.profilePicImg.image = UIImage.init(named: "icon_profile")
                }
            }
        })
    }
    func sendCountryCode(code: String) {
        self.countryCodeTxt.text = code
    }
    func navigateToSearchCountryCode(){
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let countryCode = storyBoard.instantiateViewController(withIdentifier: "SearchCountryCodeVC") as! SearchCountryCodeVC
        countryCode.delegate = self
        self.present(countryCode, animated: true, completion: nil)
    }
    func profileImageURL(){
        self.activityIndicator.isHidden = false
        self.activityIndicator.startAnimating()
        DispatchQueue.global().async {
            self.getImageFromApi()
            /* let profileImageURL = Constants.getValueFromUserDefults(for: "profileImgLink") as! String
             let concateStr = APPURLS.getProfilePicUrl + profileImageURL
             let url = NSURL(string: concateStr)
             do {
             let data = try Data(contentsOf: url! as URL)
             if let image = UIImage(data: data) {
             DispatchQueue.main.async {
             self.activityIndicator.stopAnimating()
             self.activityIndicator.isHidden = true
             self.profilePicImg.image = image
             UserDefaults.standard.set(data, forKey: "propic")
             }
             }else{
             self.profileImageURL()
             }
             } catch {
             print("Unable to load data: \(error)")
             DispatchQueue.main.async {
             self.activityIndicator.stopAnimating()
             self.activityIndicator.isHidden = true
             }
             // self.displayAlert(message: NSLocalizedString("error_downloadpicfail", comment: ""))
             // self.profileImageURL()
             }*/
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear (animated)
        appdelegate.profilePicStatus = ""
        self.deregisterFromKeyboardNotifications()
    }
    @IBAction func editProfileIconTapped(_ sender : UIButton){
        self.editProfilePicAction()
    }
    override func didReceiveMemoryWarning(){
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnsTapped(_ sender : UIButton){
        let btn = sender as UIButton
        if btn.tag == 10{
            Analytics.logEvent("ProfileVC_CancelledButtonTapped", parameters: nil)
            self.resignKeyBoard()
            self.dismiss(animated: true, completion: nil)
        }else if btn.tag == 20{
            Analytics.logEvent("ProfileVC_UpdateProfileDetailsButtonTapped", parameters: nil)
            self.resignKeyBoard()
            updateProfileAddress()
        }else if btn.tag == 100{
            self.resignKeyBoard()
            self.navigateToSearchCountryCode()
            //            self.isSearching = false
            //            self.searchBar.text = ""
            //            self.countryView.isHidden = false
        }
    }
    func updateProfileAddress(){
        
        if firstNameTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("valid_firstname", comment: ""), completion: {(result) in
                self.editButton.setTitle(NSLocalizedString("btn_done1", comment: ""), for: .normal)
                self.editButton.tag = 60
                self.firstNameTxt.becomeFirstResponder()
            })
            return
        }else if lastNameTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("valid_lastname", comment: ""), completion: {(result) in
                self.editButton.setTitle(NSLocalizedString("btn_done1", comment: ""), for: .normal)
                self.editButton.tag = 60
                self.lastNameTxt.becomeFirstResponder()
            })
            return
        }else if self.contactNoTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("valid_mobileno", comment: ""), completion: {(result) in
                self.editButton.setTitle(NSLocalizedString("btn_done1", comment: ""), for: .normal)
                self.editButton.tag = 60
                self.contactNoTxt.becomeFirstResponder()
            })
            return
        }/*else if Constants().validatePhoneNumber(value: self.contactNoTxt.text!) == false{
             self.showAlertMessagewithAction(titleStr:NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("valid_mobileno1", comment: ""), completion: {(result) in
             self.contactNoTxt.becomeFirstResponder()
             })
         }*/else{
            updateprofile()
        }
    }
    func updateprofile(){
        
        if self.ineternetAlert() == false{
            return
        }
        IJProgressView.shared.showProgressView(view)
        var username = ""
        if Constants.getValueFromUserDefults(for:"customer_id") != nil{
            username = Constants.getValueFromUserDefults(for: "customer_id") as! String
        }
        var bodyReq = [String:String]()
        var mobilenum = ""
        mobilenum = self.countryCodeTxt.text! + " " + self.contactNoTxt.text!
        bodyReq = ["customer_id":username,"firstname":self.firstNameTxt.text!,"lastname":self.lastNameTxt.text!,"email":emailTxt.text!,"mobile":mobilenum,"cust_type":self.custtypeTxt.text!]
        //  print("bodyreq",bodyReq)
        var reultanttoken = ""
        
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            let token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            reultanttoken = "Bearer" + " " + token
        }
        
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.updateProfileURL , method: "POST", token:reultanttoken, body: "", productBody: bodyData as NSData) { (data,error,response) in
                
                if let httpResponse = response as? HTTPURLResponse{
                    // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            let finalName = self.firstNameTxt.text!.capitalizedFirst() + " " + self.lastNameTxt.text!.capitalizedFirst()
                            self.usernameLbl.text = finalName
                            Constants.setValueInUserDefaults(objValue:finalName , for:"finalname")
                             self.editButton.setTitle(NSLocalizedString("btn_edit",comment:""),for:.normal)
                            
                            self.firstNameTxt.isUserInteractionEnabled = false
                            self.lastNameTxt.isUserInteractionEnabled = false
                            self.contactNoTxt.isUserInteractionEnabled = false
                            self.countryCodeTxt.isUserInteractionEnabled = false
                            self.firstNameTxt.textColor = .lightGrayColorCode
                            self.lastNameTxt.textColor = .lightGrayColorCode
                            self.contactNoTxt.textColor = .lightGrayColorCode
                            self.countryCodeTxt.textColor = .lightGrayColorCode
                            self.editProfile.isHidden = true

                            self.showAlertMessagewithAction(titleStr:NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("ver_profileupdate", comment: ""), completion: {(result) in
                               // self.dismiss(animated: true, completion: nil)
                            })
                        }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "UpdateProfile_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "GetProfile_506", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                    default:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                    }
                }
            }
        }
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    
    func getProfileApi(){
        if self.ineternetAlert() == false{
            return
        }
        IJProgressView.shared.showProgressView(view)
        var customerId = ""
        if Constants.getValueFromUserDefults(for:"customer_id") != nil{
            customerId = Constants.getValueFromUserDefults(for: "customer_id") as! String
        }
        var bodyReq = [String:String]()
        bodyReq = ["customer_id":customerId]
        // print("bodyreq",bodyReq)
        var sessionToken = ""
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            let token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            sessionToken = "Bearer" + " " + token
        }
        //   print("token",sessionToken)
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
        {
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.getProfileURL , method: "POST", token:sessionToken, body: "", productBody: bodyData as NSData) { (data,error,response) in
                
                if let httpResponse = response as? HTTPURLResponse{
                    // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        if let receivedData = data{
                            do{
                                let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    self.responseApi(response: resultDic as! [String : Any])
                                }
                            }catch {
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                }
                            }
                        }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "GetProfile_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "GetProfile_506", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                    default:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                    }
                }
            }
        }
    }
    func responseApi(response: [String : Any]){
        if let customerDetails = response["customer_details"] as? [[String:Any]]{
            for array in customerDetails {
                if let firstname = array["firstname"] as? String{
                    self.firstNameTxt.text =  firstname.capitalizedFirst()
                }
                if let custtype = array["cust_type"] as? String{
                    self.cust_type = custtype
                }
                if let orgType = array["org_name"] as? String{
                    self.orgnaisationTxt.text = orgType
                }
                if let lastname = array["lastname"] as? String{
                    self.lastNameTxt.text = lastname.capitalizedFirst()
                }
                if let email = array["email"] as? String{
                    self.emailTxt.text = email
                }
                let name = self.firstNameTxt.text!.capitalizedFirst() + " " + self.lastNameTxt.text!.capitalizedFirst()
                self.usernameLbl.text = name
                
                if let mobile = array["mobile"] as? String{
                    if let str1 = mobile.components(separatedBy: " ") as? [String]{
                        let count = str1.count
                        
                        switch count {
                        case 0:
                            break;
                        case 1:
                            self.contactNoTxt.text = str1[0] as? String
                            break;
                        case 2:
                            self.countryCodeTxt.text = str1[0] as? String
                            self.contactNoTxt.text = str1[1] as? String
                        default:
                            break;
                        }
                    }
                }
            }
        }
    }
    
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name:UIResponder.keyboardWillHideNotification, object: nil)
    }
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        self.scrollViewObj.isScrollEnabled = true
        var info = notification.userInfo!
        var keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        if keyboardSize?.height == 0{
            keyboardSize?.height = 258
        }
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: keyboardSize!.height+50, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollViewObj.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
    }
    @objc func keyboardWillBeHidden(notification: NSNotification){
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
    }
    func textFieldDidBeginEditing(_ textField: UITextField){
        
        if textField == self.firstNameTxt{
            self.firstNameTxt.returnKeyType = .next
        }else if textField == self.lastNameTxt{
            self.lastNameTxt.returnKeyType = .next
        }else if textField == self.contactNoTxt{
            self.contactNoTxt.returnKeyType = .next
            self.contactNoTxt.keyboardType = .numberPad
            self.addBarBtnToKeyboard(textfield: self.contactNoTxt)
        }else if textField == self.orgnaisationTxt{
            orgnaisationTxt.returnKeyType = .next
        }
        activeField = textField
    }
    
    func textFieldDidEndEditing(_ textField: UITextField){
        activeField = nil
        if textField == self.firstNameTxt{
            if self.firstNameTxt.text?.count == 0 || self.firstNameTxt.text == ""{
            }
            else{
                self.firstNameTxt.text = self.firstNameTxt.text!.capitalizedFirst()
            }
        }
        if textField == self.lastNameTxt{
            if self.lastNameTxt.text?.count == 0 || self.lastNameTxt.text == ""{
            }else{
                self.lastNameTxt.text = self.lastNameTxt.text!.capitalizedFirst()
            }
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        switch textField{
        case self.firstNameTxt:
            self.lastNameTxt.becomeFirstResponder()
            break
        case self.lastNameTxt:
            contactNoTxt.becomeFirstResponder()
            break
        case self.contactNoTxt:
            break
        case self.orgnaisationTxt:
            textField.resignFirstResponder()
            break
        default:
            textField.resignFirstResponder()
        }
        return true
    }
    func addBarBtnToKeyboard(textfield : UITextField){
        let keyPadToolBar = UIToolbar()
        keyPadToolBar.barStyle = UIBarStyle.blackTranslucent
        keyPadToolBar.barTintColor = AppColors.greenColorRGB
        keyPadToolBar.sizeToFit()
        let DoneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(ProfileVC.dismissKeypad))
        DoneButton.tintColor = AppColors.whiteColorRGB
        keyPadToolBar.setItems([DoneButton], animated: true)
        textfield.inputAccessoryView = keyPadToolBar
    }
    
    @objc func dismissKeypad(){
        self.contactNoTxt.resignFirstResponder()
    }
    @IBAction func editAction(_ sender: UIButton){
        if sender.tag == 50{
            sender.tag = 60
            countryButton.isUserInteractionEnabled = true
            self.resignKeyBoard()
            self.editProfile.isHidden = false
            editButton.setTitle(NSLocalizedString("btn_done1", comment: ""), for: .normal)
            emailTxt.textColor = AppColors.lightGrayColorRGB
            contactNoTxt.textColor = AppColors.greenColorRGB
            firstNameTxt.textColor = AppColors.greenColorRGB
            lastNameTxt.textColor = AppColors.greenColorRGB
            countryCodeTxt.textColor = AppColors.greenColorRGB
            firstNameTxt.isUserInteractionEnabled = true
            lastNameTxt.isUserInteractionEnabled = true
            emailTxt.isUserInteractionEnabled = false
            contactNoTxt.isUserInteractionEnabled = true
            self.profilePicImg.isUserInteractionEnabled = true
        }else if sender.tag == 60{
            Analytics.logEvent("ProfileVC_EditProfileDetailsButtonTapped", parameters: nil)
            sender.tag = 50
            self.resignKeyBoard()
            updateProfileAddress()
            countryButton.isUserInteractionEnabled = false
            editButton.setTitle(NSLocalizedString("btn_edit", comment: ""), for: .normal)
        }
    }
    
    func profileUploadApi(pic : UIImage){
        if self.ineternetAlert() == false{
            return
        }
        IJProgressView.shared.showProgressView(self.view)
        let imageData = pic.jpegData(compressionQuality: 0.5)
        let imageStr = imageData?.base64EncodedString()
        var body = [String:AnyObject]()
        var username = ""
        if Constants.getValueFromUserDefults(for:"customer_id") != nil{
            username = Constants.getValueFromUserDefults(for: "customer_id") as! String
        }
        body = ["image":imageStr as AnyObject,"user_id": username as AnyObject]
        var authToken = ""
        if Constants.getValueFromUserDefults(for:"usertoken") != nil{
            authToken = Constants.getValueFromUserDefults(for:"usertoken") as! String
        }
        let authStr = "Bearer" + " " + authToken
        if let bodyData = try? JSONSerialization.data(withJSONObject: body, options:[]){
            
            APICommnicationManager.sharedInstance.requestforImageUploading(service:APPURLS.updateProfilePicURL, method: "POST", token:authStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                if let httpResponse = response as? HTTPURLResponse{
                    // print("APPURLS.updateProfilePicURL \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        if let receivedData = data{
                            do{
                                let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    var ImageURLStr = ""
                                    if let imageURL = resultDic!["img"] as? String{
                                        ImageURLStr = imageURL
                                        ImageURLStr.removeFirst()
                                    }
                                    //   print(ImageURLStr)
                                    self.activityIndicator.stopAnimating()
                                    self.activityIndicator.isHidden = true
                                    Constants.setDataInUserDefaults(objValue: ImageURLStr, for: "profileImgLink")
                                    self.profilePicImg.image = pic
                                    self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("error_propicupdated", comment: ""), completion: {_ in
                                        let imageData = self.profilePicImg.image!.jpegData(compressionQuality: 0.5)
                                        UserDefaults.standard.set(imageData, forKey: "propic")
                                    })
                                }
                            }catch {
                                self.somethingWentWrong()
                            }
                        }
                        break
                    case 500:
                        self.somethingWentWrong()
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "UpdateFailProfile_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "GetProfile_506", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                    default:
                        self.somethingWentWrong()
                    }
                }else{
                    self.somethingWentWrong()
                }
            }
        }
    }
    
    
    func somethingWentWrong(){
        DispatchQueue.main.async {
            IJProgressView.shared.hideProgressView()
            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
        }
    }
}
extension ProfileVC:UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
// Local variable inserted by Swift 4.2 migrator.
let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)

        if let chosenImage = info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.originalImage)] as? UIImage{
            
            let profileImage = chosenImage.resizeImage(image: chosenImage)
            print(profileImage.size.width)
            print(profileImage.size.height)
            DispatchQueue.global().async {
                self.profileUploadApi(pic: profileImage)
            }
        }else{
            print("Something went wrong")
        }
        self.dismiss(animated:true, completion: nil) //5
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated:true, completion: nil)
    }
}



// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
	return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromAVMediaType(_ input: AVMediaType) -> String {
	return input.rawValue
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromUIImagePickerControllerInfoKey(_ input: UIImagePickerController.InfoKey) -> String {
	return input.rawValue
}
