//
//  NewAddressViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 28/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import GoogleMaps
import CoreLocation
import GooglePlaces
import GooglePlacePicker

protocol newAddressDelegate
{
    func confirmNewAddressBtnTapped()
}

class NewAddressViewController: UIViewController,UIGestureRecognizerDelegate{
    @IBOutlet weak var contentViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var locMarker: UIImageView!
    var locationStatus = ""
    var pickuplat = ""
    var pickuplong = ""
    var addressStr1 = ""
    var addressStr2 = ""
    var cityStr = ""
    var countryStr = ""
    var constanttext = ""
    var stateStr = ""
    var zipcodeStr = ""
    var fulladdressStr = ""
    var fulladdressStr1 = ""
    var houseno = ""
    var streetNoStr = ""
    var addressStr3 = ""
    
    @IBOutlet var headerView: UIView!
    @IBOutlet var mapViewObj: GMSMapView!
    @IBOutlet var containerView: UIView!
    @IBOutlet var nameLbl: UILabel!
    @IBOutlet var addressLbl: UILabel!
    @IBOutlet var zipCodeLbl: UILabel!
    @IBOutlet var contactLbl: UILabel!
    @IBOutlet var editedLbl: UILabel!
    @IBOutlet var cancelBtn: UIButton!
    @IBOutlet var confirmBtn: UIButton!
    @IBOutlet var titleLbl: UILabel!
   var timer :Timer!
    var delegate : newAddressDelegate?
  var mapmove = Bool()
    var controlerName : String = String()
    var addressObjStr : String = String()
    var nameObjStr : String = String()
    var zipcodeObjStr : String = String()
    var contactNoObjStr : String = String()
    var emailObjStr : String = String()
    var houseNoObjStr : String = String()
    var streetObjStr1 : String = String()
    var streetObjStr2: String = String()
    var streetObjStr3 : String = String()
    var cityObjStr : String = String()
    var stateObjStr : String = String()
    var countryObjStr : String = String()
    var typeofAddressObjStr : String = String()

    var latitudeObjStr : String = String()
    var longitudeObjStr : String = String()

    var formatted_address : String = String()
    var locationManager = CLLocationManager()
    let appdeletegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate

    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        editedLbl.layer.cornerRadius = 1
        editedLbl.layer.masksToBounds = true
        editedLbl.backgroundColor = AppColors.whiteColorRGB
        editedLbl.layer.borderWidth = 1
        editedLbl.layer.borderColor = AppColors.lightGrayColorRGB.cgColor
        editedLbl.font = AppFont.regularTextFont
        editedLbl.textColor = AppColors.darkRedColorRGB
        editedLbl.text = NSLocalizedString("lbl_addresschanged", comment: "")
        editedLbl.isHidden = true
        self.mapViewObj.delegate = self
        self.mapViewObj.bringSubview(toFront:self.locMarker)
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        locationManager.activityType = .automotiveNavigation
        locationManager.distanceFilter = 10.0
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
       
        if CLLocationManager.locationServicesEnabled() {
            switch(CLLocationManager.authorizationStatus()) {
            case .notDetermined, .restricted, .denied:
                print("No access")
                locationStatus = "Yes"
                self.checkinglocationService()
            case .authorizedAlways:
                print("authorizedAlways")
            case .authorizedWhenInUse:
                print("authorizedWhenInUse")
                break
            }
        } else {
            print("Location services are not enabled")
        }
        if !CLLocationManager.locationServicesEnabled() {
            
            locationStatus = "Yes"
            checkinglocationService()
        }
        else
        {
            self.performGoogleSearch(string: self.addressObjStr)
        }
        
        self.view.bringSubview(toFront: headerView)
        self.mapViewObj.bringSubview(toFront: headerView)
        self.mapViewObj.bringSubview(toFront: containerView)
        self.mapViewObj.bringSubview(toFront: self.confirmBtn)
        self.titleLbl.text = NSLocalizedString("lbl_newaddress", comment: "")
        self.titleLbl.font = AppFont.regularTextFont
        self.titleLbl.textColor = AppColors.whiteColorRGB
        self.cancelBtn.titleLabel?.text = NSLocalizedString("btn_cancel", comment: "")
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.confirmBtn.titleLabel?.text = NSLocalizedString("btn_confirm", comment: "")
        self.confirmBtn.titleLabel?.font = AppFont.boldTextFont
        self.confirmBtn.backgroundColor = AppColors.greenColorRGB
        self.confirmBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.confirmBtn.titleLabel?.font = AppFont.boldTextFont
        let tapGesture = UITapGestureRecognizer(target: self, action:nil)
        tapGesture.delegate = self
        mapViewObj.addGestureRecognizer(tapGesture)
        self.nameLbl.text = nameObjStr
        self.zipCodeLbl.text = zipcodeObjStr
        self.contactLbl.text = contactNoObjStr
          self.addressLbl.text = addressObjStr
        //self.constanttext = self.addressLbl.text!
        var height : CGFloat = 0
        height += self.heightForView(text: addressObjStr, font: UIFont(name: "HelveticaNeue", size: 15)!, width: self.addressLbl.frame.size.width)
      
        self.contentViewHeight.constant = 25+5+height+5+25+5+25+5
        
        self.addressLbl.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.addressLbl.numberOfLines = 0
        self.addressLbl.sizeToFit()
        
        self.confirmBtn.isUserInteractionEnabled = false
        self.confirmBtn.backgroundColor = AppColors.lightGrayColorRGB

    }
    
    func checkinglocationService()
    {
        let actionSheetController: UIAlertController = UIAlertController(title: NSLocalizedString("Rytle", comment: ""), message: NSLocalizedString("error_locationservice", comment: ""), preferredStyle: .alert)
        let cancelAction: UIAlertAction = UIAlertAction(title: "Ok", style: .cancel) { action -> Void in
            //Just dismiss the action sheet
            
            DispatchQueue.main.async {
                
                if let url = URL(string: "App-Prefs:root=Privacy&path=LOCATION") {
                    if #available(iOS 10.0, *)
                    {
                        UIApplication.shared.open(url, completionHandler: .none)
                    }else
                    {
                        UIApplication.shared.openURL(url)
                    }
                }
            }
        }
        actionSheetController.addAction(cancelAction)
        self.present(actionSheetController, animated: true, completion: nil)
    }
    
  
    func heightForView(text:String, font:UIFont, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRect(x:0, y:0, width:width, height:2000))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }

    func performGoogleSearch(string: String)
    {
        if self.ineternetAlert() == false
        {
            return
        }
        IJProgressView.shared.showProgressView(view)

        var components = URLComponents(string: GoogleMapsApiKey.URL)!
        let key = URLQueryItem(name: "key", value: GoogleMapsApiKey.key) // use your key
        let address = URLQueryItem(name: "address", value: string)
        components.queryItems = [key, address]
        
        print(components)
        
        let task = URLSession.shared.dataTask(with: components.url!) { data, response, error in
            guard let data = data, let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200, error == nil else {
                print(String(describing: response))
                print(String(describing: error))
                return
            }
            
            guard let json = try! JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                print("not JSON format expected")
                print(String(data: data, encoding: .utf8) ?? "Not string?!?")
                return
            }
            print("json ::: ", json)
            
            if let Result = json["results"] as? [[String: Any]]{
                print("Result",Result)
                
                if let status = json["status"] as? String {
                    
                    if status == "OK"{
                        DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                          let  array = (json["results"] as! NSArray).mutableCopy() as! NSMutableArray
                            
                           print(array.value(forKey: "formatted_address"))
                            
                            print(array.value(forKey: "geometry"))
                            
                            let formattedAddress = array.value(forKey: "formatted_address") as! NSArray

                            self.formatted_address = formattedAddress[0] as! String
                            
                            let geometry = ((array.value(forKey: "geometry")) as! NSArray).mutableCopy() as! NSMutableArray
                            print(geometry)

                            print(geometry.value(forKey: "location"))
                            
                            let location = (geometry.value(forKey: "location") as! NSArray).mutableCopy() as! NSMutableArray
                            
                            print(location)
                            
                            let lat = location.value(forKey: "lat") as! NSArray
                            
                            let lng = location.value(forKey: "lng") as! NSArray
                            
                            print(lat[0])
                            print(lng[0])
                            
                            let latNumber = lat[0] as! NSNumber
                            self.latitudeObjStr = String(describing: latNumber)
                            self.pickuplat = self.latitudeObjStr
                            let lngNumber = lng[0] as! NSNumber
                            self.longitudeObjStr = String(describing: lngNumber)
                            self.pickuplong = self.longitudeObjStr
                            DispatchQueue.main.async(execute: {
                            
                            //let position = CLLocationCoordinate2DMake(lat[0] as! CLLocationDegrees,lng[0] as! CLLocationDegrees)
//                           let marker = GMSMarker(position: position)
//                            marker.title = self.formatted_address
//                           marker.map = self.mapViewObj
                            let camera: GMSCameraPosition = GMSCameraPosition.camera(withLatitude: Double(self.latitudeObjStr)!, longitude: Double(self.longitudeObjStr)!, zoom: 15.0)
//                                self.mapViewObj.camera = camera
            self.mapViewObj.animate(to: camera)
                self.confirmBtn.isUserInteractionEnabled = true
                            self.confirmBtn.backgroundColor = AppColors.greenColorRGB
                            })
                        })
                    }
                    else if status == "ZERO_RESULTS"
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            IJProgressView.shared.hideProgressView()
                            self.confirmBtn.isUserInteractionEnabled = false
                            self.confirmBtn.backgroundColor = AppColors.lightGrayColorRGB
                            self.showAlertMessage(vc: self, titleStr: "RYTLE", messageStr:NSLocalizedString("findlocation_error", comment: ""))
                        })
                    }
                    else {
                        DispatchQueue.main.async(execute: { () -> Void in
                            IJProgressView.shared.hideProgressView()
                            self.confirmBtn.isUserInteractionEnabled = false
                            self.confirmBtn.backgroundColor = AppColors.lightGrayColorRGB
                            self.showAlertMessage(vc: self, titleStr: "RYTLE", messageStr:NSLocalizedString("findlocation_error", comment: ""))
                        })
                    }
                }
                else
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                        self.showAlertMessage(vc: self, titleStr: "RYTLE", messageStr:NSLocalizedString("findlocation_error", comment: ""))
                    })
                }
            }
           
        }
        
        task.resume()
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnsTapped(_ sender : UIButton)
    {
        let btn = sender as UIButton
        
        if btn.tag == 10
        {
            self.dismiss(animated: true, completion: nil)
        }
        else if btn.tag == 20
        {
            if controlerName == "PickUpDetails"
            {
                let customer_id = UserDefaults.standard.value(forKey: "customer_id") as! String
                
                if self.ineternetAlert() == false
                {
                    return
                }
                self.pickupAddNewAddressApi(p_fullname: nameObjStr, p_email_id: emailObjStr, p_mobile_no: contactNoObjStr, customer_id:customer_id , house_noStr: houseNoObjStr, streetStr1: streetObjStr1, streetStr2: streetObjStr2, streetStr3: streetObjStr3, zip_code: zipcodeObjStr, state: stateObjStr, city: cityObjStr, country: countryObjStr, longitude: longitudeObjStr, latitude: latitudeObjStr, address_type: typeofAddressObjStr)
            }
            else if controlerName  == "ReceiverDetails"
            {
                let customer_id = UserDefaults.standard.value(forKey: "customer_id") as! String
                if self.ineternetAlert() == false
                {
                    return
                }
                  self.receiverAddNewAddressApi(d_fullname: nameObjStr, d_email_id: emailObjStr, house_no: houseNoObjStr, d_mobile_no: contactNoObjStr, customer_id: customer_id , house_noStr: houseNoObjStr, streetStr1: streetObjStr1, streetStr2: streetObjStr2, streetStr3: streetObjStr3, zip_code: zipcodeObjStr, state: stateObjStr, city: cityObjStr, country: countryObjStr, longitude: longitudeObjStr, latitude: latitudeObjStr, address_type: typeofAddressObjStr)
            }
        }
    }
    
    func pickupAddNewAddressApi(p_fullname : String ,p_email_id :String, p_mobile_no : String,customer_id : String,house_noStr : String ,streetStr1 : String ,streetStr2: String, streetStr3 : String ,zip_code : String,state :String, city :String,country:String,longitude: String, latitude:String,address_type:String)
    {
        IJProgressView.shared.showProgressView(view)
        
        var bodyReq = [String:String]()
        
        bodyReq = ["p_fullname":p_fullname,"p_email_id":p_email_id, "house_no" : house_noStr,"p_mobile_no" : p_mobile_no, "customer_id": customer_id,"street1": streetStr1,"street2":streetStr2,"street3":streetStr3 ,"zip_code":zip_code,"state" : state,"city":city,"country" : country,"latitude" : latitude ,"longitude":longitude , "address_type" : address_type]
      
        print("bodyReq",bodyReq)
        
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
        {
            let token = UserDefaults.standard.value(forKey: "usertoken") as! String
            
            let sessionStr = "Bearer " + token

            APICommnicationManager.sharedInstance.requestforAPI(service:"Pickup/createNewPickupaddress" , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (result, error) in
                print("pickup confirmation result",result as Any)
                if let Result = result as? [String:Any]{
                    print("Result",Result)
                    if let status = Result["status"] as? Bool {
                        if status == true{
                            DispatchQueue.main.async(execute: { () -> Void in
                               IJProgressView.shared.hideProgressView()
                                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "pickupnotification"), object: nil)
                            self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
                            })
                        }
                        if status == false
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.showAlertMessage(vc: self, titleStr: "RYTLE", messageStr:  (Result["error"] as? String)!)
                            })
                        }
                    }
                }
                else
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                    })
                    if error != nil
                    {
                        if (error!.value(forKey: "code") as! NSNumber).stringValue == "-1001"
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("ver_internet", comment: ""))
                            })
                        }
                        else
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                 self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("ver_somethingwrong", comment: ""))
                            })
                        }
                    }
                    else
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                             self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("ver_somethingwrong", comment: ""))
                        })
                    }
                }
            }
        }
    }
    
    func receiverAddNewAddressApi(d_fullname : String ,d_email_id :String, house_no : String , d_mobile_no : String,customer_id : String,house_noStr : String ,streetStr1 : String ,streetStr2: String, streetStr3 : String ,zip_code : String,state :String, city :String,country:String,longitude: String, latitude:String,address_type:String)
    {
        IJProgressView.shared.showProgressView(view)
        
        var bodyReq = [String:String]()
        
        bodyReq = ["d_fullname":d_fullname,"d_email_id":d_email_id, "house_no" : house_noStr,"d_mobile_no" : d_mobile_no, "customer_id": customer_id,"street1": streetStr1,"street2":streetStr2,"street3":streetStr3 ,"zip_code":zip_code,"state" : state,"city":city,"country" : country,"latitude" : latitude ,"longitude":longitude , "address_type" : address_type]
            print("bodyReq",bodyReq)
        
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
        {
            let token = UserDefaults.standard.value(forKey: "usertoken") as! String
            
            let sessionStr = "Bearer " + token
            
            APICommnicationManager.sharedInstance.requestforAPI(service:"Parcel/createDeliveryaddress" , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (result, error) in
                
                if let Result = result as? [String:Any]{
                    print("Result",Result)
                    
                    if let status = Result["status"] as? Bool {
                        
                        if status == true{
                            DispatchQueue.main.async(execute: { () -> Void in
                                
                                IJProgressView.shared.hideProgressView()

                                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "receivernotification"), object: nil)
                            self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
                            })
                        }
                        if status == false{
                            DispatchQueue.main.async(execute: { () -> Void in
                                
                                IJProgressView.shared.hideProgressView()
                                self.showAlertMessage(vc: self, titleStr: "RYTLE", messageStr:  (Result["error"] as? String)!)
                            })
                        }
                    }
                }
                else
                {
                    if error != nil
                    {
                        if (error!.value(forKey: "code") as! NSNumber).stringValue == "-1001"
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.showAlertMessage(vc: self, titleStr:NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("ver_internet", comment: ""))
                            })
                        }
                        else
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                               IJProgressView.shared.hideProgressView()
                               self.showAlertMessage(vc: self, titleStr:NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("ver_somethingwrong", comment: ""))
                            })
                        }
                    }
                    else
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            IJProgressView.shared.hideProgressView()
                            self.showAlertMessage(vc: self, titleStr:NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("ver_somethingwrong", comment: ""))
                        })
                    }
                }
            }
        }
    }
   
    func getAddressFromLatLon(coordinate: CLLocationCoordinate2D) {
        
        let geocode: GMSGeocoder = GMSGeocoder()
         pickuplat  = String(coordinate.latitude)
        pickuplong = String(coordinate.longitude)
        
        
        geocode.reverseGeocodeCoordinate(coordinate, completionHandler:
            {(response, error) in
                if (error != nil)
                {
                    print("reverse geodcode fail: \(error!.localizedDescription)")
                }
                if let address = response?.firstResult()
                {   let lines = address.lines
            
                        //DispatchQueue.main.async(execute: { () -> Void in
                       self.addressLbl.text = lines?.joined(separator: "\n")
                // self.constanttext = self.addressLbl.text!
                    var height : CGFloat = 0
                    height += self.heightForView(text: self.addressLbl.text!, font: UIFont(name: "HelveticaNeue", size: 15)!, width: self.addressLbl.frame.size.width)
                    self.contentViewHeight.constant = 25+5+height+5+25+5+25+5

                   
                    self.addressLbl.lineBreakMode = NSLineBreakMode.byWordWrapping
                    self.addressLbl.numberOfLines = 0
                    self.addressLbl.sizeToFit()
            
                                            let newcamera = GMSCameraPosition.camera(withLatitude: coordinate.latitude,longitude: coordinate.longitude,zoom: 17)
                    
                    
                    self.mapViewObj.animate(toLocation:coordinate)
                    //                    UIView.animate(withDuration: 0.25) {
                    //                        self.view.layoutIfNeeded()
                    //                    }
                    print("label657656558568===\(String(describing: address.lines?[0]))");
                    
                    self.timerMethod()
                   // })
                    if let address = address.lines as NSArray?
                    {
                        if let addressStr = address[0] as? String
                        {
                            self.fulladdressStr += addressStr
                        }
                        if let addressStr1 = address[1] as? String
                        {
                           self.fulladdressStr += ", " + addressStr1
                        }
                        
                        if let fullNameArr = self.fulladdressStr.components(separatedBy: ", ") as NSArray?
                        {
                            print(fullNameArr.count)
                            
                            let count = fullNameArr.count
                            
                            
                            switch fullNameArr.count
                            {
                            case 0:
                                self.houseno = (fullNameArr[0] as? String)!
                                self.houseNoObjStr = self.houseno
                                break
                            case 1:
                                self.self.houseno = (fullNameArr[0] as? String)!
                                 self.houseNoObjStr = self.houseno
                                break
                            case 2:
                                self.self.houseno = (fullNameArr[0] as? String)!
                                 self.houseNoObjStr = self.houseno
                                self.addressStr1 = (fullNameArr[1] as? String)!
                                self.streetObjStr1 = self.addressStr1
                                
                                break
                            case 3:
                                self.houseno = (fullNameArr[0] as? String)!
                                 self.houseNoObjStr = self.houseno
                                self.addressStr1 = (fullNameArr[1] as? String)!
                                  self.streetObjStr1 = self.addressStr1
                                self.self.addressStr2 = (fullNameArr[2] as? String)!
                                  self.streetObjStr2 = self.addressStr2
                                break
                            case 4:
                                self.houseno = (fullNameArr[0] as? String)!
                                 self.houseNoObjStr = self.houseno
                                self.addressStr1 = (fullNameArr[1] as? String)!
                                self.addressStr2 = (fullNameArr[2] as? String)!
                                self.addressStr3 = (fullNameArr[3] as? String)!
                                  self.streetObjStr1 = self.addressStr1
                                  self.streetObjStr2 = self.addressStr2
                                  self.streetObjStr3 = self.addressStr3
                                break
                            case 5:
                                self.houseno = fullNameArr[0] as! String
                                 self.houseNoObjStr = self.houseno
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)!
                                  self.streetObjStr1 = self.addressStr1
                                  self.streetObjStr2 = self.addressStr2
                                  self.streetObjStr3 = self.addressStr3
                                break
                            case 6:
                                self.houseno = fullNameArr[0] as! String
                                 self.houseNoObjStr = self.houseno
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)!
                                  self.streetObjStr1 = self.addressStr1
                                  self.streetObjStr2 = self.addressStr2
                                  self.streetObjStr3 = self.addressStr3
                                
                                break
                            case 7:
                                self.houseno  = fullNameArr[0] as! String
                                 self.houseNoObjStr = self.houseno
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)!
                                  self.streetObjStr1 = self.addressStr1
                                  self.streetObjStr2 = self.addressStr2
                                  self.streetObjStr3 = self.addressStr3
                                break
                            case 8:
                                self.houseno  = fullNameArr[0] as! String
                                 self.houseNoObjStr = self.houseno
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)!
                                  self.streetObjStr1 = self.addressStr1
                                  self.streetObjStr2 = self.addressStr2
                                  self.streetObjStr3 = self.addressStr3
                            
                                break
                            case 9:
                                self.houseno  = fullNameArr[0] as! String
                                 self.houseNoObjStr = self.houseno
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)! + ", " + (fullNameArr[8] as? String)!
                                  self.streetObjStr1 = self.addressStr1
                                  self.streetObjStr2 = self.addressStr2
                                  self.streetObjStr3 = self.addressStr3
                                break
                            case 10:
                                self.houseno  = fullNameArr[0] as! String
                                 self.houseNoObjStr = self.houseno
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)! + ", " + (fullNameArr[8] as? String)! + ", " + (fullNameArr[9] as? String)!
                                  self.streetObjStr1 = self.addressStr1
                                  self.streetObjStr2 = self.addressStr2
                                  self.streetObjStr3 = self.addressStr3
                                break
                            default: break
                            }
                        }
                        
                    }
                    if let locality = address.locality
                    {
                        print(locality)
                        self.cityStr = locality
                        self.cityObjStr = self.cityStr
                    }
                    if let admistrateArea = address.administrativeArea
                    {
                        print(admistrateArea)
                        self.stateStr = admistrateArea
                        self.stateObjStr = self.stateStr
                    }
                    if let country = address.country
                    {
                        print(country)
                        self.countryStr = country
                        self.countryObjStr = self.countryStr
                    }
                    if let zipcode = address.postalCode
                    {
                        print(zipcode)
                        self.zipcodeStr = zipcode
                        self.zipcodeObjStr = self.zipcodeStr
                        self.zipCodeLbl.text = self.zipcodeStr
                    }
                    
                    if let streetno = address.thoroughfare
                    {
                        print(streetno)
                        self.streetNoStr = streetno
                        
                    }
                    
                    if self.streetNoStr.characters.count != 0
                    {
                        
                    }
                }                
        })
        
    }
  /*  func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        
        return true
    }*/
    
    func timerMethod(){
        editedLbl.isHidden = false
        self.mapViewObj.bringSubview(toFront:editedLbl)
        timer = Timer.scheduledTimer(timeInterval:05, target:self, selector: #selector((NewAddressViewController.updateCounter)), userInfo: nil, repeats: false)
    }
    func updateCounter(){
       editedLbl.isHidden = true
        
    }
}

extension NewAddressViewController:CLLocationManagerDelegate{
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedWhenInUse:
            manager.startUpdatingLocation()
            break
        case .authorizedAlways:
            manager.startUpdatingLocation()
            break
        case .denied:
            //handle denied
            self.checkinglocationService()
            break
        case .notDetermined:
            manager.requestWhenInUseAuthorization()
            // self.checkinglocationService()
            break
        default:
            break
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let locationArray = locations as NSArray
        let locationObj = locationArray.firstObject as! CLLocation
       
        if locationStatus == "Yes"
        {
            locationStatus = ""
            self.performGoogleSearch(string: self.addressObjStr)
        }
        locationManager.stopUpdatingLocation()
        self.currentLocation(location: locationObj)
        
    }
    func currentLocation(location: CLLocation)
    {
        let camera: GMSCameraPosition = GMSCameraPosition.camera(withLatitude: location.coordinate.latitude, longitude: location.coordinate.longitude, zoom: 12.0)
        self.mapViewObj.camera = camera
        self.mapViewObj.isMyLocationEnabled = true
        
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Couldn't get your location")
    }
}

extension NewAddressViewController:GMSMapViewDelegate{
    
    func mapView(_ mapView: GMSMapView, willMove gesture: Bool) {
        if gesture == true{
            mapmove = true
           //getAddressFromLatLon(coordinate:mapView.camera.target)
             mapViewObj.selectedMarker = nil
            
        }
    }
    
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        if mapmove == true{
          getAddressFromLatLon(coordinate:position.target)
            
        }

    }
    
}
