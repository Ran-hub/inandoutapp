//
//  FeedbackViewController.swift
//  RYTLE
//
//  Created by pavan on 03/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class FeedbackViewController: UIViewController
{
    @IBOutlet weak var feedBackText : UITextView!
    @IBOutlet weak var cancelBtn : UIButton!
    @IBOutlet weak var feedbackBtn : UIButton!
    @IBOutlet weak var titleLbl : UILabel!
    @IBOutlet weak var textLbl : UILabel!
    
    let appdelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationController?.isNavigationBarHidden = true
        
        self.titleLbl.text = NSLocalizedString("lbl_feedback", comment: "")
        self.titleLbl.font = AppFont.regularTextFont
        
        self.textLbl.text = NSLocalizedString("lbl_fdtext", comment: "")
        self.textLbl.font = AppFont.regularTextFont
        
        self.cancelBtn.titleLabel?.text = NSLocalizedString("btn_cancel", comment: "")
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        
        self.feedbackBtn.titleLabel?.text = NSLocalizedString("btn_text", comment: "")
        self.feedbackBtn.titleLabel?.font = AppFont.boldTextFont
        self.feedbackBtn.backgroundColor = AppColors.greenColorRGB
        self.feedbackBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.feedbackBtn.titleLabel?.font = AppFont.boldTextFont
        
        self.feedBackText.layer.masksToBounds = true
        self.feedBackText.layer.borderColor = UIColor.lightGray.cgColor
        self.feedBackText.layer.borderWidth = 1
        
    }
    
    @IBAction func doneAction(_ sender: Any)
    {
        
    }
    
    
    @IBAction func cancelAction(_ sender: Any)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    func initialSetup()
    {
        
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
extension FeedbackViewController:UITextViewDelegate
{
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        textView.returnKeyType = .done
        return true
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        textView.returnKeyType = .done
        Constants().animateViewMoving(up: true, moveValue: 60,view:self.view)
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        textView.textColor =
            UIColor(red: 94/255, green: 230/255, blue: 169/255, alpha: 1)
        Constants().animateViewMoving(up:false, moveValue: 60,view:self.view)
    }
    
}
