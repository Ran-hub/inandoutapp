//
//  AddNewViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 26/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import CoreLocation
import GoogleMaps
struct CountryCode {
    var code: String?
    var name: String?
    var phoneCode: String?
    
    
    init(code: String?, name: String?, phoneCode: String?) {
        self.code = code
        self.name = name
        self.phoneCode = phoneCode
    }
}
protocol addAddressDelegate
{
    func addAddressDelegateTapped()
}

class AddNewAddressViewController: UIViewController,UIScrollViewDelegate,newAddressDelegate,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate {
   
    
    @IBOutlet weak var reciverNameTxt: ACFloatingTextfield!
    @IBOutlet weak var emailTxt : ACFloatingTextfield!
    @IBOutlet weak var houseNoTxt :ACFloatingTextfield!
    @IBOutlet weak var streetTxt1 : ACFloatingTextfield!
    @IBOutlet weak var streetTxt2 : ACFloatingTextfield!
    @IBOutlet weak var streetTxt3 : ACFloatingTextfield!
    @IBOutlet weak var zipcodeTxt :ACFloatingTextfield!
    @IBOutlet weak var cityTxt :ACFloatingTextfield!
    @IBOutlet weak var stateTxt : ACFloatingTextfield!
    @IBOutlet weak var countryTxt : ACFloatingTextfield!
    @IBOutlet weak var conatctNoTxt : ACFloatingTextfield!
    
    @IBOutlet weak var countrycodeTextField: UITextField!
    @IBOutlet weak var currentLocationButton: UIButton!
    
    @IBOutlet weak var countryViewBottom: NSLayoutConstraint!
    
    @IBOutlet weak var phoneCodeView: UIView!
    @IBOutlet weak var currentLocationImg: UIImageView!
    @IBOutlet weak var currentLocationViewObj: UIView!
    @IBOutlet weak var headerView : UIView!
    @IBOutlet weak var titleLbl : UILabel!
    @IBOutlet weak var cancelBtn : UIButton!
    @IBOutlet weak var scrollViewObj : UIScrollView!
    @IBOutlet weak var containerView : UIView!
    @IBOutlet weak var contentView : UIView!

    @IBOutlet weak var typeOffParcelTxt : UITextField!
    @IBOutlet weak var stateViewObj : UIView!
    @IBOutlet weak var countryViewObj : UIView!
    @IBOutlet weak var addressViewObj : UIView!
    @IBOutlet weak var addressBtn : UIButton!
    @IBOutlet weak var continueBtn : UIButton!
    
    @IBOutlet weak var countryCodeView: UIView!
    
    @IBOutlet weak var currentlocLbl: UILabel!
    
    @IBOutlet weak var addressTextView: UITableView!
 
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var CLTopConstraints: NSLayoutConstraint!
    @IBOutlet weak var CLHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var containerHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var contentViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var countryCodeViewObj: UIView!
    var delegate : addAddressDelegate?
    
    var filteredphonecodeArray = NSMutableArray()
    var filteredcodeArray = NSMutableArray()
    var nameArray = NSMutableArray()
    var filteredArray:[String] = []
    var  countrycodeArray = NSMutableArray()
    var phonecodeArray = NSMutableArray()
     var isSearching  = false
    var activeField: UITextField?
    var contactStatus = ""
    var keyboardHide = ""
    var controllerName : String = String()
     var errorstatus = false
    
    let appdeletegate: AppDelegate = (UIApplication.shared.delegate as! AppDelegate)
    var countries = [CountryCode]()
    let addressDropDown = DropDown()
    var locationManager = CLLocationManager()
    lazy var dropDowns: [DropDown] = {
        return [
            self.addressDropDown
        ]
    }()

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.initialSetUp()
        self.keyboardHide = ""
        countries = self.countryNamesByCode()
        if let countryCode = (Locale.current as NSLocale).object(forKey: .countryCode) as? String {
            //  print("countryCode",countryCode)
            
            for country in countries{
                if countryCode == country.code{
                    self.countrycodeTextField.text = country.phoneCode
                }
            }
        }
        self.scrollViewObj.delegate = self
    }
    
    func determineMyCurrentLocation() {
       
        IJProgressView.shared.showProgressView(self.view)
       // locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
        if !CLLocationManager.locationServicesEnabled() {

            let actionSheetController: UIAlertController = UIAlertController(title: NSLocalizedString("Rytle", comment: ""), message: NSLocalizedString("error_locationservice", comment: ""), preferredStyle: .alert)
            let cancelAction: UIAlertAction = UIAlertAction(title: "Ok", style: .cancel) { action -> Void in
                //Just dismiss the action sheet
                if let url = URL(string: "App-Prefs:root=Privacy&path=LOCATION") {
                    // If general location settings are disabled then open general location settings
                    UIApplication.shared.openURL(url)
                }
            }
            actionSheetController.addAction(cancelAction)
            self.present(actionSheetController, animated: true, completion: nil)
            
        }
    }
    
    func getAddressFromLatLon(location:CLLocation) {
        
        var center : CLLocationCoordinate2D = CLLocationCoordinate2D()

        let geocode: GMSGeocoder = GMSGeocoder()
        center.latitude = location.coordinate.latitude
        center.longitude = location.coordinate.longitude
        
        // let loc: CLLocation = CLLocation(latitude:center.latitude, longitude: center.longitude)
        
        geocode.reverseGeocodeCoordinate(center, completionHandler:
            {(response, error) in
                if (error != nil)
                {IJProgressView.shared.hideProgressView()
                   self.showAlertMessage(vc: self, titleStr:NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("ver_somethingwrong", comment: ""))
                    print("reverse geodcode fail: \(error!.localizedDescription)")
                }
                if let address = response?.firstResult()
                {
                    print("label657656558568===\(String(describing: address.lines?[0]))");
                    
                    var addressStr1 = ""
                    var addressStr2 = ""
                    var cityStr = ""
                    var countryStr = ""
                    var stateStr = ""
                    var zipcodeStr = ""
                    var fulladdressStr = ""
                    var fulladdressStr1 = ""
                    
                    var streetNoStr = ""
                    
                    if let address = address.lines as NSArray?
                    {
                        if let addressStr = address[0] as? String
                        {
                            fulladdressStr += addressStr
                        }
                        if let addressStr1 = address[1] as? String
                        {
                            fulladdressStr += ", " + addressStr1
                        }
                        
                        if let fullNameArr = fulladdressStr.components(separatedBy: ", ") as NSArray?
                        {
                            print("fullNameArr.count",fullNameArr.count)
                            
                            let count = fullNameArr.count
                            
                            
                            switch fullNameArr.count
                            {
                            case 0:
                                self.houseNoTxt.text = fullNameArr[0] as? String
                                break
                            case 1:
                                self.houseNoTxt.text = fullNameArr[0] as? String
                                break
                            case 2:
                                self.houseNoTxt.text = fullNameArr[0] as? String
                                self.streetTxt1.text = fullNameArr[1] as? String
                                //  self.streetTxt3.text = fullNameArr[3]
                                break
                            case 3:
                                self.houseNoTxt.text = fullNameArr[0] as? String
                                self.streetTxt1.text = fullNameArr[1] as? String
                                self.streetTxt2.text = fullNameArr[2] as? String
                                break
                            case 4:
                                self.houseNoTxt.text = fullNameArr[0] as? String
                                self.streetTxt1.text = fullNameArr[1] as? String
                                self.streetTxt2.text = fullNameArr[2] as? String
                                self.streetTxt3.text = (fullNameArr[3] as? String)!
                                break
                            case 5:
                                self.houseNoTxt.text = fullNameArr[0] as? String
                                self.streetTxt1.text = fullNameArr[1] as? String
                                self.streetTxt2.text = fullNameArr[2] as? String
                                self.streetTxt3.text = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)!
                                break
                            case 6:
                                self.houseNoTxt.text = fullNameArr[0] as? String
                                self.streetTxt1.text = fullNameArr[1] as? String
                                self.streetTxt2.text = fullNameArr[2] as? String
                                self.streetTxt3.text = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)!
                                break
                            case 7:
                                self.houseNoTxt.text = fullNameArr[0] as? String
                                self.streetTxt1.text = fullNameArr[1] as? String
                                self.streetTxt2.text = fullNameArr[2] as? String
                                self.streetTxt3.text = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)!
                                break
                            case 8:
                                self.houseNoTxt.text = fullNameArr[0] as? String
                                self.streetTxt1.text = fullNameArr[1] as? String
                                self.streetTxt2.text = fullNameArr[2] as? String
                                self.streetTxt3.text = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)!
                                break
                            case 9:
                                self.houseNoTxt.text = fullNameArr[0] as? String
                                self.streetTxt1.text = fullNameArr[1] as? String
                                self.streetTxt2.text = fullNameArr[2] as? String
                                self.streetTxt3.text = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)! + ", " + (fullNameArr[8] as? String)!
                                break
                            case 10:
                                self.houseNoTxt.text = fullNameArr[0] as? String
                                self.streetTxt1.text = fullNameArr[1] as? String
                                self.streetTxt2.text = fullNameArr[2] as? String
                                self.streetTxt3.text = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)! + ", " + (fullNameArr[8] as? String)! + ", " + (fullNameArr[9] as? String)!
                            case 15:
                                self.houseNoTxt.text = fullNameArr[0] as? String
                                self.streetTxt1.text = fullNameArr[1] as? String
                                self.streetTxt2.text = fullNameArr[2] as? String
                                self.streetTxt3.text = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)! + ", " + (fullNameArr[8] as? String)! + ", " + (fullNameArr[9] as? String)! 
                                break
                            default: break
                            }
                        }
                        
                    }
                    if let locality = address.locality
                    {
                        print(locality)
                        cityStr = locality
                    }
                    if let admistrateArea = address.administrativeArea
                    {
                        print(admistrateArea)
                        stateStr = admistrateArea
                    }
                    if let country = address.country
                    {
                        print(country)
                        countryStr = country
                    }
                    if let zipcode = address.postalCode
                    {
                        print(zipcode)
                        zipcodeStr = zipcode
                    }
                    
                    if let streetno = address.thoroughfare
                    {
                        print(streetno)
                        streetNoStr = streetno
                    }
                    
                    if streetNoStr.characters.count != 0
                    {
                        //self.houseNoTxt.text = streetNoStr
                    }
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    }
                    self.cityTxt.text = cityStr
                    self.zipcodeTxt.text = zipcodeStr
                    self.countryTxt.text = countryStr
                    self.stateTxt.text = stateStr
                    
                }
                
        })
        
    }
    func countryNamesByCode() -> [CountryCode] {
        var countries = [CountryCode]()
        
        do{
            if let file = Bundle.main.url(forResource: "countryCodes", withExtension: "json") {
                let data = try Data(contentsOf: file)
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                if let object = json as? [String: Any] {
                    // json is a dictionary
                    print(object)
                } else if let object = json as? [Any] {
                    // json is an array
                    for jsonObject in object {
                        
                        guard let countryObj = jsonObject as? NSDictionary else {
                            return countries
                        }
                        
                        guard let code = countryObj["code"] as? String, let phoneCode = countryObj["dial_code"] as? String, let name = countryObj["name"] as? String else {
                            return countries
                        }
                        nameArray.add(name)
                        
                        let country = CountryCode(code: code, name: name, phoneCode: phoneCode)
                        countries.append(country)
                        
                    }
                    
                    print(object)
                } else {
                    print("JSON is invalid")
                }
            } else {
                print("no file")
            }
        }
        catch {
            print(error.localizedDescription)
        }
        return countries
    }

    func initialSetUp()
    {
        currentlocLbl.text = NSLocalizedString("lbl_currentloc", comment: "")
        if Constants.getValueFromUserDefults(for: "countrycode") != nil
        {
            let countrycode = Constants.getValueFromUserDefults(for: "countrycode") as! String
            self.countrycodeTextField.text = countrycode
        }
       
        self.addressTextView.layer.borderWidth = 1
        self.addressTextView.layer.borderColor = AppColors.lightGrayColorRGB.cgColor
        self.searchBar.returnKeyType = .done
        searchBar.delegate = self
        
        self.addressTextView.register(UINib(nibName: "CountryTableViewCell", bundle: nil), forCellReuseIdentifier: "CountryTableViewCell")
        self.addressTextView.delegate = self
        self.addressTextView.dataSource = self
        self.countryCodeView.isHidden = true
        self.addressViewObj.isUserInteractionEnabled = true
        self.addressBtn.isUserInteractionEnabled = true
        self.scrollViewObj.delaysContentTouches = false;

        self.view.bringSubview(toFront : self.scrollViewObj)
        self.scrollViewObj.bringSubview(toFront : self.containerView)
        self.containerView.bringSubview(toFront : self.contentView)
        self.contentView.bringSubview(toFront : self.addressViewObj)
        self.addressViewObj.bringSubview(toFront : self.addressBtn)
      self.typeOffParcelTxt.text = NSLocalizedString("valid_home",comment: "")
        self.reciverNameTxt.placeholder = NSLocalizedString("txt_receivername", comment: "")
        self.reciverNameTxt.font = AppFont.regularTextFont
  
        self.emailTxt.placeholder = NSLocalizedString("txt_eamil", comment: "")
        self.emailTxt.font = AppFont.regularTextFont
     
        self.houseNoTxt.placeholder = NSLocalizedString("txt_houseno", comment: "")
        self.houseNoTxt.font = AppFont.regularTextFont
 
        self.streetTxt1.placeholder = NSLocalizedString("txt_street1", comment: "")
        self.streetTxt1.font = AppFont.regularTextFont
        
        self.countrycodeTextField.placeholder = NSLocalizedString("lbl_code", comment: "")
        self.countrycodeTextField.font = AppFont.regularTextFont

        self.phoneCodeView = addBorderToView(view: self.phoneCodeView)
        self.addressViewObj = addBorderToView(view:  self.addressViewObj)
        self.currentLocationViewObj = self.addBorderToView(view : self.currentLocationViewObj)
        
       
        self.streetTxt2.placeholder = NSLocalizedString("txt_street2", comment: "")
        self.streetTxt2.font = AppFont.regularTextFont
        
        self.streetTxt3.placeholder = NSLocalizedString("txt_street3", comment: "")
        self.streetTxt3.font = AppFont.regularTextFont

        self.zipcodeTxt.placeholder = NSLocalizedString("txt_zipcode",comment: "")
        self.zipcodeTxt.font = AppFont.regularTextFont

        self.cityTxt.placeholder = NSLocalizedString("txt_city",comment: "")
   self.cityTxt.font = AppFont.regularTextFont
        self.stateTxt.placeholder = NSLocalizedString("txt_state",comment: "")
        self.stateTxt.font =  AppFont.regularTextFont
      
        self.countryTxt.placeholder = NSLocalizedString("txt_country",comment: "")
        self.countryTxt.font = AppFont.regularTextFont
    
        self.conatctNoTxt.placeholder = NSLocalizedString("txt_contactno",comment: "")
        self.conatctNoTxt.font = AppFont.regularTextFont
  
        self.typeOffParcelTxt.placeholder = NSLocalizedString("txt_typeofparcel",comment: "")
        self.typeOffParcelTxt.font = AppFont.regularTextFont
     
        
        self.cancelBtn.titleLabel?.text = NSLocalizedString("btn_cancel", comment: "")
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        
        self.continueBtn.titleLabel?.text = NSLocalizedString("btn_next", comment: "")
        self.continueBtn.titleLabel?.font = AppFont.boldTextFont
        self.continueBtn.backgroundColor = AppColors.greenColorRGB
        self.continueBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.continueBtn.titleLabel?.font = AppFont.boldTextFont
        
        self.registerForKeyboardNotifications()
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        self.contentView.isUserInteractionEnabled = true
        self.view.addGestureRecognizer(tapGestureRecognizer)
        
        self.cancelBtn.titleLabel?.text = NSLocalizedString("btn_cancel", comment: "")
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        
        self.continueBtn.titleLabel?.text = NSLocalizedString("btn_continue", comment: "")
        self.continueBtn.titleLabel?.font = AppFont.boldTextFont
        self.continueBtn.backgroundColor = AppColors.greenColorRGB
        self.continueBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.continueBtn.titleLabel?.font = AppFont.boldTextFont
        
        if controllerName == "PickUpDetails"
        {
            currentLocationButton.isHidden = false
              CLHeightConstraint.constant = 40
              CLTopConstraints.constant = 10
              contentViewHeightConstraint.constant = 700
              containerHeightConstraint.constant = 700
            currentlocLbl.isHidden = false
            self.titleLbl.text = NSLocalizedString("lbl_pickupaddress", comment: "")
            
         }
        else if controllerName == "ReceiverDetails"
        {
            currentLocationButton.isHidden = true
            CLHeightConstraint.constant = 0
            CLTopConstraints.constant = 0
            contentViewHeightConstraint.constant = 670
            containerHeightConstraint.constant = 670
            currentlocLbl.isHidden = true
            self.titleLbl.text = NSLocalizedString("lbl_receiverdetails", comment: "")
           
        }
        self.titleLbl.textColor = AppColors.whiteColorRGB
        titleLbl.font = AppFont.regularTextFont

//        if appdeletegate.IS_IPHONE5
//        {
//            titleLbl.font = AppFont.regularTextFont
//        }
        
        self.setupAmountDropDown()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear (animated)
        self.deregisterFromKeyboardNotifications()
    }
    
//    func displayborderToTextField()
//    {
//        self.reciverNameTxt = self.addBorder(textfield: reciverNameTxt)
//        self.emailTxt = self.addBorder(textfield: emailTxt)
//        self.houseNoTxt = self.addBorder(textfield: houseNoTxt)
//        self.streetTxt1 = self.addBorder(textfield: streetTxt1)
//        self.streetTxt2 = self.addBorder(textfield: streetTxt2)
//        self.streetTxt3 = self.addBorder(textfield: streetTxt3)
//        self.zipcodeTxt = self.addBorder(textfield: zipcodeTxt)
//        self.cityTxt = self.addBorder(textfield: cityTxt)
//        self.conatctNoTxt = self.addBorder(textfield: conatctNoTxt)
//        self.countryTxt = self.addBorder(textfield: self.countryTxt)
//        self.countrycodeTextField = self.addBorder(textfield: self.countrycodeTextField)
//        // self.countryCodeViewObj = self.addBorderToView(view: self.countryCodeViewObj)
//        self.stateViewObj = self.addBorderToView(view : self.stateViewObj)
//        self.countryViewObj = self.addBorderToView(view : self.countryViewObj)
//        self.addressViewObj = self.addBorderToView(view : self.addressViewObj)
//        self.currentLocationViewObj = self.addBorderToView(view : self.currentLocationViewObj)
//    }
    func addBorder(textfield : UITextField) -> UITextField
    {
        let borderBottom = CALayer()
        let borderWidth = CGFloat(1)
        borderBottom.borderColor = UIColor.lightGray.cgColor //AppColors.textBoderColorRgb.cgColor
        borderBottom.frame = CGRect(x: 0, y: textfield.frame.height - 1, width: textfield.frame.width , height: textfield.frame.height - 1)
        borderBottom.borderWidth = borderWidth
        textfield.layer.addSublayer(borderBottom)
        textfield.layer.masksToBounds = true
        
        return textfield
    }
    func addBorderToView(view : UIView) -> UIView
    {
        let borderBottom = CALayer()
        let borderWidth = CGFloat(1)
        borderBottom.borderColor = UIColor.lightGray.cgColor //AppColors.textBoderColorRgb.cgColor
        borderBottom.frame = CGRect(x: 0, y: view.frame.height - 1, width: view.frame.width , height: view.frame.height - 1)
        borderBottom.borderWidth = borderWidth
        view.layer.addSublayer(borderBottom)
        view.layer.masksToBounds = true
        return view
    }
    override func viewDidAppear(_ animated: Bool) {
        
       self.currentLocationViewObj = self.addBorderToView(view : self.currentLocationViewObj)

       // self.displayborderToTextField()

    }
    override func viewDidLayoutSubviews()
    {
 
    DispatchQueue.main.async{
    
    self.scrollViewObj.translatesAutoresizingMaskIntoConstraints = true
    self.scrollViewObj.contentSize = CGSize(width: self.scrollViewObj.frame.width, height: self.containerView.frame.origin.y+self.containerView.frame.size.height+64+50);
        }
    }
    
    func confirmNewAddressBtnTapped()
    {
        print("delegate1 called")
        self.delegate?.addAddressDelegateTapped()
    }
    
    func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        self.reciverNameTxt.resignFirstResponder()
        self.emailTxt.resignFirstResponder()
        self.houseNoTxt.resignFirstResponder()
        self.streetTxt1.resignFirstResponder()
        self.streetTxt2.resignFirstResponder()
        self.streetTxt3.resignFirstResponder()
        self.zipcodeTxt.resignFirstResponder()
        self.cityTxt.resignFirstResponder()
        self.countryTxt.resignFirstResponder()
        self.stateTxt.resignFirstResponder()
        self.typeOffParcelTxt.resignFirstResponder()
        self.conatctNoTxt.resignFirstResponder()
    }
    func setupDropDowns() {
        
        setupAmountDropDown()
    }
    func setupAmountDropDown()
    {

        addressDropDown.anchorView = self.addressViewObj
        addressDropDown.dismissMode = .onTap
        addressDropDown.direction = .top
        //self.scrollViewObj.bringSubview(toFront: amountDropDown.anchorView)
        
        // By default, the dropdown will have its origin on the top left corner of its anchor view
        // So it will come over the anchor view and hide it completely
        // If you want to have the dropdown underneath your anchor view, you can do this:
        addressDropDown.bottomOffset = CGPoint(x: 0, y: addressViewObj.bounds.height)
        
        // You can also use localizationKeysDataSource instead. Check the docs.
        addressDropDown.dataSource = [NSLocalizedString("txt_typeofparcel",comment: ""),NSLocalizedString("valid_home",comment: ""),
            NSLocalizedString("valid_office",comment: "")

        ]
        
        // Action triggered on selection
        addressDropDown.selectionAction = { [unowned self] (index, item) in
            // self.amountButton.setTitle(item, for: .normal)
            self.typeOffParcelTxt.text = item
        }
    }
    
    @IBAction func btnsTapped(_ sender : UIButton)
    {
        let btn = sender as UIButton
        
        if btn.tag == 10
        {
            self.dismiss(animated: true, completion: nil)
        }
        else if btn.tag == 20
        {
            addNewAddress()
            
        }else if btn.tag == 30
        {
            appdeletegate.addressStatus = "Yes"
            addressDropDown.show()
        }
        else if btn.tag == 40{
           
            self.dismissallkeybords()
            self.isSearching = false
            self.searchBar.text = ""
            self.view.bringSubview(toFront: self.countryCodeView)
            self.scrollViewObj.bringSubview(toFront: self.countryCodeView)
            self.countryCodeView.isHidden = false

        }
        else if btn.tag == 50{
            btn.tag = 60
           
            stateTxt.resignFirstResponder()
            houseNoTxt.resignFirstResponder()
            self.currentLocationImg.image = UIImage.init(named: "icon_selectedBtn")
          //  btn.setImage(UIImage(named:"icon_selectedBtn"), for: .normal)
            determineMyCurrentLocation()
        }
        else if btn.tag == 60
        {
            btn.tag = 50
            
            self.cityTxt.text = ""
            self.zipcodeTxt.text = ""
            self.countryTxt.text = ""
            self.stateTxt.text = ""
            self.houseNoTxt.text = ""
            self.streetTxt1.text = ""
            self.streetTxt2.text = ""
            self.streetTxt3.text = ""
            self.currentLocationImg.image = UIImage.init(named: "icon_unselectedBtn")
            //btn.setImage(UIImage(named:"icon_unselectedBtn"), for: .normal)
        }
    }
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        self.scrollViewObj.isScrollEnabled = true
        keyboardHide = "No"
        var info = notification.userInfo!
        var keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        if keyboardSize?.height == 0
        {
            keyboardSize?.height = 258
        }
        var contentInsets : UIEdgeInsets!
        
        if contactStatus == "Yes"
        {
           contactStatus = ""
           contentInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height, 0.0)
        }
        else
        {
            contentInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height+50, 0.0)
        }
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollViewObj.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
        
      /*  var keyboardFrame = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height, 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets

        var aRect : CGRect = self.view.frame
        aRect.size.height =  aRect.size.height -  keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollViewObj.scrollRectToVisible(activeField.frame, animated: true)
            }
        }*/
       /* var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.scrollViewObj.contentInset
        contentInset.bottom = keyboardFrame.size.height + 180
        
       scrollViewObj.contentInset = contentInset*/
        
    }
    
    func keyboardWillBeHidden(notification: NSNotification)
    {
        //Once keyboard disappears, restore original positions
        keyboardHide = ""
       let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)
       self.scrollViewObj.contentInset = contentInsets
       self.scrollViewObj.scrollIndicatorInsets = contentInsets
       self.view.endEditing(true)
       self.scrollViewObj.isScrollEnabled = true

    }
    
    func textFieldDidBeginEditing(_ textField: UITextField){
        
        if textField == self.reciverNameTxt
        {
            self.reciverNameTxt.returnKeyType = .next
            activeField = textField
        }
        else if textField == self.emailTxt
        {
            self.emailTxt.returnKeyType = .next
            activeField = textField
            
        }
        else if textField == self.houseNoTxt
        {
            self.houseNoTxt.returnKeyType = .next
            activeField = textField
            
        }
        else if textField == self.streetTxt1
        {
            self.streetTxt1.returnKeyType = .next
            activeField = textField
            
        }
        else if textField == self.streetTxt2
        {
            self.streetTxt2.returnKeyType = .next
            activeField = textField
            
        }
        else if textField == self.streetTxt3
        {
            self.streetTxt3.returnKeyType = .next
            activeField = textField
            
        }
        else if textField == self.zipcodeTxt
        {
            self.countryTxt.text = ""
            self.stateTxt.text  = ""
            self.cityTxt.text = ""
           // zipcodeTxt.returnKeyType = .next
            self.zipcodeTxt.keyboardType = .numberPad
            self.addBarBtnToKeyboard(textfield: self.zipcodeTxt)
            activeField = textField
        }
        else if textField == self.cityTxt
        {activeField = textField
            self.cityTxt.returnKeyType = .next
            if zipcodeTxt.text?.characters.count == 6{
                self.googleAddressApi(str:zipcodeTxt.text!)
            }
            
//            if zipcodeTxt.text?.characters.count == 0||(zipcodeTxt.text?.characters.count)! < 6||(zipcodeTxt.text?.characters.count)! > 6
//            {
//                self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_zipcode1",comment: ""), completion: {(result) in
//
//                    //
//                    self.zipcodeTxt.becomeFirstResponder()
//                })
//            }
            

        }
        else if textField == self.stateTxt
        {activeField = textField
            self.stateTxt.returnKeyType = .next
//            activeField?.frame = CGRect(x: 20, y: self.cityTxt.frame.origin.y+self.cityTxt.frame.size.height+10, width: self.view.frame.size.width-40, height: 40)

        } else if textField == self.countryTxt
        {
            self.countryTxt.returnKeyType = .next

//            activeField?.frame = CGRect(x: 20, y: self.stateTxt.frame.origin.y+self.stateTxt.frame.size.height+10, width: self.view.frame.size.width-40, height: 40)
             activeField = textField

        }
        else if textField == self.conatctNoTxt
        {
            if countrycodeTextField.text?.characters.count == 0{
                self.showAlertMessage(vc: self, titleStr:NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("val_countrycode", comment: ""))
            }
            else{
                contactStatus = "Yes"
                self.conatctNoTxt.keyboardType = .numberPad
                self.addBarBtnToKeyboard(textfield: self.conatctNoTxt)
               // textField.frame = CGRect(x: self.conatctNoTxt.frame.origin.x, y: self.countryViewObj.frame.origin.y+self.countryViewObj.frame.size.height+10, width: self.conatctNoTxt.frame.size.width, height: self.conatctNoTxt.frame.size.height)
                print("textField ::: ",textField.frame)
                activeField = textField
                //activeField?.frame = CGRect(x: self.conatctNoTxt.frame.origin.x, y: self.countryViewObj.frame.origin.y+self.countryViewObj.frame.size.height+10, width: self.conatctNoTxt.frame.size.width, height: self.conatctNoTxt.frame.size.height)
                print("activeField ::: ",activeField?.frame as Any)

            }
          
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField){
        activeField = nil
        contactStatus = ""

        if textField == self.reciverNameTxt{
            if self.reciverNameTxt.text?.characters.count == 0 || self.reciverNameTxt.text == ""
            {
                
            }
            else
            {
                self.reciverNameTxt.text = firstCharacterUpperCase(string:self.reciverNameTxt.text!)
            }
        }
        
        
    }
    func dismissKeyBoard(){
        self.reciverNameTxt.resignFirstResponder()
        self.emailTxt.resignFirstResponder()
        self.houseNoTxt.resignFirstResponder()
        self.streetTxt1.resignFirstResponder()
        self.streetTxt2.resignFirstResponder()
        self.streetTxt3.resignFirstResponder()
        self.zipcodeTxt.resignFirstResponder()
        self.cityTxt.resignFirstResponder()
        self.countryTxt.resignFirstResponder()
        self.stateTxt.resignFirstResponder()
        self.typeOffParcelTxt.resignFirstResponder()
        self.conatctNoTxt.resignFirstResponder()
        if errorstatus == true{
            errorstatus = false
        }
    }
    func firstCharacterUpperCase(string:String) -> String {
        let str = string as NSString
        let firstUppercaseCharacter = str.substring(to: 1).uppercased()
        let firstUppercaseCharacterString = str.replacingCharacters(in: NSMakeRange(0, 1), with: firstUppercaseCharacter)
        return firstUppercaseCharacterString
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        switch textField
        {
        case self.reciverNameTxt:
         //   self.reciverNameTxt.text = firstCharacterUpperCase(string:self.reciverNameTxt.text!)
            self.emailTxt.becomeFirstResponder()
            break
        case self.emailTxt:
            self.houseNoTxt.becomeFirstResponder()
            break
        case self.houseNoTxt:
            streetTxt1.becomeFirstResponder()
            break
        case self.streetTxt1:
            streetTxt2.becomeFirstResponder()
            break
        case self.streetTxt2:
            streetTxt3.becomeFirstResponder()
            break
        case self.streetTxt3:
            zipcodeTxt.becomeFirstResponder()
            break
        case self.zipcodeTxt:
           // cityTxt.becomeFirstResponder()
            break
        case self.cityTxt:
            self.stateTxt.becomeFirstResponder()
            break
        case self.stateTxt:
            self.countryTxt.becomeFirstResponder()
            break
        case self.countryTxt:
            self.conatctNoTxt.becomeFirstResponder()
            break
        case self.conatctNoTxt:
            textField.resignFirstResponder()
            break
        default:
            textField.resignFirstResponder()
        }
        if errorstatus == true{
            dismissKeyBoard()
        }
        return true
    }
    func addBarBtnToKeyboard(textfield : UITextField)
    {
        if textfield == conatctNoTxt{
        let keyPadToolBar = UIToolbar()
        keyPadToolBar.barStyle = UIBarStyle.blackTranslucent
        keyPadToolBar.sizeToFit()
        let DoneButton = UIBarButtonItem(title:NSLocalizedString("keyboard_done", comment: ""), style: UIBarButtonItemStyle.done, target: self, action: #selector(AddNewAddressViewController.dismissKeypad))
        keyPadToolBar.setItems([DoneButton], animated: true)
        textfield.inputAccessoryView = keyPadToolBar
    }
    else{
        let keyPadToolBar = UIToolbar()
        keyPadToolBar.barStyle = UIBarStyle.blackTranslucent
        keyPadToolBar.sizeToFit()
        let DoneButton = UIBarButtonItem(title:NSLocalizedString("keyboard_next", comment: ""), style: UIBarButtonItemStyle.done, target: self, action: #selector(AddNewAddressViewController.dismissKeypad1))
        keyPadToolBar.setItems([DoneButton], animated: true)
        textfield.inputAccessoryView = keyPadToolBar
        }
    }
    
    func dismissallkeybords()
    {
        self.reciverNameTxt.resignFirstResponder()
        self.emailTxt.resignFirstResponder()
        self.houseNoTxt.resignFirstResponder()
        self.streetTxt1.resignFirstResponder()
        self.streetTxt2.resignFirstResponder()
        self.streetTxt3.resignFirstResponder()
        self.zipcodeTxt.resignFirstResponder()
        self.cityTxt.resignFirstResponder()
        self.countryTxt.resignFirstResponder()
        self.stateTxt.resignFirstResponder()
        self.typeOffParcelTxt.resignFirstResponder()
        self.conatctNoTxt.resignFirstResponder()
    }
    func dismissKeypad()
    {
        // self.zipcodeTxt.resignFirstResponder()
        self.conatctNoTxt.resignFirstResponder()
    }
    func dismissKeypad1()
    {
        self.zipcodeTxt.resignFirstResponder()
        
 
        self.cityTxt.becomeFirstResponder()
    }
    
   func scrollViewDidScroll(_ scrollView: UIScrollView) // any offset changes
   {
    if keyboardHide == "No"
    {
        scrollView.contentSize = CGSize(width: scrollView.frame.size.width, height: (self.containerView.frame.origin.y+self.contentView.frame.size.height)-34)
    }
    else
    {
        scrollView.contentSize = CGSize(width: scrollView.frame.size.width, height: self.containerView.frame.origin.y+self.containerView.frame.size.height+64+50)
    }
    
   }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func addNewAddress()
    {
        if reciverNameTxt.text?.characters.count == 0{
            
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_name",comment: ""), completion: {(result) in
          self.errorstatus = true
                self.reciverNameTxt.becomeFirstResponder()
            })
            
            return
        }
       else if emailTxt.text?.characters.count == 0{
            
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_email",comment: ""), completion: {(result) in
                self.errorstatus = true
                self.emailTxt.becomeFirstResponder()
            })
            
            return
        }
      else if Constants().isValidEmail(emailTxt.text!) == false{
            
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_email1",comment: ""), completion: {(result) in
                self.errorstatus = true
                self.emailTxt.becomeFirstResponder()
            })
        }
        else if houseNoTxt.text?.characters.count == 0{
            
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_houseno",comment: ""), completion: {(result) in
                 self.errorstatus = true
                self.houseNoTxt.becomeFirstResponder()
            })
            
            return
        }
      else if streetTxt1.text?.characters.count == 0{
            
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_street1",comment: ""), completion: {(result) in
                self.errorstatus = true
                self.streetTxt1.becomeFirstResponder()
            })
            
            return
        }
          else if zipcodeTxt.text?.characters.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_zipcode",comment: ""), completion: {(result) in
                self.errorstatus = true
                self.zipcodeTxt.becomeFirstResponder()
            })
            
            return
        }
          else if Constants().isValidPincode(value:self.zipcodeTxt.text!) == false{
            
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_zipcode1",comment: ""), completion: {(result) in
               self.errorstatus = true
                self.zipcodeTxt.becomeFirstResponder()
            })
            
            return
        }
        else if cityTxt.text?.characters.count == 0{
            
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_city",comment: ""), completion: {(result) in
              self.errorstatus = true
                self.cityTxt.becomeFirstResponder()
            })
            
            return
        }
          else if stateTxt.text?.characters.count == 0{
            
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_state",comment: ""), completion: {(result) in
                self.errorstatus = true
                self.stateTxt.becomeFirstResponder()
            })
            
            return
        }
       else if countryTxt.text?.characters.count == 0
        {
            
        self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_country",comment: ""), completion: {(result) in
                self.errorstatus = true
                self.countryTxt.becomeFirstResponder()
            })
            
            return
        }
       else if self.conatctNoTxt.text?.characters.count == 0{
            
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_phno",comment: ""), completion: {(result) in
                self.errorstatus = true
                self.conatctNoTxt.becomeFirstResponder()
            })
            
            return
        }
         else if Constants().validatePhoneNumber(value:self.conatctNoTxt.text!) == false{
            
            
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_phno1",comment: ""), completion: {(result) in
                 self.errorstatus = true
                self.conatctNoTxt.becomeFirstResponder()
            })
            
            return
        }
        else if typeOffParcelTxt.text  == NSLocalizedString("txt_typeofparcel",comment:""){
            
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_parceltype",comment: ""), completion: {(result) in
                
            })
            
            return
        }
       else if typeOffParcelTxt.text?.characters.count == 0{
            
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_parceltype",comment: ""), completion: {(result) in
                
            })
            
            return
        }
        else
        {
            var address = self.houseNoTxt.text! + ", " + self.streetTxt1.text!
            
            
            if self.streetTxt2.text?.characters.count == 0
            {
                
            }else
            {
               address += ", " + self.streetTxt2.text!
            }
            if self.streetTxt2.text?.characters.count == 0
            {
                
            }else
            {
                address += ", " + self.streetTxt3.text!
            }
            
            address += ", " + self.cityTxt.text! + ", " + self.stateTxt.text! + ", " + self.zipcodeTxt.text! + ", " + self.countryTxt.text!
            
            Constants.setValueInUserDefaults(objValue: self.countrycodeTextField.text!, for: "countrycode")

            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let newadddress = storyboard.instantiateViewController(withIdentifier: "NewAddressViewController") as! NewAddressViewController
            newadddress.controlerName = controllerName
            newadddress.nameObjStr = self.reciverNameTxt.text!
            newadddress.zipcodeObjStr = self.zipcodeTxt.text!
            newadddress.contactNoObjStr = self.countrycodeTextField.text! + " " + self.conatctNoTxt.text!
            newadddress.addressObjStr = address
            newadddress.emailObjStr = self.emailTxt.text!
            newadddress.houseNoObjStr = self.houseNoTxt.text!
            newadddress.streetObjStr1 = self.streetTxt1.text!
            newadddress.streetObjStr2 = self.streetTxt2.text!
            newadddress.streetObjStr3 = self.streetTxt3.text!
            newadddress.cityObjStr = self.cityTxt.text!
            newadddress.stateObjStr = self.stateTxt.text!
            newadddress.countryObjStr = self.countryTxt.text!
            newadddress.typeofAddressObjStr = self.typeOffParcelTxt.text!
            newadddress.delegate = self
            self.present(newadddress, animated: true, completion: nil)
        }
    }
        func googleAddressApi(str:String)
        {
            let geocoder = CLGeocoder()
            geocoder.geocodeAddressString(str) {
                (placemarks, error) -> Void in
                // Placemarks is an optional array of CLPlacemarks, first item in array is best guess of Address
                if (error == nil) || placemarks?.count == nil
               {
                    self.cityTxt.isUserInteractionEnabled = true
                    self.stateTxt.isUserInteractionEnabled = true
                    self.countryTxt.isUserInteractionEnabled = true
                }
            
                if let placemark = placemarks?[0] {
                    
                  
                    let city:String = placemark.locality!
                    let country : String = placemark.country!
                    let state: String = placemark.administrativeArea!
                    DispatchQueue.main.async {
                                      self.cityTxt.text = city
                                        self.stateTxt.text = state
                                        self.countryTxt.text = country
                }
            }
      
    }
    }
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        countryViewBottom.constant = 216+20+5 - countryViewBottom.constant
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        // countryViewBottom.constant = 20 + countryViewBottom.constant
        searchBar.resignFirstResponder()
        self.searchBar.endEditing(true)
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchBar.text == "" || searchBar.text == nil{
            isSearching = false
            addressTextView.reloadData()
        }
        else{
            // isSearching = true
            
            self.phonecodeArray = [];
            self.countrycodeArray = [];
            self.filteredArray = [];
            
            let searchPredicate = NSPredicate(format: "SELF beginswith[c] %@",searchBar.text!)
            
            filteredArray = (nameArray.filtered(using: searchPredicate) as NSMutableCopying) as! [String]
            
            for index in filteredArray{
                
                var name = ""
                
                name = index
                
                for country in countries{
                    if name == country.name{
                        self.phonecodeArray.add(country.phoneCode!)
                        self.countrycodeArray.add(country.code!)
                    }
                }
                
            }
            
            if(filteredArray.count == 0){
                isSearching = false;
            } else {
                isSearching = true;
            }
            
            //  filteredArray = (nameArray.filtered(using: searchPredicate) as! NSMutableArray) as! [String]
            
            
            self.addressTextView.reloadData()
            print("fiteredArray",filteredArray)
            
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if isSearching == true
        {
            return  filteredArray.count
        }
        else
        {
            return countries.count
        }
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CountryTableViewCell", for: indexPath) as! CountryTableViewCell
        
        if isSearching  == true{
            
            let countrycode =  "(" + (countrycodeArray[indexPath.row] as? String)! + ")"
            let newcountry = (filteredArray[indexPath.row] as? String)!
                + countrycode
            cell.countryNameLbl.text = newcountry
            cell.countryCodeLbl.text = phonecodeArray[indexPath.row] as? String
            
        }
        else
        {
            let country = countries[indexPath.row]
            let countrycode = "(" + country.code! + ")"
            cell.countryNameLbl.text = country.name! + countrycode
            cell.countryCodeLbl.text = country.phoneCode
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        countryViewBottom.constant = 20
        if isSearching == true
        {
            isSearching = false
            self.searchBar.resignFirstResponder()
            let code = phonecodeArray[indexPath.row] as? String
            self.countrycodeTextField.text = code
            self.countryCodeView.isHidden = true
            // self.phonecodeArray = NSMutableArray()
            // self.countrycodeArray = NSMutableArray()
            // filteredArray = NSMutableArray()
            /* self.phonecodeArray.removeAllObjects()
             self.countrycodeArray.removeAllObjects()
             filteredArray.removeAllObjects()*/
            self.phonecodeArray = [];
            self.countrycodeArray = [];
            self.filteredArray = [];
        }
        else
        {
            isSearching = false
            let country = countries[indexPath.row]
            let code = country.phoneCode
            self.countrycodeTextField.text = code
            self.countryCodeView.isHidden = true
            self.searchBar.resignFirstResponder()
            
        }
        self.addressTextView.reloadData()
    }
    
//    func getLatLngForZip(zipCode: String)
//    {
//        let baseUrl = "https://maps.googleapis.com/maps/api/geocode/json?"
//        let apikey = "AIzaSyAcSYeF7hyGSEG27a-NG5qZ8rhBy24fQTs"
//
//        var latitude = Double()
//        var longitude = Double()
//        let url:NSURL = NSURL(string:"\(baseUrl)address=\(zipCode)&key=\(apikey)")!
//        let data = NSData(contentsOf:url as URL)
//        let json = try! JSONSerialization.jsonObject(with: data! as Data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSDictionary
//        if let result = json["results"] as? [[String:Any]] {
//
//            for array in result{
//            if let geometry = array["geometry"] as? NSDictionary {
//                if let location = geometry["location"] as? NSDictionary {
//                     latitude = location["lat"] as! Double
//                     longitude = location["lng"] as! Double
//                    print("\n\(latitude), \(longitude)")
//
//                }
//            }
//        }
//            getAddressForLatLng(latitude: latitude, longitude:longitude)
//        }
//    }
//    func getAddressForLatLng(latitude: Double, longitude: Double) {
//        let baseUrl = "https://maps.googleapis.com/maps/api/geocode/json?"
//        let apikey = "AIzaSyAcSYeF7hyGSEG27a-NG5qZ8rhBy24fQTs"
//        let url = NSURL(string: "\(baseUrl)latlng=\(latitude),\(longitude)&key=\(apikey)")
//        let data = NSData(contentsOf:url! as URL)
//        let json = try! JSONSerialization.jsonObject(with: data! as Data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSDictionary
//        print("json",json)
//        if let result = json["results"] as? [String:AnyObject]{
//            print("result",result)
//
////                if let address = result[0]["address_components"] as? NSArray {
////
////                let number = address[0]["short_name"] as! String
////                let street = address[1]["short_name"] as! String
////                let city = address[2]["short_name"] as! String
////                let state = address[4]["short_name"] as! String
////                let zip = address[6]["short_name"] as! String
////                print("\n\(number) \(street), \(city), \(state) \(zip)")
////            }
//
//        }
//    }
   
}
extension AddNewAddressViewController:CLLocationManagerDelegate{
    
    @nonobjc func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        switch status {
        case .authorizedWhenInUse:
            manager.startUpdatingLocation()
            break
        case .authorizedAlways:
            manager.startUpdatingLocation()
            break
        case .denied:
            //handle denied
            break
        case .notDetermined:
            manager.requestWhenInUseAuthorization()
            break
        default:
            break
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let locationArray = locations as NSArray
        let locationObj = locationArray.firstObject as! CLLocation
        //  let coord = locationObj.coordinate
        self.getAddressFromLatLon(location: locationObj)
        locationManager.stopUpdatingLocation()
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        IJProgressView.shared.hideProgressView()
       
        self.showAlertMessage(vc: self, titleStr:NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("ver_somethingwrong", comment: ""))
        print("Couldn't get your location")
    }
    
    
    
}

