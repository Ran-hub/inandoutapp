//
//  HeaderView.swift
//  RYTLE
//
//  Created by Admin on 19/04/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

protocol headerProtocol
{
    func BtnTapped(sender:UIButton);
}

class HeaderView: UIView {

    let dayLabel = UILabel()
    let Home = UIButton()
    let btn1 = UIButton()
    
    let imageObject = UIImageView()
    
    var delegate : headerProtocol?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
      //  let width : CGFloat = frame.width
      //  let height : CGFloat = frame.height
      //  let color : UIColor = UIColor(red: 0.5, green: 0.7, blue: 0.2, alpha: 1)
        self.backgroundColor = UIColor(red: 52/255, green: 152/255, blue: 219/255, alpha: 1)
        Home.frame = CGRect(x: 15, y:25, width: 35, height: 30)
       // Home.setTitle("Menu", for: UIControlState())
        Home.setImage(UIImage.init(named: "white_menu_icon.png"), for: UIControl.State.normal)
    //    Home.setTitleColor(UIColor(red: 0.5, green: 0.7, blue: 0.2, alpha: 1), for: UIControlState.normal)
        //Home.backgroundColor = UIColor.white
       // Home.titleLabel?.lineBreakMode = NSLineBreakMode.byWordWrapping
       // Home.titleLabel?.textAlignment = NSTextAlignment.center
       // Home.layer.borderColor = UIColor(red: 0.5, green: 0.7, blue: 0.2, alpha: 1).cgColor
      //  Home.layer.borderWidth = 1
        Home.addTarget(self, action: #selector(HeaderView.AlertBtnTapped), for: UIControl.Event.touchUpInside)
        self.addSubview(Home)
      /*  self.dayLabel.frame = CGRect(x: 0, y: 0, width: width, height: 40)
        self.dayLabel.textAlignment = NSTextAlignment.center
        self.dayLabel.textColor = color
        self.dayLabel.font = UIFont.systemFont(ofSize: 25)
        self.dayLabel.text = "Custom Alert"
        self.dayLabel.backgroundColor = UIColor.white
        
        self.addSubview(self.dayLabel)
        
        self.imageObject.frame = CGRect(x: 0, y: 40, width: width , height: height-165)
        self.imageObject.isUserInteractionEnabled = true
        self.imageObject.image = UIImage(named:"drink2")
        self.addSubview(self.imageObject)
        
       
        
        btn1.frame = CGRect(x: 0, y: self.Home.frame.origin.y+self.Home.frame.size.height+2, width: width, height: 40)
        btn1.setTitle("Cancel", for: UIControlState())
        btn1.setTitleColor(UIColor(red: 0.5, green: 0.7, blue: 0.2, alpha: 1), for: UIControlState.normal)
        btn1.backgroundColor = UIColor.white
        btn1.titleLabel?.lineBreakMode = NSLineBreakMode.byWordWrapping
        btn1.titleLabel?.textAlignment = NSTextAlignment.center
        btn1.layer.borderColor = UIColor(red: 0.5, green: 0.7, blue: 0.2, alpha: 1).cgColor
        btn1.layer.borderWidth = 1
        btn1.addTarget(self, action: #selector(HeaderView.AlertBtnTapped1), for: UIControlEvents.touchUpInside)*/
        self.addSubview(btn1)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
   //    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
    @objc func AlertBtnTapped(sender:UIButton)
    {
        self.delegate?.BtnTapped(sender: sender);
    }
    func AlertBtnTapped1(sender:UIButton)
    {
        self.delegate?.BtnTapped(sender: sender);
    }

    

}
