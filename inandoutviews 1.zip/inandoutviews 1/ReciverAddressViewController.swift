
//
//  ReciverAddressViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 28/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class ReciverAddressVC: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var cancelBtn : UIButton!
    @IBOutlet weak var titleTxt : UILabel!
    @IBOutlet weak var reciverDetailsTable : UITableView!
    @IBOutlet weak var continueBtn : UIButton!
    @IBOutlet weak var addnewBtn : UIButton!
    @IBOutlet weak var headerView : UIView!
    @IBOutlet weak var titleLblCC: NSLayoutConstraint!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    
    var receiverAddessData = [PickupAddressData()]
    var refreshControl = UIRefreshControl()
    var count : Int = 0
    var addressSelected = true
    var recieverListModalArray : NSMutableArray = NSMutableArray()
    let appdeletegate:AppDelegate=(UIApplication.shared.delegate as! AppDelegate)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = true
        self.statusLabel.text = NSLocalizedString("ver_noaddress", comment: "")
        self.statusLabel.numberOfLines = 2
        self.recieverAddressapi()
        self.initialSetup()
        self.intialConstraintsSetup()
        self.addRefreshVCToTableView()
        self.languageValidationForGermany()
        self.statusDisplay()
    }
    
    func initialSetup(){
        self.reciverDetailsTable.register(UINib(nibName: "ReciverDetailsTableViewCell", bundle: nil), forCellReuseIdentifier: "ReciverDetailsTableViewCell")
        self.titleTxt.text = NSLocalizedString("lbl_receiverdetails", comment: "")
        self.titleTxt.font = AppFont.boldTextFont
        if appdeletegate.IS_IPHONE5{
            titleTxt.font = UIFont(name: "HelveticaNeue", size: 18)
        }
        self.titleTxt.textColor = AppColors.whiteColorRGB
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.continueBtn.setTitle(NSLocalizedString("btn_continue", comment: ""), for: .normal)
        self.continueBtn.titleLabel?.font = AppFont.boldTextFont
        self.continueBtn.backgroundColor = AppColors.greenColorRGB
        self.continueBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.continueBtn.titleLabel?.font = AppFont.boldTextFont
        self.addnewBtn.setTitle(NSLocalizedString("btn_addnew", comment: ""), for: .normal)
        self.addnewBtn.titleLabel?.font = AppFont.boldTextFont
        self.addnewBtn.backgroundColor = AppColors.greenColorRGB
        self.addnewBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.addnewBtn.titleLabel?.font = AppFont.boldTextFont
    }
    func addRefreshVCToTableView(){
        // Add Refresh Control to Table View
        if #available(iOS 10.0, *) {
            reciverDetailsTable.refreshControl = refreshControl
        } else {
            // Fallback on earlier versions
            reciverDetailsTable.addSubview(refreshControl)
        }
        refreshControl.tintColor = AppColors.greenColorRGB
        refreshControl.attributedTitle = NSAttributedString(string: "Loading...")
        refreshControl.addTarget(self, action: #selector(ReciverAddressVC.refreshData), for: .valueChanged)
    }
    func intialConstraintsSetup(){
        if appdeletegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    
    func languageValidationForGermany()
    {
        let languageCode = Constants.getValueFromUserDefults(for: "languageCode") as! String
        
        if languageCode == "Yes"
        {
            self.languageValidationForGermany(headerView: self.headerView, cancelBtn: self.cancelBtn, labelConstraints: self.titleLblCC, titleLbl: self.titleTxt)
        }
        /*if appdeletegate.IS_IPHONE5 || appdeletegate.IS_IPHONE6 || appdeletegate.IS_IPHONEX
         {
         if languageCode == "Yes"
         {
         self.titleTxt.textAlignment = .left
         self.headerView.removeConstraint(self.titleLblCC)
         self.headerView.addConstraint(NSLayoutConstraint(item: self.cancelBtn, attribute: .width, relatedBy: .equal , toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 90))
         
         self.headerView.addConstraint(NSLayoutConstraint(item: self.titleTxt, attribute: .leading, relatedBy: .equal , toItem: self.cancelBtn, attribute: .trailing, multiplier: 1, constant: 5))
         
         self.headerView.addConstraint(NSLayoutConstraint(item: self.headerView, attribute: .trailing, relatedBy: .equal , toItem: self.titleTxt, attribute: .trailing, multiplier: 1, constant: 5))
         }
         else
         {
         
         }*/
        
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
        if self.appdeletegate.recieverAddAddress == "yes"
        {
            self.appdeletegate.recieverAddAddress = ""
            self.recieverAddressapi()
            
        }
    }
    
    func refreshData()
    {
        self.recieverAddressapi()
    }
    
    override func viewDidLayoutSubviews()
    {
        
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        self.refreshControl.endRefreshing()
    }
    
    func deleteAddress(sender:UIButton){
        let receiverAddress = self.recieverListModalArray.object(at: sender.tag) as! RecieverAddreesData
        let address_id =  receiverAddress.address_id
        
        let alert = UIAlertController(title: NSLocalizedString("Rytle", comment: ""), message:NSLocalizedString("alert_msg", comment: ""), preferredStyle: .alert)
        let clearAction = UIAlertAction(title:NSLocalizedString("alert_delete", comment: ""), style: .destructive) { (alert: UIAlertAction!) -> Void in
            if self.ineternetAlert() == false
            {
                return
            }
            
            IJProgressView.shared.showProgressView(self.view)
            
            var bodyReq = [String:String]()
            
            bodyReq = ["delivery_add_id":address_id]
            var token = String()
            var reultanttoken = ""
            if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
                token = Constants.getValueFromUserDefults(for: "usertoken") as! String
                reultanttoken = "Bearer" + " " + token
                //print("token",reultanttoken)
            }
            if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
            {
                APICommnicationManager.sharedInstance.requestforAPI(service:"/Parcel/deleteDeliveryaddress"
                , method: "POST", token:reultanttoken, body: "", productBody: bodyData as NSData) { (result, error) in
                    
                    if let Result = result as? [String:Any]{
                        // print("Result",Result)
                        
                        if let status = Result["status"] as? Bool {
                            // print("status",status)
                            if status == true{
                                DispatchQueue.main.async(execute: { () -> Void in
                                    IJProgressView.shared.hideProgressView()
                                    self.recieverListModalArray.removeObject(at:sender.tag)
                                    self.reciverDetailsTable.reloadData()
                                    self.statusDisplay()
                                })
                            }
                            if status == false{
                                DispatchQueue.main.async(execute: { () -> Void in
                                    IJProgressView.shared.hideProgressView()
                                    
                                    self.displayAlert(message: NSLocalizedString("delete_add_failure", comment: ""))
                                })
                            }
                        }
                        else
                        {
                            if Result["code"] as? String == "InvalidCredentials"
                            {
                                DispatchQueue.main.async(execute: { () -> Void in
                                    IJProgressView.shared.hideProgressView()
                                    self.tokenExpireAlert()
                                })
                            }
                        }
                    }
                    else
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            IJProgressView.shared.hideProgressView()
                            self.displayAlert(message: NSLocalizedString("ver_somethingwrong", comment: ""))
                        })
                        
                    }
                }
            }
        }
        clearAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        let cancelAction = UIAlertAction(title:NSLocalizedString("alert_cancel", comment:""), style: .default) { (alert: UIAlertAction!) -> Void in
            
        }
        cancelAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        alert.addAction(clearAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion:nil)
        
        
    }
    
    func displayAlert(message: String)
    {
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    @IBAction func btnsTapped(_ sender : UIButton)
    {
        let btn = sender as UIButton
        
        if btn.tag == 10 {
            
            self.dismiss(animated: true, completion: nil)
        }
        else if btn.tag == 20
        {
            if addressSelected == true
            {
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ParcelBookingConfirmationVC") as! ParcelBookingConfirmationVC
                self.present(nextViewController, animated:true, completion: nil)
            }
            else{
                self.displayAlert(message: NSLocalizedString("ver_address", comment: ""))
            }
            
        }else if btn.tag == 30
        {
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "AddNewAddressVC") as! AddNewAddressVC
            nextViewController.controllerName = "ReceiverDetails"
            self.present(nextViewController, animated:true, completion: nil)
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return recieverListModalArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ReciverDetailsTableViewCell") as! ReciverDetailsTableViewCell
        
        let reciever = self.recieverListModalArray.object(at: indexPath.row) as! RecieverAddreesData
        
        //cell.usernameLbl.text = parcel.name
        
        let str = reciever.fulladdress // pickupListArray1.object(at: indexPath.row) as! String
        
        var height : CGFloat = 0
        //height += 15+21+5
        height += self.heightForView(text: str, font: UIFont(name: "HelveticaNeue", size: 15)!, width: self.view.frame.size.width-70)
        if height < 21{
            height += 21
        }
        cell.addresssLbl.frame = CGRect(x: 50, y: cell.addresssLbl.frame.origin.y, width: self.view.frame.size.width-70, height: height)
        height += 26+26+20+15+21+5
        
        return  height
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell  = tableView.dequeueReusableCell(withIdentifier: "ReciverDetailsTableViewCell") as! ReciverDetailsTableViewCell
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        cell.selectedBtn.layer.masksToBounds = true
        cell.selectedBtn.layer.cornerRadius = cell.selectedBtn.frame.size.width/2
        cell.selectedView.layer.masksToBounds = true
        cell.selectedView.layer.cornerRadius = cell.selectedView.frame.size.width/2
        cell.unSelectedView.layer.masksToBounds = true
        cell.unSelectedView.layer.cornerRadius = cell.unSelectedView.frame.size.width/2
        cell.deleteButton.tag = indexPath.row
        cell.deleteButton.addTarget(self, action: #selector(ReciverAddressVC.deleteAddress), for:.touchUpInside)
        if count == indexPath.row
        {
            cell.unSelectedView.isHidden = false
        }
        else{
            
            cell.unSelectedView.isHidden = true
        }
        cell.selectedBtn.isUserInteractionEnabled = false
        cell.borderlbl.frame = CGRect(x: 0, y: cell.frame.size.height-1, width: cell.frame.size.width, height: 0.5)
        
        
        let reciever = self.recieverListModalArray.object(at: indexPath.row) as! RecieverAddreesData
        
        cell.usernameLbl.text = reciever.name
        
        var height : CGFloat = 0
        let str = reciever.fulladdress //pickupListArray1.object(at: indexPath.row)
        height += self.heightForView(text: str , font: UIFont(name: "HelveticaNeue", size: 15)!, width: self.view.frame.size.width-70)
        if height < 21{
            height += 21
        }
        cell.contentView.addConstraint(NSLayoutConstraint(item: cell.addresssLbl, attribute: NSLayoutAttribute.height, relatedBy: NSLayoutRelation.equal, toItem: nil, attribute: NSLayoutAttribute.notAnAttribute, multiplier: 1, constant: height))
        
        cell.addresssLbl.text = reciever.fulladdress
        cell.addresssLbl.lineBreakMode = NSLineBreakMode.byWordWrapping
        cell.addresssLbl.numberOfLines = 0
        cell.zipcodeLbl.text = reciever.zipcode
        cell.contactLbl.text = reciever.mobile
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        count = indexPath.row
        let receiverAddress = self.recieverListModalArray.object(at: indexPath.row) as! RecieverAddreesData
        let address_id =  receiverAddress.address_id
        self.addressSelected = true
        
        Constants.setValueInUserDefaults(objValue:receiverAddress.name , for:"receiver_username")
        Constants.setValueInUserDefaults(objValue:receiverAddress.fulladdress , for:"receiver_address")
        Constants.setValueInUserDefaults(objValue:receiverAddress.zipcode , for:"receiver_zipcode")
        Constants.setValueInUserDefaults(objValue:receiverAddress.mobile , for:"receiver_mobileno")
        Constants.setValueInUserDefaults(objValue:receiverAddress.address_id , for:"receiver_receiveraddressID")
        
        // print("addree_id",address_id)
        reciverDetailsTable.reloadData()
        
    }
    
    func heightForView(text:String, font:UIFont, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRect(x:0, y:0, width:width, height:2000))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    
    func recieverAddressapi(){
        
        if self.ineternetAlert() == false
        {
            self.statusLabel.text = NSLocalizedString("ver_internetavailable_error", comment: "")
            return
        }
        
        IJProgressView.shared.showProgressView(view)
        
        var bodyReq = [String:String]()
        var cust_id = String()
        if Constants.getValueFromUserDefults(for:"customer_id") as? String != nil{
            cust_id = Constants.getValueFromUserDefults(for:"customer_id") as! String
            // print("cust_id",cust_id)
        }
        bodyReq = ["customer_id":cust_id]
        var token = String()
        var reultanttoken = ""
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            reultanttoken = "Bearer" + " " + token
            // print("token",reultanttoken)
        }
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
        {
            APICommnicationManager.sharedInstance.requestforAPI(service:"/Parcel/getAllDeliveryaddress"
            , method: "POST", token:reultanttoken, body: "", productBody: bodyData as NSData) { (result, error) in
                
                if let Result = result as? [String:Any]{
                    // print("Result",Result)
                    
                    if let status = Result["status"] as? Bool {
                        
                        if status == true{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.recieverListModalArray.removeAllObjects()
                                self.receiverAddessData.removeAll()
                                self.refreshControl.endRefreshing()
                                let newArray  = Result["Msg"] as? [[String:Any]]
                                for array in newArray! {
                                    
                                    var houseno = ""
                                    var street1 = ""
                                    var street2 = ""
                                    var street3 = ""
                                    var city = ""
                                    var state = ""
                                    var country = ""
                                    var name = ""
                                    var Zipcode = ""
                                    var Address_id = ""
                                    var Mobile = ""
                                    
                                    if let pickupName = array["reciver_fullname"] as? String{
                                        name = pickupName
                                    }
                                    houseno = array["house_no"] as! String
                                    if let Street1 = array["street1"] as? String{
                                        street1 = Street1
                                    }
                                    let street2Array = NSMutableArray()
                                    let newstreet2 = Constants.checkForNull(value: array["street2"] as AnyObject)
                                    if newstreet2  == ""
                                    {
                                    }
                                    else
                                    {
                                        street2 = newstreet2
                                    }
                                    street2Array.add(street2)
                                    
                                    let street3Array = NSMutableArray()
                                    let newstreet3 = Constants.checkForNull(value: array["street3"] as AnyObject)
                                    if newstreet3  == ""
                                    {
                                    }
                                    else
                                    {
                                        street3 = newstreet3
                                    }
                                    street3Array.add(street3)
                                    
                                    if let City = array["city"] as? String{
                                        city = City
                                    }
                                    if let State = array["state"] as? String{
                                        state = State
                                    }
                                    if let Country = array["country"] as? String{
                                        country = Country
                                    }
                                    
                                    var address = ""
                                    if  street2.count == 0 && street3.count == 0{
                                        address = houseno  + ", " + street1 + ", "  + city  + ", " + state  + ", " + country
                                    }
                                    else if street2.count>0 && street3.count == 0{
                                        address = houseno  + ", " + street1 + ", " + street2  + ", " + city  + ", "  + state  + ", " + country
                                        
                                    }
                                    else if street2.count == 0 && street3.count > 0{
                                        address = houseno  + ", " + street1 + ", " + street3 + ", " + city  + ", "  + state  + ", " + country
                                    }
                                    else{
                                        address = houseno  + ", " + street1 + ", " + street2  + ", "  + street3 + ", " + city  + ", "  + state  + ", " + country
                                    }
                                    
                                    if let pickupPincode = array["zip_code"] as? String{
                                        Zipcode = pickupPincode
                                    }
                                    if let pickupMobile = array["reciver_mobile_no"] as? String{
                                        Mobile = pickupMobile
                                    }
                                    if let pickupaddressid = array["del_add_id"] as? Int{
                                        // Address_id = pickupaddressid
                                        Address_id = String(pickupaddressid)
                                    }
                                    let addressData1 = RecieverAddreesData()
                                    addressData1.houseno = houseno
                                    addressData1.street1 = street1
                                    addressData1.street2 = street2
                                    addressData1.street3 = street3
                                    addressData1.city = city
                                    addressData1.state = state
                                    addressData1.country = country
                                    addressData1.name = name
                                    addressData1.zipcode = Zipcode
                                    addressData1.mobile = Mobile
                                    addressData1.address_id = Address_id
                                    addressData1.fulladdress = address
                                    self.recieverListModalArray.add(addressData1)
                                }
                                
                                DispatchQueue.main.async {
                                    
                                    self.statusDisplay()
                                }
                            })
                        }
                        if status == false{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.statusDisplay()
                                self.refreshControl.endRefreshing()
                                self.displayAlert(message: NSLocalizedString("ver_noaddress", comment: ""))
                            })
                        }
                    }
                    else
                    {
                        if Result["code"] as? String == "InvalidCredentials"
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.tokenExpireAlert()
                            })
                        }
                    }
                }
                else
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                        self.statusDisplay()
                        self.refreshControl.endRefreshing()
                        self.displayAlert(message: NSLocalizedString("ver_internet", comment: ""))
                    })
                }
            }
        }
        
        
    }
    func addAddressDelegateTapped() {
        
        //  print("address delegate called")
        self.recieverAddressapi()
    }
    
    func statusDisplay()
    {
        if self.recieverListModalArray.count == 0
        {
            self.reciverDetailsTable.isHidden = true
            self.statusLabel.isHidden = false
            self.continueBtn.isUserInteractionEnabled = false
            self.continueBtn.backgroundColor = AppColors.lightGrayColorRGB
            self.addressSelected = false
        }
        else
        {
            self.addressSelected = true
            self.statusLabel.isHidden = true
            self.reciverDetailsTable.isHidden = false
            self.continueBtn.isUserInteractionEnabled = true
            self.continueBtn.backgroundColor = AppColors.greenColorRGB
            self.reciverDetailsTable.reloadData()
            let indexPath = IndexPath(row: 0, section: 0)
            self.reciverDetailsTable.selectRow(at: indexPath, animated: true, scrollPosition: .top)
            self.reciverDetailsTable.delegate?.tableView!(reciverDetailsTable, didSelectRowAt: indexPath)
        }
        
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

