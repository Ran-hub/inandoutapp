//
//  AppCoordinator.swift
//  RYTLERIDERAPP
//
//  Created by AMT on 8/20/18.
//  Copyright © 2018 Pavan. All rights reserved.
//

import Foundation
import UIKit

class AppCoordinator{
    var window: UIWindow?
    lazy var navigationController : UINavigationController = {
        let navigationController = UINavigationController()
        navigationController.isNavigationBarHidden = true
        return navigationController
    }()
    init(window : UIWindow) {
        self.window = window
        self.window?.makeKeyAndVisible()
        self.window?.rootViewController = navigationController
    }
    func start() -> (Void){
        let storyBoardObj = UIStoryboard(name: "Main", bundle: nil)
        let setupOrganizationVc = storyBoardObj.instantiateViewController(withIdentifier: "BaseURLVC") as! BaseURLVC
        self.navigationController.viewControllers = [setupOrganizationVc]
    }
}
