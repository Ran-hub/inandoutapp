//
//  APICommnicationManager.swift
//  RYTLE
//
//  Created by Admin on 11/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class APICommnicationManager: NSObject{
    
    static let sharedInstance : APICommnicationManager = {
        let instance = APICommnicationManager()
        return instance
    }()
    
    func requestforAPI(service:String,method:String,token:String,body:String,productBody:NSData?,completion:@escaping (_ data:Data?,_ error:AnyObject?,_ response : URLResponse?) -> ()){
       
         APPURLS.baseURL = self.getTheUrlType()
         print("APPURLS.baseURL :: ",APPURLS.baseURL)
        
        let urlpath:String = APPURLS.baseURL + APPURLS.versionNumber + service
        let url:NSURL = NSURL(string:urlpath)!
        // print("URL:\(url)")
        let request = NSMutableURLRequest(url: url as URL)
        request.httpMethod = method
        if token != ""{
            request.setValue("\(token)", forHTTPHeaderField: "Authorization")
        }
        if productBody == NSData(){
            if body != ""{
                let bodydata = body.data(using: String.Encoding.utf8)
                request.httpBody = bodydata
            }
        }else{
            request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            if productBody != nil{
            request.httpBody = productBody! as Data
            }
        }
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 30
        let session = URLSession(configuration: config)
        let task = session.dataTask(with: request as URLRequest) { (data,response,error) -> Void in
            if let receivedData = data{
                if response != nil{
                   completion(receivedData,nil,response!)
                }else{
                    completion(receivedData,nil,nil)
                }
            }else if let errorMessage = error{
                completion(nil,errorMessage as AnyObject?,nil)
            }
        }
        task.resume()
    }
    func getTheUrlType() -> String{
        var urlpath = ""
        var urlType = ""
        if Constants.getValueFromUserDefults(for: "org") as? String != nil{
            urlType = Constants.getValueFromUserDefults(for: "org") as! String
            if urlType == "local"{
                urlpath = APPURLS.localbaseURL
            }else if urlType == "localwithport"{
                var portNumber = ""
                portNumber = Constants.getValueFromUserDefults(for: "portnumber") as! String
                urlpath = portNumber
            }else if urlType == "stag"{
                urlpath = APPURLS.stagingbaseURL
            }else if urlType == "prod"{
                urlpath = APPURLS.productionbaseURL
            }else{
                urlpath = APPURLS.localbaseURL
            }
            return urlpath
        }else{
           urlpath = APPURLS.localbaseURL
        }
        return urlpath
    }
    
    func requestforImageUploading(service:String,method:String,token:String,body:String,productBody:NSData?,completion:@escaping (_ data:Data?,_ error:AnyObject?,_ response : URLResponse?) -> ()){
        
        APPURLS.baseURL = self.getTheUrlType()
        print("APPURLS.baseURL :: ",APPURLS.baseURL)
        
        let urlpath:String = APPURLS.baseURL + APPURLS.versionNumber + service
        let url:NSURL = NSURL(string:urlpath)!
        //print("URL:\(url)")
        let request = NSMutableURLRequest(url: url as URL)
        request.httpMethod = method
        if token != ""{
            request.setValue("\(token)", forHTTPHeaderField: "Authorization")
        }
        if productBody == NSData(){
            if body != ""{
                let bodydata = body.data(using: String.Encoding.utf8)
                request.httpBody = bodydata
            }
        }else{
            request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            if productBody != nil{
                request.httpBody = productBody! as Data
            }
        }
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        let task = session.dataTask(with: request as URLRequest) { (data,response,error) -> Void in
            if let receivedData = data{
                //  completion(data,resultDic,nil)
                if response != nil{
//                    if let httpResponse = response as? HTTPURLResponse{
//                        print("httpResponse status code \(httpResponse.statusCode)")
//                    }
                    completion(receivedData,nil,response!)
                }else{
                    completion(receivedData,nil,nil)
                }
            }else if let errorMessage = error{
                completion(nil,errorMessage as AnyObject?,nil)
            }
        }
        task.resume()
    }
    /*func requestforAPI1(service:String,method:String,token:String,body:String,productBody:NSData?,completion:@escaping (_ data:Data?,_ error:AnyObject?,_ response : URLResponse) -> ()){
        
        let urlpath:String = APPURLS.baseURL + APPURLS.versionNumber + service
        let url:NSURL = NSURL(string:urlpath)!
        print("URL:\(url)")
        let request = NSMutableURLRequest(url: url as URL)
        request.httpMethod = method
        if token != ""{
            request.setValue("\(token)", forHTTPHeaderField: "Authorization")
        }
        if productBody == NSData(){
            if body != ""{
                let bodydata = body.data(using: String.Encoding.utf8)
                request.httpBody = bodydata
            }
        }else{
            request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            if productBody != nil{
                request.httpBody = productBody! as Data
            }
        }
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 30
        let session = URLSession(configuration: config)
        let task = session.dataTask(with: request as URLRequest) { (data, response, error) -> Void in
            if let receivedData = data{
                completion(receivedData,nil,response!)
            }else if let errorMessage = error{
                print("error messges for response",errorMessage)
                completion(nil,errorMessage as AnyObject?,response!)
            }
        }
        task.resume()
    }*/
    func requestGetApiMethod(completion:@escaping(_ responseData:NSData? ,_ error:Any)->()){
            var session:URLSession!
            var token = String()
            var sessionToken = ""
            token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            sessionToken = "Bearer" + " " + token
            let urlPath: String = APPURLS.baseURL + APPURLS.getParcelTypeURL
            let url: NSURL = NSURL(string: urlPath)!
          //  print("URL:\(url)")
            let request = NSMutableURLRequest(url: url as URL)
            request.httpMethod = "GET"
            request.setValue("\(sessionToken)", forHTTPHeaderField: "Authorization")
            request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            let config = URLSessionConfiguration.ephemeral
            session = URLSession(configuration: config)
            let task = session.dataTask(with: request as URLRequest) { (data, response, error) -> Void in
               // print(response ?? AnyObject.self)
                if let receivedData = data{
                  //  print("RESULt",receivedData)
                    completion(receivedData as NSData, error ?? (Any).self)
                }else if let errorMessage = error{
                    completion(data as NSData?, error ?? (Any).self)
                   // print(errorMessage.localizedDescription)
                }
                session.invalidateAndCancel()
            }
            task.resume()
    }
    func imageUpload(service:String,email:String,imagedata:Data,completion:@escaping (_ result:NSDictionary?,_ error:AnyObject?) -> ()){
        let boundaryConstant  = "----------V2y2HFg03eptjbaKO0j1"
        let params = NSMutableDictionary()
        // params.setObject("file", forKey:"fieldname" as NSCopying)
        // params.setObject("image/jpeg", forKey:"mimetype" as NSCopying)
        // params.setObject("7bit", forKey:"encoding" as NSCopying)
        // params.setObject("biryani.jpg", forKey:"originalname" as NSCopying)
        params.setObject(email, forKey:"email" as NSCopying)
        // params.setObject(imagedata, forKey:"base64" as NSCopying)
        let urlpath:String = "http://192.168.3.41:8881/" + service
        let url:NSURL = NSURL(string:urlpath)!
        //  print("URL:\(url)")
        var request = URLRequest(url: url as URL)
        request.httpShouldHandleCookies = false
        request.httpMethod = "POST"
        request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringLocalCacheData
        let contentType = "multipart/form-data; boundary=\(boundaryConstant)"
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")
        let body = NSMutableData()
        for param in params {
            body.append("--\(boundaryConstant)\r\n" .data(using: String.Encoding.utf8,allowLossyConversion: false)! )
            body.append("Content-Disposition: form-data;name=\"\(param.key)\"\r\n\r\n" .data(using: String.Encoding.utf8,allowLossyConversion: false)!)
            body.append("\(param.value)\r\n" .data(using: String.Encoding.utf8,allowLossyConversion: false)!)
        }
        body.append("--\(boundaryConstant)\r\n".data(using: String.Encoding.utf8,allowLossyConversion: false)!)
        body.append("Content-Disposition: form-data;   name=\"\("file")\" ;  filename=\"biriyani.jpg\"\r\n".data(using: String.Encoding.utf8,allowLossyConversion: false)!)
        body.append("Content-Type: image/jpeg\r\n\r\n".data(using: String.Encoding.utf8,allowLossyConversion: false)!)
        body.append(imagedata)
        body.append("\r\n".data(using: String.Encoding.utf8,allowLossyConversion: false)!)
        body.append("--\(boundaryConstant)--\r\n".data(using: String.Encoding.utf8,allowLossyConversion: false)!)
        request.httpBody  = body as Data
        let postLength = "\(body.length)"
        request.setValue(postLength, forHTTPHeaderField: "Content-Length")
        let config = URLSessionConfiguration.default
        var session:URLSession!
        session = URLSession(configuration: config)
        let task = session.dataTask(with: request) { (data, response, error) -> Void in
            if let receivedData = data{
                do{
                    let resultDic = try JSONSerialization.jsonObject(with: receivedData, options:JSONSerialization.ReadingOptions.allowFragments) as? NSDictionary
                    completion(resultDic!,nil)
                }catch let error{
                    NSLog("\(error)")
                }
            }else if let errorMessage = error{
                completion(nil,errorMessage as AnyObject?)
            }
         session.invalidateAndCancel()
        }
        task.resume()
    }
    
}

