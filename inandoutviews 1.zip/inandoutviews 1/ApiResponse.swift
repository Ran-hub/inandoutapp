//
//  ApiResponse.swift
//  RYTLECUSTOMERAPP
//
//  Created by AMT on 1/23/18.
//  Copyright © 2018 Pavan. All rights reserved.
//

import Foundation
class ApiResponse{
    class func pickupAndReceiverAddressApiResponse(response : [String: Any], pikupAddressArray: NSMutableArray, addressStatus :String){
        
        var name = "";var address_id = "";var mobileNumber = "";var emailId = "";
        var latitude = ""; var longitude = ""; var addressType = ""; var flatnumber = "";var extensionNumber = ""
        if addressStatus == "pickup"{
            let (nameStr,mobileNumberStr,addess_idStr,email) = self.pickupAddressDetails(response: response)
            name = nameStr
            mobileNumber = mobileNumberStr
            address_id = addess_idStr
            emailId = email
            if let addesstype = response["pick_address_fk_address_type_id"] as? Int{
                addressType = String(addesstype)
//                if addesstype == 1{
//                    addressType =  NSLocalizedString("valid_office",comment: "")
//                }else if addesstype == 2{
//                     addressType =  NSLocalizedString("valid_home",comment: "")
//                }
            }
        }else if addressStatus == "receiver"{
            let (nameStr,mobileNumberStr,addess_idStr,email) = self.receiverAddressDetails(response: response)
            name = nameStr
            mobileNumber = mobileNumberStr
            address_id = addess_idStr
            emailId = email
            if let addesstype = response["del_address_fk_address_type_id"] as? Int{
                addressType = String(addesstype)
//                if addesstype == 1{
//                    addressType =  NSLocalizedString("valid_office",comment: "")
//                }else if addesstype == 2{
//                    addressType =  NSLocalizedString("valid_home",comment: "")
//                }
            }
        }
        
        if let flat = response["flat_no"] as? String{
            flatnumber = flat
        }
        if let ext = response["extension"] as? String{
            extensionNumber = ext
        }
        if let lat = response["latitude"] as? String{
            latitude = lat
        }
        if let lat = response["longitude"] as? String{
            longitude = lat
        }
        let(houseno,street1,city,state,country,zipcode,street2,street3) = self.addressStateValues(response: response)
        var address = ""
        address = self.checkingAddressValidationAndReturnAddress(flatNumber :flatnumber, houseno: houseno, street1: street1, street2: street2, street3: street3, city: city, state: state, country: country,zipcode: zipcode)
        let addressData1 = PickupAddressData()
        addressData1.houseno = houseno
        addressData1.street1 = street1
        addressData1.street2 = street2
        addressData1.street3 = street3
        addressData1.city = city
        addressData1.state = state
        addressData1.country = country
        addressData1.name = name
        addressData1.email = emailId
        addressData1.zipcode = zipcode
        addressData1.mobile = mobileNumber
        addressData1.flatNumber = flatnumber
        addressData1.address_id = address_id
        addressData1.fulladdress = address
        addressData1.latitude = latitude
        addressData1.longitude = longitude
        addressData1.addressType = addressType
        addressData1.extensionCode = extensionNumber
        pikupAddressArray.add(addressData1)
    }
    class func pickupAddressDetails(response : [String :Any])->(String,String,String,String){
        var name = ""
        var address_id = ""
        var mobileNumber = ""
        var emailId = ""
        if let pickupName = response["pickup_fullname"] as? String{
            name = pickupName
        }
        if let pickupMobile = response["pickup_mobile_no"] as? String{
            mobileNumber = pickupMobile
        }
        if let pickupaddressid = response["pick_add_id"] as? Int{
            address_id = String(pickupaddressid)
        }
        if let email = response["pickup_email_id"] as? String{
            emailId = email
        }
        return(name,mobileNumber,address_id,emailId)
    }
    class func receiverAddressDetails(response : [String :Any])->(String,String,String,String){
        var name = ""
        var address_id = ""
        var mobileNumber = ""
        var emailId = ""
        if let pickupName = response["reciver_fullname"] as? String{
            name = pickupName
        }
        if let pickupMobile = response["reciver_mobile_no"] as? String{
            mobileNumber = pickupMobile
        }
        if let email = response["reciver_email_id"] as? String{
            emailId = email
        }
        if let receiverAddressid = response["del_add_id"] as? Int{
            address_id = String(receiverAddressid)
        }
        return(name,mobileNumber,address_id,emailId)
    }
    class func addressStateValues(response : [String :Any]) -> (String,String,String,String,String,String,String,String) {
        var houseno = ""
        var street1 = ""
        var city = ""
        var state = ""
        var country = ""
        var zipcode = ""
        var street2 = ""
        var street3 = ""
        if let house = response["house_no"] as? String{
            houseno = house
        }
        if let Street1 = response["street1"] as? String{
            street1 = Street1
        }
        if let City = response["city"] as? String{
            city = City
        }
        if let State = response["state"] as? String{
            state = State
        }
        if let Country = response["country"] as? String{
            country = Country
        }
        if let pickupPincode = response["zip_code"] as? String{
            zipcode = pickupPincode
        }
        let newstreet2 = self.checkForNull(value: response["street2"] as AnyObject)
        if newstreet2  == ""{
            street2 = ""
        }else{
            street2 = newstreet2
        }
        let newstreet3 = self.checkForNull(value: response["street3"] as AnyObject)
        if newstreet3  == ""{
            street3 = ""
        }else{
            street3 = newstreet3
        }
        return (houseno,street1,city,state,country,zipcode,street2,street3)
    }
    class func pickupAddressStateValues(response : [String :Any]) -> (String,String,String,String,String,String,String,String) {
        
        var houseno = ""; var street1 = ""; var city = ""; var state = ""; var country = "";
        var zipcode = ""; var street2 = ""; var street3 = "";
        if let house = response["pickup_house_no"] as? String{
            houseno = house
        }
        if let Street1 = response["pickup_street1"] as? String{
            street1 = Street1
        }
        if let City = response["pickup_city"] as? String{
            city = City
        }
        if let State = response["pickup_state"] as? String{
            state = State
        }
        if let Country = response["pickup_country"] as? String{
            country = Country
        }
        if let pickupPincode = response["pickup_zip_code"] as? String{
            zipcode = pickupPincode
        }
        let newstreet2 = self.checkForNull(value: response["pickup_street2"] as AnyObject)
        if newstreet2  == ""{
            street2 = ""
        }else{
            street2 = newstreet2
        }
        let newstreet3 = self.checkForNull(value: response["pickup_street3"] as AnyObject)
        if newstreet3  == ""{
            street3 = ""
        }else{
            street3 = newstreet3
        }
        return (houseno,street1,city,state,country,zipcode,street2,street3)
    }
    class func parcelSizes(responseDic: [String : Any], parcelSizesArray : NSMutableArray){
        
        if let length = responseDic["length"] as? String{
            parcelSizesArray.add(length)
        }
        if let width = responseDic["width"] as? String{
            parcelSizesArray.add(width)
        }
        if let heigth = responseDic["heigth"] as? String{
            parcelSizesArray.add(heigth)
        }
        if let weight = responseDic["weight"] as? String{
            parcelSizesArray.add(weight)
        }
    }
    class func checkingAddressValidationAndReturnAddress(flatNumber : String, houseno: String, street1: String, street2: String, street3 : String, city: String, state: String, country: String ,zipcode :String) -> String{
        
        var fulladdress = ""
        if flatNumber.count == 0{
           // fulladdress += flatNumber
        }else{
            fulladdress += flatNumber + ", "
        }
        if houseno.count != 0{
            fulladdress += houseno
        }
        if street1.count != 0{
            fulladdress += ", " + street1
        }
        if street2.count != 0{
            fulladdress += ", "  + street2
        }
        if street3.count != 0{
            fulladdress += ", " + street3
        }
        if city.count != 0{
            fulladdress += ", " + city
        }
        if state.count != 0{
            fulladdress += ", " + state
        }
        if country.count != 0{
            fulladdress += ", " + country
        }
        return fulladdress
    }
    class func checkForNull(value:AnyObject) -> String{
        if(value as! NSObject == NSNull() || value as! String == ""){
            return ""
        }else{
            return value as! String
        }
    }
}
