//
//  CreateAccountViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 25/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import Firebase

struct Country{
    var code: String?
    var name: String?
    var phoneCode: String?
    init(code: String?, name: String?, phoneCode: String?) {
        self.code = code
        self.name = name
        self.phoneCode = phoneCode
    }
}
protocol RegisterProtocol {
    func loginMethodApi(username: String,password : String)
}
class SignupVC: UIViewController,UITextFieldDelegate,countryCodeProtocol{
    @IBOutlet weak var textFieldTC: NSLayoutConstraint!
    @IBOutlet weak var countryButton: UIButton!
    @IBOutlet weak var firstnameTxt: UITextField!
    @IBOutlet weak var lastnameTxt: UITextField!
    @IBOutlet weak var mobileNumberTxt: UITextField!
    @IBOutlet weak var countryCodeTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var headinglabel: UILabel!
    @IBOutlet weak var userNameTxt: UITextField!
    @IBOutlet weak var passwordTxt: UITextField!
    @IBOutlet weak var confirmPasswordTxt: UITextField!
    @IBOutlet weak var btnTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet var containerView: UIView!
    @IBOutlet var countrycodeView: UIView!
    @IBOutlet var bgImg: UIImageView!
    @IBOutlet var headerViewObj: UIView!
    @IBOutlet var scrollViewObj: UIScrollView!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    var delegate : RegisterProtocol?
    var toolbar : UIToolbar = UIToolbar()
    var datePicker = UIDatePicker()
    var isSearching = false
    var activeField: UITextField?
    var firstname = ""
    var secondName = ""
    var countries = [Country]()
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.isHidden = true
        self.initialSetUp()
        self.intialConstraintsSetup()
        self.countryCodeSetup()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func countryCodeSetup(){
        countries = countryNamesByCode()
        if let countryCode = (Locale.current as NSLocale).object(forKey: .countryCode) as? String {
            for country in countries{
                if countryCode == country.code{
                    self.countryCodeTxt.text = country.phoneCode
                }
            }
        }
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func sendCountryCode(code: String) {
        self.countryCodeTxt.text = code
    }
    func countryNamesByCode() -> [Country] {
        var countries = [Country]()
        do{
            if let file = Bundle.main.url(forResource: "countryCodes", withExtension: "json") {
                let data = try Data(contentsOf: file)
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                if let object = json as? [String: Any] {
                    // json is a dictionary
                    // print(object)
                } else if let object = json as? [Any] {
                    // json is an array
                    for jsonObject in object {
                        guard let countryObj = jsonObject as? NSDictionary else {
                            return countries
                        }
                        guard let code = countryObj["code"] as? String, let phoneCode = countryObj["dial_code"] as? String, let name = countryObj["name"] as? String else {
                            return countries
                        }
                        let country = Country(code: code, name: name, phoneCode: phoneCode)
                        countries.append(country)
                    }
                    // print(object)
                } else {
                    // print("JSON is invalid")
                }
            } else {
                print("no file")
            }
        }
        catch {
            print(error.localizedDescription)
        }
        return countries
    }
    
    func initialSetUp(){
        self.firstnameTxt.placeholder = NSLocalizedString("txt_firstname", comment: "")
        self.firstnameTxt.font = AppFont.regularTextFont
        self.firstnameTxt.backgroundColor = AppColors.whiteColorRGB
        self.lastnameTxt.placeholder = NSLocalizedString("txt_lastname", comment: "")
        self.lastnameTxt.font = AppFont.regularTextFont
        self.emailTxt.placeholder = NSLocalizedString("txt_eamil", comment: "")
        self.emailTxt.font = AppFont.regularTextFont
        self.mobileNumberTxt.placeholder = NSLocalizedString("txt_mobileno", comment: "")
        self.mobileNumberTxt.font = AppFont.regularTextFont
        self.passwordTxt.placeholder = NSLocalizedString("txt_password", comment: "")
        self.passwordTxt.font = AppFont.regularTextFont
        self.userNameTxt.placeholder = NSLocalizedString("txt_username", comment: "")
        self.userNameTxt.font = AppFont.regularTextFont
        self.confirmPasswordTxt.placeholder = NSLocalizedString("txt_confirmpassword", comment: "")
        self.confirmPasswordTxt.font = AppFont.regularTextFont
        headinglabel.text = NSLocalizedString("register", comment: "")
        headinglabel.font = AppFont.boldTextFont
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.nextBtn.setTitle(NSLocalizedString("register", comment: ""), for: .normal)
        self.nextBtn.titleLabel?.font = AppFont.boldTextFont
        self.nextBtn.backgroundColor = AppColors.greenColorRGB
        self.nextBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.nextBtn.titleLabel?.font = AppFont.boldTextFont
        self.registerForKeyboardNotifications()
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        self.bgImg.isUserInteractionEnabled = true
        self.bgImg.addGestureRecognizer(tapGestureRecognizer)
        self.textFieldTC.constant = self.view.frame.size.height/20
        self.scrollViewObj.isScrollEnabled = true
        
        if appdelegate.IS_IPHONE5{
            self.scrollViewObj.isScrollEnabled = true
            self.btnTopConstraint.constant = 10
            self.textFieldTC.constant = 20
        }else{
            self.scrollViewObj.isScrollEnabled = true
            self.btnTopConstraint.constant = 50
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear (animated)
        self.deregisterFromKeyboardNotifications()
    }
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        self.firstnameTxt.resignFirstResponder()
        self.lastnameTxt.resignFirstResponder()
        self.mobileNumberTxt.resignFirstResponder()
        self.emailTxt.resignFirstResponder()
        self.passwordTxt.resignFirstResponder()
        self.confirmPasswordTxt.resignFirstResponder()
        self.countryCodeTxt.resignFirstResponder()
        //self.organizationTxt.resignFirstResponder()
    }
    func dismissTextFieldKeyboard(){
        self.firstnameTxt.resignFirstResponder()
        self.lastnameTxt.resignFirstResponder()
        self.mobileNumberTxt.resignFirstResponder()
        self.emailTxt.resignFirstResponder()
        self.passwordTxt.resignFirstResponder()
        self.confirmPasswordTxt.resignFirstResponder()
    }
   
    @IBAction func btnsTapped(_ sender : UIButton){
        let btn = sender as UIButton
        if btn.tag == 10{
            self.dismiss(animated: true, completion: nil)
        }else if btn.tag == 20{
            self.dismissTextFieldKeyboard()
            self.navigateToSearchCountryCode()
        }else if btn.tag == 60{
            self.registerMethod()
        }
    }
    func navigateToSearchCountryCode(){
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let countryCode = storyBoard.instantiateViewController(withIdentifier: "SearchCountryCodeVC") as! SearchCountryCodeVC
        countryCode.delegate = self
        self.present(countryCode, animated: true, completion: nil)
    }
    func registerMethod(){
        Analytics.logEvent("SignupVC_RegistrationButtonTapped", parameters: nil)
        self.dismissTextFieldKeyboard()
        if self.ineternetAlert() == false{
            return
        }
        if firstnameTxt.text?.trimmingCharacters(in: .whitespaces).count == 0 {
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_firstname",comment: ""), completion: {(result) in
                self.firstnameTxt.becomeFirstResponder()
            })
            return
        }else if lastnameTxt.text?.trimmingCharacters(in: .whitespaces).count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_lastname",comment: ""), completion: {(result) in
                self.lastnameTxt.becomeFirstResponder()
            })
            return
        }else if countryCodeTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("val_countrycode",comment: ""), completion: {(result) in
            })
            return
        }else if mobileNumberTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_phno",comment: ""), completion: {(result) in
                self.mobileNumberTxt.becomeFirstResponder()
            })
            return
        }/*else if Constants().validatePhoneNumber(value:self.mobileNumberTxt.text!) == false{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_mobileno1",comment: ""), completion: {(result) in
                self.mobileNumberTxt.becomeFirstResponder()
            })
            return
        }*/else if emailTxt.text?.trimmingCharacters(in: .whitespaces).count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_email",comment: ""), completion: {(result) in
                self.emailTxt.becomeFirstResponder()
            })
            return
        }else if Constants().isValidEmail(emailTxt.text!) == false{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_email1",comment: ""), completion: {(result) in
                self.emailTxt.becomeFirstResponder()
            })
        }else if userNameTxt.text?.trimmingCharacters(in: .whitespaces).count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_username",comment: ""), completion: {(result) in
                self.userNameTxt.becomeFirstResponder()
            })
            return
        }else if passwordTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_password",comment: ""), completion: {(result) in
                self.passwordTxt.becomeFirstResponder()
            })
            return
        }else if (self.passwordTxt.text?.count)! < 8 || (self.passwordTxt.text?.count)! > 20{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE", comment: ""), messageStr: NSLocalizedString("valid_passworddigits", comment: "") , completion: {(result) in
                self.passwordTxt.becomeFirstResponder()
            })
        } else if confirmPasswordTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_invalidpwd",comment: ""), completion: {(result) in
                self.confirmPasswordTxt.becomeFirstResponder()
            })
            return
        }else if (self.confirmPasswordTxt.text?.count)! < 8 || (self.confirmPasswordTxt.text?.count)! > 20{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE", comment: ""), messageStr: NSLocalizedString("valid_passworddigits", comment: "") , completion: {(result) in
                self.confirmPasswordTxt.becomeFirstResponder()
            })
        }else if self.passwordTxt.text != self.confirmPasswordTxt.text{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_invalidpwd",comment: ""), completion: {(result) in
                self.confirmPasswordTxt.becomeFirstResponder()
            })
        }else{
            if UserDefaults.standard.value(forKey: "customerOrgid") as? String == nil{
                self.orgnaizationAPi(completion:{(result) in
                    DispatchQueue.main.async {
                        self.registrationApi(orgId: result)
                    }
                })
            }else{
                var orgId = ""
                orgId = Constants.getValueFromUserDefults(for:"customerOrgid") as! String
                self.registrationApi(orgId: orgId)
            }
        }
    }
    func registrationApi(orgId : String){
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        var cust_id = ""
        cust_id = "1"
        var mobilenum = ""
        mobilenum = self.countryCodeTxt.text! + " " +  self.mobileNumberTxt.text!
        bodyReq = ["first_name":self.firstnameTxt.text!,
                   "last_name":self.lastnameTxt.text!,
                   "email":self.emailTxt.text!,
                   "alt_email":"",
                   "mobile":mobilenum,
                   "alt_mobile":"",
                   "status_id":"1",
                   "customertype_id":cust_id,
                   "username":self.userNameTxt.text!,
                   "password":passwordTxt.text!,"org_id":orgId]
      //  print("bodyReq",bodyReq)
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.registrationURL , method: "POST", token: "", body: "", productBody: bodyData as NSData) { (data, error,response) in
               
                if let httpResponse = response as? HTTPURLResponse{
                  //  print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("ver_userregistersuccess",comment: ""), completion: {(result) in
                                self.loginApiMethod()
                            })
                        }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Register_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Register_506", controller: self)
                        }
                    case 507:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Register_507", controller: self)
                        }
                    case 508:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Register_508", controller: self)
                        }
                        break
                    default:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                    }
                }
            }
        }
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    func loginApiMethod() {
        IJProgressView.shared.showProgressView(view)
        var orgId = ""
        orgId = Constants.getValueFromUserDefults(for:"customerOrgid") as! String
        var bodyReq = [String:String]()
        bodyReq = ["username":userNameTxt.text!,"password":passwordTxt.text!,"org_id":orgId]
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.loginURL , method: "POST", token: "", body: "", productBody: bodyData as NSData) { (data, error,response) in
                if let httpResponse = response as? HTTPURLResponse{
                  //  print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        if let receivedData = data{
                            do{
                                let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    self.responseApi(response: resultDic as! [String : Any])
                                }
                            }catch{
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                }
                            }
                        }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Login_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Login_506", controller: self)
                        }
                        break
                    default:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                    }
                }
            }
        }
    }
    func responseApi(response : [String : Any]){
      //  print("Result",response)
        if let status = response["status"] as? Bool {
            if status == true{
                if let authentication = response["token"] as? String{
                    IJProgressView.shared.hideProgressView();
                    Constants.setValueInUserDefaults(objValue:authentication , for:"usertoken")
                    let rider_details :NSDictionary  = (response["customer_details"] as? NSDictionary)!
                    let riderNum = rider_details.object(forKey: "customer_id") as! Int
                    let riderStr = String(riderNum)
                    Constants.setValueInUserDefaults(objValue:riderStr , for:"customer_id")
                    Constants.setValueInUserDefaults(objValue:(rider_details.object(forKey: "username") as! NSString) as String , for:"username")
                    if let firstName = rider_details.object(forKey:"firstname") as? String{
                        self.firstname = firstName.capitalizedFirst()
                    }
                    var profileImgURl = ""
                    if let imageURL = rider_details["image"] as? String{
                        profileImgURl = imageURL
                    }
                    Constants.setValueInUserDefaults(objValue: profileImgURl , for:"profileImgLink")
                    if let lastName = rider_details.object(forKey: "lastname") as? String{
                        self.secondName = lastName.capitalizedFirst()
                    }
                    let finalName = self.firstname + " " + self.secondName
                    Constants.setValueInUserDefaults(objValue:finalName , for:"finalname")
                    self.deviceTokanApi()
                    self.appdelegate.sidemenucount = 0
                    let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                    let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
                    self.present(nextViewController, animated: true, completion: nil)
                }
            }
        }
    }
    func deviceTokanApi(){
        DispatchQueue.global().async {
            if UserDefaults.standard.value(forKey: "devicetoken") as? String == nil{
                return
            }else{
                var customerId  = ""
                var deviceToken = ""
                deviceToken = UserDefaults.standard.value(forKey: "devicetoken") as! String
                customerId = UserDefaults.standard.value(forKey: "customer_id") as! String
                var bodyReq = [String:String]()
                bodyReq = ["device_token":deviceToken,"rider_id": "" ,"device_type":"iphone","customer_id":customerId,"user_type":"customer"]
                if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                    let token = UserDefaults.standard.value(forKey: "usertoken") as! String
                    let sessionStr = "Bearer " + token
                    APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.deviceTypeURL , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                        if let httpResponse = response as? HTTPURLResponse{
                           // print("httpResponse status code \(httpResponse.statusCode)")
                            switch(httpResponse.statusCode){
                            case 200:
                                Constants.setValueInUserDefaults(objValue:deviceToken , for:"devicetoken")
                                break
                            default:break
                            }
                        }
                    }
                }
            }
        }
    }
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    deinit{
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        self.scrollViewObj.isScrollEnabled = true
        var info = notification.userInfo!
        var keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        if keyboardSize?.height == 0{
            keyboardSize?.height = 258
        }
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: keyboardSize!.height, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollViewObj.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
    }
    @objc func keyboardWillBeHidden(notification: NSNotification){
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        self.view.endEditing(true)
        self.scrollViewObj.isScrollEnabled = true
        // self.scrollViewObj.contentSize = CGSize(width: self.scrollViewObj.frame.width, height: self.containerView.frame.origin.y+self.containerView.frame.size.height - 160);
    }
    func textFieldDidBeginEditing(_ textField: UITextField){
        
        if textField == self.firstnameTxt{
            self.firstnameTxt.returnKeyType = .next
        }else if textField == self.lastnameTxt{
            self.lastnameTxt.returnKeyType = .next
        }else if textField == self.mobileNumberTxt{
            if countryCodeTxt.text?.count == 0{
                self.displayAlert(message: NSLocalizedString("val_countrycode", comment: ""))
            }else{
                self.mobileNumberTxt.keyboardType = .numberPad
                self.addBarBtnToKeyboard(textfield: self.mobileNumberTxt)
            }
        }else if textField == self.lastnameTxt{
            
        }else if textField == self.emailTxt{
            self.emailTxt.keyboardType = .emailAddress
            self.emailTxt.returnKeyType = .next
        }else if textField == self.userNameTxt{
            self.userNameTxt.returnKeyType = .next
        }else if textField == self.passwordTxt{
            self.passwordTxt.returnKeyType = .next
        }else if textField == self.confirmPasswordTxt{
            self.confirmPasswordTxt.returnKeyType = .done
        }
        activeField = textField
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == self.passwordTxt || textField == self.confirmPasswordTxt{
            if string == " "{
                return false
            }
            else{
                return true
            }
        }
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField){
        if textField == self.firstnameTxt{
            if self.firstnameTxt.text?.count == 0 || self.firstnameTxt.text == ""{
            }else{
                self.firstnameTxt.text =  self.firstnameTxt.text!.capitalizedFirst()
            }
        }
        if textField == self.lastnameTxt{
            if self.lastnameTxt.text?.count == 0 || self.lastnameTxt.text == ""{
            }else{
                self.lastnameTxt.text =  self.lastnameTxt.text!.capitalizedFirst()
            }
        }
        activeField = nil
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        switch textField{
        case self.firstnameTxt:
            self.lastnameTxt.becomeFirstResponder()
            break
        case self.lastnameTxt:
            self.lastnameTxt.resignFirstResponder()
            break
        case self.emailTxt:
            self.userNameTxt.becomeFirstResponder()
            break
        case self.userNameTxt:
            self.passwordTxt.becomeFirstResponder()
            break
        case self.passwordTxt:
            self.confirmPasswordTxt.becomeFirstResponder()
            break
        case self.confirmPasswordTxt:
            textField.resignFirstResponder()
            break
        default:
            textField.resignFirstResponder()
        }
        return true
    }
    func addBarBtnToKeyboard(textfield : UITextField){
        self.mobileNumberTxt.keyboardType = .numberPad
        let keyPadToolBar = UIToolbar()
        keyPadToolBar.barStyle = UIBarStyle.blackTranslucent
        keyPadToolBar.barTintColor = AppColors.greenColorRGB
        keyPadToolBar.sizeToFit()
        let DoneButton = UIBarButtonItem(title: "Next", style: UIBarButtonItem.Style.done, target: self, action: #selector(SignupVC.dismissKeypad))
        DoneButton.tintColor = AppColors.whiteColorRGB
        keyPadToolBar.setItems([DoneButton], animated: true)
        textfield.inputAccessoryView = keyPadToolBar
    }
    @objc func dismissKeypad(){
        self.mobileNumberTxt.resignFirstResponder()
        emailTxt.becomeFirstResponder()
    }
}

