//
//  BoxContentViewController.swift
//  RYTLE
//
//  Created by Admin on 31/07/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class ParcelsHistoryVC: UIViewController,UITableViewDataSource,UITableViewDelegate{
    
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet var parcelHistoryTable: UITableView!
    @IBOutlet var cancelBtn: UIButton!
    @IBOutlet var titleLbl: UILabel!
    @IBOutlet weak var headerView : UIView!
    @IBOutlet weak var titleLblCC: NSLayoutConstraint!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    var refreshControl = UIRefreshControl()
    var parcelListArray = NSMutableArray()
    var countArray = NSMutableArray()
    var riderIdArray = NSMutableArray()
    var rowArray = NSMutableArray()
    var pushNotificationStr = ""
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetup()
        self.intialConstraintsSetup()
        self.tableviewSetup()
        self.addRefreshVCtoTableView()
        self.getAllParcelsapi()
    }
  
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    
    func initialSetup(){
        self.navigationController?.navigationBar.isHidden = true
        self.statusLbl.text = NSLocalizedString("ver_noparcelfound", comment: "")
        self.statusLbl.numberOfLines = 2
        self.titleLbl.text = NSLocalizedString("lbl_parcelhistory1", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        self.titleLbl.textColor = AppColors.whiteColorRGB
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        appdelegate.parcelHistoryStatus = "Yes"
        NotificationCenter.default.addObserver(self, selector: #selector(ParcelTrackingVC.notifcationMethod), name: NSNotification.Name(rawValue: "ParcelHistoryNotifiation"), object: nil)
        self.languageValidationForGermany()
    }
    
    func tableviewSetup()
    {
        self.parcelHistoryTable.register(UINib(nibName: "ParcelHistoryTableViewCell", bundle: nil), forCellReuseIdentifier: "ParcelHistoryTableViewCell")
        self.parcelHistoryTable.rowHeight = UITableViewAutomaticDimension
        self.parcelHistoryTable.estimatedRowHeight = 185;
        self.statusLbl.text = NSLocalizedString("ver_noparcelfound", comment: "")
    }
    func addRefreshVCtoTableView()
    {
        if #available(iOS 10.0, *) {
            parcelHistoryTable.refreshControl = refreshControl
        } else {
            // Fallback on earlier versions
            parcelHistoryTable.addSubview(refreshControl)
        }
        refreshControl.tintColor = AppColors.greenColorRGB
        refreshControl.attributedTitle = NSAttributedString(string: "Loading...")
        refreshControl.addTarget(self, action: #selector(PickupAddressViewController.refreshData), for: .valueChanged)
    }
    
    func languageValidationForGermany(){
        let languageCode = Constants.getValueFromUserDefults(for: "languageCode") as! String
        if languageCode == "Yes"
        {
            self.languageValidationForGermany(headerView: self.headerView, cancelBtn: self.cancelBtn, labelConstraints: self.titleLblCC, titleLbl: self.titleLbl)
        }
    }
    override func viewWillDisappear(_ animated: Bool){
        appdelegate.parcelHistoryStatus = ""
        appdelegate.parcelHistoryParcelId = ""
        self.pushNotificationStr = ""
        NotificationCenter.default.removeObserver(self, name:NSNotification.Name(rawValue: "ParcelHistoryNotifiation") , object: nil)
    }
    
    func notifcationMethod()
    {
        self.notificationRefreshDataApi()
        NotificationCenter.default.addObserver(self, selector: #selector(ParcelTrackingVC.notifcationMethod), name: NSNotification.Name(rawValue: "ParcelHistoryNotifiation"), object: nil)
        
    }
    
    func refreshData()
    {
        self.getAllParcelsapi()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.parcelListArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ParcelHistoryTableViewCell") as! ParcelHistoryTableViewCell
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
        cell.api_feedbckLbl.layer.masksToBounds = true
        cell.api_feedbckLbl.layer.cornerRadius = cell.api_feedbckLbl.frame.size.height/2
        cell.api_feedbckLbl.layer.borderWidth = 1
        cell.api_feedbckLbl.layer.borderColor = AppColors.greenColorRGB.cgColor
        cell.api_feedbckLbl.textColor = AppColors.greenColorRGB
        
        cell.parcelID.text = NSLocalizedString("lbl_parcelid", comment: "")
        cell.timeofBookingLbl.text = NSLocalizedString("lbl_timeofbooking", comment: "")
        cell.modeofPaymentLbl.text = NSLocalizedString("lbl_modeofdelivery", comment: "")
        cell.feedbckLbl.text = NSLocalizedString("lbl_feedback", comment: "")
        cell.riderNameLbl.text = NSLocalizedString("lbl_riderassigned", comment: "")
        
        let parcel = self.parcelListArray.object(at: indexPath.row) as! parcelHistoryDetails
        cell.api_feedbckLbl.text = parcel.status
        
        if parcel.status == "Waiting for pickup"
        {
            cell.api_feedbckLbl.text = NSLocalizedString("lbl_waitingforpickup", comment: "")
        }
        else if parcel.status == "Out for Delivery"
        {
            cell.api_feedbckLbl.text = NSLocalizedString("lbl_outfordelivery", comment: "")
        }
        else if parcel.status == "Delivered"
        {
            cell.api_feedbckLbl.text = NSLocalizedString("lbl_parceldelivered", comment: "")
        }
        else if parcel.status == "Not Picked Up"
        {
            cell.api_feedbckLbl.text = NSLocalizedString("lbl_notpickedup", comment: "")
            
        }else if parcel.status == "Not Delivered"
        {
            cell.api_feedbckLbl.text = NSLocalizedString("lbl_notdelivered", comment: "")
        }
        cell.api_parcelID.text = parcel.parcel_id
        cell.api_modeofPaymentLbl.text = parcel.deliveryMode
        cell.api_timeofBookingLbl.text = parcel.bookingtime
        cell.api_riderNameLbl.text = parcel.riderFirstName + " " + parcel.riderLastName
        
        let riderID = String(parcel.riderId)
        
        if riderID != "0"
        {
            // print("with rider indexpath ::: ",indexPath.row)
            cell.containerHeightConstraints.constant = 165
            cell.riderHeightConstraint.constant = 25
            cell.riderTopConstraint.constant = 5
            cell.api_riderHeightConstraint.constant = 25
            cell.api_riderTopConstraint.constant = 5
        }
        else
        {
            //print("without rider indexpath ::: ",indexPath.row)
            cell.containerHeightConstraints.constant = 135
            cell.riderHeightConstraint.constant = 0
            cell.riderTopConstraint.constant = 0
            cell.api_riderHeightConstraint.constant = 0
            cell.api_riderTopConstraint.constant = 0
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        let heightStr = self.countArray.object(at: indexPath.row) as! String
        //  let parcel = self.parcelListArray.object(at: indexPath.row) as! parcelHistoryDetails
        let myFloat = (heightStr as NSString).floatValue
        return  CGFloat(myFloat)
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let parcel = self.parcelListArray.object(at: indexPath.row) as! parcelHistoryDetails
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let PDVC = storyBoard.instantiateViewController(withIdentifier: "ParcelDetailVC") as! ParcelDetailVC
        PDVC.parcelId = parcel.parcel_id
        self.present(PDVC, animated:true, completion: nil)
    }
    @IBAction func cancelBtnTapped(_ sender : UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    func notificationRefreshDataApi()
    {
        //  print("parcelid ",appdelegate.parcelHistoryParcelId)
        
        if self.ineternetAlert() == false
        {
            return
        }
        else
        {
            DispatchQueue.global().async
                {
                    if Constants.getValueFromUserDefults(for:"customer_id") as? String == nil{
                    }
                    else
                    {
                        var bodyReq = [String:String]()
                        var cust_id = String()
                        cust_id = Constants.getValueFromUserDefults(for:"customer_id") as! String
                        bodyReq = ["customer_id":cust_id]
                        var token = String()
                        var reultanttoken = ""
                        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
                            token = Constants.getValueFromUserDefults(for: "usertoken") as! String
                            reultanttoken = "Bearer" + " " + token
                        }
                        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
                        {
                            APICommnicationManager.sharedInstance.requestforAPI(service:"/Parcel/allParcels" , method: "POST", token:reultanttoken, body: "", productBody: bodyData as NSData) { (result, error) in
                                
                                if let Result = result as? [String:Any]{
                                    // print("Result",Result)
                                    
                                    if let status = Result["status"] as? Bool {
                                        //print("status",status)
                                        if status == true{
                                            DispatchQueue.main.async(execute: { () -> Void in
                                                IJProgressView.shared.hideProgressView()
                                                // self.refreshControl.endRefreshing()
                                                // self.countArray.removeAllObjects()
                                                // self.parcelListArray.removeAllObjects()
                                                let newArray  = Result["Msg"] as? [[String:Any]]
                                                // for array in newArray! {
                                                for (index, array) in (newArray?.enumerated())! {
                                                    
                                                    // print(array.count)
                                                    //  print(index)
                                                    
                                                    var parcel_id = ""
                                                    var bookingtime = ""
                                                    var  delimode = 0
                                                    var deliveryMode = ""
                                                    var str = ""
                                                    var Status = 0
                                                    var parcelstatus = ""
                                                    var riderIdStr = 0
                                                    var riderFirstName = ""
                                                    var riderLastName = ""
                                                    
                                                    if let id = array ["parcel_id"] as?String{
                                                        parcel_id = id
                                                        
                                                        if self.appdelegate.parcelHistoryParcelId == parcel_id
                                                        {
                                                            // print("index :::::: ",index)
                                                        }
                                                    }
                                                    
                                                    if let  time = array["created_datetime"] as? String{
                                                        
                                                        bookingtime = time
                                                        let formatter = DateFormatter()
                                                        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
                                                        let date = formatter.date(from: bookingtime)
                                                        
                                                        let formatter1 = DateFormatter()
                                                        formatter1.dateFormat = "HH:mm dd/MM/yyyy"
                                                        str = formatter1.string(from:date!)
                                                        // print("date",str)
                                                    }
                                                    if let deliverymode = array["parcel_fk_delivery_option_id"] as? Int{
                                                        
                                                        delimode = deliverymode
                                                    }
                                                    if delimode == 1
                                                    {
                                                        deliveryMode = "Express"
                                                    }
                                                    if delimode == 2
                                                    {
                                                        deliveryMode = "Normal"
                                                    }
                                                    
                                                    if let parcelstatus =  array["parcel_fk_status"] as? Int{
                                                        
                                                        Status = parcelstatus
                                                    }
                                                    
                                                    if Status  == 1
                                                    {
                                                        parcelstatus = "Picked Up"
                                                    }
                                                    if Status  == 2
                                                    {
                                                        parcelstatus = "Out for Delivery"
                                                    }
                                                    if Status  == 8
                                                    {
                                                        parcelstatus = "Waiting for pickup"
                                                    }
                                                    if Status  == 11
                                                    {
                                                        parcelstatus = "Delivered"
                                                    }
                                                    if Status == 12
                                                    {
                                                        parcelstatus = "Not Delivered"
                                                    }
                                                    if Status ==  14
                                                    {
                                                        parcelstatus = "Not Picked Up"
                                                    }
                                                    
                                                    if let riderID =  array["rider_id"] as? Int{
                                                        
                                                        riderIdStr = riderID
                                                        self.countArray.add("185")
                                                        self.riderIdArray.add(riderIdStr)
                                                    }
                                                    else
                                                    {
                                                        self.countArray.add("155")
                                                        self.riderIdArray.add("")
                                                    }
                                                    if let riderfirstname = array["firstname"] as? String
                                                    {
                                                        riderFirstName = riderfirstname
                                                    }
                                                    
                                                    if let riderlaststname = array["lastname"] as? String
                                                    {
                                                        riderLastName = riderlaststname
                                                    }
                                                    
                                                    if self.appdelegate.parcelHistoryParcelId == parcel_id
                                                    {
                                                        // print("index :::::: ",index)
                                                        
                                                        let parcelData = parcelHistoryDetails()
                                                        parcelData.parcel_id = parcel_id
                                                        parcelData.bookingtime = str
                                                        parcelData.deliveryMode = deliveryMode
                                                        parcelData.status = parcelstatus
                                                        parcelData.riderId = riderIdStr
                                                        parcelData.riderFirstName = riderFirstName
                                                        parcelData.riderLastName = riderLastName
                                                        self.countArray.replaceObject(at: index, with: "185")
                                                        self.parcelListArray.replaceObject(at: index, with: parcelData)
                                                        let indexPath = NSIndexPath(row: index, section: 0)
                                                        self.parcelHistoryTable.reloadRows(at: [indexPath as IndexPath], with: UITableViewRowAnimation.top)
                                                    }
                                                    
                                                }
                                                
                                                DispatchQueue.main.async(execute: { () -> Void in
                                                    // self.diplayStatus()
                                                })
                                                
                                            })
                                        }
                                        if status == false
                                        {
                                            DispatchQueue.main.async(execute: { () -> Void in
                                                IJProgressView.shared.hideProgressView()
                                                
                                                if Result["error"] as! String == "No Parcel booked from your side"
                                                {
                                                    self.displayAlert(message: NSLocalizedString("ver_noparcelfound", comment:""))
                                                }
                                                else{
                                                    self.displayAlert(message: NSLocalizedString("ver_somethingwrong", comment:""))
                                                }
                                            })
                                        }
                                    }
                                    if Result["code"] as? String == "InvalidCredentials"
                                    {
                                        DispatchQueue.main.async(execute: { () -> Void in
                                            IJProgressView.shared.hideProgressView()
                                            self.tokenExpireAlert()
                                        })
                                    }
                                }
                                else
                                {
                                    DispatchQueue.main.async(execute: { () -> Void in
                                        IJProgressView.shared.hideProgressView()
                                        self.displayAlert(message: NSLocalizedString("ver_somethingwrong", comment:""))
                                    })
                                }
                            }
                        }
                    }
                    
            }
        }
        
    }
    
    func displayAlert(message: String)
    {
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    
    func getAllParcelsapi()
    {
        if self.ineternetAlert() == false
        {
            self.statusLbl.isHidden = false
            self.statusLbl.text = NSLocalizedString("ver_internetavailable_error", comment: "")
            return
        }
        else
        {
            if Constants.getValueFromUserDefults(for:"customer_id") as? String == nil{
            }
            else
            {
                IJProgressView.shared.showProgressView(view)
                var bodyReq = [String:String]()
                var cust_id = String()
                cust_id = Constants.getValueFromUserDefults(for:"customer_id") as! String
                bodyReq = ["customer_id":cust_id]
                var token = String()
                var reultanttoken = ""
                if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
                    token = Constants.getValueFromUserDefults(for: "usertoken") as! String
                    reultanttoken = "Bearer" + " " + token
                }
                if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
                {
                    APICommnicationManager.sharedInstance.requestforAPI(service:"/Parcel/allParcels" , method: "POST", token:reultanttoken, body: "", productBody: bodyData as NSData) { (result, error) in
                        
                        if let Result = result as? [String:Any]{
                            
                            print("Result",Result)
                            if let status = Result["status"] as? Bool {
                                if status == true{
                                    DispatchQueue.main.async(execute: { () -> Void in
                                        IJProgressView.shared.hideProgressView()
                                        self.refreshControl.endRefreshing()
                                        self.countArray.removeAllObjects()
                                        self.parcelListArray.removeAllObjects()
                                        self.statusLbl.isHidden = true
                                        self.parcelHistoryTable.isHidden = false
                                        let newArray  = Result["Msg"] as? [[String:Any]]
                                        for array in newArray! {
                                            
                                            var parcel_id = ""
                                            var bookingtime = ""
                                            var  delimode = 0
                                            var deliveryMode = ""
                                            var str = ""
                                            var Status = 0
                                            var parcelstatus = ""
                                            var riderIdStr = 0
                                            var riderFirstName = ""
                                            var riderLastName = ""
                                            
                                            if let id = array["parcel_id"] as? String{
                                                parcel_id = id
                                                //parcel_id = id
                                            }
                                            
                                            if let  time = array["created_datetime"] as? String{
                                                
                                                bookingtime = time
                                                let formatter = DateFormatter()
                                                formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
                                                let date = formatter.date(from: bookingtime)
                                                
                                                let formatter1 = DateFormatter()
                                                formatter1.dateFormat = "HH:mm dd/MM/yyyy"
                                                str = formatter1.string(from:date!)
                                                //    print("date",str)
                                            }
                                            if let deliverymode = array["parcel_fk_delivery_option_id"] as? Int{
                                                
                                                delimode = deliverymode
                                            }
                                            if delimode == 1
                                            {
                                                deliveryMode = "Express"
                                            }
                                            if delimode == 2
                                            {
                                                deliveryMode = "Normal"
                                            }
                                            
                                            if let parcelstatus =  array["parcel_fk_status"] as? Int{
                                                Status = parcelstatus
                                            }
                                            
                                            if Status  == 1
                                            {
                                                parcelstatus = "Picked Up"
                                            }
                                            if Status  == 2
                                            {
                                                parcelstatus = "Out for Delivery"
                                            }
                                            if Status  == 8
                                            {
                                                parcelstatus = "Waiting for pickup"
                                            }
                                            if Status  == 11
                                            {
                                                parcelstatus = "Delivered"
                                            }
                                            if Status == 12
                                            {
                                                parcelstatus = "Not Delivered"
                                            }
                                            if Status ==  14
                                            {
                                                parcelstatus = "Not Picked Up"
                                            }
                                            
                                            if let riderID =  array["rider_id"] as? Int{
                                                
                                                riderIdStr = riderID
                                                self.countArray.add("185")
                                                self.riderIdArray.add(riderIdStr)
                                            }
                                            else
                                            {
                                                self.countArray.add("155")
                                                self.riderIdArray.add("")
                                            }
                                            if let riderfirstname = array["firstname"] as? String
                                            {
                                                riderFirstName = riderfirstname
                                            }
                                            
                                            if let riderlaststname = array["lastname"] as? String
                                            {
                                                riderLastName = riderlaststname
                                            }
                                            
                                            let parcelData = parcelHistoryDetails()
                                            parcelData.parcel_id = parcel_id
                                            parcelData.bookingtime = str
                                            parcelData.deliveryMode = deliveryMode
                                            parcelData.status = parcelstatus
                                            parcelData.riderId = riderIdStr
                                            parcelData.riderFirstName = riderFirstName
                                            parcelData.riderLastName = riderLastName
                                            self.parcelListArray.add(parcelData)
                                        }
                                        DispatchQueue.main.async(execute: { () -> Void in
                                            self.diplayStatus()
                                        })
                                        
                                    })
                                }
                                else if status == false{
                                    DispatchQueue.main.async(execute: { () -> Void in
                                        IJProgressView.shared.hideProgressView()
                                        self.diplayStatus()
                                        self.refreshControl.endRefreshing()
                                        self.statusLbl.isHidden = false
                                        self.parcelHistoryTable.isHidden = true
                                        self.displayAlert(message: NSLocalizedString("ver_noparcelfound", comment:""))
                                    })
                                }
                            }
                            else
                            {
                                if Result["code"] as? String == "InvalidCredentials"
                                {
                                    DispatchQueue.main.async(execute: { () -> Void in
                                        IJProgressView.shared.hideProgressView()
                                        self.tokenExpireAlert()
                                    })
                                }
                            }
                        }
                        else
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.diplayStatus()
                                self.refreshControl.endRefreshing()
                                self.displayAlert(message: NSLocalizedString("ver_somethingwrong", comment:""))
                                
                            })
                        }
                    }
                }
            }
            
        }
        
    }
    func diplayStatus()
    {
        
        if self.parcelListArray.count == 0
        {
            self.parcelHistoryTable.isHidden = true
            self.statusLbl.isHidden = false
        }
        else
        {
            self.statusLbl.isHidden = true
            self.parcelHistoryTable.isHidden = false
            self.parcelHistoryTable.reloadData()
        }
        
    }
    
}

