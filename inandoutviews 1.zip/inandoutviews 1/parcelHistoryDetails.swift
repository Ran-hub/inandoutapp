//
//  parcelDetails.swift
//  RYTLECUSTOMERAPP
//
//  Created by Shilpashree on 06/09/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class parcelHistoryDetails: NSObject {
    
    var parcel_id = String()
    var bookingtime = String()
    var status = String()
    var deliveryMode = String()
    var riderId = Int()
    var riderFirstName = String()
    var riderLastName = String()
    var riderLiveStatus = String()

}

