//
//  CreateAccountViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 25/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

struct Country
{
    var code: String?
    var name: String?
    var phoneCode: String?
    
    init(code: String?, name: String?, phoneCode: String?) {
        self.code = code
        self.name = name
        self.phoneCode = phoneCode
    }
}

/*protocol headerProtocol{    func BtnTapped(sender:UIButton);}
 var delegate : headerProtocol?*/

protocol RegisterProtocol {
    func loginMethodApi(username: String,password : String)
}
class SignupVC: UIViewController,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate
    
{
    @IBOutlet weak var countryViewBottom: NSLayoutConstraint!
    @IBOutlet weak var textFieldTC: NSLayoutConstraint!
    @IBOutlet weak var countryButton: UIButton!
    @IBOutlet weak var countryView: UIView!
    @IBOutlet weak var firstnameTxt: UITextField!
    @IBOutlet weak var lastnameTxt: UITextField!
    @IBOutlet weak var mobileNumberTxt: UITextField!
    @IBOutlet weak var countryCodeTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var regTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var headinglabel: UILabel!
    @IBOutlet weak var organizationTxt: UITextField!
    @IBOutlet weak var passwordTxt: UITextField!
    @IBOutlet weak var confirmPasswordTxt: UITextField!
    @IBOutlet weak var btnTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet var containerView: UIView!
    @IBOutlet var countrycodeView: UIView!
    @IBOutlet var bgImg: UIImageView!
    @IBOutlet var headerViewObj: UIView!
    @IBOutlet var scrollViewObj: UIScrollView!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    var delegate : RegisterProtocol?
    var toolbar : UIToolbar = UIToolbar()
    var datePicker = UIDatePicker()
    var isSearching = false
    var activeField: UITextField?
    var firstname = ""
    var secondName = ""
    let customerTypeDropDown = DropDown()
    let countryTypeDropDown = DropDown()
    lazy var dropDowns: [DropDown] = {
        return [
            self.customerTypeDropDown,
            self.countryTypeDropDown
        ]
    }()
    var ModalArray = NSMutableArray()
    var countries = [Country]()
    var filteredphonecodeArray = NSMutableArray()
    var filteredcodeArray : NSMutableArray = NSMutableArray()
    var nameArray : NSMutableArray = NSMutableArray()
    var filteredArray:[String] = []
    var countrycodeArray : NSMutableArray = NSMutableArray()
    var phonecodeArray : NSMutableArray = NSMutableArray()
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.isHidden = true
        countryView.isHidden = true
        self.initialSetUp()
        self.intialConstraintsSetup()
        self.countryCodeSetup()
       
    }
   func countryCodeSetup(){
    countries = countryNamesByCode()
    if let countryCode = (Locale.current as NSLocale).object(forKey: .countryCode) as? String {
        for country in countries{
            if countryCode == country.code{
                self.countryCodeTxt.text = country.phoneCode
            }
        }
    }
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func countryNamesByCode() -> [Country] {
        var countries = [Country]()
        do{
            if let file = Bundle.main.url(forResource: "countryCodes", withExtension: "json") {
                let data = try Data(contentsOf: file)
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                if let object = json as? [String: Any] {
                    // json is a dictionary
                    // print(object)
                } else if let object = json as? [Any] {
                    // json is an array
                    for jsonObject in object {
                        guard let countryObj = jsonObject as? NSDictionary else {
                            return countries
                        }
                        guard let code = countryObj["code"] as? String, let phoneCode = countryObj["dial_code"] as? String, let name = countryObj["name"] as? String else {
                            return countries
                        }
                        nameArray.add(name)
                        let country = Country(code: code, name: name, phoneCode: phoneCode)
                        countries.append(country)
                    }
                    // print(object)
                } else {
                    // print("JSON is invalid")
                }
            } else {
                print("no file")
            }
        }
        catch {
            print(error.localizedDescription)
        }
        return countries
    }
    func initialSetUp(){
        searchBar.returnKeyType = .done
        searchBar.delegate = self
        self.regTableView.register(UINib(nibName: "CountryTableViewCell", bundle: nil), forCellReuseIdentifier: "CountryTableViewCell")
        self.firstnameTxt.placeholder = NSLocalizedString("txt_firstname", comment: "")
        self.firstnameTxt.font = AppFont.regularTextFont
        self.firstnameTxt.backgroundColor = AppColors.whiteColorRGB
        self.lastnameTxt.placeholder = NSLocalizedString("txt_lastname", comment: "")
        self.lastnameTxt.font = AppFont.regularTextFont
        self.emailTxt.placeholder = NSLocalizedString("txt_eamil", comment: "")
        self.emailTxt.font = AppFont.regularTextFont
        self.mobileNumberTxt.placeholder = NSLocalizedString("txt_mobileno", comment: "")
        self.mobileNumberTxt.font = AppFont.regularTextFont
        self.passwordTxt.placeholder = NSLocalizedString("txt_password", comment: "")
        self.passwordTxt.font = AppFont.regularTextFont
        self.confirmPasswordTxt.placeholder = NSLocalizedString("txt_confirmpassword", comment: "")
        self.confirmPasswordTxt.font = AppFont.regularTextFont
        headinglabel.text = NSLocalizedString("lbl_createaccount", comment: "")
        headinglabel.font = AppFont.boldTextFont
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.nextBtn.setTitle(NSLocalizedString("lbl_createaccount", comment: ""), for: .normal)
        self.nextBtn.titleLabel?.font = AppFont.boldTextFont
        self.nextBtn.backgroundColor = AppColors.greenColorRGB
        self.nextBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.nextBtn.titleLabel?.font = AppFont.boldTextFont
        self.registerForKeyboardNotifications()
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        self.bgImg.isUserInteractionEnabled = true
        self.bgImg.addGestureRecognizer(tapGestureRecognizer)
        self.textFieldTC.constant = self.view.frame.size.height/20
        if appdelegate.IS_IPHONE5{
            self.scrollViewObj.isScrollEnabled = true
            self.btnTopConstraint.constant = 10
        }
        else{
            self.scrollViewObj.isScrollEnabled = false
            self.btnTopConstraint.constant = 50
        }
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear (animated)
        self.deregisterFromKeyboardNotifications()
    }
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    func dismissSearchKeyboard(){
        searchBar.resignFirstResponder()
    }
    func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        self.firstnameTxt.resignFirstResponder()
        self.lastnameTxt.resignFirstResponder()
        self.mobileNumberTxt.resignFirstResponder()
        self.emailTxt.resignFirstResponder()
        self.passwordTxt.resignFirstResponder()
        self.confirmPasswordTxt.resignFirstResponder()
        self.countryCodeTxt.resignFirstResponder()
        //self.organizationTxt.resignFirstResponder()
    }
    func dismissTextFieldKeyboard(){
        self.firstnameTxt.resignFirstResponder()
        self.lastnameTxt.resignFirstResponder()
        self.mobileNumberTxt.resignFirstResponder()
        self.emailTxt.resignFirstResponder()
        self.passwordTxt.resignFirstResponder()
        self.confirmPasswordTxt.resignFirstResponder()
    }
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar){
        countryViewBottom.constant = 216+20+5 - countryViewBottom.constant
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar){
        searchBar.resignFirstResponder()
        self.searchBar.endEditing(true)
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String){
        if searchBar.text == "" || searchBar.text == nil{
            isSearching = false
            regTableView.reloadData()
        }
        else{
            // isSearching = true
            self.phonecodeArray = [];
            self.countrycodeArray = [];
            self.filteredArray = [];
            let searchPredicate = NSPredicate(format: "SELF beginswith[c] %@",searchBar.text!)
            filteredArray = (nameArray.filtered(using: searchPredicate) as NSMutableCopying) as! [String]
            for index in filteredArray{
                var name = ""
                name = index
                for country in countries{
                    if name == country.name{
                        self.phonecodeArray.add(country.phoneCode!)
                        self.countrycodeArray.add(country.code!)
                    }
                }
            }
            if(filteredArray.count == 0){
                isSearching = false;
            } else {
                isSearching = true;
            }
            self.regTableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isSearching == true{
            return  filteredArray.count
        }else{
            return countries.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CountryTableViewCell", for: indexPath) as! CountryTableViewCell
        if isSearching  == true{
            let countrycode =  "(" + (countrycodeArray[indexPath.row] as? String)! + ")"
            let newcountry = (filteredArray[indexPath.row] as? String)!
                + countrycode
            cell.countryNameLbl.text = newcountry
            cell.countryCodeLbl.text = phonecodeArray[indexPath.row] as? String
        }
        else{
            let country = countries[indexPath.row]
            let countrycode = "(" + country.code! + ")"
            cell.countryNameLbl.text = country.name! + countrycode
            cell.countryCodeLbl.text = country.phoneCode
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        countryViewBottom.constant = 20
        if isSearching == true{
            isSearching = false
            self.searchBar.resignFirstResponder()
            let code = phonecodeArray[indexPath.row] as? String
            self.countryCodeTxt.text = code
            self.countryView.isHidden = true
            self.phonecodeArray = [];
            self.countrycodeArray = [];
            self.filteredArray = [];
        }else{
            isSearching = false
            let country = countries[indexPath.row]
            let code = country.phoneCode
            self.countryCodeTxt.text = code
            self.countryView.isHidden = true
            self.searchBar.resignFirstResponder()
        }
        self.regTableView.reloadData()
    }
    @IBAction func btnsTapped(_ sender : UIButton){
        let btn = sender as UIButton
        if btn.tag == 10{
            self.dismiss(animated: true, completion: nil)
        }else if btn.tag == 20{
            self.dismissTextFieldKeyboard()
            self.isSearching = false
            self.searchBar.text = ""
            self.countryView.isHidden = false
        }else if btn.tag == 60{
            self.registerMethod()
        }
    }
    
    func registerMethod(){
        self.dismissTextFieldKeyboard()
        if firstnameTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_firstname",comment: ""), completion: {(result) in
                self.firstnameTxt.becomeFirstResponder()
            })
            return
        }else if lastnameTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_lastname",comment: ""), completion: {(result) in
                self.lastnameTxt.becomeFirstResponder()
            })
            return
        }else if countryCodeTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("val_countrycode",comment: ""), completion: {(result) in
                //self.mobileNumberTxt.becomeFirstResponder()
            })
            return
        }else if mobileNumberTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_phno",comment: ""), completion: {(result) in
                self.mobileNumberTxt.becomeFirstResponder()
            })
            return
        }else if Constants().validatePhoneNumber(value:self.mobileNumberTxt.text!) == false{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_mobileno1",comment: ""), completion: {(result) in
                self.mobileNumberTxt.becomeFirstResponder()
            })
            return
        }else if emailTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_email",comment: ""), completion: {(result) in
                self.emailTxt.becomeFirstResponder()
            })
            return
        }else if Constants().isValidEmail(emailTxt.text!) == false{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("valid_email1",comment: ""), completion: {(result) in
                self.emailTxt.becomeFirstResponder()
            })
        }else if passwordTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_password",comment: ""), completion: {(result) in
                self.passwordTxt.becomeFirstResponder()
            })
            return
        } else if confirmPasswordTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_cnfpassword",comment: ""), completion: {(result) in
                self.confirmPasswordTxt.becomeFirstResponder()
            })
            return
        }else if (self.passwordTxt.text?.count)! < 8 || (self.passwordTxt.text?.count)! > 20{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE", comment: ""), messageStr: NSLocalizedString("valid_passworddigits", comment: "") , completion: {(result) in
                self.passwordTxt.becomeFirstResponder()
            })
        }else if self.passwordTxt.text != self.confirmPasswordTxt.text{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_invalidpwd",comment: ""), completion: {(result) in
                self.confirmPasswordTxt.becomeFirstResponder()
            })
        }else{
            self.registrationApi()
        }
    }
    
    func registrationApi(){
        if self.ineternetAlert() == false{
            return
        }
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        var cust_id = ""
        cust_id = "1"
        var mobilenum = ""
        mobilenum = self.countryCodeTxt.text! + " " +  self.mobileNumberTxt.text!
        bodyReq = ["first_name":self.firstnameTxt.text!,
                   "last_name":self.lastnameTxt.text!,
                   "email":self.emailTxt.text!,
                   "alt_email":"",
                   "mobile":mobilenum,
                   "alt_mobile":"",
                   "status_id":"1",
                   "customertype_id":cust_id,
                   "username":self.emailTxt.text!,
                   "password":passwordTxt.text!]
        print("bodyReq",bodyReq)
        
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
        {
            APICommnicationManager.sharedInstance.requestforAPI(service:"/User/addCustomerUser" , method: "POST", token: "", body: "", productBody: bodyData as NSData) { (result, error) in
                if let Result = result as? [String:Any]{
                    print("Result",Result)
                    if let status = Result["status"] as? Bool {
                        if status == true{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                Constants.setValueInUserDefaults(objValue: self.countryCodeTxt.text!, for: "countrycode")
                                self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("ver_userregistersuccess", comment: ""), completion: {(result) in
                                    self.loginApiMethod()
                                })
                            })
                        }
                        if status == false{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                if let error = Result["Error"] as? [String:AnyObject]{
                                    if let code = error["code"] as? String{
                                        if code == "ER_DUP_ENTRY"{
                                            self.displayAlert(message: NSLocalizedString("dup_registration", comment: ""))
                                        }
                                    }
                                }
                            })
                        }
                    }
                }
                else
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                        self.displayAlert(message: NSLocalizedString("ver_somethingwrong", comment: ""))
                    })
                }
            }
        }
        
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    func loginApiMethod() {
        if self.ineternetAlert() == false{
            return
        }
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        bodyReq = ["username":emailTxt.text!,"password":passwordTxt.text!]
        // print("bodyReq",bodyReq)
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:"/CustomerAuth/customerLogin" , method: "POST", token: "", body: "", productBody: bodyData as NSData) { (result, error) in
                if let Result = result as? [String:Any]{
                    // print("Result",Result)
                    if let status = Result["status"] as? Bool {
                        if status == true{
                            DispatchQueue.main.async(execute: { () -> Void in
                                if let authentication = Result["token"] as? String{
                                    IJProgressView.shared.hideProgressView()
                                Constants.setValueInUserDefaults(objValue:authentication , for:"usertoken")
                                    let rider_details :NSDictionary  = (Result["customer_details"] as? NSDictionary)!
                                    let riderNum = rider_details.object(forKey: "customer_id") as! Int
                                    let riderStr = String(riderNum)
                                    if let firstName = rider_details.object(forKey:"firstname") as? String{
                                        self.firstname = firstName
                                    }
                                    if let lastName = rider_details.object(forKey: "lastname") as? String{
                                        self.secondName = lastName
                                    }
                                    let finalName = self.firstname + " " + self.secondName
                                    Constants.setValueInUserDefaults(objValue:finalName , for:"finalname")
                                    Constants.setValueInUserDefaults(objValue:riderStr , for:"customer_id")
                                    Constants.setValueInUserDefaults(objValue:(rider_details.object(forKey: "username") as! NSString) as String , for:"username")
                                    self.deviceTokanApi()
                                    let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                                    let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
                                    self.present(nextViewController, animated: true, completion: nil)
                                }
                            })
                        }
                        if status == false{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                if let incorrect = Result["error"] as? String{
                                    if incorrect == "Incorrect user or password"{
                                        self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("error_Incorrect user or password", comment: ""), completion: {(result) in
                                            self.passwordTxt.text = ""
                                            self.passwordTxt.becomeFirstResponder()
                                        })
                                    }
                                    else  if incorrect == "User does not exist"{
                                        self.displayAlert(message: NSLocalizedString("error_User does not exist", comment: ""))
                                    }
                                }
                            })
                        }
                    }
                }
                else
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                        self.displayAlert(message: NSLocalizedString("ver_somethingwrong", comment: ""))
                    })
                }
            }
        }
    }
    func deviceTokanApi(){
        DispatchQueue.global().async {
            if UserDefaults.standard.value(forKey: "devicetoken") as? String == nil{
                return
            }else{
                var customerId  = ""
                var deviceToken = ""
                deviceToken = UserDefaults.standard.value(forKey: "devicetoken") as! String
                customerId = UserDefaults.standard.value(forKey: "customer_id") as! String
                var bodyReq = [String:String]()
                bodyReq = ["device_token":deviceToken,"rider_id": "" ,"device_type":"iphone","customer_id":customerId,"user_type":"customer"]
                // print("bodyReq",bodyReq)
                if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                    let token = UserDefaults.standard.value(forKey: "usertoken") as! String
                    let sessionStr = "Bearer " + token
                    // print(sessionStr)
                    APICommnicationManager.sharedInstance.requestforAPI(service:"/RiderAuth/identifyDeviceType" , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (result, error) in
                        if let Result = result as? [String:Any]{
                            //print("Result",Result)
                            if let status = Result["status"] as? Bool {
                                if status == true{
                                    DispatchQueue.main.async(execute: { () -> Void in
                                        IJProgressView.shared.hideProgressView()
                                        Constants.setValueInUserDefaults(objValue:deviceToken , for:"devicetoken")
                                    })
                                }
                                if status == false{
                                    self.displayAlert(message: (Result["error"] as? String)!)
                                }
                            }
                        }else{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.displayAlert(message: NSLocalizedString("ver_somethingwrong", comment: ""))
                            })
                        }
                    }
                }
            }
        }
    }
    
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    deinit{
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        self.scrollViewObj.isScrollEnabled = true
        var info = notification.userInfo!
        var keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        if keyboardSize?.height == 0{
            keyboardSize?.height = 258
        }
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height, 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollViewObj.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
        
    }
    
    func keyboardWillBeHidden(notification: NSNotification){
        var info = notification.userInfo!
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        self.view.endEditing(true)
        self.scrollViewObj.isScrollEnabled = true
        self.scrollViewObj.contentSize = CGSize(width: self.scrollViewObj.frame.width, height: self.containerView.frame.origin.y+self.containerView.frame.size.height - 160);
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField){
        
        if textField == self.firstnameTxt{
            self.firstnameTxt.returnKeyType = .next
        }else if textField == self.lastnameTxt{
            self.lastnameTxt.returnKeyType = .next
        }else if textField == self.mobileNumberTxt{
            if countryCodeTxt.text?.count == 0{
                self.displayAlert(message: NSLocalizedString("val_countrycode", comment: ""))
            }else{
                self.mobileNumberTxt.keyboardType = .numberPad
                self.addBarBtnToKeyboard(textfield: self.mobileNumberTxt)
            }
        }else if textField == self.lastnameTxt{
            self.countryView.isHidden = false
        }else if textField == self.emailTxt{
            self.emailTxt.keyboardType = .emailAddress
            self.emailTxt.returnKeyType = .next
        }else if textField == self.passwordTxt{
            self.passwordTxt.returnKeyType = .next
        }else if textField == self.confirmPasswordTxt{
            self.confirmPasswordTxt.returnKeyType = .done
        }
        activeField = textField
    }
    
    func textFieldDidEndEditing(_ textField: UITextField){
        if textField == self.firstnameTxt{
            if self.firstnameTxt.text?.count == 0 || self.firstnameTxt.text == ""{
            }else{
                self.firstnameTxt.text =  self.firstnameTxt.text!.capitalizedFirst()
            }
        }
        if textField == self.lastnameTxt{
            if self.lastnameTxt.text?.count == 0 || self.lastnameTxt.text == ""{
            }else{
                self.lastnameTxt.text =  self.lastnameTxt.text!.capitalizedFirst()
            }
        }
        activeField = nil
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        switch textField{
        case self.firstnameTxt:
            self.lastnameTxt.becomeFirstResponder()
            break
        case self.lastnameTxt:
            self.lastnameTxt.resignFirstResponder()
            break
        case self.emailTxt:
            self.passwordTxt.becomeFirstResponder()
            break
        case self.passwordTxt:
            self.confirmPasswordTxt.becomeFirstResponder()
            break
        case self.confirmPasswordTxt:
            textField.resignFirstResponder()
            break
        default:
            textField.resignFirstResponder()
        }
        return true
    }
    
    func addBarBtnToKeyboard(textfield : UITextField){
        self.mobileNumberTxt.keyboardType = .numberPad
        let keyPadToolBar = UIToolbar()
        keyPadToolBar.barStyle = UIBarStyle.blackTranslucent
        keyPadToolBar.barTintColor = AppColors.greenColorRGB
        keyPadToolBar.sizeToFit()
        let DoneButton = UIBarButtonItem(title: "Next", style: UIBarButtonItemStyle.done, target: self, action: #selector(SignupVC.dismissKeypad))
        DoneButton.tintColor = AppColors.whiteColorRGB
        keyPadToolBar.setItems([DoneButton], animated: true)
        textfield.inputAccessoryView = keyPadToolBar
    }
    
    func dismissKeypad(){
        self.mobileNumberTxt.resignFirstResponder()
        emailTxt.becomeFirstResponder()
    }
}

