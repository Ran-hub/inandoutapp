//
//  Constant.swift
//  RYTLE
//
//  Created by Admin on 17/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import Foundation

struct APPURLS{
    
    static let versionNumber = "/1.0.1"
    //static let versionNumber = "/1.0.0"
   //static let profilePicPath = "/User/image/"
    static let profilePicPath = "/FileStorage/Download/"
    static let rebookParcel = "/Parcel/parcelRebook"
    static let loginURL = "/CustomerAuth/customerLogin"
    static let deviceTypeURL = "/RiderAuth/identifyDeviceType"
    static let feedBackURL = "/User/customerFeedback"
    static let pickAddressListURL = "/Pickup/getAllPickupaddress"
    static let deletePickupAddressURL = "/Pickup/deletePickpaddress"
    static let deleveryAddressURL = "/Parcel/getAllDeliveryaddress"
    static let deleteDeliveryAddressURL = "/Parcel/deleteDeliveryaddress"
    static let createPickupAddressURL = "/Pickup/createNewPickupaddress"
    static let createDeliveryAddressURl = "/Parcel/createDeliveryaddress"
    static let updatePickupAddress = "/Pickup/updatePickupaddress"
    static let updateDeliveryAddress =  "/Parcel/updateDeliveryaddress"
    static let parcelBookURL = "/Parcel/bookParcels"
    static let riderAvailabilityURL = "/Parcel/riderAvailability"
    static let getProfileURL = "/CustomerAuth/getCustomerProfile"
    static let updateProfileURL = "/CustomerAuth/editCustomerProfile"
    static let updateProfilePicURL = "/User/updateProfileimg"
    static let allParcelURL = "/Parcel/allParcels"
    static let getParcelDetailsURL = "/Parcel/getCustomerParceldetails"
    static let parcelDetailsURL = "/Parcel/getParceldetails"
    static let forgotPasswordURL = "/CustomerAuth/customerForgotPassword"
    static let verifyOTPURL = "/CustomerAuth/customerVerifyOTP"
    static let resetPasswordURL = "/CustomerAuth/customerResetPassword"
    static let changePasswordURL = "/CustomerAuth/customerChangePassword"
    static let logoutURL = "/CustomerAuth/customerLogout"
    static let registrationURL = "/User/addCustomerUser"
    static let customerAppOrgWiseRegURL = "/User/getOrgidForCustomerApp"
    static let cancelParcelRequestURL = "/Pickup/cancelParcelpickup"
    static let getParcelTypeURL = "/Parcel/getParceltype"
    static let getParcelDimensionURL = "/Parcel/getParceldimensions"
    static let getParcelWeightsURL = "/Parcel/getParcelweight"
    static let uploadParcelAttachImageURL = "/Parcel/uploadParcelimage"
    static let getAddressTypeURL = "/Pickup/getAddressType"

    //live secrect key
      static let orgScrectKey1 = "OrgfxTZWwbVQU"
    
     // static let orgScrectKey2 = "orggVPvCDvhYb"
    
    //orbitak
    //static let orgScrectKey3 = "OrbD9u1iTBCnD"
    
    //production
        static var productionbaseURL = "https://apiconnect.rytle.com"
    //   static var baseURL = "https://apiconnect.rytle.com"
    
    //staging URL
     static var stagingbaseURL = "http://apis-rytle.software-development.biz"
//    static var baseURL = "http://apis-rytle.software-development.biz"
    
         //Local
//        static let baseURL = "http://192.168.3.48:8091"
//        static let localbaseURLWithPort = "http://192.168.3.48:8091" //asmita
    
      static var localbaseURL = "http://192.168.3.46"//localamt
      static var baseURL = "http://192.168.3.46"//localamt
    
}
struct AppColors{
    static let darkRedColorRGB = UIColor.init(red: 228/255, green: 23/255, blue: 56/255, alpha: 1)
    static let greenColorRGB = UIColor.init(red: 13/255, green: 229/255, blue: 169/255, alpha: 1)
    static let blackColorRGB = UIColor.init(red: 28/255, green: 28/255, blue: 26/255, alpha: 1)
    static let whiteColorRGB = UIColor.init(red: 241/255, green: 241/255, blue: 241/255, alpha: 1)
    static let lightGrayColorRGB = UIColor(red: 189/255, green: 189/255, blue: 189/255, alpha: 1)
    static let btn_grayColorRGB = UIColor(red: 170/255, green: 170/255, blue: 170/255, alpha: 1)
    static let fontTextDarkColorRGB = UIColor(red: 77/255, green: 78/255, blue: 78/255, alpha: 1)
    static let textBoderColorRGB = UIColor(red: 19/255, green: 19/255, blue: 17/255, alpha: 1)
    static let darkGrayColorRGB =  UIColor(red: 105/255, green: 105/255, blue: 105/255, alpha: 1)
}
struct AppFont{
    static let boldTextFont = UIFont(name: "HelveticaNeue", size: 20)
    static let boldTextFont1 = UIFont(name: "HelveticaNeue-Bold", size: 20)
    static let boldMediumTextFont = UIFont(name: "HelveticaNeue-Bold", size: 17)
    static let regularSmallTextFont = UIFont(name: "HelveticaNeue", size: 15)
    static let regularTextFont = UIFont(name: "HelveticaNeue", size: 17)
    static let regularLargeTextFont = UIFont(name: "HelveticaNeue", size: 20)
}
struct GoogleMapsApiKey{
    //static let key = "AIzaSyB-y5OE60WhKVKr0Gy-VxiTsx4adTihZMw"
    //( Google Premium Licence)
      static let key = "AIzaSyAqD9_dKOa48dplcRNCEBmE4vblLPMqHjQ"

    // static let URL = "https://maps.googleapis.com/maps/api/geocode/json"
}

