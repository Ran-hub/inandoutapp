//
//  GoogleNewAddressViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Shilpashree on 26/10/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces
import CoreLocation

class AddNewAddressVC: UIViewController,CLLocationManagerDelegate,UISearchBarDelegate{
    
    @IBOutlet weak var continueBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var searchBarObj: UISearchBar!
    @IBOutlet weak var mapViewObj: GMSMapView!
    @IBOutlet weak var addressViewHeightHC: NSLayoutConstraint!
    @IBOutlet weak var addressLblHeightHC: NSLayoutConstraint!
    @IBOutlet weak var addressLbl: UILabel!
    @IBOutlet weak var AddressView: UIView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var nextButton: UIButton!
    var controllerName : String = String()
    var apicount : CGFloat = 0
    @IBOutlet weak var iconView: UIImageView!
    @IBOutlet weak var addrssStatusLbl: UILabel!
    @IBOutlet weak var titleLblCC: NSLayoutConstraint!
    
    var pickuplat = ""
    var pickuplong = ""
    var addressStr1 = ""
    var addressStr2 = ""
    var cityStr = ""
    var countryStr = ""
    var stateStr = ""
    var zipcodeStr = ""
    var fulladdressStr = ""
    var fulladdressStr1 = ""
    var houseno = ""
    var streetNoStr = ""
    var addressStr3 = ""
    var mapmove = Bool()
    var addressType = ""
    var pickupMarker = GMSMarker()
    var fromAutoSearch = false
    var curentlat = Double()
    var currentlong = Double()
    var center : CLLocationCoordinate2D = CLLocationCoordinate2D()
    var locationManager = CLLocationManager()
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.searchBarObj.delegate = self
        initialSetUp()
    }
    
    
    @IBAction func cancelAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func heightForView(text:String, font:UIFont, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRect(x:0, y:0, width:width, height:10000))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    func languageValidationForGermany()
    {
        let languageCode = Constants.getValueFromUserDefults(for: "languageCode") as! String
        
        if languageCode == "Yes"
        {
            self.languageValidationForGermany(headerView: self.headerView, cancelBtn: self.cancelBtn, labelConstraints: self.titleLblCC, titleLbl: self.titleLbl)
        }
        
        /*  if appdelegate.IS_IPHONE5 || appdelegate.IS_IPHONE6 || appdelegate.IS_IPHONEX || appdelegate.IS_IPHONE6PLUS
         {
         if languageCode == "Yes"
         {
         self.titleLbl.textAlignment = .left
         self.headerView.removeConstraint(self.titleLblCC)
         self.headerView.addConstraint(NSLayoutConstraint(item: self.cancelBtn, attribute: .width, relatedBy: .equal , toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 90))
         
         self.headerView.addConstraint(NSLayoutConstraint(item: self.titleLbl, attribute: .leading, relatedBy: .equal , toItem: self.cancelBtn, attribute: .trailing, multiplier: 1, constant: 5))
         
         self.headerView.addConstraint(NSLayoutConstraint(item: self.headerView, attribute: .trailing, relatedBy: .equal , toItem: self.titleLbl, attribute: .trailing, multiplier: 1, constant: 5))
         }
         else
         {
         
         }
         }*/
    }
    override func viewWillAppear(_ animated: Bool) {
        
        if self.ineternetAlert() == false
        {
            return
        }
    }
    
    func initialSetUp(){
        
        if controllerName == "PickUpDetails"
        {
            self.titleLbl.text = NSLocalizedString("lbl_pickupaddress", comment: "")
        }
        else if controllerName == "ReceiverDetails"
        {
            self.titleLbl.text = NSLocalizedString("lbl_receiverdetails", comment: "")
            if appdelegate.IS_IPHONE5
            {
                self.languageValidationForGermany()
            }
        }
        
        self.titleLbl.textColor = AppColors.whiteColorRGB
        self.titleLbl.font = AppFont.boldTextFont
        
        if appdelegate.IS_IPHONE5
        {
            self.titleLbl.font = UIFont(name: "HelveticaNeue", size: 18)
        }
        
        self.addrssStatusLbl.text = NSLocalizedString("lbl_addresschange", comment: "")
        self.addrssStatusLbl.font = AppFont.regularTextFont
        
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        
        self.nextButton.setTitle(NSLocalizedString("btn_continue", comment: ""), for: .normal)
        self.nextButton.titleLabel?.font = AppFont.boldTextFont
        self.nextButton.backgroundColor = AppColors.greenColorRGB
        self.nextButton.titleLabel?.textColor = AppColors.whiteColorRGB
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            //locationManager.requestAlwaysAuthorization()
            locationManager.requestWhenInUseAuthorization()
        }
        locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
        }
        mapViewObj.isUserInteractionEnabled = true
        mapViewObj.isMyLocationEnabled = true
        mapViewObj.delegate = self
        nextButton.isHidden = false
        self.view.bringSubview(toFront: self.searchBarObj)
        self.mapViewObj.bringSubview(toFront: self.searchBarObj)
        mapViewObj.bringSubview(toFront: self.AddressView)
        mapViewObj.bringSubview(toFront: self.addrssStatusLbl)
        mapViewObj.bringSubview(toFront: self.headerView)
        mapViewObj.bringSubview(toFront: self.nextButton)
        
        self.AddressView.isHidden = true
        self.addrssStatusLbl.isHidden = true
        mapViewObj.bringSubview(toFront:iconView)
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations.last
        curentlat = (location?.coordinate.latitude)!
        currentlong =
            (location?.coordinate.longitude)!
        center.latitude = curentlat
        center.longitude = currentlong
        
        self.mapViewObj.camera = GMSCameraPosition(target: (location?.coordinate)!, zoom: 15, bearing: 0, viewingAngle: 0)
        
        if apicount == 0
        {
            self.fromAutoSearch = true
            apicount += 1
            self.getAddressFromLatLon(coordinate: CLLocationCoordinate2D(latitude: (location?.coordinate.latitude)!, longitude: (location?.coordinate.longitude)!))
        }
        
        self.locationManager.stopUpdatingLocation()
        
    }
    func getAddressFromLatLon(coordinate: CLLocationCoordinate2D) {
        
        let geocode: GMSGeocoder = GMSGeocoder()
        // pickuplat  = String(coordinate.latitude)
        //pickuplong = String(coordinate.longitude)
        
        geocode.reverseGeocodeCoordinate(coordinate, completionHandler:
            {(response, error) in
                if (error != nil)
                {
                    //  print("reverse geodcode fail: \(error!.localizedDescription)")
                    return
                }
                if let address = response?.firstResult()
                {
                    if  self.fromAutoSearch == true
                    {
                        self.addrssStatusLbl.isHidden = true
                    }
                    else
                    {
                        self.addrssStatusLbl.isHidden = false
                    }
                    
                    let lines = address.lines
                    
                    self.searchBarObj.text = lines?.joined(separator: "\n")
                    
                    self.mapViewObj.animate(toLocation: CLLocationCoordinate2D(latitude:coordinate.latitude, longitude:coordinate.longitude))
                    self.pickuplat = String(format: "%f", coordinate.latitude)
                    self.pickuplong = String(format: "%f", coordinate.longitude)
                    
                    // print("label657656558568===\(String(describing: address.lines?[0]))");
                    self.fulladdressStr = ""
                    if let address = address.lines as NSArray?
                    {
                        if let addressStr = address[0] as? String
                        {
                            self.fulladdressStr += addressStr
                        }
                        if let addressStr1 = address[1] as? String
                        {
                            //self.self.fulladdressStr += ", " + addressStr1
                        }
                        
                        if let fullNameArr = self.fulladdressStr.components(separatedBy: ", ") as NSArray?
                        {
                            // print(fullNameArr.count)
                            
                            let count = fullNameArr.count
                            
                            switch fullNameArr.count
                            {
                            case 0:
                                self.houseno = (fullNameArr[0] as? String)!
                                break
                            case 1:
                                self.self.houseno = (fullNameArr[0] as? String)!
                                break
                            case 2:
                                self.self.houseno = (fullNameArr[0] as? String)!
                                self.addressStr1 = (fullNameArr[1] as? String)!
                                
                                break
                            case 3:
                                self.houseno = (fullNameArr[0] as? String)!
                                self.addressStr1 = (fullNameArr[1] as? String)!
                                self.self.addressStr2 = (fullNameArr[2] as? String)!
                                break
                            case 4:
                                self.houseno = (fullNameArr[0] as? String)!
                                self.addressStr1 = (fullNameArr[1] as? String)!
                                self.addressStr2 = (fullNameArr[2] as? String)!
                                self.addressStr3 = (fullNameArr[3] as? String)!
                                break
                            case 5:
                                self.houseno = fullNameArr[0] as! String
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)!
                                break
                            case 6:
                                self.houseno = fullNameArr[0] as! String
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)!
                                break
                            case 7:
                                self.houseno  = fullNameArr[0] as! String
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)!
                                break
                            case 8:
                                self.houseno  = fullNameArr[0] as! String
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)!
                                break
                            case 9:
                                self.houseno  = fullNameArr[0] as! String
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)! + ", " + (fullNameArr[8] as? String)!
                                break
                            case 10:
                                self.houseno  = fullNameArr[0] as! String
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)! + ", " + (fullNameArr[8] as? String)! + ", " + (fullNameArr[9] as? String)!
                                break
                            default: break
                            }
                        }
                        
                    }
                    if let locality = address.locality
                    {
                        // print(locality)
                        self.cityStr = locality
                    }
                    if let admistrateArea = address.administrativeArea
                    {
                        // print(admistrateArea)
                        self.stateStr = admistrateArea
                    }
                    if let country = address.country
                    {
                        // print(country)
                        self.countryStr = country
                    }
                    if let zipcode = address.postalCode
                    {
                        // print(zipcode)
                        self.zipcodeStr = zipcode
                    }
                    
                    if let streetno = address.thoroughfare
                    {
                        // print(streetno)
                        self.streetNoStr = streetno
                    }
                    self.addressLbl.text = ""
                    
                    self.AddressView.isHidden = false
                    
                    if self.fromAutoSearch == false
                    {
                        self.addrssStatusLbl.text = "Address changed"
                    }
                    self.addressLbl.text = self.fulladdressStr + ", " + self.cityStr + ", " + self.stateStr + ", " + self.zipcodeStr + ", " + self.countryStr
                    //print("addresss :: ",self.addressLbl.text!)
                    self.searchBarObj.text = self.addressLbl.text
                    
                    var height : CGFloat = 0
                    height += self.heightForView(text: self.addressLbl.text!, font: UIFont(name: "HelveticaNeue", size: 17)!, width: self.addressLbl.frame.size.width)
                    self.addressLblHeightHC.constant = height
                    self.addressLbl.lineBreakMode = NSLineBreakMode.byWordWrapping
                    self.addressLbl.numberOfLines = 0
                    self.addressLbl.sizeToFit()
                    self.addressViewHeightHC.constant = 10+height+10
                    self.timerMethod()
                    // var count : CGFloat = 0
                    
                    // count += self.heightForView(text: self.addressLbl.text!, font: AppFont.regularTextFont!, width: self.addrssStatusLbl.frame.size.width)
                    
                    
                    //self.addressViewHeightHC.constant = count
                    //  self.addrssStatusLbl.isHidden = true
                }
        })
        
    }
    
    func timerMethod()
    {
        Timer.scheduledTimer(timeInterval:3, target:self, selector: #selector((AddNewAddressVC.updateCounter)), userInfo: nil, repeats: false)
    }
    func updateCounter()
    {
        self.addrssStatusLbl.isHidden = true
    }
    
    
    func setBottomBorder(textField:UITextField)-> UITextField {
        textField.borderStyle = .none
        textField.layer.backgroundColor = UIColor.white.cgColor
        
        textField.layer.masksToBounds = false
        textField.layer.shadowColor = UIColor.gray.cgColor
        textField.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        textField.layer.shadowOpacity = 1.0
        textField.layer.shadowRadius = 0.0
        return textField
    }
    
    @IBAction func btnsTapped(_ sender: UIButton) {
        if sender.tag == 10
        {
            let autocompleteController = GMSAutocompleteViewController()
            autocompleteController.delegate = self
            present(autocompleteController, animated: true, completion: nil)
        }
        else if sender.tag == 20{
            self.mapViewObj.isHidden = true
            continueBottomConstraint.constant = 90
            nextButton.isHidden = false
            sender.tag = 30
        }
        else if sender.tag == 30{
            self.mapViewObj.isHidden = false
            continueBottomConstraint.constant = 20
            nextButton.isHidden = true
            
            //self.confirmButton.setTitle("CONFIRM", for:.normal)
            sender.tag = 20
        }
        else if sender.tag == 40
        {
            if addressLbl.text?.count == 0
            {
                self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("ver_address",comment: ""), completion: {(result) in
                })
                return
            }
            else
            {
                let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                let addressVC = storyboard.instantiateViewController(withIdentifier: "AddressDetailsViewController") as! AddressDetailsViewController
                addressVC.fullAddress = self.addressLbl.text!
                addressVC.controlerName = self.controllerName
                addressVC.zipcodeObjStr = self.zipcodeStr
                addressVC.houseNoObjStr = self.houseno
                addressVC.streetObjStr1 = self.addressStr1
                addressVC.streetObjStr2 = self.addressStr2
                addressVC.streetObjStr3 = self.addressStr3
                addressVC.cityObjStr = self.cityStr
                addressVC.stateObjStr = self.stateStr
                addressVC.countryObjStr = self.countryStr
                addressVC.latitudeObjStr = self.pickuplat
                addressVC.longitudeObjStr = self.pickuplong
                self.present(addressVC, animated: true, completion: nil)
            }
            
        }
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        let autocompleteController = GMSAutocompleteViewController()
        autocompleteController.delegate = self
        present(autocompleteController, animated: true, completion: nil)
    }
    
    
}

extension AddNewAddressVC: GMSAutocompleteViewControllerDelegate
{
    // Handle the user's selection.
    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace) {
        
        let address = place.formattedAddress!
        
        // if addressType == "Pickup"{
        // self.addressLabel.text = address
        // self.pickUpLabel.text = address
        
        self.searchBarObj.text = address
        
        print("address ::: ",address)
        
        //self.mapViewObj.animate(to: GMSCameraPosition.camera(withLatitude:place.coordinate.latitude, longitude:place.coordinate.longitude, zoom: 15.0))
        
        // self.mapViewObj.animate(toLocation: CLLocationCoordinate2D(latitude:coordinate.latitude, longitude:coordinate.longitude))
        
        self.fromAutoSearch = true
        getAddressFromLatLon(coordinate: CLLocationCoordinate2D(latitude: place.coordinate.latitude, longitude: place.coordinate.longitude))
        
        
        dismiss(animated: true, completion: nil)
    }
    
    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error) {
        // TODO: handle the error.
        // print("Error: ", error.localizedDescription)
    }
    
    // User canceled the operation.
    func wasCancelled(_ viewController: GMSAutocompleteViewController) {
        dismiss(animated: true, completion: nil)
    }
    
    // Turn the network activity indicator on and off again.
    func didRequestAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    func didUpdateAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
    
}
extension AddNewAddressVC:GMSMapViewDelegate{
    
    func mapView(_ mapView: GMSMapView, willMove gesture: Bool) {
        if gesture == true{
            mapmove = true
            //  self.searchBarObj.text = nil
            // self.searchBarObj.placeholder = "   Searching...."
            if AddressView.isHidden
            {
                
            }
            else
            {
                self.addrssStatusLbl.isHidden = true
                //self.addrssStatusLbl.text = "Address changing..."
            }
            // self.AddressView.isHidden = true
            mapView.selectedMarker = nil
        }
    }
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        if mapmove == true{
            fromAutoSearch = false
            getAddressFromLatLon(coordinate:mapView.camera.target)
            
        }
    }
    
}
extension AddNewAddressVC:UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
}

