import UIKit
protocol SideDelegate{
    func disableButtonAction(position:String)
}
class RevealViewController: SWRevealViewController, SWRevealViewControllerDelegate {
    var delegate1:SideDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        self.rearViewRevealOverdraw = 0.0
        self.tapGestureRecognizer()
        self.panGestureRecognizer()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // MARK: - SWReveal view controller delegate
    
    func revealControllerPanGestureShouldBegin(_ revealController: SWRevealViewController!) -> Bool {
        return true
    }
    func revealController(_ revealController: SWRevealViewController!, didMoveTo position: FrontViewPosition) {
        if position == .right {
            //NSLog("Did open")
        }
        else {
            // NSLog("Did close")
        }
    }
    func revealController(_ revealController: SWRevealViewController!, willMoveTo position: FrontViewPosition) {
        if position == .right {
            revealController.frontViewController.view.isUserInteractionEnabled = false
        }else{
            revealController.frontViewController.view.isUserInteractionEnabled = true
        }
    }
    
    func revealController(_ revealController: SWRevealViewController!, panGestureMovedToLocation location: CGFloat, progress: CGFloat, overProgress: CGFloat) {
        // print("progress: \(progress)")
        //revealController.frontViewController.view.alpha = 1.0 - (progress * 0.2)
    }
}

