//
//  BoxContentViewController.swift
//  RYTLE
//
//  Created by Admin on 31/07/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import Firebase

class ParcelsHistoryVC: UIViewController,UITableViewDataSource,UITableViewDelegate{
    
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet var parcelHistoryTable: UITableView!
    @IBOutlet var cancelBtn: UIButton!
    @IBOutlet var titleLbl: UILabel!
    @IBOutlet weak var headerView : UIView!
    @IBOutlet weak var titleLblCC: NSLayoutConstraint!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    var refreshControl = UIRefreshControl()
    var parcelListArray = NSMutableArray()
    var countArray = NSMutableArray()
    var riderIdArray = NSMutableArray()
    var rowArray = NSMutableArray()
    var pushNotificationStr = ""
    var not_parcelId = ""
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetup()
        self.intialConstraintsSetup()
        self.tableviewSetup()
        self.addRefreshVCtoTableView()
        self.gesturesSetup()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func initialSetup(){
        self.navigationController?.navigationBar.isHidden = true
        self.statusLbl.text = NSLocalizedString("ver_noparcelfound", comment: "")
        self.statusLbl.numberOfLines = 2
        self.titleLbl.text = NSLocalizedString("lbl_parcelhistory1", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        self.titleLbl.textColor = AppColors.whiteColorRGB
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        NotificationCenter.default.addObserver(self, selector: #selector(ParcelsHistoryVC.notifcationMethod(notification:)), name: NSNotification.Name(rawValue: "ParcelHistoryNotifiation"), object: nil)
        self.languageValidationForGermany()
    }
    override func viewWillAppear(_ animated: Bool) {
        appdelegate.parcelHistoryStatus = "Yes"
        self.getAllParcelsapi()
    }
    func gesturesSetup(){
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(ParcelsHistoryVC.respondToSwipeGesture(gesture:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.down
        self.statusLbl.isUserInteractionEnabled = true
        self.statusLbl.addGestureRecognizer(swipeRight)
    }
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
                 self.statusLbl.isHidden = true
                 self.getAllParcelsapi()
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    func tableviewSetup(){
        self.parcelHistoryTable.register(UINib(nibName: "ParcelHistoryTC", bundle: nil), forCellReuseIdentifier: "ParcelHistoryTC")
        self.parcelHistoryTable.rowHeight = UITableView.automaticDimension
        self.parcelHistoryTable.estimatedRowHeight = 185;
        self.statusLbl.text = NSLocalizedString("ver_noparcelfound", comment: "")
    }
    func addRefreshVCtoTableView(){
        if #available(iOS 10.0, *) {
            parcelHistoryTable.refreshControl = refreshControl
        } else {
            // Fallback on earlier versions
            parcelHistoryTable.addSubview(refreshControl)
        }
        refreshControl.tintColor = AppColors.greenColorRGB
        refreshControl.attributedTitle = NSAttributedString(string: NSLocalizedString("lbl_loading", comment: ""))
        refreshControl.addTarget(self, action: #selector(PickupAddressVC.refreshData), for: .valueChanged)
    }
    func languageValidationForGermany(){
        let languageCode = Constants.getValueFromUserDefults(for: "languageCode") as! String
        if languageCode == "Yes"{
            self.languageValidationForGermany(headerView: self.headerView, cancelBtn: self.cancelBtn, labelConstraints: self.titleLblCC, titleLbl: self.titleLbl)
        }
    }
    override func viewWillDisappear(_ animated: Bool){
        appdelegate.parcelHistoryStatus = ""
        appdelegate.parcelHistoryParcelId = ""
        self.pushNotificationStr = ""
        NotificationCenter.default.removeObserver(self, name:NSNotification.Name(rawValue: "ParcelHistoryNotifiation") , object: nil)
    }
    @objc func notifcationMethod(notification : NSNotification){
        if let parcelId = notification.userInfo?["parcelId"] as? String {
           // print("parcelId :: ",parcelId)
            self.notificationRefreshDataApi(parcelId: parcelId)
            NotificationCenter.default.addObserver(self, selector: #selector(ParcelsHistoryVC.notifcationMethod(notification:)), name: NSNotification.Name(rawValue: "ParcelHistoryNotifiation"), object: nil)
        }
    }
    func refreshData(){
        self.getAllParcelsapi()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return self.parcelListArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ParcelHistoryTC") as! ParcelHistoryTC
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        cell.api_feedbckLbl.layer.masksToBounds = true
        cell.api_feedbckLbl.layer.cornerRadius = cell.api_feedbckLbl.frame.size.height/2
        cell.api_feedbckLbl.layer.borderWidth = 1
        cell.api_feedbckLbl.layer.borderColor = AppColors.greenColorRGB.cgColor
        cell.api_feedbckLbl.textColor = AppColors.greenColorRGB
        cell.parcelID.text = NSLocalizedString("lbl_parcelid", comment: "")
        cell.timeofBookingLbl.text = NSLocalizedString("lbl_timeofbooking", comment: "")
        cell.modeofPaymentLbl.text = NSLocalizedString("lbl_modeofdelivery", comment: "")
        cell.feedbckLbl.text = NSLocalizedString("lbl_status", comment: "")
        cell.riderNameLbl.text = NSLocalizedString("lbl_riderassigned", comment: "")
        
        let parcel = self.parcelListArray.object(at: indexPath.row) as! parcelHistoryDetails
        cell.api_feedbckLbl.text = parcel.status
       // print("indexPath.row",indexPath.row)
       // print("parcel.status",parcel.status)
        if parcel.status == "Waiting for pickup"{
            cell.api_feedbckLbl.text = NSLocalizedString("lbl_waitingforpickup", comment: "")
        }else if parcel.status == "Out for Delivery"{
            cell.api_feedbckLbl.text = NSLocalizedString("lbl_outfordelivery", comment: "")
        }else if parcel.status == "Delivered"{
            cell.api_feedbckLbl.text = NSLocalizedString("lbl_parceldelivered", comment: "")
        }else if parcel.status == "Not Picked Up"{
            cell.api_feedbckLbl.text = NSLocalizedString("lbl_notpickedup", comment: "")
        }else if parcel.status == "Not Delivered"{
            cell.api_feedbckLbl.text = NSLocalizedString("lbl_notdelivered", comment: "")
        }else if parcel.status == "Not Delivered"{
            cell.api_feedbckLbl.text = NSLocalizedString("lbl_notdelivered", comment: "")
        }else if parcel.status == "Cancelled"{
            cell.api_feedbckLbl.text = NSLocalizedString("lbl_cancelled", comment: "")
        }
        cell.api_parcelID.text = parcel.parcel_id
        cell.api_modeofPaymentLbl.text = parcel.deliveryMode
        cell.api_timeofBookingLbl.text = parcel.bookingtime
        cell.api_riderNameLbl.text = parcel.riderFirstName + " " + parcel.riderLastName
        let riderID = String(parcel.riderId)
        cell.liveImgTC.constant = 0
        cell.liveImgHC.constant = 0
        if riderID != "0"{
            if parcel.riderLiveStatus == "Yes"{
                cell.containerHeightConstraints.constant = 195
                cell.liveImgTC.constant = 5
                cell.liveImgHC.constant = 19
                cell.riderHeightConstraint.constant = 25
                cell.riderTopConstraint.constant = 5
                cell.api_riderHeightConstraint.constant = 25
                cell.api_riderTopConstraint.constant = 5
            }else{
                cell.containerHeightConstraints.constant = 165
                cell.riderHeightConstraint.constant = 25
                cell.riderTopConstraint.constant = 5
                cell.api_riderHeightConstraint.constant = 25
                cell.api_riderTopConstraint.constant = 5
            }
        }else{
            cell.containerHeightConstraints.constant = 135
            cell.riderHeightConstraint.constant = 0
            cell.riderTopConstraint.constant = 0
            cell.api_riderHeightConstraint.constant = 0
            cell.api_riderTopConstraint.constant = 0
        }
        if parcel.riderLiveStatus == "Yes"{
            cell.contentView.backgroundColor = UIColor.white
        }else{
            cell.contentView.backgroundColor = UIColor.white
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        let heightStr = self.countArray.object(at: indexPath.row) as! String
        let myFloat = (heightStr as NSString).floatValue
        return  CGFloat(myFloat)
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        Analytics.logEvent("ParcelsHistoryVC_SelectedParcelFromTheListToSeeParcelDetails", parameters: nil)
        let parcel = self.parcelListArray.object(at: indexPath.row) as! parcelHistoryDetails
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let PDVC = storyBoard.instantiateViewController(withIdentifier: "ParcelDetailVC") as! ParcelDetailVC
        PDVC.parcelId = parcel.parcel_id
        self.present(PDVC, animated:true, completion: nil)
    }
    @IBAction func cancelBtnTapped(_ sender : UIButton){
        Analytics.logEvent("ParcelsHistoryVC_CancelButtonTapped", parameters: nil)
        self.dismiss(animated: true, completion: nil)
    }
    func notificationRefreshDataApi(parcelId : String){
        if self.ineternetAlert() == false{
            return
        }else{
            not_parcelId = ""
            not_parcelId = parcelId
            DispatchQueue.global().async{
                if Constants.getValueFromUserDefults(for:"customer_id") as? String == nil{
                }else{
                    var bodyReq = [String:String]()
                    var cust_id = String()
                    cust_id = Constants.getValueFromUserDefults(for:"customer_id") as! String
                    bodyReq = ["customer_id":cust_id]
                    var token = String()
                    var reultanttoken = ""
                    if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
                        token = Constants.getValueFromUserDefults(for: "usertoken") as! String
                        reultanttoken = "Bearer" + " " + token
                    }
                    if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                    APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.allParcelURL , method: "POST", token:reultanttoken, body: "", productBody: bodyData as NSData) { (data,error,response) in
                       
                            if let httpResponse = response as? HTTPURLResponse{
                             //   print("httpResponse status code \(httpResponse.statusCode)")
                                switch(httpResponse.statusCode){
                                case 200:
                                    if let receivedData = data{
                                        do{
                                            let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                            DispatchQueue.main.async {
                                                IJProgressView.shared.hideProgressView()
                                                self.responseFromApi(response: resultDic as! [String : Any])
                                            }
                                        }catch {
                                            DispatchQueue.main.async {
                                                IJProgressView.shared.hideProgressView()
                                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                            }
                                        }
                                    }
                                    break
                                case 500:
                                    DispatchQueue.main.async {
                                        IJProgressView.shared.hideProgressView()
                                    self.refreshControl.endRefreshing()
                                    self.diplayStatus(status: NSLocalizedString("ver_noparcelfound", comment: ""))
                                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                    }
                                    break
                                case 505:
                                    DispatchQueue.main.async {
                                        IJProgressView.shared.hideProgressView()
                                    self.refreshControl.endRefreshing()
                                    self.diplayStatus(status: NSLocalizedString("ver_noparcelfound", comment: ""))
                                    if self.parcelListArray.count != 0{
                                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                    }
                                    }
                                    break
                                case 506:
                                    DispatchQueue.main.async {
                                        IJProgressView.shared.hideProgressView()
                                    self.refreshControl.endRefreshing()
                                    self.diplayStatus(status: NSLocalizedString("error_failedtogetparcelhistory", comment: ""))
                                    if self.parcelListArray.count != 0{
                                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                    }
                                    }
                                    break
                                case 498:
                                    DispatchQueue.main.async {
                                        self.tokenExpireAlert()
                                    }
                                break
                                default:
                                    DispatchQueue.main.async {
                                        IJProgressView.shared.hideProgressView()
                                    self.refreshControl.endRefreshing()
                                    self.diplayStatus(status: NSLocalizedString("error_failedtogetparcelhistory", comment: ""))
                                    if self.parcelListArray.count != 0{
                                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                    }
                                    }
                                }
                            }else{
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                self.refreshControl.endRefreshing()
                                self.diplayStatus(status: NSLocalizedString("error_failedtogetparcelhistory", comment: ""))
                                if self.parcelListArray.count != 0{
                                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                }
                            }
                          }
                        }
                    }
                }
            }
        }
    }
    func responseFromApi(response:[String : Any]){
        print("/Parcel/allParcels notification",response)
        let newArray  = response["Msg"] as? [[String:Any]]
        for (index, array) in (newArray?.enumerated())! {
            var parcel_id = ""
            var bookingtime = ""
            var  delimode = 0
            var deliveryMode = ""
            var str = ""
            var Status = 0
            var parcelstatus = ""
            var riderIdStr = 0
            var riderFirstName = ""
            var riderLastName = ""
            var riderLive = ""
            if let parcelid = array ["parcel_id"] as?String{
                parcel_id = parcelid
            }
            if let parcelLive = array["live_tracking"] as? String{
                riderLive = parcelLive
            }
            if let  time = array["created_datetime"] as? String{
                bookingtime = time
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
                let date = formatter.date(from: bookingtime)
                let formatter1 = DateFormatter()
                formatter1.dateFormat = "HH:mm dd/MM/yyyy"
                str = formatter1.string(from:date!)
            }
            if let deliverymode = array["parcel_fk_delivery_option_id"] as? Int{
                delimode = deliverymode
            }
            if delimode == 1{
                deliveryMode = "Express"
            }
            if delimode == 2{
                deliveryMode = "Normal"
            }
            if let parcelstatus =  array["parcel_fk_status"] as? Int{
                Status = parcelstatus
            }
            parcelstatus = self.parcelStatus(Status: Status)
            if let riderID =  array["rider_id"] as? Int{
                riderIdStr = riderID
                if riderLive == "Yes"{
                    self.countArray.add("215")
                    self.countArray.replaceObject(at: index, with: "215")
                }else{
                    self.countArray.add("185")
                    self.countArray.replaceObject(at: index, with: "185")
                }
                self.riderIdArray.add(riderIdStr)
            }else{
                self.countArray.add("155")
                self.countArray.replaceObject(at: index, with: "155")
                self.riderIdArray.add("")
            }
            if let riderfirstname = array["firstname"] as? String{
                riderFirstName = riderfirstname
            }
            if let riderlaststname = array["lastname"] as? String{
                riderLastName = riderlaststname
            }
            if self.not_parcelId == parcel_id{
                let parcelData = parcelHistoryDetails()
                parcelData.parcel_id = parcel_id
                parcelData.bookingtime = str
                parcelData.deliveryMode = deliveryMode
                parcelData.status = parcelstatus
                parcelData.riderId = riderIdStr
                parcelData.riderFirstName = riderFirstName
                parcelData.riderLastName = riderLastName
                parcelData.riderLiveStatus = riderLive
                self.parcelListArray.replaceObject(at: index, with: parcelData)
                let indexPath = NSIndexPath(row: index, section: 0)
                self.parcelHistoryTable.reloadRows(at: [indexPath as IndexPath], with: UITableView.RowAnimation.none)
            }
        }
    }
    
    func parcelStatus(Status:Int)-> String{
        var parcelStatus = ""
        if Status  == 1{
            parcelStatus = "Picked Up"
        }else if Status  == 2{
            parcelStatus = "Out for Delivery"
        }else if Status  == 8{
            parcelStatus = "Waiting for pickup"
        }else if Status  == 11{
            parcelStatus = "Delivered"
        }else if Status == 12{
            parcelStatus = "Not Delivered"
        }else if Status ==  14{
            parcelStatus = "Not Picked Up"
        }else if Status ==  15{
            parcelStatus = "Cancelled"
        }
        return parcelStatus
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    func getAllParcelsapi(){
        if self.ineternetAlert() == false{
            return
        }else{
            if Constants.getValueFromUserDefults(for:"customer_id") as? String == nil{
            }else{
                IJProgressView.shared.showProgressView(view)
                var bodyReq = [String:String]()
                var cust_id = String()
                cust_id = Constants.getValueFromUserDefults(for:"customer_id") as! String
                bodyReq = ["customer_id":cust_id]
                var token = String()
                var reultanttoken = ""
                if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
                    token = Constants.getValueFromUserDefults(for: "usertoken") as! String
                    reultanttoken = "Bearer" + " " + token
                }
                if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                    APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.allParcelURL , method: "POST", token:reultanttoken, body: "", productBody: bodyData as NSData) { (data,error,response) in
                        
                        if let httpResponse = response as? HTTPURLResponse{
                           // print("httpResponse status code \(httpResponse.statusCode)")
                            switch(httpResponse.statusCode){
                            case 200:
                                if let receivedData = data{
                                    do{
                                        let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                        DispatchQueue.main.async {
                                            IJProgressView.shared.hideProgressView()
                                            self.responseApi(response: resultDic as! [String : Any])
                                        }
                                    }catch {
                                        DispatchQueue.main.async {
                                            IJProgressView.shared.hideProgressView()
                                            self.refreshControl.endRefreshing()
                                            self.diplayStatus(status: NSLocalizedString("ver_noparcelfound", comment: ""))
                                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                        }
                                    }
                                }
                                break
                            case 500:
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                self.refreshControl.endRefreshing()
                                self.diplayStatus(status: NSLocalizedString("ver_noparcelfound", comment: ""))
                                errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                }
                                break
                            case 505:
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                self.refreshControl.endRefreshing()
                                self.diplayStatus(status: NSLocalizedString("ver_noparcelfound", comment: ""))
                                if self.parcelListArray.count != 0{
                                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                }
                                }
                                break
                            case 506:
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                self.refreshControl.endRefreshing()
                                self.diplayStatus(status: NSLocalizedString("error_failedtogetparcelhistory", comment: ""))
                                if self.parcelListArray.count != 0{
                                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                }
                                }
                                break
                            case 498:
                                DispatchQueue.main.async {
                                    self.tokenExpireAlert()
                                }
                                break
                            default:
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                self.refreshControl.endRefreshing()
                                self.diplayStatus(status: NSLocalizedString("ver_somethingwrong", comment: ""))
                                if self.parcelListArray.count != 0{
                                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                }
                                }
                            }
                        }else{
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            self.refreshControl.endRefreshing()
                            self.diplayStatus(status: NSLocalizedString("ver_somethingwrong", comment: ""))
                            if self.parcelListArray.count != 0{
                                errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                            }
                        }
                    }
                }
            }
        }
    }
    func responseApi(response:[String : Any]){
       // print("/Parcel/allParcels",response)
        self.refreshControl.endRefreshing()
        self.countArray.removeAllObjects()
        self.parcelListArray.removeAllObjects()
        self.statusLbl.isHidden = true
        self.parcelHistoryTable.isHidden = false
        let newArray  = response["Msg"] as? [[String:Any]]
        for array in newArray! {
            var parcel_id = ""
            var bookingtime = ""
            var  delimode = 0
            var deliveryMode = ""
            var str = ""
            var Status = 0
            var parcelstatus = ""
            var riderIdStr = 0
            var riderFirstName = ""
            var riderLastName = ""
            var riderLive = ""
            if let id = array["parcel_id"] as? String{
                parcel_id = id
               // print(parcel_id)
            }
            if let parcelLive = array["live_tracking"] as? String{
                riderLive = parcelLive
            }
            if let  time = array["created_datetime"] as? String{
                bookingtime = time
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
                let date = formatter.date(from: bookingtime)
                let formatter1 = DateFormatter()
                formatter1.dateFormat = "HH:mm:ss dd-MM-yyyy"
                str = formatter1.string(from:date!)
            }
            if let deliverymode = array["parcel_fk_delivery_option_id"] as? Int{
                delimode = deliverymode
            }
            if delimode == 1{
                deliveryMode = "Express"
            }
            if delimode == 2{
                deliveryMode = "Normal"
            }
            if let parcelstatus =  array["parcel_fk_status"] as? Int{
                Status = parcelstatus
            }
            if Status == 1{
                parcelstatus = "Picked Up"
            }
            if Status == 2{
                parcelstatus = "Out for Delivery"
            }
            if Status == 8{
                parcelstatus = "Waiting for pickup"
            }
            if Status == 11{
                parcelstatus = "Delivered"
            }
            if Status == 12{
                parcelstatus = "Not Delivered"
            }
            if Status == 14{
                parcelstatus = "Not Picked Up"
            }
            if Status == 15{
                parcelstatus = "Cancelled"
            }
            //print("parcelstatus :::",parcelstatus)
            if let riderID =  array["rider_id"] as? Int{
                riderIdStr = riderID
                if riderLive == "Yes"{
                    self.countArray.add("215")
                }else{
                    self.countArray.add("185")
                }
                self.riderIdArray.add(riderIdStr)
            }else{
                self.countArray.add("155")
                self.riderIdArray.add("")
            }
            if let riderfirstname = array["firstname"] as? String{
                riderFirstName = riderfirstname
            }
            if let riderlaststname = array["lastname"] as? String{
                riderLastName = riderlaststname
            }
            let parcelData = parcelHistoryDetails()
            parcelData.parcel_id = parcel_id
            parcelData.bookingtime = str
            parcelData.deliveryMode = deliveryMode
            parcelData.status = parcelstatus
            parcelData.riderId = riderIdStr
            parcelData.riderFirstName = riderFirstName
            parcelData.riderLastName = riderLastName
            parcelData.riderLiveStatus = riderLive
            self.parcelListArray.add(parcelData)
        }
        self.diplayStatus(status: NSLocalizedString("ver_noparcelfound", comment: ""))
    }
    
    func diplayStatus(status:String){
        if self.parcelListArray.count == 0{
            self.parcelHistoryTable.isHidden = true
            self.statusLbl.isHidden = false
            self.statusLbl.text = NSLocalizedString(status, comment:"")
        }else{
            self.statusLbl.isHidden = true
            self.parcelHistoryTable.isHidden = false
            self.parcelHistoryTable.reloadData()
        }
    }
}

