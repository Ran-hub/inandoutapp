//
//  PickUpAddressTableViewCell.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 28/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class PickupAddressTC: UITableViewCell {

    @IBOutlet weak var selectedBtn : UIView!
    @IBOutlet weak var selectedView : UIView!
    @IBOutlet weak var unSelectedView : UIView!
    @IBOutlet weak var borderlbl : UILabel!
    @IBOutlet weak var usernameLbl : UILabel!
    @IBOutlet weak var addresssLbl : UILabel!
    @IBOutlet weak var zipcodeLbl : UILabel!
    @IBOutlet weak var contactLbl : UILabel!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var addressLblHeight: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
