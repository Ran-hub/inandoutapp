//
//  ForgotPasswordViewController.swift
//  RYTLE
//
//  Created by pavan on 08/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import Firebase

class ForgotPasswordVC: UIViewController,UITextFieldDelegate,UIScrollViewDelegate{
    
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var mobileField: UITextField!
    @IBOutlet weak var scrollViewObj: UIScrollView!
    @IBOutlet weak var bgImg: UIImageView!
    @IBOutlet weak var logoImg: UIImageView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var logoHeightHC: NSLayoutConstraint!
    @IBOutlet weak var logoWidthWC: NSLayoutConstraint!
    @IBOutlet weak var logoTopTC: NSLayoutConstraint!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var titleLblCC: NSLayoutConstraint!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    var activeField: UITextField?
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var movement:CGFloat = 0
    
    override func viewDidLoad(){
        super.viewDidLoad()
        self.scrollViewObj.delegate = self
        initialSetUp()
        self.intialConstraintsSetup()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear (animated)
        self.deregisterFromKeyboardNotifications()
    }
    
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func initialSetUp(){
        if appdelegate.IS_IPADPRO9 || appdelegate.IS_IPADPRO10 || appdelegate.IS_IPADPRO12{
            self.contentView.removeConstraint(self.logoWidthWC)
            self.contentView.removeConstraint(self.logoHeightHC)
            self.contentView.removeConstraint(self.logoTopTC)
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.contentView, attribute: NSLayoutConstraint.Attribute.width, multiplier: 200/414, constant: 0))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.contentView, attribute: NSLayoutConstraint.Attribute.height, multiplier: 150/736, constant: 0))
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.bgImg, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1, constant: self.view.frame.size.height/7))
        }
        titleLbl.font = AppFont.boldTextFont
        if appdelegate.IS_IPHONE5{
            titleLbl.font = UIFont(name: "HelveticaNeue", size: 18)
            self.contentView.removeConstraint(self.logoTopTC)
            self.contentView.addConstraint(NSLayoutConstraint(item: self.emailField, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.logoImg, attribute: .bottom, multiplier: 1, constant: self.view.frame.size.height/9))
        }else if appdelegate.IS_IPHONEX{
            self.contentView.removeConstraint(self.logoWidthWC)
            self.contentView.removeConstraint(self.logoHeightHC)
            
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem:nil, attribute: .notAnAttribute, multiplier: 1, constant: 250))
            
            self.contentView.addConstraint(NSLayoutConstraint(item: self.logoImg, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem:nil, attribute: .notAnAttribute, multiplier: 1, constant: 160))
        }
        
        titleLbl.text = NSLocalizedString("lbl_forgot",comment:"")
        titleLbl.textColor = AppColors.whiteColorRGB
        
        emailField.placeholder = NSLocalizedString("lbl_emailforgot",comment:"")
        emailField.font = AppFont.regularTextFont
        mobileField.placeholder = NSLocalizedString("lbl_phoneforgot",comment:"")
        mobileField.font = AppFont.regularTextFont
        mobileField.delegate = self
        emailField.delegate = self
        
        cancelButton.setTitle(NSLocalizedString("btn_cancel",comment:""),for:.normal)
        cancelButton.titleLabel?.font = AppFont.regularTextFont
        cancelButton.titleLabel?.textColor = AppColors.greenColorRGB
        
        submitButton.setTitle(NSLocalizedString("btn_sendOTP",comment:""),for:.normal)
        submitButton.titleLabel?.textColor = AppColors.whiteColorRGB
        submitButton.titleLabel?.font = AppFont.boldTextFont
        submitButton.backgroundColor = AppColors.greenColorRGB
        self.registerForKeyboardNotifications()
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        self.bgImg.isUserInteractionEnabled = true
        self.bgImg.addGestureRecognizer(tapGestureRecognizer)
        self.languageValidationForGermany()
        //test
    }
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        //self.dismissKeypad()
       // self.scrollViewObj.isScrollEnabled = false
        self.emailField.resignFirstResponder()
        self.mobileField.resignFirstResponder()
    }
    func dismissKeyboard(){
        self.scrollViewObj.isScrollEnabled = false
        self.emailField.resignFirstResponder()
        self.mobileField.resignFirstResponder()
    }
    func languageValidationForGermany(){
        let languageCode = Constants.getValueFromUserDefults(for: "languageCode") as! String
        if languageCode == "Yes"{
            self.languageValidationForGermany(headerView: self.headerView, cancelBtn: self.cancelButton, labelConstraints: self.titleLblCC, titleLbl: self.titleLbl)
        }
    }
    override func viewWillAppear(_ animated: Bool){
        if self.ineternetAlert() == false{
            return
        }
    }
    @IBAction func cancelAction(_ sender: Any) {
        Analytics.logEvent("ForgotPasswordVC_CancelButtonTapped", parameters: nil)
        self.dismiss(animated:true,completion:nil)
    }
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        self.scrollViewObj.isScrollEnabled = true
        var info = notification.userInfo!
        var keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        if keyboardSize?.height == 0{
            keyboardSize?.height = 260
        }
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: keyboardSize!.height+50, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollViewObj.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
    }
    @objc func keyboardWillBeHidden(notification: NSNotification){
        let contentInsets : UIEdgeInsets = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        self.scrollViewObj.contentInset = contentInsets
    }
    func textFieldDidBeginEditing(_ textField: UITextField){
        if textField == self.emailField{
            textField.returnKeyType = .next
        }else if textField == self.mobileField{
            textField.returnKeyType = .next
            self.mobileField.keyboardType = .numberPad
            let keyPadToolBar = UIToolbar()
            keyPadToolBar.barStyle = UIBarStyle.blackTranslucent
            keyPadToolBar.barTintColor = AppColors.greenColorRGB
            keyPadToolBar.sizeToFit()
            let DoneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(ForgotPasswordVC.dismissKeypad))
            DoneButton.tintColor = AppColors.whiteColorRGB
            keyPadToolBar.setItems([DoneButton], animated: true)
            mobileField.inputAccessoryView = keyPadToolBar
        }
        self.activeField = textField
    }
    func textFieldDidEndEditing(_ textField: UITextField){
        self.activeField = nil
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        switch textField{
        case self.emailField:
            self.mobileField.becomeFirstResponder()
            break
        case self.mobileField:
            textField.resignFirstResponder()
            break
        default:
            textField.resignFirstResponder()
        }
        return true
    }
    @objc func dismissKeypad(){
        self.mobileField.resignFirstResponder()
    }
    func resignTextFields(){
        self.mobileField.resignFirstResponder()
        self.emailField.resignFirstResponder()
    }
    @IBAction func submitAction(_ sender: Any){
        Analytics.logEvent("ForgotPasswordVC_ForgotPaswordButtonTapped", parameters: nil)
        self.resignTextFields()
        if self.ineternetAlert() == false{
            return
        }
        if emailField.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("valid_email", comment: ""), completion: {(result) in
                self.emailField.becomeFirstResponder()
            })
        }else if Constants().isValidEmail(emailField.text!) == false{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("valid_email1", comment: ""), completion: {(result) in
                self.emailField.becomeFirstResponder()
            })
        }else if mobileField.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("valid_phno", comment: ""), completion: {(result) in
                self.mobileField.becomeFirstResponder()
            })
        }else{
            if UserDefaults.standard.value(forKey: "customerOrgid") as? String == nil{
                self.orgnaizationAPi(completion:{(result) in
                    DispatchQueue.main.async {
                        self.forgotPasswordApi(orgId: result)
                    }
                })
            }else{
                var orgId = ""
                orgId = Constants.getValueFromUserDefults(for:"customerOrgid") as! String
                self.forgotPasswordApi(orgId: orgId)
            }
        }
    }
    func forgotPasswordApi(orgId : String){
        IJProgressView.shared.showProgressView(self.view)
        var bodyReq = [String:String]()
        bodyReq = ["email":emailField.text!,"org_id":orgId]
        //print("bodyReq",bodyReq)
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.forgotPasswordURL, method: "POST", token: "", body: "", productBody: bodyData as NSData) { (data,error,response) in
                if let httpResponse = response as? HTTPURLResponse{
                   // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        if let receivedData = data{
                            do{
                                let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    self.responseApi(response: resultDic as! [String : Any])
                                }
                            }catch{
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                }
                            }
                        }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "FP_505", controller: self)
                        }
                        break
                    case 507:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "FP_507", controller: self)
                        }
                        break
                    default:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                  }
                }
            }
        }
    }
    func responseApi(response : [String : Any]){
        if let status = response["status"] as? Bool {
            if status == true{
                    Constants.setValueInUserDefaults(objValue:self.emailField.text! , for:"forgotEmail")
                    Constants.setValueInUserDefaults(objValue:self.mobileField.text! , for:"forgotMobile")
                    let alertController = UIAlertController(title: NSLocalizedString("Rytle", comment: ""), message:NSLocalizedString("success_mailsuccessfullysent", comment:""), preferredStyle: UIAlertController.Style.alert)
                    alertController.addAction(UIAlertAction(title: NSLocalizedString("lbl_ok", comment: ""), style: UIAlertAction.Style.default,handler: { action in
                        self.emailField.text = ""
                        self.mobileField.text = ""
                        let nextViewController = self.storyboard?.instantiateViewController(withIdentifier: "VerifyOtpVC") as! VerifyOtpVC
                        self.present(nextViewController, animated: true, completion:nil)
                    }
                    ))
                    self.present(alertController, animated: false, completion: nil)
            }
        }
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    public func scrollViewDidScroll(_ scrollView: UIScrollView){
        scrollView.isScrollEnabled = false
    }
    
}


