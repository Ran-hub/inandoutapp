//
//  ProfileViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 24/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import Photos
import PhotosUI

struct CountryPofile
{
    var code: String?
    var name: String?
    var phoneCode: String?
    
    init(code: String?, name: String?, phoneCode: String?) {
        self.code = code
        self.name = name
        self.phoneCode = phoneCode
    }
}


class ProfileV: UIViewController,UISearchBarDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
    
    @IBOutlet weak var personalLabel: UILabel!
    @IBOutlet weak var countryViewBottom: NSLayoutConstraint!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var scrollViewObj: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet var profilePicImg: UIImageView!
    @IBOutlet weak var usernameLbl: UILabel!
    @IBOutlet weak var firstNameTxt: UITextField!
    @IBOutlet weak var lastNameTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var contactNoTxt: UITextField!
    @IBOutlet weak var orgnaisationTxt: UITextField!
    @IBOutlet weak var custtypeTxt: UITextField!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var updateBtn: UIButton!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var regTableView: UITableView!
    @IBOutlet var countrycodeView: UIView!
    @IBOutlet weak var countryCodeTxt: UITextField!
    @IBOutlet weak var countryButton: UIButton!
    @IBOutlet weak var countryView: UIView!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    let picker = UIImagePickerController()
    var isSearching = false
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var cust_type = ""
    var activeField: UITextField?
    var ModalArray = NSMutableArray()
    var countries = [CountryPofile]()
    var filteredphonecodeArray = NSMutableArray()
    var filteredcodeArray : NSMutableArray = NSMutableArray()
    var nameArray : NSMutableArray = NSMutableArray()
    var filteredArray:[String] = []
    var countrycodeArray : NSMutableArray = NSMutableArray()
    var phonecodeArray : NSMutableArray = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        countryCodeTxt.isUserInteractionEnabled = false
        countryButton.isUserInteractionEnabled = false
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ProfileV.showPhotoAndCamera(_:)))
        self.profilePicImg.isUserInteractionEnabled = false
        self.profilePicImg.addGestureRecognizer(tapGestureRecognizer)
        getProfileApi()
        regTableView.delegate = self
        regTableView.dataSource = self
        self.initialSetUp()
        self.intialConstraintsSetup()
        countryView.isHidden = true
        countries = countryNamesByCode()
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    
    func countryNamesByCode() -> [CountryPofile] {
        var countries = [CountryPofile]()
        
        do{
            if let file = Bundle.main.url(forResource: "countryCodes", withExtension: "json") {
                let data = try Data(contentsOf: file)
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                if let object = json as? [String: Any] {
                    // json is a dictionary
                    
                } else if let object = json as? [Any] {
                    // json is an array
                    for jsonObject in object {
                        
                        guard let countryObj = jsonObject as? NSDictionary else {
                            return countries
                        }
                        guard let code = countryObj["code"] as? String, let phoneCode = countryObj["dial_code"] as? String, let name = countryObj["name"] as? String else {
                            return countries
                        }
                        nameArray.add(name)
                        
                        let country = CountryPofile(code: code, name: name, phoneCode: phoneCode)
                        countries.append(country)
                        
                    }
                    
                    // print(object)
                } else {
                    // print("JSON is invalid")
                }
            } else {
                // print("no file")
            }
        }
        catch {
            print(error.localizedDescription)
        }
        return countries
    }
    
    func resignKeyBoard(){
        
        firstNameTxt.resignFirstResponder()
        lastNameTxt.resignFirstResponder()
        emailTxt.resignFirstResponder()
        contactNoTxt.resignFirstResponder()
        custtypeTxt.resignFirstResponder()
        orgnaisationTxt.resignFirstResponder()
    }
    
    func editProfilePicAction() {
        
        let optionMenuController = UIAlertController(title: nil, message: "", preferredStyle: .actionSheet)
        
        // Create UIAlertAction for UIAlertController
        
        let cameraAction = UIAlertAction(title: "Camera", style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            self.camera()
        })
        let gallerAction = UIAlertAction(title: "Photo Library", style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            self.photolibrary()
            
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            
        })
        
        // Add UIAlertAction in UIAlertController
        optionMenuController.addAction(cameraAction)
        optionMenuController.addAction(gallerAction)
        optionMenuController.addAction(cancelAction)
        
        // Present UIAlertController with Action Sheet
        
        self.present(optionMenuController, animated: true, completion: nil)
    }
    
    func showPhotoAndCamera(_ sender:AnyObject){
        // print("you tap image number : \(sender.view.tag)")
        self.editProfilePicAction()
    }
    
    func photolibrary(){
        picker.delegate = self
        picker.allowsEditing = false
        picker.sourceType = .photoLibrary
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(picker, animated: true, completion: nil)
    }
    
    func camera(){
        
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            picker.delegate = self
            picker.allowsEditing = false
            picker.sourceType = UIImagePickerControllerSourceType.camera
            picker.cameraCaptureMode = .photo
            picker.modalPresentationStyle = .fullScreen
            present(picker,animated: true,completion: nil)
        } else {
            noCamera()
        }
    }
    func noCamera(){
        let alertVC = UIAlertController(
            title: "No Camera",
            message: "Sorry, this device has no camera",
            preferredStyle: .alert)
        let okAction = UIAlertAction(
            title: NSLocalizedString("lbl_ok", comment: ""),
            style:.default,
            handler: nil)
        alertVC.addAction(okAction)
        present(
            alertVC,
            animated: true,
            completion: nil)
    }
    
    
    override func viewDidLayoutSubviews() {
        
        DispatchQueue.main.async {
            self.scrollViewObj.translatesAutoresizingMaskIntoConstraints = true
            self.scrollViewObj.contentSize = CGSize(width: self.scrollViewObj.frame.width, height: self.contentView.frame.origin.y+self.contentView.frame.size.height);
        }
    }
    func dismissSearchKeyboard(){
        
        searchBar.resignFirstResponder()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar)
    {
        countryViewBottom.constant = 216+20+5 - countryViewBottom.constant
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar)
    {
        searchBar.resignFirstResponder()
        self.searchBar.endEditing(true)
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        if searchBar.text == "" || searchBar.text == nil{
            isSearching = false
            regTableView.reloadData()
        }
        else{
            self.phonecodeArray = [];
            self.countrycodeArray = [];
            self.filteredArray = [];
            
            let searchPredicate = NSPredicate(format: "SELF beginswith[c] %@",searchBar.text!)
            
            filteredArray = (nameArray.filtered(using: searchPredicate) as NSMutableCopying) as! [String]
            
            for index in filteredArray{
                
                var name = ""
                
                name = index
                
                for country in countries{
                    if name == country.name{
                        self.phonecodeArray.add(country.phoneCode!)
                        self.countrycodeArray.add(country.code!)
                    }
                }
                
            }
            if(filteredArray.count == 0){
                isSearching = false;
            } else {
                isSearching = true;
            }
            self.regTableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if isSearching == true
        {
            return  filteredArray.count
        }
        else
        {
            return countries.count
        }
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CountryTableViewCell", for: indexPath) as! CountryTableViewCell
        
        if isSearching  == true{
            
            let countrycode =  "(" + (countrycodeArray[indexPath.row] as? String)! + ")"
            let newcountry = (filteredArray[indexPath.row] as? String)!
                + countrycode
            cell.countryNameLbl.text = newcountry
            cell.countryCodeLbl.text = phonecodeArray[indexPath.row] as? String
            
        }
        else
        {
            let country = countries[indexPath.row]
            let countrycode = "(" + country.code! + ")"
            cell.countryNameLbl.text = country.name! + countrycode
            cell.countryCodeLbl.text = country.phoneCode
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        countryViewBottom.constant = 20
        if isSearching == true
        {
            isSearching = false
            self.searchBar.resignFirstResponder()
            let code = phonecodeArray[indexPath.row] as? String
            self.countryCodeTxt.text = code
            self.countryView.isHidden = true
            self.phonecodeArray = [];
            self.countrycodeArray = [];
            self.filteredArray = [];
            
        }
        else
        {
            isSearching = false
            let country = countries[indexPath.row]
            let code = country.phoneCode
            self.countryCodeTxt.text = code
            self.countryView.isHidden = true
            self.searchBar.resignFirstResponder()
            
        }
        self.regTableView.reloadData()
    }
    func initialSetUp()
    {
        searchBar.returnKeyType = .done
        searchBar.delegate = self
        
        self.regTableView.register(UINib(nibName: "CountryTableViewCell", bundle: nil), forCellReuseIdentifier: "CountryTableViewCell")
        
        
        if appdelegate.IS_IPHONE5
        {
            
        }
        
        self.usernameLbl?.textColor = AppColors.greenColorRGB
        self.editButton.setTitle(NSLocalizedString("btn_edit", comment: ""), for:.normal)
        self.editButton.titleLabel?.textColor = AppColors.greenColorRGB
        self.editButton.titleLabel?.font = AppFont.regularTextFont
        self.titleLbl.text = NSLocalizedString("lbl_profile", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        
        self.titleLbl.textColor = AppColors.whiteColorRGB
        
        self.personalLabel.text = NSLocalizedString("lbl_peronal", comment: "")
        self.personalLabel.font = AppFont.regularTextFont
        
        self.personalLabel.textColor = AppColors.blackColorRGB
        self.firstNameTxt.placeholder = NSLocalizedString("txt_firstname", comment: "")
        self.firstNameTxt.font = AppFont.regularTextFont
        
        self.lastNameTxt.placeholder = NSLocalizedString("txt_lastname", comment: "")
        self.lastNameTxt.font = AppFont.regularTextFont
        
        self.contactNoTxt.placeholder = NSLocalizedString("txt_mobileno", comment: "")
        self.lastNameTxt.font = AppFont.regularTextFont
        
        self.emailTxt.placeholder = NSLocalizedString("txt_eamil", comment: "")
        self.emailTxt.font = AppFont.regularTextFont
        
        self.custtypeTxt.placeholder = NSLocalizedString("lbl_custtype", comment: "")
        self.custtypeTxt.font = AppFont.regularTextFont
        
        self.orgnaisationTxt.placeholder = NSLocalizedString("txt_organisation", comment: "")
        self.orgnaisationTxt.font = AppFont.regularTextFont
        
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        
        
        profilePicImg.layer.masksToBounds = true
        profilePicImg.layer.cornerRadius =  profilePicImg.frame.size.width/2
        
        if UserDefaults.standard.value(forKey: "propic") as? NSData == nil
        {
            profilePicImg.image = UIImage.init(named: "icon_profile")
        }
        else
        {
            let propicdata = UserDefaults.standard.object(forKey: "propic") as! NSData
            profilePicImg.image = UIImage(data: propicdata as Data)
        }
        
        self.registerForKeyboardNotifications()
        firstNameTxt.isUserInteractionEnabled = false
        lastNameTxt.isUserInteractionEnabled = false
        emailTxt.isUserInteractionEnabled = false
        contactNoTxt.isUserInteractionEnabled = false
        custtypeTxt.isUserInteractionEnabled = false
        orgnaisationTxt.isUserInteractionEnabled = false
        firstNameTxt.delegate = self
        lastNameTxt.delegate = self
        emailTxt.delegate = self
        contactNoTxt.delegate = self
        custtypeTxt.delegate = self
        orgnaisationTxt.delegate = self
        
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear (animated)
        self.deregisterFromKeyboardNotifications()
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnsTapped(_ sender : UIButton)
    {
        let btn = sender as UIButton
        
        if btn.tag == 10
        {
            self.resignKeyBoard()
            self.dismiss(animated: true, completion: nil)
            
        }else if btn.tag == 20
            
        {
            self.resignKeyBoard()
            updateProfileAddress()
        }
        else if btn.tag == 100{
            self.resignKeyBoard()
            self.isSearching = false
            self.searchBar.text = ""
            self.countryView.isHidden = false
        }
    }
    
    func updateProfileAddress()
    {
        if firstNameTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("valid_firstname", comment: ""), completion: {(result) in
                self.editButton.setTitle(NSLocalizedString("btn_done1", comment: ""), for: .normal)
                self.editButton.tag = 60
                self.firstNameTxt.becomeFirstResponder()
            })
            return
        }
        else if lastNameTxt.text?.count == 0{
            
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("valid_lastname", comment: ""), completion: {(result) in
                self.editButton.setTitle(NSLocalizedString("btn_done1", comment: ""), for: .normal)
                self.editButton.tag = 60
                self.lastNameTxt.becomeFirstResponder()
            })
            
            return
        }
        else if self.contactNoTxt.text?.count == 0{
            
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("valid_mobileno", comment: ""), completion: {(result) in
                self.editButton.setTitle(NSLocalizedString("btn_done1", comment: ""), for: .normal)
                self.editButton.tag = 60
                self.contactNoTxt.becomeFirstResponder()
            })
            return
        }
        else if Constants().validatePhoneNumber(value: self.contactNoTxt.text!) == false{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("valid_mobileno1", comment: ""), completion: {(result) in
                self.contactNoTxt.becomeFirstResponder()
            })
        }
        else{
            updateprofile()
        }
    }
    
    func updateprofile(){
        
        if self.ineternetAlert() == false{
            return
        }
        IJProgressView.shared.showProgressView(view)
        var username = ""
        if Constants.getValueFromUserDefults(for:"customer_id") != nil{
            username = Constants.getValueFromUserDefults(for: "customer_id") as! String
        }
        var bodyReq = [String:String]()
        var mobilenum = ""
        mobilenum = self.countryCodeTxt.text! + " " + self.contactNoTxt.text!
        bodyReq = ["customer_id":username,"firstname":self.firstNameTxt.text!,"lastname":self.lastNameTxt.text!,"email":emailTxt.text!,"mobile":mobilenum,"cust_type":self.custtypeTxt.text!]
        print("bodyreq",bodyReq)
        var reultanttoken = ""
       
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            let token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            reultanttoken = "Bearer" + " " + token
        }
        
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:"/CustomerAuth/editCustomerProfile" , method: "POST", token:reultanttoken, body: "", productBody: bodyData as NSData) { (result, error) in
                
                if let Result = result as? [String:Any]{
                     print("Result",Result)
                    if let status = Result["status"] as? Bool {
                        if status == true{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                let finalName = self.firstNameTxt.text!.capitalizedFirst() + " " + self.lastNameTxt.text!.capitalizedFirst()
                                self.usernameLbl.text = finalName
                                Constants.setValueInUserDefaults(objValue:finalName , for:"finalname")
                                self.showAlertMessagewithAction(titleStr:NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("ver_profileupdate", comment: ""), completion: {(result) in
                                    self.dismiss(animated: true, completion: nil)
                                })
                                
                            })
                        }
                        if status == false{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.displayAlert(message: NSLocalizedString("ver_profileupdatefailure", comment: ""))
                            })
                        }
                    }
                    else
                    {
                        if Result["code"] as? String == "InvalidCredentials"
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.tokenExpireAlert()
                            })
                        }
                    }
                }
                else
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                        self.displayAlert(message: NSLocalizedString("ver_internet", comment: ""))
                    })
                    
                }
            }
        }
        
    }
    func displayAlert(message: String)
    {
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    
    func getProfileApi()
    {
        if self.ineternetAlert() == false
        {
            return
        }
        IJProgressView.shared.showProgressView(view)
        var username = ""
        if Constants.getValueFromUserDefults(for:"customer_id") != nil{
            username = Constants.getValueFromUserDefults(for: "customer_id") as! String
        }
        var bodyReq = [String:String]()
        
        bodyReq = ["customer_id":username]
        // print("bodyreq",bodyReq)
        var reultanttoken = ""
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            let token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            reultanttoken = "Bearer" + " " + token
        }
        
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
        {
            APICommnicationManager.sharedInstance.requestforAPI(service:"/CustomerAuth/getCustomerProfile" , method: "POST", token:reultanttoken, body: "", productBody: bodyData as NSData) { (result, error) in
                
                if let Result = result as? [String:Any]{
                    
                      print("CustomerAuth/getCustomerProfile ::: ",Result)
                    
                    if let status = Result["status"] as? Bool {
                        
                        if status == true
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                if let customerDetails = Result["customer_details"] as? [[String:Any]]{
                                    for array in customerDetails {
                                        if let firstname = array["firstname"] as? String{
                                            self.firstNameTxt.text =  firstname.capitalizedFirst()
                                        }
                                        if let custtype = array["cust_type"] as? String{
                                            self.cust_type = custtype
                                        }
                                        if let lastname = array["lastname"] as? String{
                                            self.lastNameTxt.text = lastname.capitalizedFirst()
                                        }
                                        if let email = array["email"] as? String{
                                            self.emailTxt.text = email
                                        }
                                        let name = self.firstNameTxt.text!.capitalizedFirst() + " " + self.lastNameTxt.text!.capitalizedFirst()
                                        self.usernameLbl.text = name
                                        
                                        if let mobile = array["mobile"] as? String{
                                            if let str1 = mobile.components(separatedBy: " ") as? [String]{
                                                let count = str1.count
                                                
                                                switch count {
                                                case 0:
                                                    break;
                                                case 1:
                                                    self.contactNoTxt.text = str1[0] as? String
                                                    break;
                                                case 2:
                                                    self.countryCodeTxt.text = str1[0] as? String
                                                    self.contactNoTxt.text = str1[1] as? String
                                                default:
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            })
                        }
                        if status == false{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.displayAlert(message: NSLocalizedString("cust_id doesnot exist", comment: ""))
                            })
                        }
                    }
                    else
                    {
                        if Result["code"] as? String == "InvalidCredentials"
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.tokenExpireAlert()
                            })
                        }
                    }
                    
                }
                else
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                        self.displayAlert(message: NSLocalizedString("ver_internet", comment: ""))
                        
                    })
                }
            }
        }
        
    }
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWasShown(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func deregisterFromKeyboardNotifications(){
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func keyboardWasShown(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        self.scrollViewObj.isScrollEnabled = true
        var info = notification.userInfo!
        var keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        if keyboardSize?.height == 0
        {
            keyboardSize?.height = 258
        }
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height+50, 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        
        var aRect : CGRect = self.view.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeField {
            if (!aRect.contains(activeField.frame.origin)){
                self.scrollViewObj.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
    }
    
    func keyboardWillBeHidden(notification: NSNotification)
    {
        //Once keyboard disappears, restore original positions
        // var info = notification.userInfo!
        // let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)
        self.scrollViewObj.contentInset = contentInsets
        self.scrollViewObj.scrollIndicatorInsets = contentInsets
        // self.scrollViewObj.scrollIndicatorInsets = UIEdgeInsetsMake(0.0, 0.0, -keyboardSize!.height, 0.0)
        //self.view.endEditing(true)
        // self.scrollViewObj.isScrollEnabled = true
        // self.scrollViewObj.contentSize = CGSize(width: self.scrollViewObj.frame.width, height: self.contentView.frame.origin.y+self.contentView.frame.size.height);
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField){
        
        if textField == self.firstNameTxt{
            self.firstNameTxt.returnKeyType = .next
        }else if textField == self.lastNameTxt{
            self.lastNameTxt.returnKeyType = .next
        }else if textField == self.contactNoTxt{
            self.contactNoTxt.returnKeyType = .next
            self.contactNoTxt.keyboardType = .numberPad
            self.addBarBtnToKeyboard(textfield: self.contactNoTxt)
        }else if textField == self.orgnaisationTxt{
            orgnaisationTxt.returnKeyType = .next
        }
        activeField = textField
    }
    
    func textFieldDidEndEditing(_ textField: UITextField){
        activeField = nil
        if textField == self.firstNameTxt{
            if self.firstNameTxt.text?.count == 0 || self.firstNameTxt.text == ""{
            }
            else{
                self.firstNameTxt.text = self.firstNameTxt.text!.capitalizedFirst()
            }
        }
        if textField == self.lastNameTxt{
            if self.lastNameTxt.text?.count == 0 || self.lastNameTxt.text == ""{
            }else{
                self.lastNameTxt.text = self.lastNameTxt.text!.capitalizedFirst()
            }
        }
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        switch textField
        {
        case self.firstNameTxt:
            self.lastNameTxt.becomeFirstResponder()
            break
        case self.lastNameTxt:
            contactNoTxt.becomeFirstResponder()
            break
        case self.contactNoTxt:
            break
        case self.orgnaisationTxt:
            textField.resignFirstResponder()
            break
        default:
            textField.resignFirstResponder()
        }
        return true
    }
    func addBarBtnToKeyboard(textfield : UITextField)
    {
        let keyPadToolBar = UIToolbar()
        keyPadToolBar.barStyle = UIBarStyle.blackTranslucent
        keyPadToolBar.barTintColor = AppColors.greenColorRGB
        keyPadToolBar.sizeToFit()
        let DoneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action: #selector(ProfileV.dismissKeypad))
        DoneButton.tintColor = AppColors.whiteColorRGB
        keyPadToolBar.setItems([DoneButton], animated: true)
        textfield.inputAccessoryView = keyPadToolBar
    }
    
    func dismissKeypad()
    {
        self.contactNoTxt.resignFirstResponder()
    }
    
    @IBAction func editAction(_ sender: UIButton)
    {
        if sender.tag == 50{
            sender.tag = 60
            countryButton.isUserInteractionEnabled = true
            self.resignKeyBoard()
            editButton.setTitle(NSLocalizedString("btn_done1", comment: ""), for: .normal)
            emailTxt.textColor = AppColors.greenColorRGB
            contactNoTxt.textColor = AppColors.greenColorRGB
            firstNameTxt.isUserInteractionEnabled = true
            lastNameTxt.isUserInteractionEnabled = true
            emailTxt.isUserInteractionEnabled = false
            contactNoTxt.isUserInteractionEnabled = true
            self.profilePicImg.isUserInteractionEnabled = true
            //orgnaisationTxt.isUserInteractionEnabled = true
            
        }
        else if sender.tag == 60{
            sender.tag = 50
            self.resignKeyBoard()
            updateProfileAddress()
            countryButton.isUserInteractionEnabled = false
            editButton.setTitle(NSLocalizedString("btn_edit", comment: ""), for: .normal)
            
        }
    }
    
    func profileUploadApi(pic : UIImage)
    {
        if self.ineternetAlert() == false
        {
            return
        }
        DispatchQueue.main.async {
            IJProgressView.shared.showProgressView(self.view)
        }
        let imageData: NSData = UIImageJPEGRepresentation(pic, 1)! as NSData
        let imageStr = imageData.base64EncodedString(options:.endLineWithCarriageReturn)
        
        var body = [String:AnyObject]()
        
        var username = ""
        if Constants.getValueFromUserDefults(for:"customer_id") != nil{
            username = Constants.getValueFromUserDefults(for: "customer_id") as! String
        }
        body = ["image":imageStr as AnyObject,"user_id": username as AnyObject]
        
        var authToken = ""
        if Constants.getValueFromUserDefults(for:"usertoken") != nil{
            authToken = Constants.getValueFromUserDefults(for:"usertoken") as! String
        }
        let authStr = "Bearer" + " "  + authToken
        appdelegate.imageUploadUrl = "yes"
        if let bodyData = try? JSONSerialization.data(withJSONObject: body, options:[])
        {
            APICommnicationManager.sharedInstance.requestforAPI(service:"/User/updateProfileimg", method: "POST", token:authStr, body: "", productBody: bodyData as NSData) { (result, error) in
                if  result != nil {
                    print("updateProfileimg :: ",result!)
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                        if let status = result!["status"] as? Bool{
                            if status == true{
                                var ImageURLStr = ""
                                if let imageURL = result!["img"] as? String
                                {
                                    ImageURLStr = imageURL
                                    ImageURLStr.removeFirst()
                                }
                                print(ImageURLStr)
                                Constants.setDataInUserDefaults(objValue: ImageURLStr, for: "profileImgLink")
                                self.profilePicImg.image = pic
                                self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("error_propicupdated", comment: ""), completion: {_ in
                                    //                                        let imageData: NSData = UIImageJPEGRepresentation(self.profilePicImg.image!, 1)! as NSData
                                    //                                        UserDefaults.standard.set(imageData, forKey: "propic")
                                })
                            }
                            if status == false{
                                DispatchQueue.main.async(execute: { () -> Void in
                                    IJProgressView.shared.hideProgressView()
                                    self.displayAlert(message: NSLocalizedString("error_propicfailure", comment: ""))
                                })
                            }
                        }
                        else
                        {
                            if result!["code"] as? String == "InvalidCredentials"
                            {
                                DispatchQueue.main.async(execute: { () -> Void in
                                    IJProgressView.shared.hideProgressView()
                                    self.tokenExpireAlert()
                                })
                            }
                        }
                        
                    })
                }
                else
                {
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                        self.displayAlert(message: NSLocalizedString("ver_internet", comment: ""))
                    })
                }
            }
        }
    }
}
extension ProfileV:UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        DispatchQueue.global().async {
            self.profileUploadApi(pic: chosenImage)
        }
        dismiss(animated:true, completion: nil) //5
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated:true, completion: nil)
    }
}


