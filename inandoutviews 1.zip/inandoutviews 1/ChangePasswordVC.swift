//
//  ChangePasswordVC.swift
//  RYTLERIDERAPP
//
//  Created by AMT on 2/6/18.
//  Copyright © 2018 Pavan. All rights reserved.
//

import UIKit
import Firebase

class ChangePasswordVC: UIViewController {

    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var oldPasswordTxt: ACFloatingTextfield!
    @IBOutlet weak var newPasswordTxt: ACFloatingTextfield!
    @IBOutlet weak var confirmPasswordTxt: ACFloatingTextfield!
    @IBOutlet weak var confirmBtn: UIButton!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblCC: NSLayoutConstraint!
    let appdelegate:AppDelegate=(UIApplication.shared.delegate as! AppDelegate)

    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetup()
        self.intialConstraintsSetupForIphoneX()
        self.germanLanguageValidation()
        self.gesturesSetup()
    }
    override func viewDidAppear(_ animated: Bool) {
        self.setBottomBorderToTextFields()
    }
    func gesturesSetup(){
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(swipeTapped(tapGestureRecognizer:)))
        self.view.isUserInteractionEnabled = true
        self.view.addGestureRecognizer(tapGestureRecognizer)
    }
    @objc func swipeTapped(tapGestureRecognizer: UITapGestureRecognizer){
        self.oldPasswordTxt.resignFirstResponder()
        self.newPasswordTxt.resignFirstResponder()
        self.confirmPasswordTxt.resignFirstResponder()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func initialSetup(){
        if appdelegate.IS_IPHONE5{
            titleLbl.font = AppFont.boldMediumTextFont
        }
        self.titleLbl.text = NSLocalizedString("lbl_changepassword", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        self.titleLbl.textColor = AppColors.whiteColorRGB
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel",comment:""),for:.normal)
        self.confirmBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.confirmBtn.titleLabel?.font = AppFont.boldTextFont
        self.confirmBtn.backgroundColor = AppColors.greenColorRGB
        self.confirmBtn.setTitle(NSLocalizedString("btn_confirm",comment:""),for:.normal)
        self.oldPasswordTxt.placeholder = NSLocalizedString("txt_oldpassword", comment: "")
        self.oldPasswordTxt.font = AppFont.regularTextFont
        self.newPasswordTxt.placeholder = NSLocalizedString("txt_newpassword", comment: "")
        self.newPasswordTxt.font = AppFont.regularTextFont
        self.confirmPasswordTxt.placeholder = NSLocalizedString("txt_cnfpassword", comment: "")
        self.confirmPasswordTxt.font = AppFont.regularTextFont
        self.setBottomBorderToTextFields()
    }
    func setBottomBorderToTextFields(){
        self.oldPasswordTxt = self.oldPasswordTxt.addBorderToTextField(textField: self.oldPasswordTxt) as? ACFloatingTextfield
        self.newPasswordTxt = self.newPasswordTxt.addBorderToTextField(textField: self.newPasswordTxt) as? ACFloatingTextfield
        self.confirmPasswordTxt = self.confirmPasswordTxt.addBorderToTextField(textField: self.confirmPasswordTxt) as? ACFloatingTextfield
    }
    func germanLanguageValidation(){
        let languageCode = Constants.getValueFromUserDefults(for: "languageCode") as! String
        if languageCode == "Yes"{
            self.languageValidationForGermany(headerView: self.headerView, cancelBtn: self.cancelBtn, labelConstraints: self.titleLblCC, titleLbl: self.titleLbl)
        }
    }
    func intialConstraintsSetupForIphoneX(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    @IBAction func btnsTapped(_ sender: UIButton) {
        if sender.tag == 10{
            Analytics.logEvent("ChangePasswordVC_CancelButtonTapped", parameters: nil)
            self.dismiss(animated: true, completion: nil)
        }else if sender.tag == 20{
            self.updatePassword()
        }
    }
    func updatePassword(){
        Analytics.logEvent("ChangePasswordVC_UpdatePasswordButtonTapped", parameters: nil)
        if self.ineternetAlert() == false{
            return
        }
        if self.oldPasswordTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("err_oldpassword", comment: ""), completion: {(result) in
                self.oldPasswordTxt.becomeFirstResponder()
            })
            return
        }else if newPasswordTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("err_newpassword", comment: ""), completion: {(result) in
                self.newPasswordTxt.becomeFirstResponder()
            })
            return
        }else if confirmPasswordTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("valid_invalidpwd", comment: ""), completion: {(result) in
                self.confirmPasswordTxt.becomeFirstResponder()
            })
            return
        }else if (self.confirmPasswordTxt.text?.count)! < 8 || (self.confirmPasswordTxt.text?.count)! > 20{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE", comment: ""), messageStr: NSLocalizedString("valid_passworddigits", comment: "") , completion: {(result) in
            })
        }/*else if self.newPasswordTxt.text != self.confirmPasswordTxt.text{
            self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("valid_invalidpwd", comment: ""))
        }else if self.oldPasswordTxt.text == self.confirmPasswordTxt.text{
            self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("err_passwordssame", comment: ""))
        }*/else if self.newPasswordTxt.text != self.confirmPasswordTxt.text{
            self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:NSLocalizedString("valid_invalidpwd", comment: ""))
        }else{
            self.updatePassordApi()
        }
    }
    func updatePassordApi(){
       
        IJProgressView.shared.showProgressView(view)
        var cust_id = ""
        if Constants.getValueFromUserDefults(for:"customer_id") as? String != nil{
            cust_id = Constants.getValueFromUserDefults(for:"customer_id") as! String
        }
        var bodyReq = [String:String]()
        bodyReq = ["customer_id":cust_id,"password":oldPasswordTxt.text!,"newPassword": newPasswordTxt.text!]
       // print("bodyReq",bodyReq)
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            var token = ""
            if UserDefaults.standard.value(forKey: "usertoken") != nil{
                token = UserDefaults.standard.value(forKey: "usertoken") as! String
            }
            let sessionStr = "Bearer " + token
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.changePasswordURL , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                
                if let httpResponse = response as? HTTPURLResponse{
                    IJProgressView.shared.hideProgressView()
                    //print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("err_successpassword",comment: ""), completion: {(result) in
                            self.dismiss(animated: true, completion: nil)
                        })
                        }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "CP_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "CP_506", controller: self)
                        }
                        break
                    case 507:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "CP_507", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                        break
                    default:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                    }
                }
            }
         }
    }
    func displayAlert(message : String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
}
extension ChangePasswordVC : UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField){
        if textField == self.oldPasswordTxt{
            textField.returnKeyType = .next
        }else if textField == self.newPasswordTxt{
            textField.returnKeyType = .next
        }else if textField == self.confirmPasswordTxt{
            textField.returnKeyType = .done
        }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string == " "{
            return false
        }else{
            return true
        }
        return true
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        switch textField{
        case self.oldPasswordTxt:
            self.newPasswordTxt.becomeFirstResponder()
            break
        case self.newPasswordTxt:
            self.confirmPasswordTxt.becomeFirstResponder()
            break
        case self.confirmPasswordTxt:
            textField.resignFirstResponder()
            break
        default:
            textField.resignFirstResponder()
        }
        return true
    }
}
