//
//  FeedbackViewController.swift
//  RYTLE
//
//  Created by pavan on 03/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import Firebase

class FeedBackVC: UIViewController {
    
    @IBOutlet weak var doneButton: UIButton!
    @IBOutlet weak var feedbacktextView: UITextView!
    @IBOutlet weak var firstButton: UIButton!
    @IBOutlet weak var secondButton: UIButton!
    @IBOutlet weak var thirdButton: UIButton!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var fourthButton: UIButton!
    @IBOutlet weak var fifthButton: UIButton!
    @IBOutlet weak var feedBackLabel: UILabel!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var headingLabel: UILabel!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    var parcel_id = ""
    var rating = ""
    let appdelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.isNavigationBarHidden = true
        initialSetup()
        self.intialConstraintsSetup()
        feedbacktextView.delegate = self
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    
    @IBAction func doneAction(_ sender: Any){
        Analytics.logEvent("FeedBackVC_SubmitFeedbackButtonTapped", parameters: nil)
        if self.rating == ""{
            self.displayAlert(message: NSLocalizedString("lbl_errorrating", comment: ""))
        }else{
            self.feedBackApi()
        }
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    @IBAction func cancelAction(_ sender: Any) {
        Analytics.logEvent("FeedBackVC_CancelButtonTapped", parameters: nil)
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func ratingButtonTapped(_ sender: UIButton) {
        
        doneButton.backgroundColor = UIColor(red: 94/255, green: 230/255, blue: 169/255, alpha: 1)
        
        if sender.tag == 10{
            //sender.setImage(UIImage(named:"icon_starselected"), for: .normal)
            
            firstButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            secondButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: UIControl.State.normal)
            
            thirdButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: UIControl.State.normal)
            
            fourthButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: UIControl.State.normal)
            
            fifthButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: UIControl.State.normal)
            
            
            self.rating = "1"
            // print(self.rating)
        }
        if sender.tag == 20{
            /* firstButton.setImage(UIImage(named:"icon_starselected"), for: .normal)
             sender.setImage(UIImage(named:"icon_starselected"), for: .normal)*/
            
            firstButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            secondButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            thirdButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: UIControl.State.normal)
            
            fourthButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: UIControl.State.normal)
            
            fifthButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: UIControl.State.normal)
            
            self.rating = "2"
            //print(self.rating)
        }
        if sender.tag == 30{
            /* firstButton.setImage(UIImage(named:"icon_starselected"),for: .normal)
             
             secondButton.setImage(UIImage(named:"icon_starselected"),for: .normal)
             sender.setImage(UIImage(named:"icon_starselected"), for: .normal)*/
            
            firstButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            secondButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            thirdButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            fourthButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: UIControl.State.normal)
            
            fifthButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: UIControl.State.normal)
            
            self.rating = "3"
            // print(self.rating)
            
        }
        if sender.tag == 40{
            
            /*firstButton.setImage(UIImage(named:"icon_starselected"),for: .normal)
             secondButton.setImage(UIImage(named:"icon_starselected"),for: .normal)
             thirdButton.setImage(UIImage(named:"icon_starselected"),for: .normal)
             sender.setImage(UIImage(named:"icon_starselected"), for: .normal)*/
            
            firstButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            secondButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            thirdButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            fourthButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            fifthButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: UIControl.State.normal)
            
            self.rating = "4"
            // print(self.rating)
        }
        if sender.tag == 50{
            /* firstButton.setImage(UIImage(named:"icon_starselected"),for: .normal)
             
             secondButton.setImage(UIImage(named:"icon_starselected"),for: .normal)
             thirdButton.setImage(UIImage(named:"icon_starselected"),for: .normal)
             fourthButton.setImage(UIImage(named:"icon_starselected"),for: .normal)
             sender.setImage(UIImage(named:"icon_starselected"), for: .normal)*/
            
            firstButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            secondButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            thirdButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            fourthButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            fifthButton.setBackgroundImage(UIImage(named:"icon_starselected"), for: UIControl.State.normal)
            
            self.rating = "5"
            //  print(self.rating)
        }
        
    }
    
    func initialSetup(){
        self.headingLabel.textColor = AppColors.whiteColorRGB
        self.headingLabel.font = AppFont.regularTextFont
        self.headingLabel.text = NSLocalizedString("btn_feedback",comment:"")
        self.cancelButton.titleLabel?.textColor = AppColors.greenColorRGB
        self.feedbacktextView.text  = NSLocalizedString("feeback_givefeedback", comment: "")
        self.feedbacktextView.textColor = AppColors.lightGrayColorRGB
        self.feedbacktextView.font = AppFont.regularSmallTextFont
        self.cancelButton.setTitle(NSLocalizedString("btn_cancel",comment:""),for:.normal)
        self.doneButton.titleLabel?.textColor = AppColors.whiteColorRGB
        self.doneButton.setTitle(NSLocalizedString("btn_done",comment:""),for:.normal)
        self.doneButton.titleLabel?.font = AppFont.boldTextFont
        self.headingLabel.font = AppFont.regularTextFont
        self.ratingLabel.font = AppFont.regularTextFont
        self.ratingLabel.text = NSLocalizedString("lbl_rating",comment:"")
        self.ratingLabel.textColor = AppColors.blackColorRGB
        self.feedBackLabel.font = AppFont.regularTextFont
        self.feedBackLabel.text = NSLocalizedString("lbl_riderfeedback",comment:"")
        self.feedBackLabel.textColor = AppColors.blackColorRGB
        doneButton.backgroundColor = AppColors.lightGrayColorRGB
        firstButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: .normal)
        secondButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: .normal)
        thirdButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: .normal)
        fourthButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: .normal)
        fifthButton.setBackgroundImage(UIImage(named:"icon_starunselected"), for: .normal)
        
    }
    func feedBackApi(){
        if self.ineternetAlert() == false{
            return
        }else{
            IJProgressView.shared.showProgressView(self.view)
            var bodyReq = [String:String]()
            var cust_id = String()
            cust_id = Constants.getValueFromUserDefults(for:"customer_id") as! String
            bodyReq = ["customer_id":cust_id,"parcel_id":self.parcel_id,"feedback":self.feedbacktextView.text!,"rating":self.rating]
              print("bodyReq",bodyReq)
            var token = String()
            var reultanttoken = ""
            if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
                token = Constants.getValueFromUserDefults(for: "usertoken") as! String
                reultanttoken = "Bearer" + " " + token
            }
            if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.feedBackURL, method: "POST", token:reultanttoken,body: "", productBody: bodyData as NSData) { (data,error,response) in
                    
                    if let httpResponse = response as? HTTPURLResponse{
                        print("httpResponse status code \(httpResponse.statusCode)")
                        switch(httpResponse.statusCode){
                        case 200:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            self.showAlertMessagewithAction(titleStr: NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("val_feedbacksuccess", comment: ""), completion: {(result) in
                                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
                                self.present(nextViewController, animated: true, completion: nil)
                            })
                            }
                            break
                        case 500:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                            break
                        case 505:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "FeedBack_505", controller: self)
                            }
                            break
                        case 498:
                            DispatchQueue.main.async {
                                self.tokenExpireAlert()
                            }
                            break
                        default:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                           errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                        }
                    }else{
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                          errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                       }
                    }
                }
            }
        }
    }
}
extension FeedBackVC:UITextViewDelegate{
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        textView.text = ""
        textView.returnKeyType = .done
        textView.textColor = AppColors.greenColorRGB
        return true
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        textView.returnKeyType = .done
        Constants().animateViewMoving(up: true, moveValue: 60,view:self.view)
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        
        if textView.text == ""{
            self.feedbacktextView.text  = NSLocalizedString("feeback_givefeedback", comment: "")
            textView.textColor = AppColors.lightGrayColorRGB
        }
        Constants().animateViewMoving(up:false, moveValue: 60,view:self.view)
    }
    
}




