//
//  GoogleNewAddressViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Shilpashree on 26/10/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces
import CoreLocation
import Firebase

class NewAddressVC: UIViewController,CLLocationManagerDelegate,UISearchBarDelegate{
    
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var searchBarObj: UISearchBar!
    @IBOutlet weak var mapViewObj: GMSMapView!
    @IBOutlet weak var addressViewHeightHC: NSLayoutConstraint!
    @IBOutlet weak var addressLblHeightHC: NSLayoutConstraint!
    @IBOutlet weak var addressLbl: UILabel!
    @IBOutlet weak var AddressView: UIView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var nextButton: UIButton!
    var controllerName : String = String()
    var latitude : String = String()
    var longitude : String = String()
    var addressArray = NSMutableArray()
    var apicount : CGFloat = 0
    @IBOutlet weak var iconView: UIImageView!
    @IBOutlet weak var addrssStatusLbl: UILabel!
    @IBOutlet weak var titleLblCC: NSLayoutConstraint!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    @IBOutlet weak var searchbarTC: NSLayoutConstraint!
    @IBOutlet weak var locationView: UIView!
    var pickuplat = ""
    var locationStatus = ""
    var pickuplong = ""
    var addressStr1 = ""
    var addressStr2 = ""
    var cityStr = ""
    var countryStr = ""
    var stateStr = ""
    var zipcodeStr = ""
    var fulladdressStr = ""
    var fulladdressStr1 = ""
    var houseno = ""
    var streetNoStr = ""
    var addressStr3 = ""
    var mapmove = Bool()
    var addressType = ""
    var pickupMarker = GMSMarker()
    var fromAutoSearch = false
    var curentlat = Double()
    var currentlong = Double()
    var center : CLLocationCoordinate2D = CLLocationCoordinate2D()
    var locationManager = CLLocationManager()
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad(){
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.searchBarObj.delegate = self
        self.initialSetUp()
        self.locationManagerSetup()
        self.mapViewSetup()
        self.intialConstraintsSetup()
        IJProgressView.shared.showProgressView(view)
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
            self.searchbarTC.constant = 36
        }
    }
    @IBAction func cancelAction(_ sender: Any){
        Analytics.logEvent("NewAddressVC_CancelButtonTapped", parameters: nil)
        self.controllerName = ""
        self.addressArray.removeAllObjects()
        self.dismiss(animated: true, completion: nil)
    }
    func heightForView(text:String, font:UIFont, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRect(x:0, y:0, width:width, height:10000))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    func languageValidationForGermany(){
        let languageCode = Constants.getValueFromUserDefults(for: "languageCode") as! String
        if languageCode == "Yes"{
            self.languageValidationForGermany(headerView: self.headerView, cancelBtn: self.cancelBtn, labelConstraints: self.titleLblCC, titleLbl: self.titleLbl)
        }
    }
    override func viewWillAppear(_ animated: Bool){
        if self.ineternetAlert() == false{
            return
        }
    }
    func initialSetUp(){
        if controllerName == "PickupDetails"{
            self.titleLbl.text = NSLocalizedString("lbl_pickupaddress", comment: "")
        }else if controllerName == "ReceiverDetails"{
            self.titleLbl.text = NSLocalizedString("lbl_receiverdetails", comment: "")
            if appdelegate.IS_IPHONE5 || appdelegate.IS_IPHONE6{
                self.languageValidationForGermany()
            }
        }else if controllerName == "EditPickupDetails"{
            self.titleLbl.text = NSLocalizedString("lbl_editaddress", comment: "")
            if appdelegate.IS_IPHONE5{
                self.languageValidationForGermany()
            }
        }else if controllerName == "EditReceiverDetails"{
            self.titleLbl.text = NSLocalizedString("lbl_editaddress", comment: "")
            if appdelegate.IS_IPHONE5{
                self.languageValidationForGermany()
            }
        }
        self.titleLbl.textColor = AppColors.whiteColorRGB
        self.titleLbl.font = AppFont.boldTextFont
        if appdelegate.IS_IPHONE5{
            self.titleLbl.font = UIFont(name: "HelveticaNeue", size: 18)
        }
        self.searchBarObj.placeholder = NSLocalizedString("lbl_searchaddress", comment: "")
        self.addrssStatusLbl.text = NSLocalizedString("lbl_addresschange", comment: "")
        self.addrssStatusLbl.font = AppFont.regularTextFont
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.nextButton.setTitle(NSLocalizedString("btn_continue", comment: ""), for: .normal)
        self.nextButton.titleLabel?.font = AppFont.boldTextFont
        self.nextButton.backgroundColor = AppColors.greenColorRGB
        self.nextButton.titleLabel?.textColor = AppColors.whiteColorRGB
        self.nextButton.backgroundColor = AppColors.lightGrayColorRGB
        self.nextButton.isUserInteractionEnabled = false
    }
    func locationManagerSetup(){
        locationManager = CLLocationManager()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestWhenInUseAuthorization()
        }
        locationManager.requestWhenInUseAuthorization()
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
        }
    }
    func mapViewSetup(){
        mapViewObj.isUserInteractionEnabled = true
        mapViewObj.isMyLocationEnabled = true
        mapViewObj.delegate = self
        nextButton.isHidden = false
        self.view.bringSubviewToFront(self.searchBarObj)
        self.mapViewObj.bringSubviewToFront(self.searchBarObj)
        mapViewObj.bringSubviewToFront(self.AddressView)
        mapViewObj.bringSubviewToFront(self.addrssStatusLbl)
        mapViewObj.bringSubviewToFront(self.headerView)
        mapViewObj.bringSubviewToFront(self.locationView)
        mapViewObj.bringSubviewToFront(self.nextButton)
        self.AddressView.isHidden = true
        self.addrssStatusLbl.isHidden = true
        mapViewObj.bringSubviewToFront(iconView)
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        let location = locations.last
        curentlat = (location?.coordinate.latitude)!
        currentlong = (location?.coordinate.longitude)!
        center.latitude = curentlat
        center.longitude = currentlong
        if self.controllerName == "EditPickupDetails" || self.controllerName == "EditReceiverDetails"{
            if apicount == 0{
                self.fromAutoSearch = true
                apicount += 1
                let latitude = self.addressArray.object(at: 0)as! String
                let longitude = self.addressArray.object(at: 1)as! String
                let addresLocation : CLLocation = CLLocation.init(latitude:Double(latitude)!, longitude: Double(longitude)!)
                self.mapViewObj.camera = GMSCameraPosition(target: addresLocation.coordinate, zoom: 17, bearing: 0, viewingAngle: 0)
                self.getAddressFromLatLon(coordinate: CLLocationCoordinate2D(latitude: (addresLocation.coordinate.latitude), longitude: (addresLocation.coordinate.longitude)))
            }
        }else {
            self.mapViewObj.camera = GMSCameraPosition(target: (location?.coordinate)!, zoom: 17, bearing: 0, viewingAngle: 0)
            if apicount == 0{
                self.fromAutoSearch = true
                apicount += 1
                self.getAddressFromLatLon(coordinate: CLLocationCoordinate2D(latitude: (location?.coordinate.latitude)!, longitude: (location?.coordinate.longitude)!))
            };
        }
        if locationStatus == "yes"{
            locationStatus = ""
            self.mapViewObj.camera = GMSCameraPosition(target: (location?.coordinate)!, zoom: 15, bearing: 0, viewingAngle: 0)
            self.fromAutoSearch = true
            self.getAddressFromLatLon(coordinate: CLLocationCoordinate2D(latitude: (location?.coordinate.latitude)!, longitude: (location?.coordinate.longitude)!))
        }
        self.locationManager.stopUpdatingLocation()
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error){
        print("\(error.localizedDescription)")
    }
    func getAddressFromLatLon(coordinate: CLLocationCoordinate2D){
        IJProgressView.shared.showProgressView(view)
        let geocode: GMSGeocoder = GMSGeocoder()
        geocode.reverseGeocodeCoordinate(coordinate, completionHandler:
            {(response, error) in
                IJProgressView.shared.hideProgressView()
                if (error != nil){
                //    print("reverse geodcode fail: \(error!.localizedDescription)")
                    self.pickuplat = ""
                    self.pickuplong = ""
                    self.fulladdressStr = ""
                    self.houseno  = ""
                    self.addressStr1 = ""
                    self.addressStr2 = ""
                    self.addressStr3 = ""
                    self.cityStr = ""
                    self.stateStr = ""
                    self.countryStr = ""
                    self.zipcodeStr = ""
                    self.streetNoStr = ""
                    self.searchBarObj.text = ""
                    self.self.addressLbl.text = ""
                    self.AddressView.isHidden = true
                    self.nextButton.backgroundColor = AppColors.lightGrayColorRGB
                    self.nextButton.isUserInteractionEnabled = false
                    self.displayAlert(message: (error?.localizedDescription)!)
                    return
                }
                if let address = response?.firstResult(){
                   // print(address)
                    self.pickuplat = ""
                    self.pickuplong = ""
                    self.AddressView.isHidden = false
                    if  self.fromAutoSearch == true{
                        self.addrssStatusLbl.isHidden = true
                    }else{
                        self.addrssStatusLbl.isHidden = false
                    }
                    let lines = address.lines
                    self.searchBarObj.text = lines?.joined(separator: "\n")
                    self.mapViewObj.animate(toLocation: CLLocationCoordinate2D(latitude:coordinate.latitude, longitude:coordinate.longitude))
                    self.mapViewObj.camera = GMSCameraPosition(target:CLLocationCoordinate2DMake(coordinate.latitude, coordinate.longitude), zoom: 17, bearing: 0, viewingAngle: 0)
                    self.pickuplat = String(coordinate.latitude)
                    self.pickuplong = String(coordinate.longitude)
                    self.fulladdressStr = ""
                    self.houseno  = ""
                    self.addressStr1 = ""
                    self.addressStr2 = ""
                    self.addressStr3 = ""
                    self.cityStr = ""
                    self.stateStr = ""
                    self.countryStr = ""
                    self.zipcodeStr = ""
                    self.streetNoStr = ""
                    if let address = address.lines as NSArray?{
                        if let addressStr = address[0] as? String{
                            self.fulladdressStr += addressStr
                        }
                        self.AddressView.isHidden = false
                        self.nextButton.backgroundColor = AppColors.greenColorRGB
                        self.nextButton.isUserInteractionEnabled = true
                        if let fullNameArr = self.fulladdressStr.components(separatedBy: ", ") as NSArray?{
                            switch fullNameArr.count{
                            case 0:
                                self.houseno = (fullNameArr[0] as? String)!
                                break
                            case 1:
                                self.self.houseno = (fullNameArr[0] as? String)!
                                break
                            case 2:
                                self.self.houseno = (fullNameArr[0] as? String)!
                                self.addressStr1 = (fullNameArr[1] as? String)!
                                break
                            case 3:
                                self.houseno = (fullNameArr[0] as? String)!
                                self.addressStr1 = (fullNameArr[1] as? String)!
                                self.self.addressStr2 = (fullNameArr[2] as? String)!
                                break
                            case 4:
                                self.houseno = (fullNameArr[0] as? String)!
                                self.addressStr1 = (fullNameArr[1] as? String)!
                                self.addressStr2 = (fullNameArr[2] as? String)!
                                self.addressStr3 = (fullNameArr[3] as? String)!
                                break
                            case 5:
                                self.houseno = fullNameArr[0] as! String
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)!
                                break
                            case 6:
                                self.houseno = fullNameArr[0] as! String
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)!
                                break
                            case 7:
                                self.houseno  = fullNameArr[0] as! String
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)!
                                break
                            case 8:
                                self.houseno  = fullNameArr[0] as! String
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)!
                                break
                            case 9:
                                self.houseno  = fullNameArr[0] as! String
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)! + ", " + (fullNameArr[8] as? String)!
                                break
                            case 10:
                                self.houseno  = fullNameArr[0] as! String
                                self.addressStr1 = fullNameArr[1] as! String
                                self.addressStr2 = fullNameArr[2] as! String
                                self.addressStr3 = (fullNameArr[3] as? String)! + ", " + (fullNameArr[4] as? String)! + ", " + (fullNameArr[5] as? String)! + ", " + (fullNameArr[6] as? String)! + ", " + (fullNameArr[7] as? String)! + ", " + (fullNameArr[8] as? String)! + ", " + (fullNameArr[9] as? String)!
                                break
                            default: break
                            }
                        }
                    }
                    self.cityStr = ""
                    self.stateStr = ""
                    self.countryStr = ""
                    self.zipcodeStr = ""
                    self.streetNoStr = ""
                    
              /*  if let locality = address.locality{
                        self.cityStr = locality
                    }
                    if let admistrateArea = address.administrativeArea{
                        self.stateStr = admistrateArea
                    }
                    if let country = address.country{
                        self.countryStr = country
                    }
                    if let zipcode = address.postalCode{
                        self.zipcodeStr = zipcode
                    }
                    if let streetno = address.thoroughfare{
                        self.streetNoStr = streetno
                    }*/
                    
                    self.addressLbl.text = ""
                    self.AddressView.isHidden = false
                    if self.fromAutoSearch == false{
                        self.addrssStatusLbl.text = "Address changed"
                    }
                    if self.cityStr != ""{
                        self.fulladdressStr += ", " + self.cityStr
                    }
                    if self.stateStr != ""{
                        self.fulladdressStr += ", " + self.stateStr
                    }
                    if self.countryStr != ""{
                        self.fulladdressStr += ", " + self.countryStr
                    }
                     if self.zipcodeStr != ""{
                        self.fulladdressStr += ", " + self.zipcodeStr
                        print(self.fulladdressStr)
                    }
                    self.addressLbl.text =  self.fulladdressStr
                    self.searchBarObj.text = ""
                    self.searchBarObj.text = self.addressLbl.text
                    var height : CGFloat = 0
                    height += self.heightForView(text: self.addressLbl.text!, font: UIFont(name: "HelveticaNeue", size: 17)!, width: self.addressLbl.frame.size.width)
                    self.addressLblHeightHC.constant = height
                    self.addressLbl.lineBreakMode = NSLineBreakMode.byWordWrapping
                    self.addressLbl.numberOfLines = 0
                    self.addressLbl.sizeToFit()
                    self.addressViewHeightHC.constant = 10+height+10
                    self.timerMethod()
                }
        })
    }
    func timerMethod(){
        Timer.scheduledTimer(timeInterval:3, target:self, selector: #selector((NewAddressVC.updateCounter)), userInfo: nil, repeats: false)
    }
    @objc func updateCounter(){
        self.addrssStatusLbl.isHidden = true
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    @IBAction func btnsTapped(_ sender: UIButton) {
        if sender.tag == 10{
            Analytics.logEvent("NewAddressVC_SearchAddressButtonTapped", parameters: nil)
            let autocompleteController = GMSAutocompleteViewController()
            autocompleteController.delegate = self
            present(autocompleteController, animated: true, completion: nil)
        }else if sender.tag == 20{
            self.mapViewObj.isHidden = true
            nextButton.isHidden = false
            sender.tag = 30
        }else if sender.tag == 30{
            self.mapViewObj.isHidden = false
            nextButton.isHidden = true
            sender.tag = 20
        }else if sender.tag == 40{
            Analytics.logEvent("NewAddressVC_ContinueButtonTapped", parameters: nil)
            if addressLbl.text?.count == 0{
                self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("ver_address",comment: ""), completion: {(result) in
                })
                return
            }else if self.pickuplat.count == 0{
                self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("ver_address",comment: ""), completion: {(result) in
                })
                return
            }else if self.pickuplong.count == 0{
                self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("ver_address",comment: ""), completion: {(result) in
                })
                return
            }else{
                let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                let addressVC = storyboard.instantiateViewController(withIdentifier: "AddNewAddresVC") as! AddNewAddresVC
                addressVC.fullAddress = self.addressLbl.text!
                addressVC.controlerName = self.controllerName
                addressVC.zipcodeObjStr = self.zipcodeStr
                addressVC.houseNoObjStr = self.houseno
                addressVC.streetObjStr1 = self.addressStr1
                addressVC.streetObjStr2 = self.addressStr2
                addressVC.streetObjStr3 = self.addressStr3
                addressVC.cityObjStr = self.cityStr
                addressVC.stateObjStr = self.stateStr
                addressVC.countryObjStr = self.countryStr
                addressVC.latitudeObjStr = self.pickuplat
                addressVC.longitudeObjStr = self.pickuplong
                addressVC.editAddessArray = self.addressArray
                self.present(addressVC, animated: true, completion: nil)
            }
        }else if sender.tag == 50{
            Analytics.logEvent("NewAddressVC_CurrentLocationButtonTapped", parameters: nil)
            self.fromAutoSearch = true
            if self.controllerName == "EditPickupDetails" || self.controllerName == "EditReceiverDetails"{
                self.locationStatus = "yes"
            }
            self.locationManagerSetup()
            self.apicount = 0
        }
    }
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        let autocompleteController = GMSAutocompleteViewController()
        autocompleteController.delegate = self
        present(autocompleteController, animated: true, completion: nil)
    }
}
extension NewAddressVC: GMSAutocompleteViewControllerDelegate{
    // Handle the user's selection.
    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace) {
        let address = place.formattedAddress!
        self.searchBarObj.text = ""
        self.searchBarObj.text = address
        print("address ::: ",address)
        self.fromAutoSearch = true
        getAddressFromLatLon(coordinate: CLLocationCoordinate2D(latitude: place.coordinate.latitude, longitude: place.coordinate.longitude))
        dismiss(animated: true, completion: nil)
    }
    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error) {
    }
    func wasCancelled(_ viewController: GMSAutocompleteViewController) {
        dismiss(animated: true, completion: nil)
    }
    func didRequestAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    func didUpdateAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
}
extension NewAddressVC:GMSMapViewDelegate{
    func mapView(_ mapView: GMSMapView, willMove gesture: Bool) {
        if gesture == true{
            mapmove = true
            if AddressView.isHidden{
            }else{
                self.addrssStatusLbl.isHidden = true
            }
            mapView.selectedMarker = nil
        }
    }
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        if mapmove == true{
            
            fromAutoSearch = false
            getAddressFromLatLon(coordinate:mapView.camera.target)
        }
    }
}
extension NewAddressVC:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

