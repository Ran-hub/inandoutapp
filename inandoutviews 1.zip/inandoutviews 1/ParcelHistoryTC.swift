//
//  BoxContentTableViewCell.swift
//  RYTLE
//
//  Created by Admin on 31/07/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class ParcelHistoryTC: UITableViewCell {
    
    @IBOutlet var containerView: UIView!
    @IBOutlet var parcelID: UILabel!
    @IBOutlet var modeofPaymentLbl: UILabel!
    @IBOutlet var riderNameLbl: UILabel!
    @IBOutlet var timeofBookingLbl: UILabel!
    @IBOutlet var feedbckLbl: UILabel!
    
    @IBOutlet var api_parcelID: UILabel!
    @IBOutlet var api_riderNameLbl: UILabel!
    @IBOutlet var api_modeofPaymentLbl: UILabel!
    @IBOutlet var api_timeofBookingLbl: UILabel!
    @IBOutlet var api_feedbckLbl: UILabel!
    
    @IBOutlet weak var riderHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var api_riderHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var riderTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var api_riderTopConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var containerHeightConstraints: NSLayoutConstraint!
    
    @IBOutlet weak var liveImgHC: NSLayoutConstraint!
    @IBOutlet weak var liveImgTC: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool){
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
