//
//  ParcelDetailHistoryViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by AMT on 9/7/17.
//  Copyright © 2017 Pavan. All rights reserved.
//
//Rebook parcel API

//Param :- parcel_id

import UIKit
import Firebase

class ParcelDetailVC: UIViewController,UITableViewDataSource,UITableViewDelegate,TrackParcelProtocol {
    
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var parcelDetailsTableView: UITableView!
    @IBOutlet weak var trackBtnEWC: NSLayoutConstraint!
    @IBOutlet weak var feedbackBtnEWC: NSLayoutConstraint!
    @IBOutlet var headerView: UIView!
    @IBOutlet var titleLbl: UILabel!
    @IBOutlet var cancelBtn: UIButton!
    @IBOutlet var trackBtn: UIButton!
    @IBOutlet var feedbackBtn: UIButton!
    @IBOutlet var parcelCancelBtn: UIButton!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    @IBOutlet weak var feedBackBtnBC: NSLayoutConstraint!
    @IBOutlet weak var trackBackBtnBC: NSLayoutConstraint!
    @IBOutlet weak var parcelCancelBtnHC: NSLayoutConstraint!
    
    var parcelPlaceHolderArray  = NSMutableArray()
    var parcelApiArray  = NSMutableArray()
    var parcelsizesPHArray  = NSMutableArray()
    var parcelsizesAPIArray  = NSMutableArray()
    var pickupDetailsArray  = NSMutableArray()
    var receiverDetailsArray  = NSMutableArray()
    var constatintsArray  = NSMutableArray()
    var constraintsArray1  = NSMutableArray()
    var pickupheight : CGFloat = 0
    var receiverheight : CGFloat = 0
    var contentHeight : CGFloat = 0
    var timeStr = ""
    var pick_addressIdStr = ""
    //var riderId_api = String()
    var parcelStatusStr = ""
    var parcelId = ""
    var riderId = ""
    var riderLiveTrack = ""
    var trackBtnEWC1 = NSLayoutConstraint()
    var feedbackBtnEWC1 = NSLayoutConstraint()
    var updateConstraint1 = NSLayoutConstraint()
    var updateConstraint2 = NSLayoutConstraint()
    var constraintsRemoved = ""
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad(){
        super.viewDidLoad()
       // print("parcelId :: ",parcelId)
        self.initialSetup()
        self.tableViewSetup()
        self.intialConstraintsSetup()
        self.trackBtnEWC1 = self.trackBtnEWC
        self.feedbackBtnEWC1 = self.feedbackBtnEWC
        
        NotificationCenter.default.addObserver(self, selector: #selector(ParcelDetailVC.notificationMethod(notification:)), name: NSNotification.Name(rawValue: "ParcelHistoryDetailsNotifiation"), object: nil)
        self.getParcelDetailsApi(parcelId: self.parcelId)
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func gesturesSetup(){
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(PickupAddressVC.respondToSwipeGesture(gesture:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.down
        self.statusLbl.isUserInteractionEnabled = true
        self.statusLbl.addGestureRecognizer(swipeRight)
    }
    func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
                self.statusLbl.isHidden = true
                self.getParcelDetailsApi(parcelId: self.parcelId)
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        appdelegate.parcelHistoryDetailsStatus = "Yes"
    }
    override func viewWillDisappear(_ animated: Bool) {
        appdelegate.parcelHistoryDetailsStatus = ""
        appdelegate.parcelHistoryDetailsStatus1 = ""
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func initialSetup(){
        self.navigationController?.navigationBar.isHidden = true
        self.statusLbl.text = NSLocalizedString("ver_noparceldetailsfound", comment: "")
        self.trackBtn.setTitle(NSLocalizedString("lbl_trackbtn", comment: ""), for: UIControl.State.normal)
        self.statusLbl.isHidden = true
        self.trackBtn.titleLabel?.font = AppFont.boldTextFont
        self.trackBtn.backgroundColor = AppColors.greenColorRGB
        self.trackBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.titleLbl.text = NSLocalizedString("lbl_parceldetals", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        if appdelegate.IS_IPHONE5{
            titleLbl.font = UIFont(name: "HelveticaNeue", size: 18)
        }
        self.titleLbl.textColor = AppColors.whiteColorRGB
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.feedbackBtn.setTitle(NSLocalizedString("btn_feedback", comment: ""), for: .normal)
        self.feedbackBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.feedbackBtn.backgroundColor = AppColors.greenColorRGB
        self.feedbackBtn.titleLabel?.font = AppFont.boldTextFont
        self.parcelCancelBtn.setTitle(NSLocalizedString("btn_parcelcancel", comment: ""), for: .normal)
        self.parcelCancelBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.parcelCancelBtn.backgroundColor = AppColors.greenColorRGB
        self.parcelCancelBtn.titleLabel?.font = AppFont.boldTextFont
        self.feedbackBtn.isHidden = true
        self.trackBtn.isHidden = true
        self.parcelCancelBtn.isHidden = true
        self.feedbackBtn.backgroundColor = AppColors.lightGrayColorRGB
        self.feedbackBtn.isUserInteractionEnabled = false
    }
    func tableViewSetup(){
        self.parcelDetailsTableView.dataSource = self
        self.parcelDetailsTableView.delegate = self
        self.parcelDetailsTableView.register(UINib(nibName:"ParcelDetailsTC", bundle: nil), forCellReuseIdentifier: "ParcelDetailsTC")
        self.parcelDetailsTableView.isHidden = true
    }
    func refreshParcelDetailsApi() {
        self.getParcelDetailsApi(parcelId: self.parcelId)
    }
    @objc func notificationMethod(notification : NSNotification){
        
        if let notparcelId = notification.userInfo?["parcelId"] as? String {
            // do something with your images
           // print("parcelId :: ",parcelId)
            var userTap = ""
            if let usertap = notification.userInfo?["userTap"] as? String{
                userTap = usertap
            }
            if userTap == "Yes"{
                self.getParcelDetailsApi(parcelId: notparcelId)
            }else{
                if notparcelId == self.parcelId{
                    self.getParcelDetailsApi(parcelId: notparcelId)
                }
            }
        }
    }
    @IBAction func btnsTapped(_ sender: UIButton){
        let btn = sender as UIButton
        if btn.tag == 10{
            if appdelegate.parcelHistoryDetailsStatus1 == "yes"{
                appdelegate.parcelHistoryDetailsStatus1 = ""
                appdelegate.parcelHistoryDetailsStatus = ""
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
                self.present(nextViewController, animated: true, completion: nil)
            }else{
                Analytics.logEvent("ParcelDetailVC_CancelButtonTapped", parameters: nil)
                appdelegate.parcelHistoryDetailsStatus = ""
                self.dismiss(animated: true, completion: nil)
            }
        }else if btn.tag == 20{
            Analytics.logEvent("ParcelDetailVC_FeedBackButtonTapped", parameters: nil)
            let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "FeedBackVC") as! FeedBackVC
            nextViewController.parcel_id = self.parcelId
            self.present(nextViewController, animated:true, completion: nil)
        }else if btn.tag == 30{
            Analytics.logEvent("ParcelDetailVC_TrackParcelButtonTapped", parameters: nil)
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let trackingVC = storyboard.instantiateViewController(withIdentifier: "ParcelTrackingVC") as! ParcelTrackingVC
            trackingVC.parcelId = self.parcelId
            trackingVC.parcelStatusStr = self.parcelStatusStr
            trackingVC.riderId_api = self.riderId
            trackingVC.delegate = self
            self.present(trackingVC, animated: true, completion: nil)
        }else if btn.tag == 40{
            Analytics.logEvent("ParcelDetailVC_ReebookParcelButtonTapped", parameters: nil)
            self.riderAvailabality()
        }else if btn.tag == 50{
            Analytics.logEvent("ParcelDetailVC_CancelParcelButtonTapped", parameters: nil)
            self.cancelParcelConfirmalertConfirm()
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int{
        return 4
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        switch (section) {
        case 0:
            return parcelPlaceHolderArray.count
        case 1:
            return pickupDetailsArray.count
        case 2:
            return receiverDetailsArray.count
        case 3:
            return parcelsizesPHArray.count
        default:
            return 0
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ParcelDetailsTC") as! ParcelDetailsTC
        cell.topBordeLbl.isHidden = true
        cell.nameLblLC.constant = 15
        switch (indexPath.section) {
        case 0:
            cell.nameLbl.textColor = AppColors.blackColorRGB
            cell.apitextLbl.textColor = AppColors.blackColorRGB
            cell.nameLbl.font = AppFont.regularTextFont
            cell.nameLbl.textColor = AppColors.blackColorRGB
            cell.apitextLbl.font = AppFont.regularTextFont
            cell.bottomBorderLblLC.constant = 15
            if indexPath.row == 0{
                cell.apitextLbl.font = AppFont.boldMediumTextFont
            }
            cell.apitextLbl.isHidden = false
            cell.apitextLbl.text = self.parcelApiArray[indexPath.row] as? String
            if cell.apitextLbl.text == NSLocalizedString("lbl_cancelled", comment: ""){
                cell.apitextLbl.font = AppFont.boldMediumTextFont
                cell.apitextLbl.textColor = AppColors.greenColorRGB
            }
            cell.nameLbl.text = self.parcelPlaceHolderArray[indexPath.row] as? String
            
            if cell.apitextLbl.text == NSLocalizedString("lbl_pickedup", comment: "") ||
                cell.apitextLbl.text == NSLocalizedString("lbl_outfordelivery", comment: "") ||
                cell.apitextLbl.text ==  NSLocalizedString("lbl_waitingforpickup", comment: "") ||
                cell.apitextLbl.text == NSLocalizedString("lbl_parceldelivered", comment: "") ||
                cell.apitextLbl.text == NSLocalizedString("lbl_notdelivered", comment: "") ||
                cell.apitextLbl.text ==  NSLocalizedString("lbl_notpickedup", comment: "") ||
                cell.apitextLbl.text == NSLocalizedString("lbl_cancelled", comment: ""){
                cell.apitextLbl.font = AppFont.boldMediumTextFont
                cell.apitextLbl.textColor = AppColors.greenColorRGB
            }
        case 1:
            cell.contentView.addConstraint(NSLayoutConstraint(item: cell.apitextLbl, attribute: .trailing, relatedBy: .equal, toItem: cell.nameLbl, attribute: .trailing, multiplier: 1, constant: 0))
            cell.nameLblLC.constant = 40
            cell.nameLbl.text = self.pickupDetailsArray[indexPath.row] as? String
            cell.nameLbl.numberOfLines = 1
            cell.nameLbl.font = AppFont.regularTextFont
            cell.nameLbl.textColor = AppColors.blackColorRGB
            cell.bottomBorderLblLC.constant = 40
            if indexPath.row == 0{
                cell.nameLbl.font = AppFont.boldTextFont1
                cell.nameLbl.numberOfLines = 0
                cell.nameLbl.lineBreakMode = .byWordWrapping
                cell.topBordeLbl.isHidden = false
            }else if indexPath.row == 1{
                cell.nameLbl.numberOfLines = 0
                cell.nameLbl.lineBreakMode = .byWordWrapping
            }else if indexPath.row == 2{
                cell.nameLbl.textColor = AppColors.greenColorRGB
            }
            cell.apitextLbl.isHidden = true
            
        case 2:
            
            cell.contentView.addConstraint(NSLayoutConstraint(item: cell.apitextLbl, attribute: .trailing, relatedBy: .equal, toItem: cell.nameLbl, attribute: .trailing, multiplier: 1, constant: 0))
            cell.nameLbl.font = AppFont.regularTextFont
            cell.nameLbl.textColor = AppColors.blackColorRGB
            cell.nameLblLC.constant = 40
            cell.nameLbl.text = self.receiverDetailsArray[indexPath.row] as? String
            cell.nameLbl.numberOfLines = 1
            cell.bottomBorderLblLC.constant = 40
            
            if indexPath.row == 0{
                cell.nameLbl.font = AppFont.boldTextFont1
                cell.nameLbl.numberOfLines = 0
                cell.nameLbl.lineBreakMode = .byWordWrapping
                cell.topBordeLbl.isHidden = false
            }else if indexPath.row == 1{
                cell.nameLbl.numberOfLines = 0
                cell.nameLbl.lineBreakMode = .byWordWrapping
            }else if indexPath.row == 2{
                cell.nameLbl.textColor = AppColors.greenColorRGB
            }
            cell.apitextLbl.isHidden = true
            
        case 3:
            if indexPath.row == 0{
                cell.topBordeLbl.isHidden = false
            }
            cell.bottomBorderLblLC.constant = 40
            cell.nameLbl.font = AppFont.regularTextFont
            cell.apitextLbl.font = AppFont.regularTextFont
            cell.nameLblLC.constant = 40
            cell.apitextLbl.isHidden = false
            cell.apitextLbl.text = self.parcelsizesAPIArray[indexPath.row] as? String
            cell.nameLbl.text = self.parcelsizesPHArray[indexPath.row] as? String
            cell.nameLbl.textColor = AppColors.blackColorRGB
            cell.apitextLbl.textColor = AppColors.blackColorRGB
            
        default:
            print("cell")
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 1 || indexPath.section == 2{
            if indexPath.row == 0 || indexPath.row == 1 {
                return UITableView.automaticDimension
            }
        }
        return 50
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView()
        headerView.frame = CGRect(x: 0, y: 0, width: self.parcelDetailsTableView.frame.size.width, height: 70)
        let title = UILabel()
        title.frame = CGRect(x: 15, y: 0, width: self.parcelDetailsTableView.frame.size.width-30, height: 70)
        title.font = AppFont.boldTextFont1
        if section == 0{
            title.text = ""
        }else if  section == 1{
            title.text = NSLocalizedString("lbl_pickupdetails", comment: "") //"Pickup Details"
        }else if  section == 2{
            title.text =  NSLocalizedString("lbl_deliverydetails", comment: "")
        }else if  section == 3{
            title.text =  NSLocalizedString("lbl_parceldetails", comment: "")
        }
        headerView.addSubview(title)
        headerView.backgroundColor = UIColor.whiteColorCode
        return headerView
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0{
            return 0
        }
        return 70
    }
    func getParcelDetailsApi(parcelId : String){
        if self.ineternetAlert() == false{
            self.statusLbl.isHidden = false
            self.statusLbl.text = NSLocalizedString("ver_internetavailable_error", comment: "")
            return
        }else{
            IJProgressView.shared.showProgressView(view)
            var bodyReq = [String:String]()
            bodyReq = ["parcel_id":parcelId]
           // print(bodyReq)
            if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                var token = ""
                if UserDefaults.standard.value(forKey: "usertoken") != nil{
                    token = UserDefaults.standard.value(forKey: "usertoken") as! String
                }
                let sessionStr = "Bearer " + token
                APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.getParcelDetailsURL , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                    
                    if let httpResponse = response as? HTTPURLResponse{
                     //   print("httpResponse status code \(httpResponse.statusCode)")
                        switch(httpResponse.statusCode){
                        case 200:
                            if let receivedData = data{
                                do{
                                    let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                    DispatchQueue.main.async {
                                        IJProgressView.shared.hideProgressView()
                                        self.responseFromApi(response: resultDic as! [String : Any])
                                    }
                                }catch {
                                    DispatchQueue.main.async {
                                        IJProgressView.shared.hideProgressView()
                                    self.statusLbl.text = NSLocalizedString("ver_somethingwrong", comment: "")
                                    if self.receiverDetailsArray.count == 0{
                                        self.statusLbl.isHidden = false
                                    }else{
                                        self.statusLbl.isHidden = true
                                    }
                                    }
                                }
                            }
                            break
                        case 500:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            self.statusLbl.text = NSLocalizedString("ver_somethingwrong", comment: "")
                            if self.receiverDetailsArray.count == 0{
                                self.statusLbl.isHidden = false
                            }else{
                                self.statusLbl.isHidden = true
                            }
                            }
                            break
                        case 505:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            self.statusLbl.text = NSLocalizedString("ver_noparceldetailsfound", comment: "")
                            if self.receiverDetailsArray.count == 0{
                                self.statusLbl.isHidden = false
                            }else{
                                self.statusLbl.isHidden = true
                            }
                            }
                            break
                        case 506:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            self.statusLbl.text = NSLocalizedString("err_parceliddoesnotexists", comment: "")
                            if self.receiverDetailsArray.count == 0{
                                self.statusLbl.isHidden = false
                            }else{
                                self.statusLbl.isHidden = true
                            }
                            }
                            break
                        case 498:
                            DispatchQueue.main.async {
                                self.tokenExpireAlert()
                            }
                            break
                        default:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            self.statusLbl.text = NSLocalizedString("ver_somethingwrong", comment: "")
                            if self.receiverDetailsArray.count == 0{
                                self.statusLbl.isHidden = false
                            }else{
                                self.statusLbl.isHidden = true
                              }
                            }
                        }
                    }else{
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        self.statusLbl.text = NSLocalizedString("ver_somethingwrong", comment: "")
                        if self.receiverDetailsArray.count == 0{
                            self.statusLbl.isHidden = false
                        }else{
                            self.statusLbl.isHidden = true
                        }
                      }
                    }
                }
            }
        }
    }
    func responseFromApi(response:[String : Any]){
        //print("Parcel/getParceldetails :: ",response)
        IJProgressView.shared.hideProgressView()
        self.statusLbl.isHidden = true
        self.parcelApiArray.removeAllObjects()
        self.parcelsizesPHArray.removeAllObjects()
        self.pickupDetailsArray.removeAllObjects()
        self.receiverDetailsArray.removeAllObjects()
        self.pick_addressIdStr = ""
        self.riderLiveTrack = ""
        if let resultDic = response["Msg"] as? [String:Any]{
            if let time = resultDic["time"] as? String{
                self.timeStr = ""
                var time1 = 0
                var time11 = ""
                var seconds1 = 0
                let contactnumber = time.split{$0 == " "}.map(String.init)
                if contactnumber.count == 2{
                    time11 = contactnumber[0]
                    time1 = Int(time11)!
                }
                if let seconds = resultDic["timeSe"] as? Int{
                    seconds1 = seconds
                }
                let startDate : Date = Date()
                let calendar = Calendar.current
                var date = calendar.date(byAdding: .minute, value: time1, to: startDate)
                date = calendar.date(byAdding: .second, value: seconds1, to: date!)
                self.timeStr = "\((calendar.component(.hour, from: date!))):\((calendar.component(.minute, from: date!))):\((calendar.component(.second, from: date!)))"
            }
            if let rowsarray = resultDic["rows"] as? [Any]{
                let responseDic = rowsarray[0] as! NSDictionary
                var Status = 0
                var rider_firstname = ""
                var rider_lastname = ""
                var parcel_Status = ""
                var r_receiverName = ""
                var r_mobilenumber = ""
                var r_receiveraddress = ""
                var receiverFlatNumber = ""
                var receiverExtensionNumber = ""
                var p_Name = ""
                var p_mobilenumber = ""
                var p_pickupaddress = ""
                var parcelPickupTime = ""
                var parcelDeliveryTime = ""
                var pickupFlatNumber = ""
                var pickupExtensionNumber = ""
                var bookingtime = ""
                var delimode = 0
                var deliveryMode = ""
                var rider_id = 0
                var datestr = ""
                var parcel_id = ""
                if let firstnameStr = responseDic["firstname"] as? String{
                    rider_firstname = firstnameStr
                }
                if let lastnameStr = responseDic["lastname"] as? String{
                    rider_lastname = lastnameStr
                }
                if let id = responseDic["parcel_id"] as? String{
                    parcel_id = id
                    // self.parcelId = parcelId
                }
                if let liveTrack = responseDic["live_tracking"] as? String{
                    self.riderLiveTrack = liveTrack
                }
                if let  time = responseDic["created_datetime"] as? String{
                    bookingtime = time
                    datestr = self.dataFormat(date: bookingtime)
                }
                if let deliverymode = responseDic["parcel_fk_delivery_option_id"] as? Int{
                    delimode = deliverymode
                }
                if delimode == 1{
                    deliveryMode = "Express"
                }
                if delimode == 2{
                    deliveryMode = "Normal"
                }
                if let riderid =  responseDic["rider_id"] as? Int{
                    rider_id = riderid
                    self.riderId = String(rider_id)
                }
                let parcelPickupTimeStr = ApiResponse.checkForNull(value: responseDic["parcelPickup_time"] as AnyObject)
                if parcelPickupTimeStr  == ""{
                    parcelPickupTime = "0"
                }else{
                    parcelPickupTime = parcelPickupTimeStr
                    parcelPickupTime = self.dataFormat(date: parcelPickupTime)
                }
                let parcelDeliveryTimeStr = ApiResponse.checkForNull(value: responseDic["parcelDelivery_time"] as AnyObject)
                if parcelDeliveryTimeStr  == ""{
                    parcelDeliveryTime = "0"
                }else{
                    parcelDeliveryTime = parcelDeliveryTimeStr
                    parcelDeliveryTime = self.dataFormat(date: parcelDeliveryTime)
                }
                if let parcelstatus =  responseDic["parcel_fk_status"] as? Int{
                    Status = parcelstatus
                }
                if let pickupAddressId =  responseDic["pickup_add_id"] as? Int{
                    self.pick_addressIdStr = String (pickupAddressId)
                }
                parcel_Status = self.parcelStatus(status: Status, liveTracking: self.riderLiveTrack)
                self.parcelStatusStr = parcel_Status
                
                let riderfullname = rider_firstname + " " + rider_lastname
                self.parcelApiArray.add(parcel_id)
                self.parcelApiArray.add(datestr)
                self.parcelApiArray.add(deliveryMode)
                
                if Status  == 8{
                    if self.timeStr == ""{
                        self.timeStr = "0"
                    }
                    self.parcelApiArray.add(self.timeStr)
                }else if Status  == 2{
                    self.parcelApiArray.add(parcelPickupTime)
                    self.parcelApiArray.add(self.timeStr)
                }else if Status  == 11{
                    self.parcelApiArray.add(parcelPickupTime)
                    self.parcelApiArray.add(parcelDeliveryTime)
                }else if Status == 15{
                }else {
                    self.parcelApiArray.add(parcelPickupTime)
                    self.parcelApiArray.add(parcelDeliveryTime)
                }
                self.parcelApiArray.add(parcel_Status)
                if rider_id != 0{
                    self.parcelPlaceHolderArray.add(NSLocalizedString("lbl_riderassigned", comment: ""))
                    self.parcelApiArray.add(riderfullname)
                }
                if let pickupnameStr = responseDic["pickup_fullname"] as? String{
                    p_Name = pickupnameStr
                }
                if let pickupmobileStr = responseDic["pickup_mobile_no"] as? String{
                    p_mobilenumber = pickupmobileStr
                }
                if let p_flatNumber = responseDic["pickup_flat_no"] as? String{
                    pickupFlatNumber = p_flatNumber
                }
                if let p_extension = responseDic["pickup_extension"] as? String{
                    pickupExtensionNumber = p_extension
                }
                let (p_add_houseno,p_add_street1,p_add_city,p_add_state,p_add_country,p_add_zipcode,p_add_street2,p_add_street3) = ApiResponse.pickupAddressStateValues(response: responseDic as! [String : Any])
                p_pickupaddress = ApiResponse.checkingAddressValidationAndReturnAddress(flatNumber: pickupFlatNumber, houseno: p_add_houseno, street1: p_add_street1, street2: p_add_street2, street3: p_add_street3, city: p_add_city, state: p_add_state, country: p_add_country,zipcode: p_add_zipcode)
                p_pickupaddress = p_pickupaddress + ", " + p_add_zipcode
                self.pickupDetailsArray.add(p_Name)
                self.pickupDetailsArray.add(p_pickupaddress)
                if p_mobilenumber != ""{
                    if pickupExtensionNumber != ""{
                        p_mobilenumber += "  " + NSLocalizedString("tex_ext", comment: "") + " " + pickupExtensionNumber
                    }
                    self.pickupDetailsArray.add(p_mobilenumber)
                }
                if let receiverStr = responseDic["reciver_fullname"] as? String{
                    r_receiverName = receiverStr
                }
                if let receivermobileStr = responseDic["reciver_mobile_no"] as? String{
                    r_mobilenumber = receivermobileStr
                }
                if let r_extension = responseDic["extension"] as? String{
                    receiverExtensionNumber = r_extension
                }
                if let r_flatnumber = responseDic["flat_no"] as? String{
                    receiverFlatNumber = r_flatnumber
                }
                let (r_add_houseno,r_add_street1,r_add_city,r_add_state,r_add_country,r_add_zipcode,r_add_street2,r_add_street3) = ApiResponse.addressStateValues(response: responseDic as! [String : Any])
                
                r_receiveraddress = ApiResponse.checkingAddressValidationAndReturnAddress(flatNumber: receiverFlatNumber, houseno: r_add_houseno, street1: r_add_street1, street2: r_add_street2, street3: r_add_street3, city: r_add_city, state: r_add_state, country: r_add_country,zipcode: r_add_zipcode)
                r_receiveraddress = r_receiveraddress + ", " + r_add_zipcode
                self.receiverDetailsArray.add(r_receiverName)
                self.receiverDetailsArray.add(r_receiveraddress)
                if r_mobilenumber != ""{
                    if receiverExtensionNumber != ""{
                        r_mobilenumber += "  " + NSLocalizedString("tex_ext", comment: "") + " " + receiverExtensionNumber
                    }
                    self.receiverDetailsArray.add(r_mobilenumber)
                }
                ApiResponse.parcelSizes(responseDic: responseDic as! [String : Any], parcelSizesArray: self.parcelsizesAPIArray)
                self.parcelsizesPHArray = [NSLocalizedString("lbl_lenght", comment: ""),NSLocalizedString("lbl_width", comment: ""),NSLocalizedString("lbl_height", comment: ""),NSLocalizedString("lbl_weight", comment: "")]
                self.parcelDetailsTableView.isHidden = false
                self.parcelDetailsTableView.reloadData()
            }
        }
    }
    func parcelStatus(status : Int,liveTracking : String) -> String{
        self.parcelPlaceHolderArray = [NSLocalizedString("lbl_parcelid", comment: ""),NSLocalizedString("lbl_timeofbooking", comment: ""),NSLocalizedString("lbl_modeofdelivery", comment: ""),NSLocalizedString("lbl_estpickuptime", comment: ""),NSLocalizedString("lbl_estdeliverytime", comment: ""),NSLocalizedString("lbl_parcelstatus", comment: "")]
        self.feedbackBtn.isHidden = false
        var parcel_Status = ""
        if status == 1{
            self.trackBtn.isHidden = false
            self.parcelPlaceHolderArray.replaceObject(at: 3, with: NSLocalizedString("lbl_pickeduptime", comment: ""))
            self.parcelPlaceHolderArray.replaceObject(at: 4, with: NSLocalizedString("lbl_estdeliverytime", comment: ""))
            parcel_Status = NSLocalizedString("lbl_pickedup", comment: "")
            if liveTracking == ""{
                self.removeAndAddConstraints()
                self.showAndHideParcelBtn(str: "hide")
            }else if liveTracking == "Yes"{
                self.addConstraints()
                self.showAndHideParcelBtn(str: "hide")
            }
            self.feedbackBtn.backgroundColor = AppColors.greenColorRGB
            self.feedbackBtn.isUserInteractionEnabled = true
        }else if status == 2{
            self.trackBtn.isHidden = false
            self.parcelPlaceHolderArray.replaceObject(at: 3, with: NSLocalizedString("lbl_pickeduptime", comment: ""))
            self.parcelPlaceHolderArray.replaceObject(at: 4, with: NSLocalizedString("lbl_estdeliverytime", comment: ""))
            parcel_Status = NSLocalizedString("lbl_outfordelivery", comment: "")
            if liveTracking == ""{
                if constraintsRemoved == ""{
                    self.removeAndAddConstraints()
                }
                self.showAndHideParcelBtn(str: "hide")
            }else if liveTracking == "Yes"{
                self.addConstraints()
                self.showAndHideParcelBtn(str: "show")
            }
            self.feedbackBtn.backgroundColor = AppColors.greenColorRGB
            self.feedbackBtn.isUserInteractionEnabled = true
        }else if status == 8{
            self.trackBtn.isHidden = false
            self.parcelPlaceHolderArray.replaceObject(at: 3, with: NSLocalizedString("lbl_estpickuptime", comment: ""))
            self.parcelPlaceHolderArray.replaceObject(at: 4, with: NSLocalizedString("lbl_estdeliverytime", comment: ""))
            self.parcelPlaceHolderArray.removeObject(at: 4)
            parcel_Status = NSLocalizedString("lbl_waitingforpickup", comment: "")
            if liveTracking == ""{
                if constraintsRemoved == ""{
                    self.removeAndAddConstraints()
                }
                self.showAndHideParcelBtn(str: "show")
            }else if liveTracking == "Yes"{
                self.addConstraints()
                self.showAndHideParcelBtn(str: "show")
            }
            self.feedbackBtn.backgroundColor = AppColors.lightGrayColorRGB
            self.feedbackBtn.isUserInteractionEnabled = false
        }else if status == 11{
            self.parcelPlaceHolderArray.replaceObject(at: 3, with: NSLocalizedString("lbl_pickeduptime", comment: ""))
            self.parcelPlaceHolderArray.replaceObject(at: 4, with: NSLocalizedString("lbl_deliverytime", comment: ""))
            parcel_Status = NSLocalizedString("lbl_parceldelivered", comment: "")
            self.removeAndAddConstraints()
            self.showAndHideParcelBtn(str: "hide")
            self.feedbackBtn.backgroundColor = AppColors.greenColorRGB
            self.feedbackBtn.isUserInteractionEnabled = true
        }else if status == 12{
            self.parcelPlaceHolderArray.replaceObject(at: 3, with: NSLocalizedString("lbl_pickeduptime", comment: ""))
            self.parcelPlaceHolderArray.replaceObject(at: 4, with: NSLocalizedString("lbl_estdeliverytime", comment: ""))
            parcel_Status = NSLocalizedString("lbl_notdelivered", comment: "")
            self.removeAndAddConstraints()
            self.showAndHideParcelBtn(str: "hide")
            self.feedbackBtn.backgroundColor = AppColors.greenColorRGB
            self.feedbackBtn.isUserInteractionEnabled = true
        }else if status  == 14{
            self.parcelPlaceHolderArray.replaceObject(at: 3, with: NSLocalizedString("lbl_estpickuptime", comment: ""))
            self.parcelPlaceHolderArray.replaceObject(at: 4, with: NSLocalizedString("lbl_estdeliverytime", comment: ""))
            parcel_Status = NSLocalizedString("lbl_notpickedup", comment: "")
            self.removeAndAddConstraints()
            self.showAndHideParcelBtn(str: "hide")
            self.feedbackBtn.backgroundColor = AppColors.greenColorRGB
            self.feedbackBtn.isUserInteractionEnabled = true
        }else if status == 15{
            self.parcelPlaceHolderArray.removeObject(at: 4)
            self.parcelPlaceHolderArray.removeObject(at: 3)
            parcel_Status = NSLocalizedString("lbl_cancelled", comment: "")
            self.feedbackBtn.tag = 40
            self.feedbackBtn.setTitle(NSLocalizedString("lbl_rebook", comment: ""), for: .normal)
            self.removeAndAddConstraints()
            self.showAndHideParcelBtn(str: "hide")
            self.feedbackBtn.backgroundColor = AppColors.greenColorRGB
            self.feedbackBtn.isUserInteractionEnabled = true
        }
        return parcel_Status
    }
    func showAndHideParcelBtn(str:String){
        if str == "hide"{
            self.parcelCancelBtnHC.constant = 0
            self.feedBackBtnBC.constant = 0
            self.trackBackBtnBC.constant = 0
            self.parcelCancelBtn.isHidden = true
        }else{
            self.parcelCancelBtn.isHidden = false
            self.parcelCancelBtnHC.constant = 50
            self.feedBackBtnBC.constant = 10
            self.trackBackBtnBC.constant = 10
        }
    }
    func removeAndAddConstraints(){
        self.constraintsRemoved = "yes"
        self.view.removeConstraint(self.trackBtnEWC)
        self.view.removeConstraint(self.feedbackBtnEWC)
        updateConstraint1 = NSLayoutConstraint(item: self.trackBtn, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 0)
        self.view.addConstraint(updateConstraint1)
        updateConstraint2 = NSLayoutConstraint(item: self.trackBtn, attribute: .trailing, relatedBy: .equal, toItem: self.feedbackBtn, attribute: .trailing, multiplier: 1, constant: 0)
        self.view.addConstraint(updateConstraint2)
    }
    func addConstraints(){
        self.constraintsRemoved = ""
        self.trackBtn.isHidden = false
        self.view.removeConstraint(self.updateConstraint1)
        self.view.removeConstraint(self.updateConstraint2)
        self.view.addConstraint(self.trackBtnEWC1)
        self.view.addConstraint(self.feedbackBtnEWC1)
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    func dataFormat(date : String) -> String{
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        let date = formatter.date(from: date)
        let formatter1 = DateFormatter()
        formatter1.dateFormat = "HH:mm:ss dd-MM-yyyy"
        return formatter1.string(from:date!)
    }
    func riderAvailabality(){
        if self.ineternetAlert() == false{
            return
        }else{
            IJProgressView.shared.showProgressView(view)
            var orgId = ""
            orgId = Constants.getValueFromUserDefults(for:"customerOrgid") as! String
            var bodyReq = [String:String]()
            bodyReq = ["pickup_add_id":self.pick_addressIdStr,"org_id":orgId]
           // print("bodyReq",bodyReq)
            if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                let token = UserDefaults.standard.value(forKey: "usertoken") as! String
                let sessionStr = "Bearer " + token
                APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.riderAvailabilityURL , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                   
                    if let httpResponse = response as? HTTPURLResponse{
                     //   print("httpResponse status code \(httpResponse.statusCode)")
                        switch(httpResponse.statusCode){
                        case 200:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            self.reebookParcelConfirmalertConfirm()
                            }
                            break
                        case 500:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                            break
                        case 505:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "NoRiderAvailable_505", controller: self)
                            }
                            break
                        case 506:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                                errorCodesMessageDisplayAlert(statusCode: "NoRiderAvailable_505", controller: self)
                            }
                            break
                        case 498:
                            DispatchQueue.main.async {
                                self.tokenExpireAlert()
                            }
                            break
                        default:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                        }
                    }else{
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                      }
                    }
                }
            }
        }
    }
    func parcelCancelRequestApi(){
        if self.ineternetAlert() == false{
            return
        }else{
            IJProgressView.shared.showProgressView(view)
            var bodyReq = [String:String]()
            bodyReq = ["parcel_id":self.parcelId]
           // print("bodyReq",bodyReq)
            if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                let token = UserDefaults.standard.value(forKey: "usertoken") as! String
                let sessionStr = "Bearer " + token
                APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.cancelParcelRequestURL , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                   
                    if let httpResponse = response as? HTTPURLResponse{
                     //   print("httpResponse status code \(httpResponse.statusCode)")
                        switch(httpResponse.statusCode){
                        case 200:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                           self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("alert_errorparcelcancel",comment: ""), completion: {(result) in
                                    self.dismiss(animated: true, completion: nil)
                                })
                            }
                            break
                        case 500:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                            break
                        case 505:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "ParcelCancel_505", controller: self)
                            }
                            break
                        case 506:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "ParcelCancel_506", controller: self)
                            }
                            break
                        case 498:
                            DispatchQueue.main.async {
                                self.tokenExpireAlert()
                            }
                            break
                        default:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                        }
                    }else{
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                      }
                    }
                }
            }
        }
    }
    func reebookParcelConfirmalertConfirm(){
        let alert = UIAlertController(title: NSLocalizedString("lbl_confirmbooking", comment: ""), message:"", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title:NSLocalizedString("btn_cancel", comment:""), style: .default) { (alert: UIAlertAction!) -> Void in
        }
        cancelAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        let clearAction = UIAlertAction(title:NSLocalizedString("btn_confirmbook", comment: ""), style: .default) { (alert: UIAlertAction!) -> Void in
            self.rebookParcelApi()
        }
        clearAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        alert.addAction(cancelAction)
        alert.addAction(clearAction)
        present(alert, animated: true, completion:nil)
    }
    func cancelParcelConfirmalertConfirm(){
        let alert = UIAlertController(title: nil, message:NSLocalizedString("alert_cancelparcel", comment: ""), preferredStyle: .alert)
        let cancelAction = UIAlertAction(title:NSLocalizedString("btn_cancel", comment:""), style: .default) { (alert: UIAlertAction!) -> Void in
        }
        cancelAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        let clearAction = UIAlertAction(title:NSLocalizedString("btn_confirmbook", comment: ""), style: .default) { (alert: UIAlertAction!) -> Void in
            self.parcelCancelRequestApi()
        }
        clearAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        alert.addAction(cancelAction)
        alert.addAction(clearAction)
        present(alert, animated: true, completion:nil)
    }
    func rebookParcelApi(){
        if self.ineternetAlert() == false{
            return
        }else{
            IJProgressView.shared.showProgressView(view)
            var bodyReq = [String:String]()
            bodyReq = ["parcel_id":parcelId]
            if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                var token = ""
                if UserDefaults.standard.value(forKey: "usertoken") != nil{
                    token = UserDefaults.standard.value(forKey: "usertoken") as! String
                }
                let sessionStr = "Bearer " + token
                APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.rebookParcel , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (data,error,response) in
                   
                    if let httpResponse = response as? HTTPURLResponse{
                       // print("httpResponse status code \(httpResponse.statusCode)")
                        switch(httpResponse.statusCode){
                        case 200:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            self.statusLbl.isHidden = true
                            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr:NSLocalizedString("val_parcelbookingconfirmation",comment: ""), completion: {(result) in
                                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
                                self.present(nextViewController, animated: true, completion: nil)
                            })
                            }
                            break
                        case 500:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                            break
                        case 505:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "BookParcel_505", controller: self)
                            }
                            break
                        case 498:
                            DispatchQueue.main.async {
                                self.tokenExpireAlert()
                            }
                            break
                        default:
                            DispatchQueue.main.async {
                                IJProgressView.shared.hideProgressView()
                            errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                            }
                        }
                    }else{
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                      }
                    }
                }
            }
        }
    }
}

