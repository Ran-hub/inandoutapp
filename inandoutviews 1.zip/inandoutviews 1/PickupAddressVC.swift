//
//  PickupAddressViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by Admin on 25/08/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit
import Firebase

class PickupAddressVC: UIViewController ,UITableViewDataSource,UITableViewDelegate{
    
    @IBOutlet weak var continueButtonHC: NSLayoutConstraint!
    @IBOutlet weak var continueButtonTC: NSLayoutConstraint!
    @IBOutlet weak var cancelBtn : UIButton!
    @IBOutlet weak var titleTxt : UILabel!
    @IBOutlet weak var pickUpTable : UITableView!
    @IBOutlet weak var continueBtn : UIButton!
    @IBOutlet weak var addnewBtn : UIButton!
    @IBOutlet weak var statusLbl : UILabel!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    var pickupLisModalArray : NSMutableArray = NSMutableArray()
    let appdelegate :AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var addressSelected  = Bool()
    var selectedRow : Int = 0
    var addressData = [PickupAddressData()]
    var refreshControl = UIRefreshControl()
    let appdeletegate:AppDelegate=(UIApplication.shared.delegate as! AppDelegate)
    var editAddressid = ""
    var editAddressIndex : Int = -1
    var editAddressStatus = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetup()
        self.gesturesSetup()
        self.addRefreshVCToTableView()
        self.intialConstraintsSetup()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
       func initialSetup(){
        self.navigationController?.isNavigationBarHidden = true
        self.statusLbl.text = NSLocalizedString("ver_noaddress", comment: "")
        self.statusLbl.isHidden = true
        self.statusLbl.numberOfLines = 2
        self.pickUpAddressapi()
        self.pickUpTable.register(UINib(nibName: "PickupAddressTC", bundle: nil), forCellReuseIdentifier: "PickupAddressTC")
        self.titleTxt.text = NSLocalizedString("lbl_pickupaddress", comment: "")
        self.titleTxt.font = AppFont.boldTextFont
        self.titleTxt.textColor = AppColors.whiteColorRGB
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.continueBtn.setTitle(NSLocalizedString("btn_continue", comment: ""), for: .normal)
        self.continueBtn.titleLabel?.font = AppFont.boldTextFont
        self.continueBtn.backgroundColor = AppColors.greenColorRGB
        self.continueBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.continueBtn.titleLabel?.font = AppFont.boldTextFont
        self.addnewBtn.setTitle(NSLocalizedString("btn_addnew", comment: ""), for: .normal)
        self.addnewBtn.titleLabel?.font = AppFont.boldTextFont
        self.addnewBtn.backgroundColor = AppColors.greenColorRGB
        self.addnewBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.addnewBtn.titleLabel?.font = AppFont.boldTextFont
        self.continueButtonHC.constant = 0
        self.continueButtonTC.constant = 0
        self.continueBtn.isHidden = true
    }
    func addRefreshVCToTableView(){
        // Add Refresh Control to Table View
        if #available(iOS 10.0, *){
            pickUpTable.refreshControl = refreshControl
        } else {
            // Fallback on earlier versions
            pickUpTable.addSubview(refreshControl)
        }
        refreshControl.tintColor = AppColors.greenColorRGB
        refreshControl.attributedTitle = NSAttributedString(string: NSLocalizedString("lbl_loading", comment: ""))
        refreshControl.addTarget(self, action: #selector(PickupAddressVC.refreshData), for: .valueChanged)
    }
    func gesturesSetup(){
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(PickupAddressVC.respondToSwipeGesture(gesture:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.down
        self.statusLbl.isUserInteractionEnabled = true
        self.statusLbl.addGestureRecognizer(swipeRight)
    }
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
                self.statusLbl.isHidden = true
                self.pickUpAddressapi()
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    @objc func refreshData(){
        self.editAddressStatus = ""
        self.pickUpAddressapi()
    }
    override func viewWillAppear(_ animated: Bool){
        if self.appdeletegate.pickAddAddress == "yes"{
            self.appdelegate.pickAddAddress = ""
            self.pickUpAddressapi()
        }
    }
    override func viewWillDisappear(_ animated: Bool){
        self.refreshControl.endRefreshing()
    }
    @IBAction func btnsTapped(_ sender : UIButton){
        let btn = sender as UIButton
        if btn.tag == 10{
            Analytics.logEvent("PickupAddressVC_CancelButtonTapped", parameters: nil)
            self.dismiss(animated: true, completion: nil)
        }else if btn.tag == 20{
            if addressSelected == true{
                Analytics.logEvent("PickupAddressVC_ContinueButtonTapped", parameters: nil)
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ReciverAddressVC") as! ReciverAddressVC
                self.present(nextViewController, animated:true, completion: nil)
            }else{
                self.displayAlert(message: NSLocalizedString("ver_address", comment: ""))
            }
        }else if btn.tag == 30{
            Analytics.logEvent("PickupAddressVC_AddNewAddressButtonTapped", parameters: nil)
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "NewAddressVC") as! NewAddressVC
            nextViewController.controllerName = "PickupDetails"
            self.present(nextViewController, animated:true, completion: nil)
        }
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return self.pickupLisModalArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PickupAddressTC") as! PickupAddressTC
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        cell.deleteButton.tag = indexPath.row
        cell.deleteButton.addTarget(self, action: #selector(PickupAddressVC.deleteAddress), for:.touchUpInside)
        cell.editButton.addTarget(self, action: #selector(PickupAddressVC.editAddress(sender:)), for:.touchUpInside)
        cell.editButton.tag = indexPath.row
        cell.selectedBtn.layer.masksToBounds = true
        cell.selectedBtn.layer.cornerRadius = cell.selectedBtn.frame.size.width/2
        cell.selectedView.layer.masksToBounds = true
        cell.selectedView.layer.cornerRadius = cell.selectedView.frame.size.width/2
        cell.unSelectedView.layer.masksToBounds = true
        cell.unSelectedView.layer.cornerRadius = cell.unSelectedView.frame.size.width/2
        if selectedRow == indexPath.row{
            cell.unSelectedView.isHidden = false
        }else{
            cell.unSelectedView.isHidden = true
        }
        cell.selectedBtn.isUserInteractionEnabled = false
        let pickup = self.pickupLisModalArray.object(at: indexPath.row) as! PickupAddressData
        cell.usernameLbl.text = pickup.name
        cell.usernameLbl.lineBreakMode = NSLineBreakMode.byWordWrapping
        cell.usernameLbl.numberOfLines = 0
        cell.addresssLbl.text = pickup.fulladdress
        cell.addresssLbl.lineBreakMode = NSLineBreakMode.byWordWrapping
        cell.addresssLbl.numberOfLines = 0
        cell.zipcodeLbl.text = pickup.zipcode
        cell.contactLbl.isHidden = false
        cell.contactLbl.text = pickup.mobile
        if pickup.mobile == ""{
           cell.contactLbl.isHidden = true
        }
        if pickup.mobile != ""{
        if pickup.extensionCode != ""{
            cell.contactLbl.text = pickup.mobile + "  " + NSLocalizedString("tex_ext", comment: "") + " " + pickup.extensionCode
         }
        }
        cell.borderlbl.frame = CGRect(x: 0, y: cell.frame.size.height-1, width: cell.frame.size.width, height: 0.5)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        selectedRow = indexPath.row
        let pickupaddress = self.pickupLisModalArray.object(at: indexPath.row) as! PickupAddressData
        self.addressSelected = true
        Constants.setValueInUserDefaults(objValue:pickupaddress.name , for:"pickup_username")
        Constants.setValueInUserDefaults(objValue:pickupaddress.fulladdress , for:"pickup_address")
        Constants.setValueInUserDefaults(objValue:pickupaddress.zipcode , for:"pickup_zipcode")
        Constants.setValueInUserDefaults(objValue:pickupaddress.mobile , for:"pickup_mobileno")
        Constants.setValueInUserDefaults(objValue:pickupaddress.address_id , for:"pickup_pickaddressID")
        Constants.setValueInUserDefaults(objValue:pickupaddress.extensionCode , for:"pickup_extensionCode")
        pickUpTable.reloadData()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return  UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 111
    }
    func heightForView(text:String, font:UIFont, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRect(x:0, y:0, width:width, height:2000))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    @objc func editAddress(sender : UIButton){
       // self.editAddressStatus = "editaddress"
        Analytics.logEvent("PickupAddressVC_EditAddressButtonTapped", parameters: nil)
        let pickupaddress = self.pickupLisModalArray.object(at: sender.tag) as! PickupAddressData
        selectedRow = sender.tag
        Constants.setValueInUserDefaults(objValue:pickupaddress.name , for:"pickup_username")
        Constants.setValueInUserDefaults(objValue:pickupaddress.fulladdress , for:"pickup_address")
        Constants.setValueInUserDefaults(objValue:pickupaddress.zipcode , for:"pickup_zipcode")
        Constants.setValueInUserDefaults(objValue:pickupaddress.mobile , for:"pickup_mobileno")
        Constants.setValueInUserDefaults(objValue:pickupaddress.address_id , for:"pickup_pickaddressID")
        Constants.setValueInUserDefaults(objValue:pickupaddress.extensionCode , for:"pickup_extensionCode")

        self.pickUpTable.reloadData()
        self.editAddressStatus = "editaddress"
        self.editAddressid = pickupaddress.address_id
       // print(self.editAddressid)
     //   print(pickupaddress.address_id)
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let newAddressVC = storyBoard.instantiateViewController(withIdentifier: "NewAddressVC") as! NewAddressVC
        newAddressVC.controllerName = ""
        newAddressVC.addressArray.removeAllObjects()
        newAddressVC.controllerName = "EditPickupDetails"
        newAddressVC.addressArray.add(pickupaddress.latitude)
        newAddressVC.addressArray.add(pickupaddress.longitude)
        newAddressVC.addressArray.add(pickupaddress.address_id)
        newAddressVC.addressArray.add(pickupaddress.name)
        newAddressVC.addressArray.add(pickupaddress.email)
        newAddressVC.addressArray.add(pickupaddress.mobile)
        newAddressVC.addressArray.add(pickupaddress.addressType)
        newAddressVC.addressArray.add(pickupaddress.flatNumber)
        newAddressVC.addressArray.add(pickupaddress.extensionCode)
        self.present(newAddressVC, animated:true, completion: nil)
    }
    func selectedButtonTapped(sender:UIButton){
        let cell = self.pickUpTable.cellForRow(at:IndexPath.init(row:sender.tag, section: 0)) as! PickupAddressTC
        cell.unSelectedView.isHidden = false
    }
    func pickUpAddressapi(){
       
        if self.ineternetAlert() == false{
            self.statusLbl.text = NSLocalizedString("ver_internetavailable_error", comment: "")
            return
        }
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        var cust_id = String()
        if Constants.getValueFromUserDefults(for:"customer_id") as? String != nil{
            cust_id = Constants.getValueFromUserDefults(for:"customer_id") as! String
        }
        bodyReq = ["customer_id":cust_id]
        var token = String()
        var reultanttoken = ""
      //  print(bodyReq)
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            reultanttoken = "Bearer" + " " + token
        }
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.pickAddressListURL , method: "POST", token:reultanttoken, body: "", productBody: bodyData as NSData) {(data,error,response)  in
                
                if let httpResponse = response as? HTTPURLResponse{
                  //  print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        if let receivedData = data{
                            do{
                                let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    self.responseApi(response: resultDic as! [String : Any])
                                }
                            }catch {
                                self.someThingWentWrong()
                            }
                        }
                        break
                    case 500:
                        self.someThingWentWrong()
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        self.refreshControl.endRefreshing()
                        self.statusDisplay(status: NSLocalizedString("ver_noaddress", comment: ""))
                        if self.pickupLisModalArray.count != 0{
                            errorCodesMessageDisplayAlert(statusCode: "PickupList_506", controller: self)
                          }
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        self.refreshControl.endRefreshing()
                        self.statusDisplay(status: NSLocalizedString("error_failedtogetpickupaddresslist", comment: ""))
                        if self.pickupLisModalArray.count != 0{
                            errorCodesMessageDisplayAlert(statusCode: "PickupList_506", controller: self)
                         }
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                        break
                    default:
                       self.someThingWentWrong()
                    }
                }else{
                   self.someThingWentWrong()
                }
            }
        }
    }
    func responseApi(response : [String : Any]){
           // print("Result",response)
            if let status = response["status"] as? Bool {
                if status == true{
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                        self.pickupLisModalArray.removeAllObjects()
                        self.addressData.removeAll()
                        self.refreshControl.endRefreshing()
                        let newArray  = response["Msg"] as? [[String:Any]]
                        for (index,resultDic) in newArray!.enumerated() {
                            var address_id = ""
                            if let pickupaddressid = resultDic["pick_add_id"] as? Int{
                                address_id = String(pickupaddressid)
                            }
                             ApiResponse.pickupAndReceiverAddressApiResponse(response: resultDic, pikupAddressArray: self.pickupLisModalArray, addressStatus: "pickup")
                            if self.editAddressStatus == "editaddress"{
                             if self.editAddressid == address_id{
                              //  print("self.editAddressid",self.editAddressid)
                              //  print("address_id",address_id)
                                self.editAddressIndex = index
                            }
                           }
                        }
                        self.statusDisplay(status: NSLocalizedString("ver_noaddress", comment: ""))
                    })
                }
            }
    }
    func someThingWentWrong(){
        DispatchQueue.main.async {
            IJProgressView.shared.hideProgressView()
            self.refreshControl.endRefreshing()
            self.statusDisplay(status: NSLocalizedString("ver_somethingwrong", comment: ""))
            if self.pickupLisModalArray.count != 0{
                errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
            }
        }
    }
    @objc func deleteAddress(sender:UIButton){
        if self.ineternetAlert() == false{
            return
        }
        self.selectedRow = sender.tag
        self.pickUpTable.reloadData()
        let alert = UIAlertController(title: NSLocalizedString("Rytle", comment: ""), message:NSLocalizedString("alert_msg", comment: ""), preferredStyle: .alert)
        let confirmAction = UIAlertAction(title:NSLocalizedString("alert_delete", comment: ""), style: .default) { (alert: UIAlertAction!) -> Void in
            Analytics.logEvent("PickupAddressVC_DeleteAddressButtonTapped", parameters: nil)
            let pickupaddress = self.pickupLisModalArray.object(at: sender.tag) as! PickupAddressData
              let address_id =  pickupaddress.address_id
              self.deletePickupAddress(addressid:address_id,index: sender.tag)
        }
        confirmAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        let cancelAction = UIAlertAction(title:NSLocalizedString("btn_cancel", comment:""), style: .default) { (alert: UIAlertAction!) -> Void in
            Analytics.logEvent("PickupAddressVC_CancelledDeleteAddress", parameters: nil)
        }
        cancelAction.setValue(AppColors.greenColorRGB, forKey: "titleTextColor")
        alert.addAction(cancelAction)
        alert.addAction(confirmAction)
        present(alert, animated: true, completion:nil)
    }
    func deletePickupAddress(addressid: String,index: Int){
        IJProgressView.shared.showProgressView(self.view)
        self.editAddressStatus = ""
        var bodyReq = [String:String]()
        bodyReq = ["pick_add_id":addressid]
        var token = String()
        var reultanttoken = ""
        if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
            token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            reultanttoken = "Bearer" + " " + token
        }
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.deletePickupAddressURL
            , method: "POST", token:reultanttoken, body: "", productBody: bodyData as NSData) { (data,error,response) in
               
                if let httpResponse = response as? HTTPURLResponse{
                   // print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        DispatchQueue.main.async {
                                    IJProgressView.shared.hideProgressView()
                                    self.pickupLisModalArray.removeObject(at:index)
                                    self.statusDisplay(status: NSLocalizedString("ver_noaddress", comment: ""))
                                    errorCodesMessageDisplayAlert(statusCode: "PickupDelete_200", controller: self)
                                }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "PickupDelete_505", controller: self)
                        }
                        break
                    case 506:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "PickupDelete_506", controller: self)
                        }
                        break
                    case 498:
                        DispatchQueue.main.async {
                            self.tokenExpireAlert()
                        }
                        break
                    default:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                    }
                }
            }
        }
    }
    func statusDisplay(status:String){
        if self.pickupLisModalArray.count == 0{
            self.continueButtonHC.constant = 0
            self.continueButtonTC.constant = 0
            self.continueBtn.isHidden = true
            self.pickUpTable.isHidden = true
            self.statusLbl.isHidden = false
            self.continueBtn.isUserInteractionEnabled = false
            self.continueBtn.backgroundColor = AppColors.lightGrayColorRGB
            self.pickUpTable.reloadData()
            self.addressSelected = false
        }else{
            self.continueButtonHC.constant = 50
            self.continueButtonTC.constant = 10
            self.continueBtn.isHidden = false
            self.addressSelected = true
            self.statusLbl.isHidden = true
            self.pickUpTable.isHidden = false
            self.continueBtn.isUserInteractionEnabled = true
            self.continueBtn.backgroundColor = AppColors.greenColorRGB
            self.pickUpTable.reloadData()
            if editAddressStatus == "editaddress"{
                self.editAddressStatus = ""
                self.editAddressid = ""
             //   self.selectedRow = self.editAddressIndex
               // self.pickUpTable.reloadData()
                let indexPath = IndexPath(row: self.editAddressIndex, section: 0)
                self.pickUpTable.selectRow(at: indexPath, animated: true, scrollPosition: .top)
                self.pickUpTable.delegate?.tableView!(pickUpTable, didSelectRowAt: indexPath)
                self.editAddressIndex = -1
            }else{
                let indexPath = IndexPath(row: 0, section: 0)
                self.pickUpTable.selectRow(at: indexPath, animated: true, scrollPosition: .top)
                self.pickUpTable.delegate?.tableView!(pickUpTable, didSelectRowAt: indexPath)
            }
        }
    }
    func addAddressDelegateTapped(){
        self.pickUpAddressapi()
    }
}

