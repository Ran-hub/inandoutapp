//
//  AddressDetailsViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by AMT on 12/11/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

struct CountryCode1 {
    var code: String?
    var name: String?
    var phoneCode: String?
    
    init(code: String?, name: String?, phoneCode: String?) {
        self.code = code
        self.name = name
        self.phoneCode = phoneCode
    }
}
class AddNewAddresVC: UIViewController,UITextFieldDelegate,UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var countryViewBottom: NSLayoutConstraint!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var countriesTableView: UITableView!
    @IBOutlet weak var countryCodeView: UIView!
    @IBOutlet weak var phoneNumberField: ACFloatingTextfield!
    @IBOutlet weak var nameField: ACFloatingTextfield!
    @IBOutlet weak var emailField: ACFloatingTextfield!
    @IBOutlet weak var typeOffParcelTxt: UITextField!
    @IBOutlet weak var conutryCodeTxt: UITextField!
    @IBOutlet weak var conutryCodeView: UIView!
    @IBOutlet weak var contentViewHC: NSLayoutConstraint!
    @IBOutlet weak var contentViewObj: UIView!
    @IBOutlet weak var addressViewObj: UIView!
    @IBOutlet weak var confirmBtm: UIButton!
    @IBOutlet weak var addressBtn: UIButton!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var addressLbl: UILabel!
    @IBOutlet weak var addressLblHC: NSLayoutConstraint!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var typeofParcel: UILabel!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    
    
    var countriesObj = [CountryCode1]()
    var filteredphonecodeArray = NSMutableArray()
    var filteredcodeArray = NSMutableArray()
    var nameArray = NSMutableArray()
    var filteredArray:[String] = []
    var  countrycodeArray = NSMutableArray()
    var phonecodeArray = NSMutableArray()
    var isSearching  = false
    
    var controlerName : String = String()
    var addressObjStr : String = String()
    var nameObjStr : String = String()
    var zipcodeObjStr : String = String()
    var contactNoObjStr : String = String()
    var emailObjStr : String = String()
    var houseNoObjStr : String = String()
    var streetObjStr1 : String = String()
    var streetObjStr2: String = String()
    var streetObjStr3 : String = String()
    var cityObjStr : String = String()
    var stateObjStr : String = String()
    var countryObjStr : String = String()
    var typeofAddressObjStr : String = String()
    var fullAddress = ""

    var latitudeObjStr : String = String()
    var longitudeObjStr : String = String()
    
    let appdeletegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    let addressDropDown = DropDown()
    lazy var dropDowns: [DropDown] = {
        return [
            self.addressDropDown
        ]
    }()
    
    override func viewDidLoad(){
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.initialSetup()
        self.getCountryCode()
    }
    
    func getCountryCode(){
        countriesObj = self.countryNamesByCode()
        if let countryCode = (Locale.current as NSLocale).object(forKey: .countryCode) as? String {
            //  print("countryCode",countryCode)
            for country in countriesObj{
                if countryCode == country.code{
                    self.conutryCodeTxt.text = country.phoneCode
                }
            }
        }
    }
    func countryNamesByCode() -> [CountryCode1] {
        var countries = [CountryCode1]()
        do{
            if let file = Bundle.main.url(forResource: "countryCodes", withExtension: "json") {
                let data = try Data(contentsOf: file)
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                if let object = json as? [String: Any] {
                    // json is a dictionary
                    //  print(object)
                } else if let object = json as? [Any] {
                    // json is an array
                    for jsonObject in object {
                        guard let countryObj = jsonObject as? NSDictionary else {
                            return countries
                        }
                        guard let code = countryObj["code"] as? String, let phoneCode = countryObj["dial_code"] as? String, let name = countryObj["name"] as? String else {
                            return countries
                        }
                        nameArray.add(name)
                        let country1 = CountryCode1(code: code, name: name, phoneCode: phoneCode)
                        countriesObj.append(country1)
                    }
                    
                    // print(object)
                } else {
                    // print("JSON is invalid")
                }
            } else {
                // print("no file")
            }
        }
        catch {
            //   print(error.localizedDescription)
        }
        return countriesObj
    }
    func initialSetup(){
        self.nameField.placeholder = NSLocalizedString("txt_receivername", comment: "")
        self.nameField.font = AppFont.regularTextFont
        self.emailField.placeholder = NSLocalizedString("txt_eamil", comment: "")
        self.emailField.font = AppFont.regularTextFont
        self.conutryCodeTxt.placeholder = NSLocalizedString("lbl_code", comment: "")
        self.conutryCodeTxt.font = AppFont.regularTextFont
        self.phoneNumberField.placeholder = NSLocalizedString("txt_contactno",comment: "")
        self.phoneNumberField.font = AppFont.regularTextFont
        self.typeofParcel.text = NSLocalizedString("txt_typeofparcel",comment: "")
        self.typeOffParcelTxt.font = AppFont.regularTextFont
        self.titleLbl.text = NSLocalizedString("lbl_addressdetails", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        self.titleLbl.textColor = AppColors.whiteColorRGB
        if appdeletegate.IS_IPHONE5{
            self.titleLbl.font = UIFont(name: "HelveticaNeue", size: 18)
        }
        self.typeOffParcelTxt.text = NSLocalizedString("valid_home",comment: "")
        self.nameField.font = AppFont.regularTextFont
        self.emailField.font = AppFont.regularTextFont
        self.phoneNumberField.font = AppFont.regularTextFont
        self.confirmBtm.setTitle(NSLocalizedString("btn_confirm", comment: ""), for: .normal)
        self.confirmBtm.backgroundColor = AppColors.greenColorRGB
        self.confirmBtm.titleLabel?.textColor = AppColors.whiteColorRGB
        self.confirmBtm.titleLabel?.font = AppFont.boldTextFont
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.addressLbl.text = self.fullAddress
        var height : CGFloat = 0
        height += self.heightForView(text: self.addressLbl.text!, font: UIFont(name: "HelveticaNeue", size: 17)!, width: self.addressLbl.frame.size.width)
        self.addressLblHC.constant = height
        self.addressLbl.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.addressLbl.numberOfLines = 0
        self.addressLbl.sizeToFit()
        self.contentViewHC.constant = 10+50+10+50+10+50+15+height+15+50+10
        let dropdown = UIButton()
        dropdown.setImage(UIImage(named:"icon_downarrow"), for: .normal)
        dropdown.imageEdgeInsets = UIEdgeInsetsMake(0, -16, 0, 0)
        dropdown.frame = CGRect(x: CGFloat(self.typeOffParcelTxt.frame.size.width - 25), y: CGFloat(5), width: CGFloat(25), height: CGFloat(25))
        dropdown.isUserInteractionEnabled = true
        self.typeOffParcelTxt.rightView = dropdown
        self.typeOffParcelTxt.rightViewMode = .always
        let dropdown1 = UIButton()
        dropdown1.setImage(UIImage(named:"icon_downarrow"), for: .normal)
        dropdown1.imageEdgeInsets = UIEdgeInsetsMake(0, -16, 0, 0)
        dropdown1.frame = CGRect(x: CGFloat(self.typeOffParcelTxt.frame.size.width - 25), y: CGFloat(5), width: CGFloat(25), height: CGFloat(25))
        dropdown1.isUserInteractionEnabled = true
        self.conutryCodeTxt.rightView = dropdown1
        self.conutryCodeTxt.rightViewMode = .always
        if Constants.getValueFromUserDefults(for: "countrycode") != nil{
            let countrycode = Constants.getValueFromUserDefults(for: "countrycode") as! String
            self.conutryCodeTxt.text = countrycode
        }
        self.countriesTableView.layer.borderWidth = 1
        self.countriesTableView.layer.borderColor = AppColors.lightGrayColorRGB.cgColor
        self.searchBar.returnKeyType = .done
        searchBar.delegate = self
        self.countriesTableView.register(UINib(nibName: "CountryTableViewCell", bundle: nil), forCellReuseIdentifier: "CountryTableViewCell")
        self.countriesTableView.delegate = self
        self.countriesTableView.dataSource = self
        self.countryCodeView.isHidden = true
        self.setupAddressDropDown()
    }
    func setupAddressDropDown(){
        addressDropDown.anchorView = self.addressViewObj
        addressDropDown.dismissMode = .onTap
        addressDropDown.direction = .top
        addressDropDown.bottomOffset = CGPoint(x: 0, y: addressViewObj.bounds.height)
        addressDropDown.dataSource = [NSLocalizedString("txt_typeofparcel",comment: ""),NSLocalizedString("valid_home",comment: ""),
                                      NSLocalizedString("valid_office",comment: "")
        ]
        addressDropDown.selectionAction = { [unowned self] (index, item) in
            // self.amountButton.setTitle(item, for: .normal)
            self.typeOffParcelTxt.text = item
        }
    }
    func heightForView(text:String, font:UIFont, width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRect(x:0, y:0, width:width, height:10000))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    
    @IBAction func btnsTapped(_ sender: UIButton){
        let btn = sender as UIButton
        if btn.tag == 10{
            dismissKeybord()
            self.dismiss(animated: true, completion: nil)
        }else if btn.tag == 20{
            dismissKeybord()
            self.addressDropDown.show()
        }else if btn.tag == 30{
            self.callApisForPickuporReceiverAddress()
        }else if btn.tag == 40{
            self.dismissKeybord()
            self.isSearching = false
            self.searchBar.text = ""
            self.view.bringSubview(toFront: self.countryCodeView)
            //  self.scrollViewObj.bringSubview(toFront: self.countryCodeView)
            self.countryCodeView.isHidden = false
        }
    }
    
    func callApisForPickuporReceiverAddress(){
        if nameField.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_name",comment: ""), completion: {(result) in
                self.nameField.becomeFirstResponder()
            })
            return
        }else if emailField.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_email",comment: ""), completion: {(result) in
                self.emailField.becomeFirstResponder()
            })
            return
        }else if Constants().isValidEmail(emailField.text!) == false{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_email1",comment: ""), completion: {(result) in
                self.emailField.becomeFirstResponder()
            })
        }else if conutryCodeTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr:NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_country",comment: ""), completion: {(result) in
            })
            return
        }else if self.phoneNumberField.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_mobileno",comment: ""), completion: {(result) in
                self.phoneNumberField.becomeFirstResponder()
            })
            return
        }else if Constants().validatePhoneNumber(value:self.phoneNumberField.text!) == false{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_mobileno1",comment: ""), completion: {(result) in
                self.phoneNumberField.becomeFirstResponder()
            })
            return
        }else if typeOffParcelTxt.text  == NSLocalizedString("txt_typeofparcel",comment:""){
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_parceltype",comment: ""), completion: {(result) in
            })
            return
        }else if typeOffParcelTxt.text?.count == 0{
            self.showAlertMessagewithAction(titleStr: NSLocalizedString("RYTLE",comment: ""), messageStr: NSLocalizedString("valid_parceltype",comment: ""), completion: {(result) in
            })
            return
        }else{
            self.dismissKeybord()
            if controlerName == "PickUpDetails"{
                let customer_id = UserDefaults.standard.value(forKey: "customer_id") as! String
                if self.ineternetAlert() == false{
                    return
                }
                self.pickupAddNewAddressApi(p_fullname: self.nameField.text!, p_email_id: self.emailField.text!, p_mobile_no: self.conutryCodeTxt.text! + " " + self.phoneNumberField.text!, customer_id:customer_id , house_noStr: houseNoObjStr, streetStr1: streetObjStr1, streetStr2: streetObjStr2, streetStr3: streetObjStr3, zip_code: zipcodeObjStr, state: stateObjStr, city: cityObjStr, country: countryObjStr, longitude: longitudeObjStr, latitude: latitudeObjStr, address_type: self.typeOffParcelTxt.text!)
            }else if controlerName  == "ReceiverDetails"{
                let customer_id = UserDefaults.standard.value(forKey: "customer_id") as! String
                if self.ineternetAlert() == false{
                    return
                }
                self.receiverAddNewAddressApi(d_fullname: self.nameField.text!, d_email_id: self.emailField.text!, d_mobile_no: self.conutryCodeTxt.text! + " " + self.phoneNumberField.text!, customer_id: customer_id , house_noStr: houseNoObjStr, streetStr1: streetObjStr1, streetStr2: streetObjStr2, streetStr3: streetObjStr3, zip_code: zipcodeObjStr, state: stateObjStr, city: cityObjStr, country: countryObjStr, longitude: longitudeObjStr, latitude: latitudeObjStr, address_type: self.typeOffParcelTxt.text!)
            }
        }
    }
    
    func receiverAddNewAddressApi(d_fullname : String ,d_email_id :String, d_mobile_no : String,customer_id : String,house_noStr : String ,streetStr1 : String ,streetStr2: String, streetStr3 : String ,zip_code : String,state :String, city :String,country:String,longitude: String, latitude:String,address_type:String){
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        bodyReq = ["d_fullname":d_fullname,"d_email_id":d_email_id, "house_no" : house_noStr,"d_mobile_no" : d_mobile_no, "customer_id": customer_id,"street1": streetStr1,"street2":streetStr2,"street3":streetStr3 ,"zip_code":zip_code,"state" : state,"city":city,"country" : country,"latitude" : latitude ,"longitude":longitude , "address_type" : address_type]
        
        //  print("bodyReq",bodyReq)
        
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            let token = UserDefaults.standard.value(forKey: "usertoken") as! String
            let sessionStr = "Bearer " + token
            APICommnicationManager.sharedInstance.requestforAPI(service:"/Parcel/createDeliveryaddress" , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (result, error) in
                if let Result = result as? [String:Any]{
                    //  print("Result",Result)
                    if let status = Result["status"] as? Bool {
                        if status == true{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.appdeletegate.recieverAddAddress = "yes"
                                self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
                            })
                        }
                        if status == false{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.displayAlert(message: (Result["error"] as? String)!)
                            })
                        }
                    }
                    else{
                        if Result["code"] as? String == "InvalidCredentials"{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.tokenExpireAlert()
                            })
                        }
                    }
                    
                }else{
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                        self.displayAlert(message: NSLocalizedString("ver_internet", comment: ""))
                    })
                }
            }
        }
    }
    
    func pickupAddNewAddressApi(p_fullname : String ,p_email_id :String, p_mobile_no : String,customer_id : String,house_noStr : String ,streetStr1 : String ,streetStr2: String, streetStr3 : String ,zip_code : String,state :String, city :String,country:String,longitude: String, latitude:String,address_type:String){
        IJProgressView.shared.showProgressView(view)
        var bodyReq = [String:String]()
        bodyReq = ["p_fullname":p_fullname,"p_email_id":p_email_id, "house_no" : house_noStr,"p_mobile_no" : p_mobile_no, "customer_id": customer_id,"street1": streetStr1,"street2":streetStr2,"street3":streetStr3 ,"zip_code":zip_code,"state" : state,"city":city,"country" : country,"latitude" : latitude ,"longitude":longitude , "address_type" : address_type]
        if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            let token = UserDefaults.standard.value(forKey: "usertoken") as! String
            let sessionStr = "Bearer " + token
            APICommnicationManager.sharedInstance.requestforAPI(service:"/Pickup/createNewPickupaddress" , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (result, error) in
                // print("pickup confirmation result",result as Any)
                if let Result = result as? [String:Any]{
                    // print("Result",Result)
                    if let status = Result["status"] as? Bool {
                        if status == true{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.appdeletegate.pickAddAddress = "yes"
                                self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
                            })
                        }
                        if status == false
                        {
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.displayAlert(message: (Result["error"] as? String)!)
                            })
                        }
                    }else{
                        if Result["code"] as? String == "InvalidCredentials"{
                            DispatchQueue.main.async(execute: { () -> Void in
                                IJProgressView.shared.hideProgressView()
                                self.tokenExpireAlert()
                            })
                        }
                    }
                }else{
                    DispatchQueue.main.async(execute: { () -> Void in
                        IJProgressView.shared.hideProgressView()
                        self.displayAlert(message: NSLocalizedString("ver_somethingwrong", comment: ""))
                    })
                }
            }
        }
    }
    func displayAlert(message: String){
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    func dismissKeybord(){
        self.nameField.resignFirstResponder()
        self.emailField.resignFirstResponder()
        self.phoneNumberField.resignFirstResponder()
    }
    func textFieldDidBeginEditing(_ textField: UITextField){
        if textField == self.nameField{
            self.nameField.returnKeyType = .next
        }else if textField == self.emailField{
            self.emailField.returnKeyType = .next
            self.emailField.keyboardType = .emailAddress
        }else if textField == self.phoneNumberField{
            self.phoneNumberField.keyboardType = .numberPad
            self.addBarBtnToKeyboard(textfield: self.phoneNumberField)
        }
    }
  
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField{
        case self.nameField:
            self.emailField.becomeFirstResponder()
            break
        case self.emailField:
            self.phoneNumberField.becomeFirstResponder()
            break
        case self.phoneNumberField:
            textField.resignFirstResponder()
            break
        default:
            textField.resignFirstResponder()
        }
        return true
    }
    func addBarBtnToKeyboard(textfield : UITextField){
        let keyPadToolBar = UIToolbar()
        keyPadToolBar.barStyle = UIBarStyle.blackTranslucent
        keyPadToolBar.barTintColor = AppColors.greenColorRGB
        keyPadToolBar.sizeToFit()
        let DoneButton = UIBarButtonItem(title:NSLocalizedString("keyboard_done", comment: ""), style: UIBarButtonItemStyle.done, target: self, action: #selector(AddNewAddresVC.dismissKeybord))
        DoneButton.tintColor = AppColors.whiteColorRGB
        keyPadToolBar.setItems([DoneButton], animated: true)
        textfield.inputAccessoryView = keyPadToolBar
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        countryViewBottom.constant = 216+20+5 - countryViewBottom.constant
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        // countryViewBottom.constant = 20 + countryViewBottom.constant
        searchBar.resignFirstResponder()
        self.searchBar.endEditing(true)
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchBar.text == "" || searchBar.text == nil{
            isSearching = false
            self.countriesTableView.reloadData()
        }else{
            // isSearching = true
            self.phonecodeArray = [];
            self.countrycodeArray = [];
            self.filteredArray = [];
            let searchPredicate = NSPredicate(format: "SELF beginswith[c] %@",searchBar.text!)
            filteredArray = (nameArray.filtered(using: searchPredicate) as NSMutableCopying) as! [String]
            for index in filteredArray{
                var name = ""
                name = index
                for country in countriesObj{
                    if name == country.name{
                        self.phonecodeArray.add(country.phoneCode!)
                        self.countrycodeArray.add(country.code!)
                    }
                }
            }
            if(filteredArray.count == 0){
                isSearching = false;
            } else {
                isSearching = true;
            }
            self.countriesTableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isSearching == true{
            return filteredArray.count
        }else{
            return countriesObj.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CountryTableViewCell", for: indexPath) as! CountryTableViewCell
        if isSearching  == true{
            let countrycode =  "(" + (countrycodeArray[indexPath.row] as? String)! + ")"
            let newcountry = (filteredArray[indexPath.row] as? String)!
                + countrycode
            cell.countryNameLbl.text = newcountry
            cell.countryCodeLbl.text = phonecodeArray[indexPath.row] as? String
        }else{
            let country = self.countriesObj[indexPath.row]
            let countrycode = "(" + country.code! + ")"
            cell.countryNameLbl.text = country.name! + countrycode
            cell.countryCodeLbl.text = country.phoneCode
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        countryViewBottom.constant = 20
        if isSearching == true{
            isSearching = false
            self.searchBar.resignFirstResponder()
            let code = phonecodeArray[indexPath.row] as? String
            self.conutryCodeTxt.text = code
            self.countryCodeView.isHidden = true
            self.phonecodeArray = [];
            self.countrycodeArray = [];
            self.filteredArray = [];
        }else{
            isSearching = false
            let country = countriesObj[indexPath.row]
            let code = country.phoneCode
            self.conutryCodeTxt.text = code
            self.countryCodeView.isHidden = true
            self.searchBar.resignFirstResponder()
        }
        self.countriesTableView.reloadData()
    }
}

