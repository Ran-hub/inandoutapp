//
//  SearchCountryCodeVC.swift
//  RYTLECUSTOMERAPP
//
//  Created by AMT on 4/15/18.
//  Copyright © 2018 Pavan. All rights reserved.
//

import UIKit

protocol countryCodeProtocol {
    func sendCountryCode(code:String)
}
struct CountryCode{
    var code: String?
    var name: String?
    var phoneCode: String?
    init(code: String?, name: String?, phoneCode: String?) {
        self.code = code
        self.name = name
        self.phoneCode = phoneCode
    }
}
class SearchCountryCodeVC: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate{
    
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var countriesTableViewBC: NSLayoutConstraint!
    @IBOutlet weak var countriesTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    var isSearching = false
    var countries = [CountryCode]()
    var delegate : countryCodeProtocol!
    var filteredphonecodeArray = NSMutableArray()
    var filteredcodeArray : NSMutableArray = NSMutableArray()
    var nameArray : NSMutableArray = NSMutableArray()
    var filteredArray:[String] = []
    var countrycodeArray : NSMutableArray = NSMutableArray()
    var phonecodeArray : NSMutableArray = NSMutableArray()
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        titleLbl.text = NSLocalizedString("lbl_countycode", comment: "")
        titleLbl.font = AppFont.boldTextFont
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.searchBar.placeholder = NSLocalizedString("lbl_searchaddress", comment: "")
        searchBar.returnKeyType = .done
        searchBar.delegate = self
        self.countriesTableView.register(UINib(nibName: "CountriesNamesTC", bundle: nil), forCellReuseIdentifier: "CountriesNamesTC")
        self.countryCodeSetup()
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        searchBar.resignFirstResponder()
    }
    func countryCodeSetup(){
        countries = countryNamesByCode()
        if let countryCode = (Locale.current as NSLocale).object(forKey: .countryCode) as? String {
            for country in countries{
                if countryCode == country.code{
                    //self.countryCodeSetup.text = country.phoneCode
                }
            }
        }
    }
    func countryNamesByCode() -> [CountryCode] {
        var countries = [CountryCode]()
        do{
            if let file = Bundle.main.url(forResource: "countryCodes", withExtension: "json") {
                let data = try Data(contentsOf: file)
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                if let object = json as? [String: Any] {
                    // json is a dictionary
                    // print(object)
                } else if let object = json as? [Any] {
                    // json is an array
                    for jsonObject in object {
                        guard let countryObj = jsonObject as? NSDictionary else {
                            return countries
                        }
                        guard let code = countryObj["code"] as? String, let phoneCode = countryObj["dial_code"] as? String, let name = countryObj["name"] as? String else {
                            return countries
                        }
                        nameArray.add(name)
                        let country = CountryCode(code: code, name: name, phoneCode: phoneCode)
                        countries.append(country)
                    }
                    // print(object)
                } else {
                    // print("JSON is invalid")
                }
            } else {
                print("no file")
            }
        }
        catch {
            print(error.localizedDescription)
        }
        return countries
    }
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar){
        countriesTableViewBC.constant = 216+5 - countriesTableViewBC.constant
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar){
        searchBar.resignFirstResponder()
         self.searchBar.endEditing(true)
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String){
        if searchBar.text == "" || searchBar.text == nil{
            isSearching = false
            countriesTableView.reloadData()
        }
        else{
            self.phonecodeArray = [];
            self.countrycodeArray = [];
            self.filteredArray = [];
            let searchPredicate = NSPredicate(format: "SELF beginswith[c] %@",searchBar.text!)
            filteredArray = (nameArray.filtered(using: searchPredicate) as NSMutableCopying) as! [String]
            for index in filteredArray{
                var name = ""
                name = index
                for country in countries{
                    if name == country.name{
                        self.phonecodeArray.add(country.phoneCode!)
                        self.countrycodeArray.add(country.code!)
                    }
                }
            }
            if(filteredArray.count == 0){
                isSearching = false;
            } else {
                isSearching = true;
            }
            self.countriesTableView.reloadData()
        }
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        countriesTableViewBC.constant = 0
        self.isSearching = false
        searchBar.text = ""
        searchBar.resignFirstResponder()
        self.countriesTableView.reloadData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isSearching == true{
            return  filteredArray.count
        }else{
            return countries.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CountriesNamesTC", for: indexPath) as! CountriesNamesTC
        if isSearching  == true{
            let countrycode =  "(" + (countrycodeArray[indexPath.row] as? String)! + ")"
            let newcountry = (filteredArray[indexPath.row] as? String)!
                + countrycode
            cell.countryNameLbl.text = newcountry
            cell.countryCodeLbl.text = phonecodeArray[indexPath.row] as? String
        }
        else{
            let country = countries[indexPath.row]
            let countrycode = "(" + country.code! + ")"
            cell.countryNameLbl.text = country.name! + countrycode
            cell.countryCodeLbl.text = country.phoneCode
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        countriesTableViewBC.constant = 0
        var countryCode = ""
        if isSearching == true{
            isSearching = false
            self.searchBar.resignFirstResponder()
            countryCode = (phonecodeArray[indexPath.row] as? String)!
          //  self.countryCodeTxt.text = code
          //  self.countryView.isHidden = true
            self.phonecodeArray = [];
            self.countrycodeArray = [];
            self.filteredArray = [];
        }else{
            isSearching = false
            let country = countries[indexPath.row]
            countryCode = country.phoneCode!
            //self.countryCodeTxt.text = code
           // self.countryView.isHidden = true
            //self.searchBar.resignFirstResponder()
        }
        if countryCode != ""{
            self.dismissSearchKeyboard()
            self.delegate.sendCountryCode(code: countryCode)
            self.dismiss(animated: true, completion: nil)
        }
        //self.regTableView.reloadData()
        //self.scrollViewObj.isScrollEnabled = true
    }
    func dismissSearchKeyboard(){
        searchBar.resignFirstResponder()
    }
    @IBAction func cancelBtnTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
