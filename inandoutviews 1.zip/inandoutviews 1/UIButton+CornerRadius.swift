//
//  UIButton+CornerRadius.swift
//  RYTLE
//
//  Created by Admin on 18/04/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import Foundation
import UIKit

extension UIView {
    @IBInspectable var view_borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    @IBInspectable var view_borderColor: UIColor? {
        get {
            return UIColor(cgColor: layer.borderColor!)
        }
        set {
            layer.borderColor = newValue?.cgColor
        }
    }
    @IBInspectable var view_cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
            clipsToBounds = newValue > 0
        }
        get {
            return layer.cornerRadius
        }
    }
}
extension UIButton{
     @IBInspectable var btn_borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    @IBInspectable var btn_borderColor: UIColor? {
        get {
            return UIColor(cgColor: layer.borderColor!)
        }
        set {
            layer.borderColor = newValue?.cgColor
        }
    }
    @IBInspectable var btn_cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
            clipsToBounds = newValue > 0
        }
        get {
            return layer.cornerRadius
        }
    }
    func butonCornerRadius(btn : UIButton) -> UIButton {
        let btn = btn;
        btn.layer.cornerRadius = 5
        btn.layer.borderWidth =  1
        btn.layer.borderColor = UIColor.white.cgColor
        btn.layer.borderWidth = 1
        return btn
    }
}
extension String {
    func capitalizedFirst() -> String {
        let first = self[self.startIndex ..< self.index(startIndex, offsetBy: 1)]
        let rest = self[self.index(startIndex, offsetBy: 1) ..< self.endIndex]
        return first.uppercased() + rest.lowercased()
    }
}
extension UILabel{
    @IBInspectable var text_borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    @IBInspectable var text_borderColor: UIColor? {
        get {
            return UIColor(cgColor: layer.borderColor!)
        }
        set {
            layer.borderColor = newValue?.cgColor
        }
    }
    @IBInspectable var text_cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
            clipsToBounds = newValue > 0
        }
        get {
            return layer.cornerRadius
        }
    }
}
extension UITextView{
    @IBInspectable var text_borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    @IBInspectable var text_borderColor: UIColor? {
        get {
            return UIColor(cgColor: layer.borderColor!)
        }
        set {
            layer.borderColor = newValue?.cgColor
        }
    }
    @IBInspectable var text_cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
            clipsToBounds = newValue > 0
        }
        get {
            return layer.cornerRadius
        }
    }
}
extension UITextField{
    @IBInspectable var text_borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    @IBInspectable var text_borderColor: UIColor? {
        get {
            return UIColor(cgColor: layer.borderColor!)
        }
        set {
            layer.borderColor = newValue?.cgColor
        }
    }
    @IBInspectable var text_cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
            clipsToBounds = newValue > 0
        }
        get {
            return layer.cornerRadius
        }
    }
    func textfieldCornerRadius(txtField : UITextField) -> UITextField {
        let txtField = txtField;
        txtField.layer.cornerRadius = 5
        return txtField
    }
    func textfieldCornerRadiusForRider(txtField : UITextField) -> UITextField {
        let txtField = txtField;
        txtField.layer.cornerRadius = 5
        txtField.layer.borderColor = UIColor.black.cgColor
        txtField.layer.borderWidth = 1
        return txtField
    }
    func addBorderToTextField(textField : UITextField) -> UITextField{
        let txtField = textField;
        let borderBottom = CALayer()
        let borderWidth = CGFloat(1)
        borderBottom.borderColor = UIColor.lightGray.cgColor
        borderBottom.frame = CGRect(x:0, y: txtField.frame.size.height - 0.5, width: txtField.frame.origin.x+txtField.frame.size.width , height:1)
        borderBottom.borderWidth = borderWidth
        txtField.layer.addSublayer(borderBottom)
        txtField.layer.masksToBounds = true
        return txtField
    }
}
extension UITextView{
    func textviewCornerRadius(txtView : UITextView) -> UITextView {
        let txtView = txtView;
        txtView.layer.cornerRadius = 5
        txtView.layer.borderColor = UIColor.black.cgColor
        txtView.layer.borderWidth = 1
        return txtView
    }
}
extension UIImageView {
    func popupAlert(title: String?, message: String?, width :CGFloat, height:CGFloat) -> UIView{
        let imageviewObject = UIImageView()
        imageviewObject.frame = CGRect(x:0, y:0 , width:width, height :height)
        imageviewObject.backgroundColor = UIColor.blue
        imageviewObject.alpha = 0.5
        let view = UIView()
        view.frame = CGRect(x:15, y:200 , width:300, height :300)
        view.backgroundColor = UIColor.red
        imageviewObject.addSubview(view)
        return imageviewObject
    }
}
extension UIImage{
    func resizeImage(image: UIImage) -> UIImage {
        let newWidth = image.size.width / 2
        let newHeight = image.size.height / 2
        UIGraphicsBeginImageContext(CGSize(width : newWidth, height : newHeight))
        image.draw(in: CGRect(x:0, y:0, width:newWidth, height:newHeight))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!
    }
}
extension UIColor {
    static let greenColorCode = UIColor.init(red: 44/255, green: 192/255, blue: 130/255, alpha: 1)
    static let blackColorCode = UIColor.init(red: 26/255, green: 26/255, blue: 24/255, alpha: 1)
    static let purpleBlueColorCode = UIColor.init(red: 30/255, green: 0/255, blue: 151/255, alpha: 1)
    static let darkRedColorCode = UIColor.init(red: 228/255, green: 23/255, blue: 56/255, alpha: 1)
    static let whiteColorCode = UIColor.white
    
    static let lightGrayColorCode = UIColor(red: 189/255, green: 189/255, blue: 189/255, alpha: 1)
}
extension UIFont {
    static let boldTextFontSize = UIFont(name: "HelveticaNeue-Bold", size: 17)
    static let mediumTextFontSize = UIFont(name: "HelveticaNeue", size: 17)
    static let smallTextFontSize = UIFont(name: "HelveticaNeue", size: 14)
    static let regularTextFontSize = UIFont(name: "HelveticaNeue", size: 15)
}

extension UIViewController {
  
    func tokenExpireMethod(){
        self.logOutApi()
    }
    func logOutApi(){
        if self.ineternetAlert() == false{
            return
        }else{
            if Constants.getValueFromUserDefults(for: "customer_id") as? String == nil{
                self.navigateLoginVC()
            }else{
            IJProgressView.shared.showProgressView(self.view)
            var bodyReq = [String:String]()
            var cust_id = String()
            cust_id = Constants.getValueFromUserDefults(for:"customer_id") as! String
            bodyReq = ["customer_id":cust_id]
            var token = String()
            var reultanttoken = ""
            if Constants.getValueFromUserDefults(for: "usertoken") as? String != nil{
                token = Constants.getValueFromUserDefults(for: "usertoken") as! String
                reultanttoken = "Bearer" + " " + token
            }
            if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[])
            {
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.logoutURL, method: "POST", token:reultanttoken,body: "", productBody: bodyData as NSData) { (data,error,response) in
                if let httpResponse = response as? HTTPURLResponse{
                    IJProgressView.shared.hideProgressView()
                  //  print("httpResponse status code \(httpResponse.statusCode)")
                    switch(httpResponse.statusCode){
                    case 200:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                            self.navigateLoginVC()
                        }
                        break
                    case 500:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                        break
                    case 505:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Logout_505", controller: self)
                        }
                        break
                    default:
                        DispatchQueue.main.async {
                            IJProgressView.shared.hideProgressView()
                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        IJProgressView.shared.hideProgressView()
                    errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                    }
                }
              }
            }
          }
       }
    }
    func navigateLoginVC(){
        var deviceToken = ""
        if UserDefaults.standard.value(forKey: "devicetoken") as? String == nil{
        }else{
            deviceToken = UserDefaults.standard.value(forKey: "devicetoken") as! String
        }
        var orgId = ""
        if UserDefaults.standard.value(forKey: "customerOrgid") as? String == nil{
        }else{
            orgId = UserDefaults.standard.value(forKey: "customerOrgid") as! String
        }
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "logout"), object: nil)
        Constants.deleteAllValuesFromUserDefaulst(obj: "")
        Constants.setValueInUserDefaults(objValue: deviceToken, for: "devicetoken")
        Constants.setValueInUserDefaults(objValue: orgId, for: "customerOrgid")
        let nextViewController = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        self.present(nextViewController, animated: true, completion:nil)
    }
    func ineternetAlert() -> Bool{
        let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        if appdelegate.isInternetAvailable() == false{
            self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr: NSLocalizedString("ver_internetavailable_error", comment: ""))
            return false
        }
        return true
    }
    func languageValidationForGermany(headerView : UIView!,cancelBtn : UIButton!,labelConstraints: NSLayoutConstraint!,titleLbl:UILabel!){
        let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let languageCode = Constants.getValueFromUserDefults(for: "languageCode") as! String
        if appdelegate.IS_IPHONE5 || appdelegate.IS_IPHONE6 || appdelegate.IS_IPHONEX || appdelegate.IS_IPHONE6PLUS{
            if languageCode == "Yes"{
                titleLbl.textAlignment = .left
                headerView.removeConstraint(labelConstraints)
                headerView.addConstraint(NSLayoutConstraint(item: cancelBtn, attribute: .width, relatedBy: .equal , toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 90))
                headerView.addConstraint(NSLayoutConstraint(item: titleLbl, attribute: .leading, relatedBy: .equal , toItem: cancelBtn, attribute: .trailing, multiplier: 1, constant: 5))
                headerView.addConstraint(NSLayoutConstraint(item: headerView, attribute: .trailing, relatedBy: .equal , toItem: titleLbl, attribute: .trailing, multiplier: 1, constant: 5))
            }
        }
    }
    func showAlertMessagewithAction(titleStr : String , messageStr : String,completion:@escaping (_ result:String?) -> ()){
        let opQueue = OperationQueue()
        let alertController = UIAlertController(title: titleStr, message:
            messageStr, preferredStyle: UIAlertController.Style.alert)
        alertController.addAction(UIAlertAction(title: NSLocalizedString("lbl_ok", comment: ""), style: UIAlertAction.Style.default,handler: { action in
            let message = messageStr as String
            completion(message)
        }
        ))
        opQueue.addOperation{
            OperationQueue.main.addOperation({
                self.present(alertController, animated: true, completion: nil)
            })
        }
    }
    func tokenExpireAlert(){
        let opQueue = OperationQueue()
        let alertController = UIAlertController(title: NSLocalizedString("Rytle", comment: ""), message:
            NSLocalizedString("lbl_tokenexpire", comment:""), preferredStyle: UIAlertController.Style.alert)
        alertController.addAction(UIAlertAction(title: NSLocalizedString("lbl_ok", comment: ""), style: UIAlertAction.Style.default,handler: { action in
            self.tokenExpireMethod()
        }
        ))
        opQueue.addOperation {
            OperationQueue.main.addOperation({
                self.present(alertController, animated: true, completion: nil)
            })
        }
    }
    func showAlertMessage(vc: UIViewController, titleStr:String, messageStr:String) -> Void {
        let opQueue = OperationQueue()
        let alert = UIAlertController(title: titleStr, message: messageStr, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("lbl_ok", comment: ""), style: UIAlertAction.Style.default, handler: nil))
        opQueue.addOperation{
            OperationQueue.main.addOperation({
                self.present(alert, animated: true, completion: nil)
            })
        }
    }
    func errorMessagesDisplayAlert(vc: UIViewController, titleStr:String, messageStr:String) -> Void {
        let alert = UIAlertController(title: titleStr, message: messageStr, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("lbl_ok", comment: ""), style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    func orgnaizationAPi(completion : @escaping(_ result : String) ->()){
        IJProgressView.shared.showProgressView(view)
        let orgId = UserDefaults.standard.object(forKey: "customerOrgid")
        if orgId == nil {
            DispatchQueue.global().async {
                var bodyReq = [String:String]()
                bodyReq = ["secret_key":APPURLS.orgScrectKey1]
                if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
            APICommnicationManager.sharedInstance.requestforAPI(service:APPURLS.customerAppOrgWiseRegURL, method: "POST", token: "", body: "", productBody: bodyData as NSData) { (data,error,response) in
                        if let httpResponse = response as? HTTPURLResponse{
                         //   print("httpResponse status code \(httpResponse.statusCode)")
                            switch(httpResponse.statusCode){
                            case 200:
                                if let receivedData = data{
                                    do{
                                        let resultDic = try JSONSerialization.jsonObject(with: receivedData, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                                        if let Result = resultDic as? [String:Any]{
                                        if let result = Result["Msg"] as? NSArray{
                                            if let resdDic = result[0] as? [String: Any]{
                                              //  print(resdDic)
                                                if let ordId = resdDic["org_id"] as? Int{
                                                    Constants.setValueInUserDefaults(objValue: String(ordId), for: "customerOrgid")
                                                    completion(String(ordId))
                                                }
                                            }
                                          }
                                        }
                                    }catch {
                                        errorCodesMessageDisplayAlert(statusCode: "Server_500", controller: self)
                                    }
                                }
                                break
                            default:break
                            }
                        }
                    }
                }
            }
        }
    }
    func getProfilePicData(completion:@escaping(_ responseData:Data? ,_ error:Any?)->()){
        var session:URLSession!
        var token = String()
        if Constants.getValueFromUserDefults(for: "usertoken") as? String == nil{
            return
        }else{
            let profileImageURL = Constants.getValueFromUserDefults(for: "profileImgLink") as! String
            let imageName = profileImageURL.split{$0 == "/"}.map(String.init)
         //   print(imageName)
            var imageNameStr = ""
            if imageName.count == 3{
                return
            }else{
                imageNameStr = imageName[3]
            }
            token = Constants.getValueFromUserDefults(for: "usertoken") as! String
            let tokenStr = "?token="+token+"&type=customer"
            let urlPath: String = APPURLS.baseURL + APPURLS.versionNumber + APPURLS.profilePicPath + imageNameStr + tokenStr
            let url: NSURL = NSURL(string: urlPath)!
           // print("URL:\(url)")
            let request = NSMutableURLRequest(url: url as URL)
            request.httpMethod = "GET"
            request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            let config = URLSessionConfiguration.ephemeral
            session = URLSession(configuration: config)
            let task = session.dataTask(with: request as URLRequest) { (data, response, error) -> Void in
              //  print(response ?? AnyObject.self)
                if let receivedData = data{
                   // print("RESULt",receivedData)
                    completion(receivedData, nil)
                }else if let errorMessage = error{
                    completion(nil, errorMessage)
                  //  print(errorMessage.localizedDescription)
                }
                session.invalidateAndCancel()
            }
            task.resume()
        }
    }
    
}
