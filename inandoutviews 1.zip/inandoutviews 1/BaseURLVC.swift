//
//  BaseURLVC.swift
//  RYTLERIDERAPP
//
//  Created by AMT on 8/20/18.
//  Copyright © 2018 Pavan. All rights reserved.
//

import UIKit

class BaseURLVC: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var localURLTF: UITextField!
    @IBOutlet weak var localPortNumberTF: UITextField!
    @IBOutlet weak var stagingURLTF: UITextField!
    @IBOutlet weak var productionURLTF: UITextField!
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.localURLTF.text = APPURLS.localbaseURL
        self.stagingURLTF.text = APPURLS.stagingbaseURL
        self.productionURLTF.text = APPURLS.productionbaseURL
        Constants.setValueInUserDefaults(objValue: "local", for: "org")
    }
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    @IBAction func btnsTapped(_ sender : UIButton){
      
        if sender.tag == 10{
            Constants.setValueInUserDefaults(objValue: "local", for: "org")
        }else if sender.tag == 20{
            Constants.setValueInUserDefaults(objValue: "stag", for: "org")
        }else if sender.tag == 30{
            Constants.setValueInUserDefaults(objValue: "prod", for: "org")
        }else if sender.tag == 40{
            UserDefaults.standard.removeObject(forKey: "customerOrgid")
          //  DispatchQueue.global().async {
                self.appdelegate.orgnaizationAPi()
          //  }
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let LoginVC = storyBoard.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            self.present(LoginVC, animated: true, completion: nil)
        }else if sender.tag == 50{
            if self.localPortNumberTF.text?.count == 0 {
               self.showAlertMessage(vc: self, titleStr: "RYTLE", messageStr: "Please enter the local url with port number")
            }else{
                Constants.setValueInUserDefaults(objValue: "localwithport", for: "org")
                Constants.setValueInUserDefaults(objValue: self.localPortNumberTF.text!, for: "portnumber")
            }
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
