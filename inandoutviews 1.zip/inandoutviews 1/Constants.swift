//
//  Constants.swift
//  CourierApp
//
//  Created by pavan on 18/07/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import Foundation
import UIKit

class Constants{
    
    class func checkingCountryLagunage(){
        if let countryCode = (Locale.current as NSLocale).object(forKey: .languageCode) as? String {
            if countryCode == "de" || countryCode == "de-AT" || countryCode == "de-CH"{
              //  print("languageCode :::: ",countryCode)
                Constants.setValueInUserDefaults(objValue: "Yes", for: "languageCode")
            }
            else{
                Constants.setValueInUserDefaults(objValue: "No", for: "languageCode")
            }
        }
        let pre = Locale.preferredLanguages[0]
      //  print("pre :: ",pre)
    }
    func validatePhoneNumber(value: String) -> Bool{
        if value.count == 10{
            return true
        }else if value.count == 11{
            return true
        }else{
            return false
        }
    }
    class func apisResponseStrings(str: String?) -> String{
        if let name = str{
            return name
        }
        return ""
    }
    class func apisResponseIntValues(values: Int?) -> Int{
        if let value = values{
            return value
        }
        return 0
    }
   /* class func checkingAddressValidationAndReturnAddress(houseno: String, street1: String, street2: String, street3 : String, city: String, state: String, country: String ) -> String
    {
        if  street2.count == 0 && street3.count == 0{
            return houseno  + ", " + street1 + ", "  + city  + ", " + state  + ", " + country
        }
        else if street2.count>0 && street3.count == 0{
            return houseno  + ", " + street1 + ", " + street2  + ", " + city  + ", "  + state  + ", " + country
            
        }
        else if street2.count == 0 && street3.count > 0{
            return houseno  + ", " + street1 + ", " + street3 + ", " + city  + ", "  + state  + ", " + country
        }
        else{
            return  houseno  + ", " + street1 + ", " + street2  + ", "  + street3 + ", " + city  + ", " + state  + ", " + country
        }
    }*/
    
    func isValidEmail(_ testStr:String) -> Bool {
        let emailRegEx = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: testStr)
        return result
    }
    
    func isValidPincode(value: String) -> Bool {
        if value.count == 6{
            return true
        }
        else{
            return false
        }
    }
    func animateViewMoving (up:Bool, moveValue :CGFloat,view:UIView){
        let movementDuration:TimeInterval = 0.3
        let movement:CGFloat = ( up ? -moveValue : moveValue)
        UIView.beginAnimations( "animateView", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration )
        view.frame = view.frame.offsetBy(dx: 0,  dy: movement)
        UIView.commitAnimations()
    }
    func removeActivityIndicatorView(screenview:UIView){
        let activityBackgroundView = screenview.viewWithTag(101)
        activityBackgroundView?.removeFromSuperview()
    }
   /* class func checkForNull(value:AnyObject) -> String
    {
        if(value as! NSObject == NSNull() || value as! String == "")
        {
            return ""
        }
        else
        {
            // print(value)
            return value as! String
        }
    }*/
    class func checkForNullNumber(value:AnyObject) -> NSNumber{
        if (value as! NSObject == NSNull()){
            var count = NSNumber()
            count = 0
            return count
        }else{
            return value as! NSNumber
        }
    }
    class func getValueFromUserDefults(for key:String) -> Any?{
        let userDefault = UserDefaults.standard
        return userDefault.value(forKey: key)
    }
    class func setValueInUserDefaults(objValue:String,for key:String){
        let userDefault = UserDefaults.standard
        userDefault.set(objValue, forKey: key)
        userDefault.synchronize()
    }
    class func setDataInUserDefaults(objValue:Any,for key:String){
        let userDefault = UserDefaults.standard
        userDefault.set(objValue, forKey: key)
        userDefault.synchronize()
    }
    class func removeValueFromUserDefults(for key:String){
        let userDefault = UserDefaults.standard
        return userDefault.removeObject(forKey:key)
    }
    class func deleteAllValuesFromUserDefaulst( obj:String) {
        let domain = Bundle.main.bundleIdentifier!
        UserDefaults.standard.removePersistentDomain(forName: domain)
        UserDefaults.standard.synchronize()
      //  print(Array(UserDefaults.standard.dictionaryRepresentation().keys).count)
    }
}


