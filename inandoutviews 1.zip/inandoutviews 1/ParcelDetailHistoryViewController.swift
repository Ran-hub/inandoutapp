//
//  ParcelDetailHistoryViewController.swift
//  RYTLECUSTOMERAPP
//
//  Created by AMT on 9/7/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

import UIKit

class ParcelDetailVC: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var parcelDetailsTableView: UITableView!
    @IBOutlet weak var trackBtnEWC: NSLayoutConstraint!
    @IBOutlet weak var feedbackBtnEWC: NSLayoutConstraint!
    @IBOutlet var headerView: UIView!
    @IBOutlet var titleLbl: UILabel!
    @IBOutlet var cancelBtn: UIButton!
    @IBOutlet var trackBtn: UIButton!
    @IBOutlet var feedbackBtn: UIButton!
    @IBOutlet weak var cancelBtnTC: NSLayoutConstraint!
    @IBOutlet weak var titleLblTC: NSLayoutConstraint!
    @IBOutlet weak var headerViewHC: NSLayoutConstraint!
    var parcelPlaceHolderArray  = NSMutableArray()
    var parcelApiArray  = NSMutableArray()
    var parcelsizesPHArray  = NSMutableArray()
    var parcelsizesAPIArray  = NSMutableArray()
    var pickupDetailsArray  = NSMutableArray()
    var receiverDetailsArray  = NSMutableArray()
    var constatintsArray  = NSMutableArray()
    var pickupheight : CGFloat = 0
    var receiverheight : CGFloat = 0
    var contentHeight : CGFloat = 0
    var timeStr = ""
    //var riderId_api = String()
    var parcelStatusStr = ""
    var parcelId = ""
    var riderId = ""
    let appdelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad(){
        super.viewDidLoad()
        self.initialSetup()
        self.tableViewSetup()
        self.intialConstraintsSetup()
        self.getParcelDetailsApi(parcelId: self.parcelId)
    }
    func intialConstraintsSetup(){
        if appdelegate.IS_IPHONEX{
            self.headerViewHC.constant = 80
            self.titleLblTC.constant = 35
            self.cancelBtnTC.constant = 35
        }
    }
    func initialSetup(){
        self.navigationController?.navigationBar.isHidden = true
        self.statusLbl.text = NSLocalizedString("ver_noparcelfound", comment: "")
        self.trackBtn.setTitle(NSLocalizedString("lbl_trackbtn", comment: ""), for: UIControlState.normal)
        self.statusLbl.isHidden = true
        self.trackBtn.titleLabel?.font = AppFont.boldTextFont
        self.trackBtn.backgroundColor = AppColors.greenColorRGB
        self.trackBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.titleLbl.text = NSLocalizedString("lbl_parceldetals", comment: "")
        self.titleLbl.font = AppFont.boldTextFont
        if appdelegate.IS_IPHONE5{
            titleLbl.font = UIFont(name: "HelveticaNeue", size: 18)
        }
        self.titleLbl.textColor = AppColors.whiteColorRGB
        self.cancelBtn.setTitle(NSLocalizedString("btn_cancel", comment: ""), for: .normal)
        self.cancelBtn.titleLabel?.textColor = AppColors.greenColorRGB
        self.cancelBtn.titleLabel?.font = AppFont.regularTextFont
        self.feedbackBtn.setTitle(NSLocalizedString("btn_feedback", comment: ""), for: .normal)
        self.feedbackBtn.titleLabel?.textColor = AppColors.whiteColorRGB
        self.feedbackBtn.backgroundColor = AppColors.greenColorRGB
        self.feedbackBtn.titleLabel?.font = AppFont.boldTextFont
        self.feedbackBtn.isHidden = true
        self.trackBtn.isHidden = true
    }
    func tableViewSetup(){
        self.parcelDetailsTableView.dataSource = self
        self.parcelDetailsTableView.delegate = self
        self.parcelDetailsTableView.register(UINib(nibName:"ParcelDetailsCell", bundle: nil), forCellReuseIdentifier: "ParcelDetailsCell")
        self.parcelDetailsTableView.isHidden = true
    }
    
    @IBAction func btnsTapped(_ sender: UIButton){
        let btn = sender as UIButton
        if btn.tag == 10{
            self.dismiss(animated: true, completion: nil)
        }else if btn.tag == 20{
            let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "CustomerFeedBackViewController") as! CustomerFeedBackViewController
            nextViewController.parcel_id = self.parcelId
            self.present(nextViewController, animated:true, completion: nil)
        }else if btn.tag == 30{
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let trackingVC = storyboard.instantiateViewController(withIdentifier: "TrackingParcelViewController") as! TrackingParcelViewController
            trackingVC.parcelId = self.parcelId
            trackingVC.parcelStatusStr = self.parcelStatusStr
            trackingVC.riderId_api = self.riderId
            self.present(trackingVC, animated: true, completion: nil)
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int{
        return 4
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        switch (section) {
        case 0:
            return parcelPlaceHolderArray.count
        case 1:
            return pickupDetailsArray.count
        case 2:
            return receiverDetailsArray.count
        case 3:
            return parcelsizesPHArray.count
        default:
            return 0
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ParcelDetailsCell") as! ParcelDetailsCell
        cell.topBordeLbl.isHidden = true
        cell.nameLblLC.constant = 15
        switch (indexPath.section) {
        case 0:
            cell.nameLbl.textColor = AppColors.blackColorRGB
            cell.apitextLbl.textColor = AppColors.blackColorRGB
            cell.nameLbl.font = AppFont.regularTextFont
            cell.nameLbl.textColor = AppColors.blackColorRGB
            cell.apitextLbl.font = AppFont.regularTextFont
            cell.bottomBorderLblLC.constant = 15
            if indexPath.row == 0{
                cell.apitextLbl.font = AppFont.boldMediumTextFont
            }
            if indexPath.row == 5{
                cell.apitextLbl.font = AppFont.boldMediumTextFont
                cell.apitextLbl.textColor = AppColors.greenColorRGB
            }
            cell.apitextLbl.isHidden = false
            cell.apitextLbl.text = self.parcelApiArray[indexPath.row] as? String
            cell.nameLbl.text = self.parcelPlaceHolderArray[indexPath.row] as? String
            
        case 1:
            cell.contentView.addConstraint(NSLayoutConstraint(item: cell.apitextLbl, attribute: .trailing, relatedBy: .equal, toItem: cell.nameLbl, attribute: .trailing, multiplier: 1, constant: 0))
            cell.nameLblLC.constant = 40
            cell.nameLbl.text = self.pickupDetailsArray[indexPath.row] as? String
            cell.nameLbl.numberOfLines = 1
            cell.nameLbl.font = AppFont.regularTextFont
            cell.nameLbl.textColor = AppColors.blackColorRGB
            cell.bottomBorderLblLC.constant = 40
            if indexPath.row == 0{
                cell.nameLbl.font = AppFont.boldTextFont1
                cell.topBordeLbl.isHidden = false
            }else if indexPath.row == 1{
                cell.nameLbl.numberOfLines = 0
                cell.nameLbl.lineBreakMode = .byWordWrapping
            }else if indexPath.row == 2{
                cell.nameLbl.textColor = AppColors.greenColorRGB
            }
            cell.apitextLbl.isHidden = true
            
        case 2:
            
            cell.contentView.addConstraint(NSLayoutConstraint(item: cell.apitextLbl, attribute: .trailing, relatedBy: .equal, toItem: cell.nameLbl, attribute: .trailing, multiplier: 1, constant: 0))
            cell.nameLbl.font = AppFont.regularTextFont
            cell.nameLbl.textColor = AppColors.blackColorRGB
            cell.nameLblLC.constant = 40
            cell.nameLbl.text = self.receiverDetailsArray[indexPath.row] as? String
            cell.nameLbl.numberOfLines = 1
            cell.bottomBorderLblLC.constant = 40
            
            if indexPath.row == 0{
                cell.nameLbl.font = AppFont.boldTextFont1
                cell.topBordeLbl.isHidden = false
            }else if indexPath.row == 1{
                cell.nameLbl.numberOfLines = 0
                cell.nameLbl.lineBreakMode = .byWordWrapping
            }else if indexPath.row == 2{
                cell.nameLbl.textColor = AppColors.greenColorRGB
            }
            cell.apitextLbl.isHidden = true
            
        case 3:
            if indexPath.row == 0{
                cell.topBordeLbl.isHidden = false
            }
            cell.bottomBorderLblLC.constant = 40
            cell.nameLbl.font = AppFont.regularTextFont
            cell.apitextLbl.font = AppFont.regularTextFont
            cell.nameLblLC.constant = 40
            cell.apitextLbl.isHidden = false
            cell.apitextLbl.text = self.parcelsizesAPIArray[indexPath.row] as? String
            cell.nameLbl.text = self.parcelsizesPHArray[indexPath.row] as? String
            cell.nameLbl.textColor = AppColors.blackColorRGB
            cell.apitextLbl.textColor = AppColors.blackColorRGB
            
        default:
            print("cell")
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 1{
            if indexPath.row == 1{
                return UITableViewAutomaticDimension
            }
        }
        if indexPath.section == 2{
            if indexPath.row == 1{
                return UITableViewAutomaticDimension
            }
        }
        return 50
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView()
        headerView.frame = CGRect(x: 0, y: 0, width: self.parcelDetailsTableView.frame.size.width, height: 70)
        let title = UILabel()
        title.frame = CGRect(x: 15, y: 0, width: self.parcelDetailsTableView.frame.size.width-30, height: 70)
        title.font = AppFont.boldTextFont1
        if section == 0{
            title.text = ""
        }else if  section == 1{
            title.text = NSLocalizedString("lbl_pickupdetails", comment: "") //"Pickup Details"
        }else if  section == 2{
            title.text =  NSLocalizedString("lbl_receiverpdetails", comment: "")
        }else if  section == 3{
            title.text =  NSLocalizedString("lbl_parceldetails", comment: "")
        }
        
        headerView.addSubview(title)
        headerView.backgroundColor = UIColor.whiteColorCode
        return headerView
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0{
            return 0
        }
        return 70
    }
    
    func removeAndAddConstraints(){
        self.view.removeConstraint(self.trackBtnEWC)
        self.view.removeConstraint(self.feedbackBtnEWC)
        self.view.addConstraint(NSLayoutConstraint(item: self.trackBtn, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 0))
        self.view.addConstraint(NSLayoutConstraint(item: self.trackBtn, attribute: .trailing, relatedBy: .equal, toItem: self.feedbackBtn, attribute: .trailing, multiplier: 1, constant: 0))
    }
    func getParcelDetailsApi(parcelId : String){
        if self.ineternetAlert() == false{
            self.statusLbl.isHidden = false
            self.statusLbl.text = NSLocalizedString("ver_internetavailable_error", comment: "")
            return
        }else{
            IJProgressView.shared.showProgressView(view)
            var bodyReq = [String:String]()
            bodyReq = ["parcel_id":parcelId]
            if let bodyData = try? JSONSerialization.data(withJSONObject: bodyReq, options:[]){
                var token = ""
                if UserDefaults.standard.value(forKey: "usertoken") != nil{
                    token = UserDefaults.standard.value(forKey: "usertoken") as! String
                }
                let sessionStr = "Bearer " + token
                APICommnicationManager.sharedInstance.requestforAPI(service:"/Parcel/getCustomerParceldetails" , method: "POST", token: sessionStr, body: "", productBody: bodyData as NSData) { (result, error) in
                    if let Result = result as? [String:Any]{
                        print("Parcel/getParceldetails :: ",Result)
                        if let status = Result["status"] as? Bool {
                            if status == true{
                                DispatchQueue.main.async(execute: { () -> Void in
                                    IJProgressView.shared.hideProgressView()
                                    if let resultDic = Result["Msg"] as? [String:Any]{
                                        //   print(resultDic)
                                        if let time = resultDic["time"] as? String{
                                            //  print(time)
                                            var time1 = 0
                                            var time2 : Double = 0
                                            var time11 = ""
                                            var seconds1 = 0
                                            var seconds11 = ""
                                            let contactnumber = time.split{$0 == " "}.map(String.init)
                                            if contactnumber.count == 2{
                                                time11 = contactnumber[0]
                                                time1 = Int(time11)!
                                                time2 = Double(time11)!
                                            }
                                            if let seconds = resultDic["timeSe"] as? Int{
                                                seconds1 = seconds
                                            }
                                            let startDate : Date = Date()
                                            let calendar = Calendar.current
                                            var date = calendar.date(byAdding: .minute, value: time1, to: startDate)
                                            date = calendar.date(byAdding: .second, value: seconds1, to: date!)
                                            self.timeStr = "\((calendar.component(.hour, from: date!))):\((calendar.component(.minute, from: date!))):\((calendar.component(.second, from: date!)))"
                                        }
                                        if let rowsarray = resultDic["rows"] as? [Any]{
                                            let responseDic = rowsarray[0] as! NSDictionary
                                            var Status = 0
                                            var rider_firstname = ""
                                            var rider_lastname = ""
                                            var parcel_Status = ""
                                            var r_receiverName = ""
                                            var r_add_houseno = ""
                                            var r_add_street1 = ""
                                            var r_add_street2 = ""
                                            var r_add_street3 = ""
                                            var r_add_city = ""
                                            var r_add_state = ""
                                            var r_add_country = ""
                                            var r_add_zipcode = ""
                                            var r_mobilenumber = ""
                                            var r_receiveraddress = ""
                                            
                                            var p_Name = ""
                                            var p_add_houseno = ""
                                            var p_add_street1 = ""
                                            var p_add_street2 = ""
                                            var p_add_street3 = ""
                                            var p_add_city = ""
                                            var p_add_state = ""
                                            var p_add_country = ""
                                            var p_add_zipcode = ""
                                            var p_mobilenumber = ""
                                            var p_pickupaddress = ""
                                            
                                            var parcelPickupTime = ""
                                            var parcelDeliveryTime = ""
                                            var bookingtime = ""
                                            var  delimode = 0
                                            var deliveryMode = ""
                                            var rider_id = 0
                                            var datestr = ""
                                            
                                            var parcel_id = ""
                                            
                                            if let firstnameStr = responseDic["firstname"] as? String{
                                                rider_firstname = firstnameStr
                                            }
                                            
                                            if let lastnameStr = responseDic["lastname"] as? String{
                                                rider_lastname = lastnameStr
                                            }
                                            
                                            if let id = responseDic["parcel_id"] as? String{
                                                parcel_id = id
                                                self.parcelId = parcelId
                                            }
                                            
                                            if let  time = responseDic["created_datetime"] as? String{
                                                bookingtime = time
                                                datestr = self.dataFormat(date: bookingtime)
                                                //print("date",datestr)
                                            }
                                            if let deliverymode = responseDic["parcel_fk_delivery_option_id"] as? Int{
                                                
                                                delimode = deliverymode
                                            }
                                            if delimode == 1
                                            {
                                                deliveryMode = "Express"
                                            }
                                            if delimode == 2
                                            {
                                                deliveryMode = "Normal"
                                            }
                                            
                                            if let riderid =  responseDic["rider_id"] as? Int{
                                                rider_id = riderid
                                                self.riderId = String(rider_id)
                                            }
                                            
                                            let parcelPickupTimeStr = Constants.checkForNull(value: responseDic["parcelPickup_time"] as AnyObject)
                                            
                                            if parcelPickupTimeStr  == ""
                                            {
                                                parcelPickupTime = "0"
                                            }
                                            else
                                            {
                                                parcelPickupTime = parcelPickupTimeStr
                                                parcelPickupTime = self.dataFormat(date: parcelPickupTime)
                                            }
                                            
                                            let parcelDeliveryTimeStr = Constants.checkForNull(value: responseDic["parcelDelivery_time"] as AnyObject)
                                            
                                            if parcelDeliveryTimeStr  == ""
                                            {
                                                parcelDeliveryTime = "0"
                                            }
                                            else
                                            {
                                                parcelDeliveryTime = parcelDeliveryTimeStr
                                                parcelDeliveryTime = self.dataFormat(date: parcelDeliveryTime)
                                            }
                                            
                                            self.parcelPlaceHolderArray = [NSLocalizedString("lbl_parcelid", comment: ""),NSLocalizedString("lbl_timeofbooking", comment: ""),NSLocalizedString("lbl_modeofdelivery", comment: ""),NSLocalizedString("lbl_estpickuptime", comment: ""),NSLocalizedString("lbl_estdeliverytime", comment: ""),NSLocalizedString("lbl_parcelstatus", comment: "")]
                                            
                                            if let parcelstatus =  responseDic["parcel_fk_status"] as? Int{
                                                Status = parcelstatus
                                            }
                                            self.feedbackBtn.isHidden = false
                                            if Status  == 1{
                                                self.trackBtn.isHidden = false
                                                self.parcelPlaceHolderArray.replaceObject(at: 3, with: NSLocalizedString("lbl_pickeduptime", comment: ""))
                                                self.parcelPlaceHolderArray.replaceObject(at: 4, with: NSLocalizedString("lbl_estdeliverytime", comment: ""))
                                                parcel_Status = "Picked Up"
                                            }
                                            else if Status  == 2
                                            {
                                                self.trackBtn.isHidden = false
                                                parcel_Status = "Out for Delivery"
                                                self.parcelPlaceHolderArray.replaceObject(at: 3, with: NSLocalizedString("lbl_pickeduptime", comment: ""))
                                                self.parcelPlaceHolderArray.replaceObject(at: 4, with: NSLocalizedString("lbl_estdeliverytime", comment: ""))
                                                parcel_Status = NSLocalizedString("lbl_outfordelivery", comment: "")
                                                
                                            }
                                            else if Status  == 8
                                            {
                                                self.trackBtn.isHidden = false
                                                self.parcelPlaceHolderArray.replaceObject(at: 3, with: NSLocalizedString("lbl_estpickuptime", comment: ""))
                                                self.parcelPlaceHolderArray.replaceObject(at: 4, with: NSLocalizedString("lbl_estdeliverytime", comment: ""))
                                                self.parcelPlaceHolderArray.removeObject(at: 4)
                                                
                                                parcel_Status = "Waiting for pickup"
                                                parcel_Status = NSLocalizedString("lbl_waitingforpickup", comment: "")
                                                
                                            }
                                            else if Status  == 11
                                            {
                                                self.parcelPlaceHolderArray.replaceObject(at: 3, with: NSLocalizedString("lbl_pickeduptime", comment: ""))
                                                self.parcelPlaceHolderArray.replaceObject(at: 4, with: NSLocalizedString("lbl_deliverytime", comment: ""))
                                                
                                                parcel_Status = "Delivered"
                                                parcel_Status = NSLocalizedString("lbl_parceldelivered", comment: "")
                                                
                                                self.removeAndAddConstraints()
                                            }
                                            else if Status  == 12
                                            {
                                                self.parcelPlaceHolderArray.replaceObject(at: 3, with: NSLocalizedString("lbl_pickeduptime", comment: ""))
                                                self.parcelPlaceHolderArray.replaceObject(at: 4, with: NSLocalizedString("lbl_estdeliverytime", comment: ""))
                                                parcel_Status = "Not Delivered"
                                                
                                                parcel_Status = NSLocalizedString("lbl_notdelivered", comment: "")
                                                
                                                self.removeAndAddConstraints()
                                                
                                            }
                                            else if Status  == 14
                                            {
                                                self.parcelPlaceHolderArray.replaceObject(at: 3, with: NSLocalizedString("lbl_estpickuptime", comment: ""))
                                                self.parcelPlaceHolderArray.replaceObject(at: 4, with: NSLocalizedString("lbl_estdeliverytime", comment: ""))
                                                parcel_Status = "Not Picked up"
                                                parcel_Status = NSLocalizedString("lbl_notpickedup", comment: "")
                                                
                                                self.removeAndAddConstraints()
                                            }
                                            
                                            self.parcelStatusStr = parcel_Status
                                            
                                            if rider_id != 0
                                            {
                                                self.parcelPlaceHolderArray.add(NSLocalizedString("lbl_riderassigned", comment: ""))
                                            }
                                            
                                            let riderfullname = rider_firstname + " " + rider_lastname
                                            self.parcelApiArray.add(parcel_id)
                                            self.parcelApiArray.add(datestr)
                                            self.parcelApiArray.add(deliveryMode)
                                            
                                            if Status  == 8
                                            {
                                                self.parcelApiArray.add(self.timeStr)
                                            }
                                            else if Status  == 2
                                            {
                                                self.parcelApiArray.add(parcelPickupTime)
                                                self.parcelApiArray.add(self.timeStr)
                                            }
                                            else if Status  == 11
                                            {
                                                self.parcelApiArray.add(parcelPickupTime)
                                                self.parcelApiArray.add(parcelDeliveryTime)
                                            }
                                            else
                                            {
                                                self.parcelApiArray.add(parcelPickupTime)
                                                self.parcelApiArray.add(parcelDeliveryTime)
                                            }
                                            self.parcelApiArray.add(parcel_Status)
                                            if rider_id != 0
                                            {
                                                self.parcelApiArray.add(riderfullname)
                                            }
                                            
                                            
                                            if let pickupnameStr = responseDic["pickup_fullname"] as? String{
                                                p_Name = pickupnameStr
                                            }
                                            if let pickupmobileStr = responseDic["pickup_mobile_no"] as? String
                                            {
                                                p_mobilenumber = pickupmobileStr
                                            }
                                            if let houseno = responseDic["pickup_house_no"] as? String{
                                                p_add_houseno = houseno
                                            }
                                            if let street1 = responseDic["pickup_street1"] as? String{
                                                p_add_street1 = street1
                                            }
                                            if let city = responseDic["pickup_city"] as? String{
                                                p_add_city = city
                                            }
                                            let pickupstr2 = Constants.checkForNull(value: responseDic["pickup_street2"] as AnyObject)
                                            if pickupstr2  == ""
                                            {
                                                p_add_street2 = ""
                                            }
                                            else
                                            {
                                                p_add_street2 = pickupstr2
                                            }
                                            let pickupstr3 = Constants.checkForNull(value: responseDic["pickup_street3"] as AnyObject)
                                            if pickupstr3  == ""
                                            {
                                                p_add_street3 = ""
                                            }
                                            else
                                            {
                                                p_add_street3 = pickupstr3
                                            }
                                            
                                            if let state = responseDic["pickup_state"] as? String{
                                                p_add_state = state
                                            }
                                            if let country = responseDic["pickup_country"] as?  String
                                            {
                                                p_add_country = country
                                                
                                            }
                                            if let zipcode = responseDic["pickup_zip_code"] as? String
                                            {
                                                p_add_zipcode = zipcode
                                                
                                            }
                                            
                                            if p_add_street2.count > 0 {
                                                p_pickupaddress = p_add_houseno  + "," + " " + p_add_street1 + "," + " " + p_add_street2  + "," + " " + p_add_city  + "," + " " + p_add_state  + "," + " " + p_add_country + ", " + " " + p_add_zipcode
                                            }
                                            if  p_add_street2.count > 0 && p_add_street3.count > 0{
                                                p_pickupaddress = p_add_houseno  + "," + " " + p_add_street1 + "," + " " + p_add_street2  + "," + " " + p_add_street3 + "," + " " + p_add_city  + "," + " " + p_add_state  + ","  + " " + p_add_country + "," + " " + p_add_zipcode
                                            }
                                            
                                            if p_add_street2.count == 0 && p_add_street3.count == 0{
                                                
                                                p_pickupaddress = p_add_houseno  + "," + " " + p_add_street1 + "," + " " + p_add_city  + "," + " " + p_add_state  + ","  + " " + p_add_country + ", " + " " + p_add_zipcode
                                            }
                                            
                                            if p_add_street2.count == 0
                                            {
                                                p_pickupaddress = p_add_houseno  + "," + " " + p_add_street1 + "," + " " + p_add_city  + "," + " " + p_add_state  + "," + " " + p_add_country + ", " + " " + p_add_zipcode
                                            }
                                            //print("address ::::: ",p_pickupaddress)
                                            
                                            self.pickupDetailsArray.add(p_Name)
                                            self.pickupDetailsArray.add(p_pickupaddress)
                                            self.pickupDetailsArray.add(p_mobilenumber)
                                            
                                            if let receiverStr = responseDic["reciver_fullname"] as? String{
                                                r_receiverName = receiverStr
                                            }
                                            if let receivermobileStr = responseDic["reciver_mobile_no"] as? String{
                                                r_mobilenumber = receivermobileStr
                                            }
                                            if let houseno = responseDic["house_no"] as? String{
                                                r_add_houseno = houseno
                                            }
                                            if let street1 = responseDic["street1"] as? String{
                                                r_add_street1 = street1
                                            }
                                            if let city = responseDic["city"] as? String{
                                                r_add_city = city
                                            }
                                            let receiverStreet2 = Constants.checkForNull(value: responseDic["street2"] as AnyObject)
                                            
                                            if receiverStreet2  == ""
                                            {
                                                r_add_street2 = ""
                                            }
                                            else
                                            {
                                                r_add_street2 = receiverStreet2
                                            }
                                            let receiverStreet3 = Constants.checkForNull(value: responseDic["street3"] as AnyObject)
                                            if receiverStreet3  == ""
                                            {
                                                r_add_street3 = ""
                                            }
                                            else
                                            {
                                                r_add_street3 = receiverStreet3
                                            }
                                            
                                            if let state = responseDic["state"] as? String{
                                                r_add_state = state
                                            }
                                            if let country = responseDic["country"] as?  String
                                            {
                                                r_add_country = country
                                            }
                                            if let zipcode = responseDic["zip_code"] as? String
                                            {
                                                r_add_zipcode = zipcode
                                            }
                                            
                                            if r_add_street2.count > 0 {
                                                r_receiveraddress = r_add_houseno  + "," + " " + r_add_street1 + "," + " " + r_add_street2  + "," + " " + r_add_city  + "," + " " + r_add_state  + "," + " " + r_add_country + ", " + " " + r_add_zipcode
                                            }
                                            if  r_add_street2.count > 0 && r_add_street3.count > 0{
                                                r_receiveraddress = r_add_houseno  + "," + " " + r_add_street1 + "," + " " + r_add_street2  + "," + " " + r_add_street3 + "," + " " + r_add_city  + "," + " " + r_add_state  + ","  + " " + r_add_country + "," + " " + r_add_zipcode
                                            }
                                            
                                            if r_add_street2.count == 0 && r_add_street3.count == 0{
                                                r_receiveraddress = r_add_houseno  + "," + " " + r_add_street1 + "," + " " + r_add_city  + "," + " " + r_add_state  + ","  + " " + r_add_country + ", " + " " + r_add_zipcode
                                            }
                                            
                                            if r_add_street2.count == 0 {
                                                r_receiveraddress = r_add_houseno  + "," + " " + r_add_street1 + "," + " " + r_add_city  + "," + " " + r_add_state  + "," + " " + r_add_country + ", " + " " + r_add_zipcode
                                            }
                                            //   print("address ::::: ",r_receiveraddress)
                                            self.receiverDetailsArray.add(r_receiverName)
                                            self.receiverDetailsArray.add(r_receiveraddress)
                                            self.receiverDetailsArray.add(r_mobilenumber)
                                            
                                            if let length = responseDic["length"] as? String
                                            {
                                                self.parcelsizesAPIArray.add(length)
                                            }
                                            if let length = responseDic["length"] as? String
                                            {
                                                self.parcelsizesAPIArray.add(length)
                                            }
                                            if let width = responseDic["width"] as? String
                                            {
                                                self.parcelsizesAPIArray.add(width)
                                            }
                                            if let heigth = responseDic["heigth"] as? String
                                            {
                                                self.parcelsizesAPIArray.add(heigth)
                                            }
                                            if let weight = responseDic["weight"] as? String
                                            {
                                                self.parcelsizesAPIArray.add(weight)
                                            }
                                            // }
                                            self.parcelsizesPHArray = [NSLocalizedString("lbl_lenght", comment: ""),NSLocalizedString("lbl_width", comment: ""),NSLocalizedString("lbl_height", comment: ""),NSLocalizedString("lbl_weight", comment: "")]
                                            self.parcelDetailsTableView.isHidden = false
                                            self.parcelDetailsTableView.reloadData()
                                        }
                                    }
                                    //}
                                    
                                })
                            }
                            if status == false{
                                
                                DispatchQueue.main.async(execute: { () -> Void in
                                    IJProgressView.shared.hideProgressView()
                                    self.statusLbl.isHidden = false
                                    self.statusLbl.text = NSLocalizedString("ver_noparcelfound", comment: "")
                                    self.displayAlert(message: NSLocalizedString("ver_noparcelfound", comment: ""))
                                })
                            }
                        }
                        else
                        {
                            if Result["code"] as? String == "InvalidCredentials"
                            {
                                DispatchQueue.main.async(execute: { () -> Void in
                                    IJProgressView.shared.hideProgressView()
                                    self.tokenExpireAlert()
                                })
                            }
                        }
                    }
                    else
                    {
                        DispatchQueue.main.async(execute: { () -> Void in
                            IJProgressView.shared.hideProgressView()
                            self.statusLbl.isHidden = false
                            self.statusLbl.text = NSLocalizedString("error_parcelerror", comment: "")
                            self.displayAlert(message: NSLocalizedString("error_parcelerror", comment: ""))
                        })
                    }
                }
            }
        }
        
    }
    func displayAlert(message: String)
    {
        self.showAlertMessage(vc: self, titleStr: NSLocalizedString("Rytle", comment: ""), messageStr:message)
    }
    func dataFormat(date : String) -> String
    {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        let date = formatter.date(from: date)
        let formatter1 = DateFormatter()
        formatter1.dateFormat = "HH:mm dd/MM/yyyy"
        return formatter1.string(from:date!)
    }
}

